//  emitter 发射监听的key
export const EventTypes = Object.freeze({
  //  打开项目列表dialog
  OPEN_PROJECT_LIST_DIALOG: 'openProjectListDialog',
})

export default EventTypes
