export const MENU_TYPE = {
  PAGE: 'page',
  DIALOG: 'dialog',
  EVENT: 'event',
  EXTEND: 'extend',
}
