import { service } from '@/services/http'

export default class SystemService {
  static async uploadFile(file) {
    return service.postFormDataFile('/system/file/uploadFile', { file })
  }
}
