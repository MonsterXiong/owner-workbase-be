import { service } from '@/services/http'

export default class BusinessService {
  // 查询任务、任务线程 树(根据项目ID)
  static async queryTaskTaskThreadByProjectId(projectId) {
    return service.postQuery('/business/relQuery/queryTaskTaskThreadByProjectId', { projectId })
  }
}
