import { service } from '@/services/http'
/**
 * 关于作战任务的基础服务
 */
export default class XydTaskService {
  /**
   * @description 删除作战任务
   * @param {String} key 作战任务Id
   * @returns
   */
  static async deleteXydTask(taskId) {
    return service.postQuery('/base/api/xydTask/deleteXydTask', { key: taskId })
  }
  /**
   * @description 删除作战任务(批量、递归)
   * @param {Array} taskIdList 作战任务Id数组
   * @returns
   */
  static async deleteXydTaskBatch(taskIdList) {
    if (!Array.isArray(taskIdList)) {
      taskIdList = [taskIdList]
    }
    return service.post('/base/api/xydTask/deleteXydTaskBatch', taskIdList)
  }
  /**
   * @description 作战任务导入模板下载
   * @returns
   */
  static async downloadXydTaskTemplate() {
    return service.postFormData('/base/api/xydTask/downloadXydTaskTemplate', {})
  }

  /**
   * @description 导出作战任务
   * @param {Object} queryCondition 查询条件
   * @returns
   */
  static async exportXydTask(queryCondition) {
    return service.post('/base/api/xydTask/exportXydTask', queryCondition, {
      responseType: 'blob',
    })
  }
  /**
   * @description 导入作战任务
   * @param {File} 文件对象
   * @returns
   */
  static async importXydTask(file) {
    return service.postForm('/base/api/xydTask/importXydTask', { file })
  }
  /**
   * @description 增加作战任务
   * @param {Object} xydTask  作战任务对象
   * @returns
   */
  static async insertXydTask(xydTask) {
    return service.post('/base/api/xydTask/insertXydTask', xydTask)
  }

  /**
   * @description 增加作战任务(批量)
   * @param {Array} xydTaskList  作战任务对象数组
   * @returns
   */
  static async insertXydTaskBatch(xydTaskList) {
    return service.post('/base/api/xydTask/insertXydTaskBatch', xydTaskList)
  }

  /**
   * @description 查询作战任务列表结果
   * @param {Object} queryCondition 查询对象
   * @returns
   */
  static async queryXydTaskByCondition(queryCondition) {
    return service.post('/base/api/xydTask/queryXydTaskByCondition', queryCondition || {})
  }
  /**
   * @description 获取作战任务
   * @param {String} taskId  作战任务ID
   * @returns
   */
  static async queryXydTask(taskId) {
    return service.postQuery('/base/api/xydTask/queryXydTaskByKey', { taskId })
  }
  /**
   * @description 保存作战任务
   * @param {Object} xydTask  作战任务对象
   * @returns
   */
  static async saveXydTask(xydTask) {
    return service.post('/base/api/xydTask/saveXydTask', xydTask)
  }

  /**
   * @description 保存作战任务
   * @param {Object} xydTask  作战任务对象
   * @returns
   */
  static async saveXydTaskForm(xydTask) {
    return service.post('/base/api/xydTask/saveXydTaskForm', xydTask)
  }

  /**
   * @description 保存作战任务(批量)
   * @param {Array} xydTaskList  作战任务对象数组
   * @returns
   */
  static async saveXydTaskBatch(xydTaskList) {
    return service.post('/base/api/xydTask/saveXydTaskBatch', xydTaskList)
  }

  /**
   * @description 修改作战任务
   * @param {Object} xydTask  作战任务对象
   * @returns
   */
  static async updateXydTask(xydTask) {
    return service.post('/base/api/xydTask/updateXydTask', xydTask)
  }

  /**
   * @description 批量修改作战任务
   * @param {Array} xydTaskList  作战任务对象数组
   * @returns
   */
  static async updateXydTaskBatch(xydTaskList) {
    return service.post('/base/api/xydTask/updateXydTaskBatch', xydTaskList)
  }
}
