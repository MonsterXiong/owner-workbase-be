import { service } from '@/services/http'
/**
 * 关于项目的基础服务
 */
export default class XydProjectService {
  /**
  * @description 删除项目
  * @param {String} key 项目Id
  * @returns
  */
  static async deleteXydProject(projectId) {
    return service.postQuery('/base/api/xydProject/deleteXydProject', { key :projectId })
  }
  /**
  * @description 删除项目(批量、递归)
  * @param {Array} projectIdList 项目Id数组
  * @returns
  */
  static async deleteXydProjectBatch(projectIdList) {
    if (!Array.isArray(projectIdList)) {
      projectIdList = [projectIdList]
    }
    return service.post('/base/api/xydProject/deleteXydProjectBatch', projectIdList)
  }
  /**
  * @description 项目导入模板下载
  * @returns
  */
  static async downloadXydProjectTemplate() {
    return service.postFormData('/base/api/xydProject/downloadXydProjectTemplate', {})
  }

  /**
    * @description 导出项目
    * @param {Object} queryCondition 查询条件
    * @returns
    */
  static async exportXydProject(queryCondition) {
    return service.post('/base/api/xydProject/exportXydProject', queryCondition, {
      responseType: 'blob',
    })
  }
  /**
   * @description 导入项目
   * @param {File} 文件对象
   * @returns
   */
  static async importXydProject(file) {
    return service.postForm('/base/api/xydProject/importXydProject', { file })
  }
  /**
   * @description 增加项目
   * @param {Object} xydProject  项目对象
   * @returns
   */
  static async insertXydProject(xydProject) {
    return service.post('/base/api/xydProject/insertXydProject', xydProject)
  }

  /**
   * @description 增加项目(批量)
   * @param {Array} xydProjectList  项目对象数组
   * @returns
   */
  static async insertXydProjectBatch(xydProjectList) {
    return service.post('/base/api/xydProject/insertXydProjectBatch', xydProjectList)
  }

  /**
    * @description 查询项目列表结果
    * @param {Object} queryCondition 查询对象
    * @returns
    */
  static async queryXydProjectByCondition(queryCondition) {
    return service.post('/base/api/xydProject/queryXydProjectByCondition', queryCondition || {})
  }
  /**
    * @description 获取项目
    * @param {String} projectId  项目ID
    * @returns
    */
  static async queryXydProject(projectId) {
    return service.postQuery('/base/api/xydProject/queryXydProjectByKey', { projectId })
  }
  /**
    * @description 保存项目
    * @param {Object} xydProject  项目对象
    * @returns
    */
  static async saveXydProject(xydProject) {
    return service.post('/base/api/xydProject/saveXydProject', xydProject)
  }

  /**
   * @description 保存项目(批量)
   * @param {Array} xydProjectList  项目对象数组
   * @returns
   */
  static async saveXydProjectBatch(xydProjectList) {
    return service.post('/base/api/xydProject/saveXydProjectBatch', xydProjectList)
  }

  /**
    * @description 修改项目
    * @param {Object} xydProject  项目对象
    * @returns
    */
  static async updateXydProject(xydProject) {
    return service.post('/base/api/xydProject/updateXydProject', xydProject)
  }

  /**
    * @description 批量修改项目
    * @param {Array} xydProjectList  项目对象数组
    * @returns
    */
  static async updateXydProjectBatch(xydProjectList) {
    return service.post('/base/api/xydProject/updateXydProjectBatch', xydProjectList)
  }
}
