import { service } from '@/services/http'
/**
 * 关于体系能力的基础服务
 */
export default class XydTixiAbiService {
  /**
   * @description 删除体系能力
   * @param {String} key 体系能力Id
   * @returns
   */
  static async deleteXydTixiAbi(tixiAbiId) {
    return service.postQuery('/base/api/xydTixiAbi/deleteXydTixiAbi', { key: tixiAbiId })
  }
  /**
   * @description 删除体系能力(批量、递归)
   * @param {Array} tixiAbiIdList 体系能力Id数组
   * @returns
   */
  static async deleteXydTixiAbiBatch(tixiAbiIdList) {
    if (!Array.isArray(tixiAbiIdList)) {
      tixiAbiIdList = [tixiAbiIdList]
    }
    return service.post('/base/api/xydTixiAbi/deleteXydTixiAbiBatch', tixiAbiIdList)
  }
  /**
   * @description 体系能力导入模板下载
   * @returns
   */
  static async downloadXydTixiAbiTemplate() {
    return service.postFormData('/base/api/xydTixiAbi/downloadXydTixiAbiTemplate', {})
  }

  /**
   * @description 导出体系能力
   * @param {Object} queryCondition 查询条件
   * @returns
   */
  static async exportXydTixiAbi(queryCondition) {
    return service.post('/base/api/xydTixiAbi/exportXydTixiAbi', queryCondition, {
      responseType: 'blob',
    })
  }
  /**
   * @description 导入体系能力
   * @param {File} 文件对象
   * @returns
   */
  static async importXydTixiAbi(file) {
    return service.postForm('/base/api/xydTixiAbi/importXydTixiAbi', { file })
  }
  /**
   * @description 增加体系能力
   * @param {Object} xydTixiAbi  体系能力对象
   * @returns
   */
  static async insertXydTixiAbi(xydTixiAbi) {
    return service.post('/base/api/xydTixiAbi/insertXydTixiAbi', xydTixiAbi)
  }

  /**
   * @description 增加体系能力(批量)
   * @param {Array} xydTixiAbiList  体系能力对象数组
   * @returns
   */
  static async insertXydTixiAbiBatch(xydTixiAbiList) {
    return service.post('/base/api/xydTixiAbi/insertXydTixiAbiBatch', xydTixiAbiList)
  }

  /**
   * @description 查询体系能力列表结果
   * @param {Object} queryCondition 查询对象
   * @returns
   */
  static async queryXydTixiAbiByCondition(queryCondition) {
    return service.post('/base/api/xydTixiAbi/queryXydTixiAbiByCondition', queryCondition || {})
  }
  /**
   * @description 获取体系能力
   * @param {String} tixiAbiId  体系能力ID
   * @returns
   */
  static async queryXydTixiAbi(tixiAbiId) {
    return service.postQuery('/base/api/xydTixiAbi/queryXydTixiAbiByKey', { tixiAbiId })
  }
  /**
   * @description 保存体系能力
   * @param {Object} xydTixiAbi  体系能力对象
   * @returns
   */
  static async saveXydTixiAbi(xydTixiAbi) {
    return service.post('/base/api/xydTixiAbi/saveXydTixiAbi', xydTixiAbi)
  }

  /**
   * @description 保存体系能力(批量)
   * @param {Array} xydTixiAbiList  体系能力对象数组
   * @returns
   */
  static async saveXydTixiAbiBatch(xydTixiAbiList) {
    return service.post('/base/api/xydTixiAbi/saveXydTixiAbiBatch', xydTixiAbiList)
  }

  /**
   * @description 修改体系能力
   * @param {Object} xydTixiAbi  体系能力对象
   * @returns
   */
  static async updateXydTixiAbi(xydTixiAbi) {
    return service.post('/base/api/xydTixiAbi/updateXydTixiAbi', xydTixiAbi)
  }

  /**
   * @description 批量修改体系能力
   * @param {Array} xydTixiAbiList  体系能力对象数组
   * @returns
   */
  static async updateXydTixiAbiBatch(xydTixiAbiList) {
    return service.post('/base/api/xydTixiAbi/updateXydTixiAbiBatch', xydTixiAbiList)
  }

  /**
   * @description 导入绘图xml数据
   * @param {File} 文件对象
   * @param {bindProject} 项目id
   * @returns
   */
  static async importXml(file, bindProject) {
    return service.postFormDataFile(`/base/api/xydTixiAbiRel/importXml?bindProject=${bindProject}`, { file })
  }
}
