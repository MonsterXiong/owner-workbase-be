<template>
  <section class="layout">
    <main class="layout-page">
      <router-view style="height: 100%" />
    </main>
    <ModalAll />
  </section>
</template>

<script>
import ModalAll from '@/views/modalAll/index.vue'
import 'splitpanes/dist/splitpanes.css'
import { linkTemplate, nodeVerticalTemplate, taskNodeTemp, typeColorConfig } from './diagramTemplate/Template'

export default {
  name: 'Layout',
  provide() {
    return {
      nodeTemp: nodeVerticalTemplate,
      linkTemp: linkTemplate,
      taskNodeTemp: taskNodeTemp,
      colorConfig: typeColorConfig,
      strokeColor: '#37d0f9',
      activityColor: ['#ec808d', '#f59a23', '#bfbf00', '#00bfbf', '#02a7f0', '#8400ff'],
      echartTextColor: '#fff',
    }
  },
  methods: {},
  components: {
    ModalAll,
  },
}
</script>

<style lang="less" scoped>
// @header-height: 90px;
@header-height: 0px;
@background-color-layout: var(--background-color-layout, #002150);

.layout {
  height: 100%;
  background-color: @background-color-layout;
  background-image: url('~@/assets/image/xydLayout/bg.png');
  .layout-page {
    height: calc(100% - @header-height);
    overflow: auto;
  }
}
@import './style/index.less';
</style>

<style lang="less">
@import './style/elementStyle.less';
@import './style/listStyle.less';
</style>
