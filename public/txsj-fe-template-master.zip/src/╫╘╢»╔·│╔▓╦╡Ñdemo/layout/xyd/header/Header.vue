<template>
  <header class="layout-header" ref="xydHeaderRef">
    <h1 class="header-title" :style="'width:' + titleWidth + 'px'">
      <img src="../../../assets/image/xydLayout/headIcon.png" alt="" />
      <span class="head-text">{{ title }}</span>
    </h1>
    <nav class="nav-menu" :style="'width:' + rightWidth + 'px;left:' + (titleWidth - 50) + 'px'">
      <div class="nav-menu-content">
        <ul class="first-menu">
          <li v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" :class="menu_setActiveClass(menu)" @click="onFirstMenuClick(menu)">
            <span
              :class="['iconfont', menu.icon || 'icon--_dakaixiangmu-copy']"
              :style="{ fontSize: ['icon-suanfamoxing', 'icon-order-fill-copy'].includes(menu.icon) ? '20px' : '16px' }"
            />
            {{ menu.name }}
          </li>
        </ul>
        <system-menus class="header-menus" hideHFIcon></system-menus>
      </div>
      <ul class="second-menu" v-click-outside="onSecondMenuClickOutside" ref="secondMenuRef">
        <li
          v-for="menu in menu_secondTreeData"
          :key="menu[MenuKeyConfig.idKey]"
          :class="menu_setActiveClass(menu)"
          @click.stop="(ev) => onSecondMenuClick(menu, ev)"
        >
          {{ menu.name }}
        </li>
      </ul>
    </nav>
    <TopMenus
      ref="TopMenus"
      class="top-menu-com"
      v-show="childrenList.length > 0"
      :menuList="childrenList"
      :style="{ left: position.x + 'px', top: position.y + 'px' }"
      @onMenuClick="menu_onMenuClick"
    />
  </header>
</template>

<script>
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import TopMenus from '@/layout/components/TopMenus'
import { MenuKeyConfig } from '@/common/constants'
import ElementResizeDetectorMaker from 'element-resize-detector'
import SystemMenus from './components/SystemMenus.vue'
import { getCurrentProjectId } from '@/utils/sysUtils'

export default {
  mixins: [menuMixin],
  components: { TopMenus, SystemMenus },
  data() {
    return {
      title: configData.systemName,
      childrenList: [],
      position: { x: -1, y: -1 },
      titleWidth: '0px',
      rightWidth: '0px',
      MenuKeyConfig,
    }
  },
  computed: {
    currentProjectId() {
      return getCurrentProjectId()
    },
  },
  watch: {
    currentProjectId() {
      this.resetMenu()
    },
  },
  mounted() {
    let erd = ElementResizeDetectorMaker()
    erd.listenTo(this.$refs.xydHeaderRef, (ele) => {
      this.calculateWidth()
    })
    this.mouseWheelChange('secondMenuRef')
    this.resetMenu()
  },
  methods: {
    async resetMenu() {
      this.menu_initMenuData()
    },
    calculateWidth() {
      this.titleWidth = this.title.length * 32 + 72 + 50
      this.rightWidth = this.$refs.xydHeaderRef.offsetWidth - this.titleWidth + 50
    },
    mouseWheelChange(refName) {
      let div = this.$refs[refName]
      div.addEventListener('wheel', (e) => {
        let left = -e.wheelDelta || e.deltaY / 2
        console.log('wheelDelta', -e.wheelDelta, 'deltaY', e.deltaY)
        div.scrollLeft = div.scrollLeft + left
      })
    },
    onFirstMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    // 二级菜单点击事件 如果有旗下的第三级菜单则弹出
    onSecondMenuClick(menu, ev) {
      this.menu_onMenuClick(menu)
      if (menu?.children) this.childrenList = menu.children || []
      else {
        this.childrenList = []
      }
      this.position.x = ev.clientX + 4 - 40
      this.position.y = 90 - 14
    },
    onSecondMenuClickOutside() {
      this.childrenList = []
    },
  },
}
</script>

<style scoped lang="less">
@font-face {
  font-family: 'ALIMAMASHUHEITI-BOLD';
  src: url('~@/assets/font/ALIMAMASHUHEITI-BOLD.TTF') format('truetype');
}

.layout-header {
  display: flex;
  // background-image: url('~@/assets/image/xydLayout/head.png');
  background-repeat: no-repeat;

  background-size: 106% 115%;
  background-position-x: -115px;
  .header-menus {
    z-index: 9;
  }
  .header-title {
    // width: 510px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin: 0;
    background-image: url('~@/assets/image/xydLayout/headL.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding-bottom: 10px;
    clip-path: polygon(0 0%, 100% 0%, calc(100% - 50px) 100%, 0 100%);
    img {
      width: 42px;
      height: 42px;
      margin: 0 15px;
    }
    .head-text {
      font-family: 'ALIMAMASHUHEITI-BOLD';
      font-weight: 700;
      font-size: 32px;
      color: transparent;
      background-image: linear-gradient(to bottom, #e8feff, #99ebff);
      background-clip: text;
    }
  }

  .nav-menu {
    // position: relative;
    height: 100%;
    position: absolute;
    // width: calc((100% - 510px));
    // background-image: url('~@/assets/image/xydLayout/headRight.png');
    // background-repeat: no-repeat;
    // background-size: 100% 100%;
    padding-bottom: 10px;
    clip-path: none;
    overflow: visible;

    &::before {
      content: '';
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      // z-index: -10;
      background-image: url('~@/assets/image/xydLayout/headRight.png');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      background-color: transparent;

      clip-path: polygon(49px 0%, 100% 0%, 100% 100%, -2px 100%);
    }
    .nav-menu-content {
      display: flex;
      .first-menu {
        flex: 1;
        display: flex;
      }
    }
    > ul {
      display: flex;
      overflow-x: auto;
      z-index: 99;
    }
    .first-menu {
      // margin-left: 35px;
      // height: 51px;
      // width: calc(100% - 35px);
      height: 44px;
      margin-left: 28px;
      width: calc(100% - 28px);
      z-index: 99;

      > li {
        margin: 0 20px;
        font-family: '微软雅黑 Bold', '微软雅黑 Regular', '微软雅黑';
        font-weight: 700;
        font-size: 18px;
        line-height: 48px;
        color: #fff;
        cursor: pointer;
        // align-items: center;
        &.active {
          color: #7dfbf5;
          background-image: linear-gradient(to bottom, #e8feff, #4cf3ee);
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
      }
    }
    .second-menu {
      // height: 34px;
      // margin-left: 14px;
      // width: calc(100% - 14px);
      height: 31px;
      margin-left: 9px;
      width: calc(100% - 9px);
      clip-path: polygon(18px 0%, 100% 0%, 100% 100%, 0 100%);
      > li {
        // min-width: 190px;
        font-family: '微软雅黑';
        font-weight: 400;
        font-size: 16px;
        color: #ffffff;
        line-height: 32px;
        padding: 0 20px;
        cursor: pointer;
        background-image: url('~@/assets/image/xydLayout/menuBg.png');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        position: relative;
        text-align: center;
        text-overflow: ellipsis;
        white-space: nowrap;
        position: relative;
        text-align: center;

        &.active {
          color: #7dfbf5;
          background-image: url('~@/assets/image/xydLayout/menuActive.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;

          &::after {
            content: '';
            position: absolute;
            width: 45px;
            height: 4px;
            border-radius: 10px 10px 0 0;
            background-color: #7dfbf5;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
          }
        }
      }
    }
    .second-menu::-webkit-scrollbar {
      display: none;
    }
  }
}

.top-menu-com {
  position: absolute;
  left: 20px;
  top: 35px;
  z-index: 2000;
  min-width: 200px;
  max-width: 250px;
  border-radius: 4px;
  background-color: #158dc1;
  z-index: 99;
  ::v-deep {
    .el-menu {
      background-color: #116191;
      .el-menu-item {
        color: #fff !important;
        background-color: #1277aa;
        &:hover,
        &:focus {
          background-color: #158dc1;
        }
        &.is-active {
          color: #7dfbf5 !important;
          background-color: #158dc1;
          border-color: #158dc1;
        }
      }
    }
  }
}
</style>
