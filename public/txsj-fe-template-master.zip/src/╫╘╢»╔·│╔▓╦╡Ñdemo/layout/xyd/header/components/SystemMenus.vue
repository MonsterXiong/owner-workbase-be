<template>
  <div class="system-menus">
    <ProSelect
      style="margin-right: 20px"
      :value="currentProjectId"
      @change="selectProject"
      placeholder="请选择项目"
      :data="projectList"
      :props="projectProps"
    />

    <span v-if="!hideHFIcon" class="menus-button-wrap tool-icon" title="换肤" v-click-outside="onClickOutside" v-show="isShowTheme" @click="showThemeList">
      <span class="iconfont icon-genghuanpifu" />
      <ThemeSelect class="theme-select-com" v-show="isSelectTheme" />
    </span>
    <div class="menus-button-wrap" v-for="item in menuList" :key="item.code" @click="onMenuClick(item)" :title="item.text">
      <span :class="['iconfont', item.icon]" v-if="item.icon" />
    </div>
  </div>
</template>

<script>
import screenfull from 'screenfull'
import ProSelect from '@/components/proSelect/ProSelect.vue'
import { mapState } from 'vuex'
import { routesConstant } from '@/router/routeConstant'
import ThemeSelect from './themeSelect/index.vue'

const MenuCodes = Object.freeze({
  GO_PROJECT_MANAGE: 'goProjectManage',
  GO_HOME: 'goHome',
  FULL_SCREEN: 'fullScreen',
  SKIN_PILLER: 'skinPiller',
  QUIT: 'quit',
})

export default {
  name: 'SystemMenus',
  components: {
    ProSelect,
    ThemeSelect,
  },
  props: {
    hideHFIcon: {
      type: Boolean,
    },
  },
  data() {
    return {
      isShowTheme: true,
      isSelectTheme: false,
      menuList: [
        {
          text: '项目管理',
          code: MenuCodes.GO_PROJECT_MANAGE,
          icon: 'icon-xiangmu',
          handler: this.goProjectPage,
          subMenu: [],
        },
        {
          text: '首页',
          code: MenuCodes.GO_HOME,
          icon: 'icon-shouye1',
          handler: this.goHomePage,
          subMenu: [],
        },
        {
          text: '全屏',
          code: MenuCodes.FULL_SCREEN,
          icon: 'icon-quanping',
          handler: this.setFullScreen,
          subMenu: [],
        },
        {
          text: '退出',
          code: MenuCodes.QUIT,
          icon: 'icon-tuichu',
          handler: this.onQuit,
          subMenu: [],
        },
      ], //操作栏按钮
      isFullScreen: false,
      projectProps: {
        id: 'projectId',
        children: 'children',
        label: 'projectName',
      },
    }
  },
  created() {
    this.$store.dispatch('project/initProjectList')
  },
  computed: {
    ...mapState('project', ['projectList', 'currentProjectId']),
  },
  methods: {
    showThemeList() {
      this.isSelectTheme = !this.isSelectTheme
    },
    onClickOutside() {
      this.isSelectTheme = false
    },
    selectProject(id, data) {
      this.$store.dispatch('project/setCurrentProject', data)
    },
    onMenuClick(item) {
      if (item.handler) {
        item.handler()
      }
    },
    goHomePage() {
      window.open('./start.html', '_self')
    },
    goProjectPage() {
      this.$router.push(routesConstant.PROJECT_MANAGE.path)
    },
    setFullScreen() {
      // todo 全屏事件
      if (!screenfull.enabled) {
        this.$message('该浏览器不支持全屏功能，请使用其他浏览器')
        return
      } else {
        screenfull.toggle()
        this.isFullScreen = !this.isFullScreen
        this.setFullScreenMenuIcon()
      }
    },
    setFullScreenMenuIcon() {
      const menuItem = this.menuList.find((ele) => ele.code === MenuCodes.FULL_SCREEN)
      if (!menuItem) {
        return
      }
      if (this.isFullScreen) {
        //todo 需要找一下非全屏的icon
        menuItem.icon = 'icon-quanping'
      } else {
        menuItem.icon = 'icon-quanping'
      }
    },
    async onQuit() {
      // 退出登录事件
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirectUrl=${this.$router.currentRoute.fullPath}`)
    },
  },
}
</script>

<style lang="less" scoped>
.system-menus {
  display: flex;
  align-items: center;
  .menus-button-wrap {
    cursor: pointer;
    margin-right: 20px;
    color: #fff;
  }
}

.theme-select-com {
  position: absolute;
  left: 200px;
  top: 35px;
  z-index: 19;
  border-radius: 4px;
  padding: 5px 0px;
  background-color: @background-color-base;
  box-shadow: 0px 0px 5px @shadow-color-base; //0px
}
::v-deep {
  .el-menu.el-menu--horizontal {
    border-bottom: none !important;
    padding: 0px 10px 0 0;
    background: transparent;
    width: 20px;
  }
  .el-submenu {
    width: 20px;
  }
  .el-submenu__title {
    padding: 0px;
  }
  .el-menu--horizontal > .el-submenu .el-submenu__title {
    height: 40px;
    line-height: 36px;
    padding: 2px 0 0;
    i {
      width: 20px;
      margin: 0;
    }
    .icon {
      font-size: 18px;
    }
  }
  .el-menu--horizontal > .el-submenu .el-submenu__title:hover {
    background-color: transparent;
  }
  .el-menu--horizontal > .el-submenu.is-active .el-submenu__title {
    border-bottom: none;
  }
  .el-menu--horizontal {
    .el-menu--popup {
      padding: 0;
    }
  }
}
</style>
