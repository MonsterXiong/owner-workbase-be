<template>
  <div class="theme-select" v-if="supportThemeList && supportThemeList.length > 1">
    <div v-for="item in supportThemeList" :key="item.name" class="theme-select-item">
      <el-radio style="display: block" v-model="themeCode" :label="item.code">{{ item.name }}</el-radio>
    </div>
  </div>
</template>

<script>
import { UserService } from '@/services'
import { mapGetters } from 'vuex'
import { ThemeMutations } from '@/store/modules/theme'
export default {
  name: 'ThemeSelect',
  data() {
    return {
      themeCode: this.$store.getters['theme/getThemeCode'],
    }
  },
  computed: {
    ...mapGetters({
      supportThemeList: 'theme/getSupportThemeList',
    }),
  },
  watch: {
    themeCode(newThemeCode) {
      this.$store.commit(`theme/${ThemeMutations.SET_THEME_CODE}`, newThemeCode)
      this.setUserTheme(newThemeCode)
    },
  },
  methods: {
    async setUserTheme(code) {
      // await UserService.setUserTheme({ theme: code })
    },
  },
}
</script>
<style lang="less" scoped>
.theme-select {
  .theme-select-item {
    padding: 0 20px;
    .el-radio {
      height: 40px;
      line-height: 40px;
    }
  }
}
</style>
