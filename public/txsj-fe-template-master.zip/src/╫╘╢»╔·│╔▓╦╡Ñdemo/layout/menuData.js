import { routesConstant } from '@/router/routeConstant'
import { listToTree, treeToList } from '@/utils/treeTool'

export const MenuKeyConfig = {
  idKey: 'id',
  pidKey: 'parent',
}

export const MENU_TYPE = {
  MODULE: 'module', // 模块 父级菜单,用于分组
  PAGE: 'page', // 页面
}

export const menuList = [
  {
    id: 'jFmhEK0F5_ry_SQsrfUvz',
    parent: '',
    code: 'BUSINESS_MODEL_DESIGN',
    name: '业务模型设计',
    icon: 'icon-a-ziyuan22',
    menuType: MENU_TYPE.MODULE,
    location: 'left_menu',
  },
  {
    id: '6nY2SR6gKFleIXz0EHDVY',
    parent: '',
    code: 'BUSINESS_MODEL_REUSE',
    name: '业务模型复用',
    icon: 'icon-a-ziyuan19-copy',
    menuType: MENU_TYPE.MODULE,
    location: 'left_menu',
  },
  {
    id: 'BIgmN1vYKAP_WyxxMOL4B',
    parent: '',
    code: 'OPERATIONAL_MODEL_IMPLEMENTATION',
    name: '业务模型执行',
    icon: 'icon-a-ziyuan19-copy',
    menuType: MENU_TYPE.MODULE,
    location: 'left_menu',
  },
  {
    id: '88JBcWmk-oUKD0krx1pPU',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'GRAPHICAL_DESIGN',
    name: '业务模型建模',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.GRAPHICAL_DESIGN.path,
    route: routesConstant.GRAPHICAL_DESIGN,
    sort: '1',
  },
  {
    id: 'MGlGKsazaMHKAiiCeUSCu',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'AUTO_GEN_OBJECTS_ON_DATA_MODELS',
    name: '业务对象生成',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.AUTO_GEN_OBJECTS_ON_DATA_MODELS.path,
    route: routesConstant.AUTO_GEN_OBJECTS_ON_DATA_MODELS,
    sort: '2',
  },
  {
    id: '53bMeKHX9sanJ7-acm1sH',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'ALGORITHM_EXECUTION',
    name: '业务算法配置',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.ALGORITHM_EXECUTION.path,
    route: routesConstant.ALGORITHM_EXECUTION,
    sort: '3',
  },
  {
    id: 'ifPy603KmYH68dGts8fL1',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'ALGEBRA_MANAGEMENT',
    name: '算法库管理',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.ALGEBRA_MANAGEMENT.path,
    route: routesConstant.ALGEBRA_MANAGEMENT,
    layout: 'DefaultLayout',
    sort: '4',
  },
  // {
  //   id: 'AH1G1VXwzbb2L9CE0XiEg',
  //   parent: 'jFmhEK0F5_ry_SQsrfUvz',
  //   code: 'ALTERATION_MODEL',
  //   name: '分层分级建立模型',
  //   icon: '',
  //   menuType: MENU_TYPE.PAGE,
  //   menuParams: routesConstant.ALTERATION_MODEL.path,
  //   sort: '5',
  // },
  {
    id: 'UtmbSWlZdvqF_TNolSccO',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'MODEL_MANAGEMENT',
    name: '模型库',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.MODEL_MANAGEMENT.path,
    route: routesConstant.MODEL_MANAGEMENT,
    sort: '6',
  },
  {
    id: 'NI3ga_tOfD9fCXHKU19B6',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'INCLUDE_PROBABILITIES_AND_RANDOM_EVENTS',
    name: '概率与随机数配置',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.INCLUDE_PROBABILITIES_AND_RANDOM_EVENTS.path,
    route: routesConstant.INCLUDE_PROBABILITIES_AND_RANDOM_EVENTS,
    sort: '7',
  },
  {
    id: '8FfD8dRe94pFue2hPO70-',
    parent: 'jFmhEK0F5_ry_SQsrfUvz',
    code: 'VERSION_MANAGEMENT',
    name: '业务模板版本管理',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.VERSION_MANAGEMENT.path,
    route: routesConstant.VERSION_MANAGEMENT,
    sort: '9',
  },
  {
    id: 'qxdMxMTlggDjSBrFgpQD7',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'PACKAGING_BUSINESS_MODEL_COMPONENTS',
    name: '业务模型组件生成',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.PACKAGING_BUSINESS_MODEL_COMPONENTS.path,
    route: routesConstant.PACKAGING_BUSINESS_MODEL_COMPONENTS,
    sort: '1',
  },
  {
    id: 'n9UCgLEalQdGrs4YhRb5O',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'COMPONENT_LIBRARY_MANAGEMENT',
    name: '组件库',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.COMPONENT_LIBRARY_MANAGEMENT.path,
    route: routesConstant.COMPONENT_LIBRARY_MANAGEMENT,
    sort: '3',
  },
  {
    id: 'n9UCgLEalQdGrs4YhRb5O_RRR',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'COMPONENT_VERSION_MANAGEMENT',
    name: '组件库版本管理',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.COMPONENT_VERSION_MANAGEMENT.path,
    route: routesConstant.COMPONENT_VERSION_MANAGEMENT,
    sort: '3',
  },
  {
    id: 'kJrEZ4MdMV1wYOr_h6ljS',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'VALIDATION_OF_COMPONENTS',
    name: '组件可行性验证',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.VALIDATION_OF_COMPONENTS.path,
    route: routesConstant.VALIDATION_OF_COMPONENTS,
    sort: '4',
  },
  {
    id: 'm7dqoaMlFefxxZdawPM7D',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'COMPONENT_MIGRATION_CAPABILITY',
    name: '组件迁移能力',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.COMPONENT_MIGRATION_CAPABILITY.path,
    route: routesConstant.COMPONENT_MIGRATION_CAPABILITY,
    sort: '5',
  },
  {
    id: 'x8V_qPlSEBFXJ7YNIvtX5',
    parent: '6nY2SR6gKFleIXz0EHDVY',
    code: 'COMPONENT_REPORT',
    name: '组件报表',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.COMPONENT_REPORT.path,
    route: routesConstant.COMPONENT_REPORT,
    sort: '6',
  },
  {
    id: 'vWFUtkZulFPaNBuQwhxh6',
    parent: 'BIgmN1vYKAP_WyxxMOL4B',
    code: 'CALCULATING_MODEL_RUNNING',
    name: '计算模型运行',
    icon: '',
    menuType: MENU_TYPE.PAGE,
    menuParams: routesConstant.CALCULATING_MODEL_RUNNING.path,
    route: routesConstant.CALCULATING_MODEL_RUNNING,
    sort: '1',
  },
]

class MenuStore {
  constructor() {
    this.userId = ''
    this.listData = []
    this.treeData = []
  }
  // 获取菜单数据
  async getMenuList() {
    if (this.listData.length === 0) {
      const menuList = await this.queryMenuList()
      this.listData = _.cloneDeep(menuList).map((item) => ({
        ...item,
        _collapse: false,
      }))
      this.treeData = listToTree(this.listData, {
        idKey: MenuKeyConfig.idKey,
        pidKey: MenuKeyConfig.pidKey,
      })
    }
    return {
      listData: this.listData,
      treeData: this.treeData,
    }
  }
  refreshMenuList() {
    this.listData = []
    this.treeData = []
    return this.getMenuList()
  }
  // 如果需要从后台获取菜单数据 则逻辑写在这里
  queryMenuList() {
    return new Promise((res, rej) => {
      res(menuList)
    })
  }
}
const menuStore = new MenuStore()
export default menuStore
