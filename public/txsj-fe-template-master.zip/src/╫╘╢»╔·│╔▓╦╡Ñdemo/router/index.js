import Vue from 'vue'
import _ from 'lodash'
import VueRouter from 'vue-router'
import Layout from '../layout/xyd/Layout.vue'
import DefaultLayout from '../layout/default/Layout.vue'
import store from '@/store'
import configData from '@/utils/config'
import { routesConstant } from './routeConstant.js'

Vue.use(VueRouter)
import menuStore, { MENU_TYPE } from '@/layout/menuData'

const routes = [
  {
    ...routesConstant.REDIRECT,
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import('@/views/baseModule/redirect/index.vue'),
      },
    ],
  },
  {
    ...routesConstant.LOGIN,
    component: () => import('@/views/baseModule/login/Login.vue'),
  },
]
const router = new VueRouter({
  routes,
})

// 初始页面路由,自动生成路由会基于这个生成
const pageRoutes = [
  {
    path: '/',
    name: 'Home',
    redirect: routesConstant.GRAPHICAL_DESIGN.path,
    component: Layout,
    children: [],
  },
  {
    path: '/layout1',
    name: 'DefaultLayout',
    component: DefaultLayout,
    children: [],
  },
]

const whiteList = ['Authority', 'Log', 'Role', 'User', 'FileManage', 'ImageManage']
router.beforeEach(async (to, from, next) => {
  if (to.query.metaTile) {
    to.meta.title = to.query.metaTile
  }
  const userId = store.getters['user/userInfo'].id
  if (whiteList.includes(to.name)) {
    //  在白名单中，直接放行
    next()
  } else if (to.name === 'login') {
    // 目标页面是登录页面
    if (configData.autoLogin == 1 && !userId) {
      // 自动登录
      store.dispatch('user/autoLogin').then(() => {
        next('/')
      })
    } else {
      userId ? next('/') : next()
    }
  } else {
    if (configData.autoLogin == 1 && !userId) {
      // 自动登录
      store.dispatch('user/autoLogin').then(() => {
        getRoutes()
          .then((routes) => {
            router.addRoutes(routes)
            next({ ...to, replace: true })
          })
          .catch(() => {
            next()
          })
      })
    } else if (userId) {
      getRoutes()
        .then((routes) => {
          router.addRoutes(routes)
          next({ ...to, replace: true })
        })
        .catch(() => {
          next()
        })
    } else {
      next(`/login?redirectUrl=${to.fullPath}`)
    }
  }
})

export default router

export const loadPage = (menu, filePath = '') => {
  const name = menu.route.path.split('/')[1]
  if (filePath) {
    return () => import(`@/pages/${filePath}/${name}/${menu.route.name}.vue`)
  }
  return () => import(`@/pages/${name}/${menu.route.name}.vue`)
}

// 动态注册路由
const generateRoutes = (treeData, filePath = '', routes) => {
  const LayoutRoutes = routes || _.cloneDeep(pageRoutes)
  if (Array.isArray(treeData)) {
    treeData.forEach((item) => {
      // 如果该菜单是一个页面 则注册该页面对应的路由
      if (item.menuType === MENU_TYPE.PAGE && item.route) {
        let LayoutRoute = LayoutRoutes[0]
        // 如果该页面没有指定布局 则默认使用第一个布局
        if (item.layout) {
          LayoutRoute = LayoutRoutes.find((layRoute) => layRoute.name === item.layout) || LayoutRoute
        }
        LayoutRoute.children.push({
          ...item.route,
          component: loadPage(item, filePath),
          meta: {
            title: item.name,
          },
        })
      }
      if (Array.isArray(item.children)) {
        generateRoutes(item.children, item.filePath || filePath, LayoutRoutes)
      }
    })
  }
  return LayoutRoutes
}
// 生成路由
const getRoutes = async () => {
  return new Promise((res, rej) => {
    // 如果用户变了, 则重新生成一遍路由
    if (menuStore.userId !== store.getters['user/userInfo'].id) {
      menuStore.userId = store.getters['user/userInfo'].id
      menuStore
        .refreshMenuList()
        .then(({ treeData }) => {
          const routes = generateRoutes(treeData)
          res(routes)
        })
        .catch(() => {
          rej()
        })
    } else {
      rej()
    }
  })
}
