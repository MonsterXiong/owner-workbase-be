const routesConstant = Object.freeze({
  PROJECT_MANAGE: {
    path: '/projectManage',
    name: 'ProjectManage',
  },
  GRAPHICAL_DESIGN: {
    path: '/graphicalDesign',
    name: 'GraphicalDesign',
  },
  AUTO_GEN_OBJECTS_ON_DATA_MODELS: {
    path: '/autoGenObjectsOnDataModels',
    name: 'AutoGenObjectsOnDataModels',
  },
  ALGORITHM_EXECUTION: {
    path: '/algorithmExecution',
    name: 'AlgorithmExecution',
  },
  ALGEBRA_MANAGEMENT: {
    path: '/algebraManagement',
    name: 'AlgebraManagement',
  },
  ALTERATION_MODEL: {
    path: '/alterationModel',
    name: 'AlterationModel',
  },
  MODEL_MANAGEMENT: {
    path: '/modelManagement',
    name: 'ModelManagement',
  },
  INCLUDE_PROBABILITIES_AND_RANDOM_EVENTS: {
    path: '/includeProbabilitiesAndRandomEvents',
    name: 'IncludeProbabilitiesAndRandomEvents',
  },
  VERSION_MANAGEMENT: {
    path: '/versionManagement',
    name: 'VersionManagement',
  },
  PACKAGING_BUSINESS_MODEL_COMPONENTS: {
    path: '/packagingBusinessModelComponents',
    name: 'PackagingBusinessModelComponents',
  },
  COMPONENT_LIBRARY_MANAGEMENT: {
    path: '/componentLibraryManagement',
    name: 'ComponentLibraryManagement',
  },
  COMPONENT_VERSION_MANAGEMENT: {
    path: '/componentVersionManagement',
    name: 'ComponentVersionManagement',
  },
  VALIDATION_OF_COMPONENTS: {
    path: '/validationOfComponents',
    name: 'ValidationOfComponents',
  },
  COMPONENT_MIGRATION_CAPABILITY: {
    path: '/componentMigrationCapability',
    name: 'ComponentMigrationCapability',
  },
  COMPONENT_REPORT: {
    path: '/componentReport',
    name: 'ComponentReport',
  },
  CALCULATING_MODEL_RUNNING: {
    path: '/calculatingModelRunning',
    name: 'CalculatingModelRunning',
  },
})

export default routesConstant
