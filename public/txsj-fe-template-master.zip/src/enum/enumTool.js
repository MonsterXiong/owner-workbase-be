import enumObj from './index'
import * as changeCase from 'change-case'
class EnumMap {
  constructor(enumMap) {
    this.enumMap = enumMap
  }
  getLabel(enumType, enumKey) {
    const enumData = this.enumMap[changeCase.camelCase(enumType)]
    if (!enumData) {
      console.log('enumType', `不存在${changeCase.camelCase(enumType)}枚举`)
      return ''
    }
    return enumData.getLabelByValue(enumKey)
  }
  getOption(enumType) {
    const enumData = this.enumMap[changeCase.camelCase(enumType)]
    if (!enumData) {
      console.log('enumType', `不存在${enumType}枚举`)
      return ''
    }
    return enumData.getEnum()
  }
}

export default new EnumMap(enumObj)
