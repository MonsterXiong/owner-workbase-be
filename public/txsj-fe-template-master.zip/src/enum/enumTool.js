import enumObj from './index'

class EnumMap {
  constructor(enumMap) {
    this.enumMap = enumMap
  }
  getLabel(enumType, enumKey) {
    const enumData = this.enumMap[enumType]
    if (!enumData) {
      console.log('enumType', `不存在${enumType}枚举`)
      return ''
    }
    return enumData.getLabelByValue(enumKey)
  }
}

export default new EnumMap(enumObj)
