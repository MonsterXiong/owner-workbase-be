import { genEnumByOption } from '@/utils/EnumFactory'

export const IndexTypes = {
  COST_METRIC: 'cost_metric',
  UTILITY_METRIC: 'utility_metric',
  SUITABLE_METRIC: 'suitable_metric',
}

// 项目阶段枚举
export const IndexTypeOptions = [
  {
    value: IndexTypes.COST_METRIC,
    label: '成本型',
  },
  {
    value: IndexTypes.UTILITY_METRIC,
    label: '效益型',
  },
  {
    value: IndexTypes.SUITABLE_METRIC,
    label: '适中型',
  },
]

export const requirementTypeEnum = genEnumByOption(IndexTypeOptions)

export default requirementTypeEnum
