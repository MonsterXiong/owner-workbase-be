<template>
  <div class="biz-tree">
    <TreeList
      v-model="activeId"
      :title="listTitle"
      :data="treeData"
      :config="config"
      :initSel="initSelectId"
      @add="onTreeAdd"
      @iconClick="onTreeHandler"
      @nodeClick="onTreeNodeClick"
      @change="onChange"
    />
    <slot name="dialog">
      <FormDialog ref="TreeListDialogRef" @update="onFormDialogUpdate" />
    </slot>
  </div>
</template>

<script>
import TreeList from '@/components/treeList/TreeList.vue'
import FormDialog from '@/components/basicForm/FormDialog.vue'
import { isFunction, mergeObj, exportFile } from '@/utils/commonUtil.js'
import { listToTree } from '@/utils/treeTool'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import tools from '@/utils/tools'

const baseConfig = {
  isFilter: false,
  allowAdd: false,
  type: '',
}

const defaultProps = {
  id: 'id',
  name: 'name',
  parentId: 'parentId',
}
const defaultIcons = [
  { icon: 'el-icon-edit', name: '编辑', code: 'update' },
  { icon: 'el-icon-delete', name: '删除', code: 'delete' },
]
const mockTreeListNodeConfig = [
  {
    defaultProps: {
      id: 'id',
      name: 'name',
      parentId: 'parentId',
    },
    icon: 'iconfont icon-roket',
    icons: [
      { icon: 'el-icon-edit', name: '编辑', code: 'edit' },
      { icon: 'el-icon-delete', name: '删除', code: 'delete' },
    ],
    nodeList: [{ id: '101', name: '节点', parentId: '' }],
    columnList: [
      {
        code: 'name',
        label: '节点名称',
        query: true,
        required: true,
        type: 'input',
      },
    ],
    name: '节点',
    code: 'plat',
    interface: {},
    relationParams: {},
    defaultAdd: true,
    queryRelateCondition: {
      bindId: 'id',
    },
  },
]

export default {
  name: 'BizTree',
  props: {
    listTitle: {
      type: String,
    },
    data: {
      type: Array,
      default: () => [],
    },
    treeListConfig: {
      type: Object,
      default: () => {},
    },
    treeListNodeConfig: {
      type: Array,
      default: () => mockTreeListNodeConfig,
    },
    defaultSelId: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      activeId: '',
      treeData: [],
      treeList: [],
      initSelectId: '',
      formItems: [],
      currentNodeConfig: null,
      iconType: '',
      currentNode: null,
    }
  },
  computed: {
    config() {
      return mergeObj(baseConfig, this.treeListConfig)
    },
  },
  watch: {
    activeId: {
      handler(val) {
        this.$emit('input', val)
      },
      immediate: true,
    },
    treeListNodeConfig: {
      handler() {
        this.formatData()
      },
      immediate: true,
    },
    defaultSelId: {
      handler() {
        this.initSelectId = this.defaultSelId
      },
      immediate: true,
    },
  },
  methods: {
    async formatData() {
      let nodeData = []
      if (this.treeListNodeConfig.length == 0) {
        this.treeData = []
        return
      }
      for (let i = 0; i < this.treeListNodeConfig.length; i++) {
        const element = this.treeListNodeConfig[i]
        let icons = defaultIcons
        if (element.icons && element.icons.length == 0) {
          icons = []
        } else {
          if (element?.icons?.length > 0) icons = element.icons
        }
        if (element?.interface?.service) {
          let arr = await this.queryNodeList(element.interface.service, element.relationParams, {
            props: element?.defaultProps || defaultProps,
            type: element?.code || '',
            icon: element?.icon || '',
            icons,
          })
          nodeData = nodeData.concat(arr)
        } else {
          let list = []
          if (Array.isArray(element.nodeList)) {
            for (let j = 0; j < element.nodeList.length; j++) {
              const node = element.nodeList[j]
              let obj = this.transformTreeNode(element.defaultProps, node)
              list.push({ ...obj, type: element?.code || '', icons, icon: element.icon })
            }
          }
          nodeData = nodeData.concat(list)
        }
      }
      this.treeList = JSON.parse(JSON.stringify(nodeData)) || []
      this.treeData = listToTree(nodeData)
    },
    transformTreeNode(props, obj) {
      let data = { nodeData: { ...obj } }
      for (const key in props) {
        const code = props[key]
        if (key && code) data[key] = obj[code] || ''
      }
      return data
    },
    async queryNodeList(url, relationParams, { props, type, icon, icons }) {
      let params = QueryConditionBuilder.getInstanceNoPage()
      if (relationParams) {
        Object.keys(relationParams).forEach((key) => {
          if (relationParams[key] || relationParams[key] === 0) {
            params.buildEqualQuery(key, relationParams[key])
          }
        })
      }
      let array = []
      let { data } = await this.$getInterface(url, 'query')(params)
      if (Array.isArray(data)) {
        array = data.map((ele) => {
          let obj = this.transformTreeNode(props, ele)
          return { ...obj, type: type || '', icons: icons || defaultIcons, icon: icon }
        })
      }
      return array
    },
    onTreeAdd(data) {
      console.log(data, 'onTreeNodeClick')
      let obj = this.treeListNodeConfig.find((ele) => ele.defaultAdd)
      this.iconType = ''
      if (obj) {
        this.currentNodeConfig = obj
        const formData = {}
        this.formItems = obj?.columnList || []
        this.$refs.TreeListDialogRef.show(`新增${obj.name}`, this.formItems, formData)
        this.iconType = 'insertDefault'
      } else {
        console.log('当前没有设置默认添加')
        this.currentNodeConfig = null
      }
    },
    async onFormDialogUpdate(formData) {
      console.log(formData, 'onFormDialogUpdate', this.iconType)
      if (this.iconType == 'edit') {
        this.updateTreeNode(formData)
      } else {
        this.addTreeNode(formData)
      }
    },
    async addTreeNode(formData) {
      if (this.iconType == 'insertDefault') {
        if (isFunction(this.$listeners.insertDefault)) {
          return this.$emit('insertDefault', formData)
        } else {
          if (this.currentNodeConfig?.interface?.service) {
            await this.$getInterface(this.currentNodeConfig?.interface?.service, 'insert')(formData)
            tools.message('操作成功')
            this.formatData()
          } else {
            return this.$emit('insertDefault', formData)
          }
        }
      } else {
        if (isFunction(this.$listeners.insert)) {
          return this.$emit('insert', formData)
        } else {
          if (this.currentNodeConfig?.interface?.service) {
            await this.$getInterface(this.currentNodeConfig.interface.service, 'insert')(formData)
            tools.message('操作成功')
            this.formatData()
          } else {
            return this.$emit('insert', formData)
          }
        }
      }
    },
    async updateTreeNode(formData) {
      if (isFunction(this.$listeners.update)) {
        return this.$emit('update', formData)
      } else {
        if (this.currentNodeConfig?.interface?.service) {
          await this.$getInterface(this.currentNodeConfig.interface.service, 'update')(formData)
          tools.message('操作成功')
          this.formatData()
        } else {
          return this.$emit('update', formData)
        }
      }
    },
    async deleteTreeNode(deleteIds) {
      let url = this.currentNodeConfig?.interface?.service
      if (isFunction(this.$listeners.delete)) {
        return this.$emit('deleteBatch', deleteIds)
      } else {
        if (url) {
          await this.$getInterface(url, 'deleteBatch')(deleteIds)
          // await this.$getInterface(url, 'delete')(deleteIds)
          tools.message('操作成功')
          this.formatData()
        } else {
          return this.$emit('deleteBatch', deleteIds)
        }
      }
    },
    onTreeHandler({ data, code, addType }) {
      console.log(data, code, 'onTreeHandler')
      this.iconType = code
      if (data.type) {
        this.currentNodeConfig = this.treeListNodeConfig.find((ele) => ele.code == data.type) || null
      } else this.currentNodeConfig = this.treeListNodeConfig[0] || null
      if (!this.currentNodeConfig) {
        this.$emit(code, data)
        this.iconType = ''
        return
      }
      if (code == 'insert') {
        let formData = {}
        if (addType) {
          this.currentNodeConfig = this.treeListNodeConfig.find((ele) => ele.code == addType)
        }
        if (this.currentNodeConfig?.defaultProps?.parentId) formData[this.currentNodeConfig.defaultProps.parentId] = data.id
        this.formItems = this.currentNodeConfig?.columnList || []
        this.$refs.TreeListDialogRef.show(`新增${this.currentNodeConfig.name}`, this.formItems, formData)
      } else if (code == 'update') {
        const formData = { ...data.nodeData }
        this.formItems = this.currentNodeConfig?.columnList || []
        this.$refs.TreeListDialogRef.show(`编辑${this.currentNodeConfig.name}`, this.formItems, formData)
      } else if (code == 'delete') {
        this.deleteTreeNode([data.id])
      } else {
        this.$emit(code, data)
        this.iconType = ''
      }
    },
    onTreeNodeClick(node) {
      this.currentNode = node
      this.$emit('changeCurrentNode', node)
    },
    onChange(node) {
      this.$emit('selectChange', node)
    },
  },
  components: {
    TreeList,
    FormDialog,
  },
}
</script>

<style lang="less" scoped>
.biz-tree {
  height: 100%;
}
</style>
