# BizTree组件

## 基本信息

- 基于TreeList组件，进一步封装，支持业务逻辑处理。

## 使用示例

```vue
<template>
  <div class="biz-tree-sample">
    <PanelLayout>
      <template slot="left">
        <BizTree 
          v-model='activeId'
          :listTitle="listTitle" 
          :treeListNodeConfig="treeListNodeConfig" :treeListConfig="treeListConfig" 
          :defaultSelId="defaultSelId" 
          @changeCurrentNode="changeCurrentNode"
        >
          <!-- @insert="onInsert" 
          @update="onUpdate" 
          @delete="onDelete" -->
          <!-- <template slot="dialog"></template> -->
        </BizTree>
      </template>
    </PanelLayout>
  </div>
</template>

<script>
import BizTree from '@/bizComponents/bizTree/BizTree.vue'
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
export default {
  name: 'BizTreeSample',
  data() {
    return {
      listTitle:'任务列表'
      activeId:'',
      treeListConfig: {
        isFilter: true,
        allowAdd: false,
        readOnly: false,
        isSelectOneNode: true,
        type: '',
      },
      defaultSelId: '',
      treeListNodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'icon-order-fill-copy',
          icons: [{ icon: 'el-icon-circle-plus-outline', name: '添加任务', code: 'insert', addType: 'task' }],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          defaultAdd: true,
          queryRelateCondition: {
            bindProject: 'id',
          },
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '任务名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'el-icon-s-management',
          icons: [
            // { icon: 'el-icon-edit', name: '编辑', code: 'update' },
            // { icon: 'el-icon-delete', name: '删除', code: 'delete' },
          ],
          name: '任务',
          code: 'task',
          interface: {
            // service: 'XydTask',
            // key: 'taskId',
          },
          relationParams: {
            // bindProject: '3587f47eae444cd08154741eeed70275',
          },
          // queryRelateCondition: {
          //   bindTask: 'id',
          // },
        },
      ],
    }
  },
  methods: {
    onInsert(data) {
      console.log(data, 'insert')
    },
    changeCurrentNode(node){
      console.log('changeCurrentNode',node)
    },
  },
  components: { BizTree, PanelLayout },
}
</script>

<style></style>

```

- insert、update、delete事件可以外部处理，以及icons自定义的按钮事件也可以外部处理

## 配置项详情

|listTitle|列表名称|String|可不传|

|treeListConfig|树形组件默认配置项|Object|可不传|

```js
treeListConfig:{
  isFilter: true,//搜索过滤框
  allowAdd: false,//是否允许新增
  readOnly: false,//只读 只读模式操作按钮都会隐藏
  isSelectOneNode: true,//默认选中第一个节点
  type: '',//允许选中的节点类型，不做限制的话默认为空字符串
}
```

|treeListNodeConfig|树形展示节点实体类型相关配置|Array|必传|

```js
[
  {
    //注释的可不传
    defaultProps: {
      id: 'taskId',//实体Id字段
      name: 'taskName',//实体名称字段
      parentId: 'bindProject',//实体父节点关联字段
    },
    nodeList: [],//实体数据 
    columnList: [
    // 实体属性集 例如：名称、编码、描述等
      {
        code: 'taskName',
        label: '任务名称',
        query: true,
        required: true,
        type: 'input',
      },
    ],
    icon: 'el-icon-s-management',//图标
    // icons: [
    //   // { icon: 'el-icon-edit', name: '编辑', code: 'update' },
    //   // { icon: 'el-icon-delete', name: '删除', code: 'delete' },
    // ],//操作按钮配置 为空数据[]则无操作按钮，icons不传默认会显示编辑和删除按钮
    name: '任务',//默认实体名称
    code: 'task',//实体类型
    // 接口
    interface: {
      // service: 'XydTask',//对应service名
      // key: 'taskId',//id字段
    },
    // 查询条件
    relationParams: {
      // bindProject: '3587f47eae444cd08154741eeed70275',
    },
    
    // queryRelateCondition: {// 关联组件条件参数
    //   bindTask: 'id',
    // },
    
    // defaultAdd: true,// 列表默认添加项
  },
],
```

|defaultSelId|默认选中节点id|String|可不传|

- defaultSelId有值和isSelectOneNode为true的情况，默认选中defaultSelId设置的值
