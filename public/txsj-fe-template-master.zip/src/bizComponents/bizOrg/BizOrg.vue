<template>
  <PanelLayout ref="panelLayoutRef" :showRightPanel="showRightPanel" :showLeftPanel="false" :defaultRightWidth="22">
    <OrgDiagram
      :saveMode="mode"
      :addToolList="addToolList"
      :addNodeConfig="addNodeConfig"
      :nodeList="nodeList"
      :textList="textList"
      @addNode="addNode"
      @deleteNode="deleteNode"
      @updateNode="updateNode"
      @saveDiagram="saveDiagramData"
      @export="onExport"
      @setCurrentNodeData="setCurrentNodeData"
      ref="bizOrgGraphRef"
    ></OrgDiagram>
    <template v-slot:right>
      <div class="form-wrap">
        <page-form :formItemList="currentColumnList" :form="currentNodeData?.properties" labelWidth="100px" @saveForm="submitFormData">
          <slot name="form"></slot>
        </page-form>
      </div>
    </template>
  </PanelLayout>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import OrgDiagram from '@/components/orgDiagram/OrgDiagram.vue'
import { isFunction } from '@/utils/commonUtil'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import tools from '@/utils/tools'
import PageForm from '@/components/basicForm/PageForm.vue'

const mockNodeConfig = [
  {
    defaultProps: {
      id: 'id',
      name: 'name',
      parentId: 'parentId',
    },
    nodeList: [{ id: '101', name: '节点', parentId: '' }],
    columnList: [
      {
        code: 'name',
        label: '节点名称',
        query: true,
        required: true,
        type: 'input',
      },
    ],
    name: '节点',
    code: 'plat',
    interface: {},
    relationParams: {},
    allowType: [],
    // tag: '平台',
    // _type: 'green',
    // category: 'node1',
  },
]
export default {
  props: {
    nodeConfig: {
      type: Array,
      default: () => [],
    },
    mode: {
      type: String,
      default: 'monitor', //save
    },
    forbidDeleteIds: {
      type: Array,
      default: () => [], //save
    },
    textList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      defaultMatchCode: {
        id: 'id',
        name: 'name',
        parentId: 'parentId',
        sortValue: 'sortValue',
        _type: '_type',
      },
      addToolList: [],
      addNodeConfig: {},
      nodeList: [],
      showRightPanel: false,
      currentNodeData: null,
      nodeData: [],
      nodeTypeList: [],
      currentColumnList: [],
      originData: [],
    }
  },
  watch: {
    nodeConfig: {
      handler() {
        this.formatData()
      },
      immediate: true,
    },
  },
  methods: {
    async formatData() {
      this.nodeData = []
      this.nodeTypeList = []
      this.addToolList = []
      for (let index = 0; index < this.nodeConfig.length; index++) {
        const element = this.nodeConfig[index]
        this.addToolList.push({
          name: '添加' + element.name,
          code: 'add',
          icon: 'el-icon-circle-plus-outline',
          addTemplateCode: element.code,
        })
        this.nodeTypeList.push({ code: element.code, interface: element.interface, relationParams: element.relationParams })
        let template = {}
        element.columnList.forEach((ele) => {
          template[ele.code] = ''
        })
        this.addNodeConfig[element.code] = {
          matchCode: {
            ...this.defaultMatchCode,
            ...element.defaultProps,
          },
          template,
          nodeLabel: element.name,
          nodeType: element.code,
          tag: element?.tag || '',
          _type: element._type || 'default',
          category: element?.category || '',
          allowType: element?.allowType || [],
        }
        if (element.nodeList.length > 0) {
          element.nodeList = element.nodeList.map((ele) => {
            return { ...ele, nodeType: element.code }
          })
        } else element.nodeList = []
        if (element?.interface?.service) {
          let arr = await this.queryNodeList(element.interface.service, element.code, element.relationParams)
          this.nodeData = this.nodeData.concat(arr)
        } else if (Array.isArray(element.nodeList)) {
          this.nodeData = this.nodeData.concat(element.nodeList)
        }
      }
      this.nodeList = this.setNodeList(this.nodeData)
      this.originData = JSON.parse(JSON.stringify(this.nodeList)) || []
    },
    setNodeList(list) {
      let arr = []
      if (list.length > 0) {
        arr = list.map((ele, index) => {
          let code = ele.nodeType
          let obj = {}
          if (code) {
            obj = {
              properties: { ...ele },
              nodeType: code,
            }
            for (const key in this.addNodeConfig[code].matchCode) {
              const match = this.addNodeConfig[code].matchCode[key]
              obj[key] = ele[match] || ''
            }
            obj._type = this.addNodeConfig[code]._type || 'dafault'
            obj.category = this.addNodeConfig[code].category || ''
            if (ele.style) {
              let style = JSON.parse(ele.style)
              obj._type = style._type
              if (style.sortValue) obj.sortValue = style.sortValue
            }
            arr.push(obj)
          }
          return obj
        })
      }
      return arr
    },
    async queryNodeList(url, nodeType, relationParams) {
      let params = QueryConditionBuilder.getInstanceNoPage()
      if (relationParams) {
        Object.keys(relationParams).forEach((key) => {
          if (relationParams[key] || relationParams[key] === 0) {
            params.buildEqualQuery(key, relationParams[key])
          }
        })
      }
      let array = []
      let { data } = await this.$getInterface(url, 'query')(params)
      if (Array.isArray(data)) {
        array = data.map((ele) => {
          return { ...ele, nodeType }
        })
      }
      return array
    },
    async saveDiagramData(nodeDataArray) {
      // 保存
      let params = nodeDataArray.map((ele) => {
        let data = this.setParams({ ...ele.properties }, ele.nodeType, ele._type, ele.sortValue)
        return data.params
      })
      if (isFunction(this.$listeners.save)) {
        return this.$emit('save', params, this.originData)
      } else {
        // 保存 多类型节点保存
        let data1 = this.getDifferentNodeList(nodeDataArray)
        if (data1.find((ele) => !ele?.interface?.service)) {
          return this.$emit('save', params, this.originData)
        } else {
          for (let i = 0; i < data1.length; i++) {
            const element = data1[i]
            if (element?.interface?.service) {
              // 保存接口调用 element.nodeList
              let old = []
              console.log(this.originData, 'this.originData')
              if (this.originData.length > 0) old = this.originData.filter((ele) => ele.nodeType == element.code)
              let params = { newDTOList: element.nodeList, oldDTOIdList: old.map((ele) => ele.id) }
              await this.$getInterface(element?.interface?.service, 'saveBatch')(params)
              tools.message('操作成功')
            }
          }
          // 批量保存之后刷新节点数据
          this.formatData()
        }
      }
    },
    async addNode(params) {
      // 新增
      let type = params.nodeType
      let flag = true
      if (this.currentNodeData) {
        let nc = this.nodeConfig.find((ele) => ele.code == this.currentNodeData.nodeType)
        let allowType = nc?.allowType || []
        if (allowType.length > 0) {
          if (!allowType.find((code) => code == type)) {
            flag = false
            this.$refs.bizOrgGraphRef.deleteNodeById(params.id)
            tools.message('当前节点下不允许添加该类型节点', { type: 'info' })
          }
        }
      }
      if (flag && this.mode == 'monitor') {
        let data = this.setParams({ ...params.properties }, params.nodeType, params._type, params.sortValue)
        // 添加节点事件
        if (isFunction(this.$listeners.insert)) {
          return this.$emit('insert', data.params)
        } else {
          // 新增 多类型节点
          if (data.nc?.interface?.service) {
            await this.$getInterface(data.nc.interface.service, 'insert')(data.params)
            tools.message('操作成功')
          } else return this.$emit('insert', data.params)
        }
      }
    },
    async deleteNode(delNodeList) {
      if (this.mode != 'monitor') return
      let data = this.getDifferentNodeList(delNodeList).filter((ele) => ele.nodeList.length != 0)
      try {
        await tools.confirm('请确认是否删除')
        // 删除节点事件
        if (isFunction(this.$listeners.delete)) {
          return this.$emit('delete', delNodeList)
        } else {
          // 删除 多类型节点
          if (data.find((ele) => !ele?.interface?.service)) {
            return this.$emit('delete', delNodeList)
          } else {
            data.forEach(async (element) => {
              if (element?.interface?.service && element.nodeList.length > 0) {
                // 删除接口调用 element.nodeList
                await this.$getInterface(
                  element?.interface?.service,
                  'deleteBatch'
                )(element.nodeList.map((ele) => ele[this.addNodeConfig[element.code].matchCode.id]))
                tools.message('操作成功')
              }
            })
          }
        }
      } catch (error) {
        console.error(error)
      }
    },
    async updateNode(updateNodes) {
      let params = updateNodes.map((ele) => {
        let { params, nc } = this.setParams({ ...ele.properties }, ele.nodeType, ele._type, ele.sortValue)
        return params
      })
      // 更新节点 节点数据
      if (this.mode !== 'monitor') return
      if (isFunction(this.$listeners.updateBacth)) {
        return this.$emit('updateBacth', params)
      } else {
        // 更新 多类型节点
        let data = this.getDifferentNodeList(updateNodes).filter((ele) => ele.nodeList.length != 0)
        if (data.find((ele) => !ele?.interface?.service)) {
          return this.$emit('updateBacth', params)
        } else {
          for (let i = 0; i < data.length; i++) {
            const element = data[i]
            if (element?.interface?.service && element.nodeList.length > 0) {
              // 更新接口调用 element.nodeList
              await this.$getInterface(element?.interface?.service, 'updateBatch')(element.nodeList)
              tools.message('操作成功')
            }
          }
        }
      }
    },
    setCurrentNodeData(nodeData) {
      this.currentNodeData = nodeData ? { ...nodeData } : null
      this.showRightPanel = this.currentNodeData ? true : false
      if (this.showRightPanel) {
        if (this.nodeConfig.length > 0)
          this.nodeConfig.forEach((ele) => {
            if (ele.code == nodeData.nodeType) this.currentColumnList = ele.columnList
          })
        else
          this.currentColumnList = [
            {
              code: 'name',
              label: '名称',
              query: true,
              required: true,
              type: 'input',
            },
          ]
      }
      if (isFunction(this.$listeners.setCurrentNodeData)) {
        return this.$emit('setCurrentNodeData', nodeData)
      }
    },
    async submitFormData(formData) {
      let nodeType = this.currentNodeData.nodeType
      let config = this.addNodeConfig[nodeType]
      let data = { properties: { ...formData }, name: formData[config?.matchCode?.name || 'name'] }
      if (config?.matchCode?.tag) {
        data.tag = formData[config?.matchCode?.tag || 'tag']
      }
      let { params, nc } = this.setParams({ ...formData }, nodeType, this.currentNodeData._type, this.currentNodeData.sortValue)
      this.$refs.bizOrgGraphRef.updateActiveNodeData(data)
      if (this.mode == 'monitor') {
        if (isFunction(this.$listeners.update)) {
          return this.$emit('update', params)
        } else {
          if (nc?.interface?.service) {
            // 更新接口调用
            await this.$getInterface(nc?.interface?.service, 'update')(params)
            tools.message('操作成功')
          } else {
            return this.$emit('update', params)
          }
        }
      } else {
        if (isFunction(this.$listeners.update)) {
          return this.$emit('update', params)
        }
      }
    },
    setParams(properties, nodeType, type, sortValue) {
      let params = { ...properties }
      let nc = this.nodeConfig.find((item) => item.code == nodeType)
      if (nc?.defaultProps?.sortValue) {
        params[nc.defaultProps.sortValue] = sortValue || ''
        params.style = JSON.stringify({ _type: type })
      } else {
        params.style = JSON.stringify({ _type: type, sortValue: sortValue || '' })
      }
      return { params, nc }
    },
    getDifferentNodeList(array) {
      this.nodeTypeList.forEach((ele) => (ele.nodeList = []))
      array.forEach((ele) => {
        let nodeType = ele.nodeType
        this.nodeTypeList.forEach((item) => {
          if (item.code == nodeType) {
            let { params } = this.setParams({ ...ele.properties }, nodeType, ele._type, ele.sortValue)
            item.nodeList.push(params)
          }
        })
      })

      return [...this.nodeTypeList]
    },
    onExport(diagram) {
      console.log('导出', diagram)
      this.$emit('export', diagram)
    },
  },
  components: {
    PanelLayout,
    OrgDiagram,
    PageForm,
  },
}
</script>

<style lang="less" scoped>
.form-wrap {
  height: calc(100% - 20px);
  padding: 10px;
}
</style>
