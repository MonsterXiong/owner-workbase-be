# BizOrg组件

## 基本信息

- 基于OrgDiagram组件，进一步封装，支持业务逻辑处理。

## 使用示例

```vue
<template>
  <div class="common-page" ref="BizOrgSampleRef">
    <PanelLayout ref="panelLayoutRef" :showLeftPanel="true" :defaultRightWidth="22">
      <template v-slot:left>
        <span style="color: gray">这是左边</span>
      </template>
      <BizOrg :nodeConfig="nodeConfig" :mode="'save'" @setCurrentNodeData="setCurrentNodeData" @export="onExport" />
      <!--  @update="onUpdate"
        @updateBatch="onUpdateBatch"
        @insert="onInsert"
        @delete="onDelete" -->
    </PanelLayout>
  </div>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BizOrg from '@/bizComponents/bizOrg/BizOrg.vue'
export default {
  name: 'BizOrgSample', 
  data() {
    return {
      nodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          allowType: ['task'],
          // tag: '平台',
          // _type: 'green',
          // category: 'node1',
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '装备名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          allowType: ['func'],
          // tag: '平台',
          _type: 'green',
          // category: 'node1',
        },
      ],
    }
  },
  mounted() {
  },
  methods: {
    onUpdate(data) {
      console.log(data, 'onUpdate')
    },
    onUpdateBatch(data) {
      console.log(data, 'onUpdateBatch')
    },
    onInsert(data) {
      console.log(data, 'onInsert')
    },
    onDelete(data) {
      console.log(data, 'onDelete')
    },
    setCurrentNodeData(data) {
      console.log(data, 'setCurrentNodeData')
    },
    onExport(diagram) {
      console.log(diagram, 'onExport')
    },
  },
  components: {
    PanelLayout,
    BizOrg,
  },
}
</script>

<style lang="less" scoped></style>

```

- update、updateBatch、insert、delete事件也可以外部处理

## 配置项详情

|nodeConfig|组织图节点类型相关配置|Array|必传|

```js
[{
  //注释的可不传
  defaultProps: {
    id: 'projectId',//实体Id字段
    name: 'projectName',//实体名称字段
    parentId: 'parentId',//实体父节点关联字段
    //sortValue: 'sysSort',//实体排序字段
    //tag:''//实体标签字段
    //_type: '_type',//实体展示颜色类型
  },
  nodeList: [],//实体数据 
  columnList: [
    // 实体属性集 例如：名称、编码、描述等
    {
      code: 'projectName',
      label: '项目名称',
      query: true,
      required: true,
      type: 'input',
    },
  ],
  name: '项目',//实体名称
  code: 'project',//实体类型
  // 接口
  interface: {
    // service: 'XydProject',//对应service名
    // key: 'projectId',//id字段
  },
  // 查询条件
  relationParams: {
    // projectId: '3587f47eae444cd08154741eeed70275',
  },
  // allowType: ['task'],//允许添加的节点类型
  // tag: '平台',//默认标签名
  // _type: 'green',//实体颜色类型
  // category: 'node1',//实体展现templatele类型
},]

```

|mode|保存类型|String|可不传|

- 可以传 save,monitor两种，默认为monitor(实时保存)

|forbidDeleteIds|禁止删除的节点Id数组|Array|可不传|

- 默认为空数组

|textList|节点展示属性集合|Array|可不传|

```js
// 默认格式
[
  { code: 'name', title: '名字' },
  { code: 'sysSort', title: '排序' },
]

```
