<template>
  <PanelLayout>
    <template v-slot:left>
      <BizList
        :listTitle="$attrs.listTitle"
        :formItems="$attrs.formItems"
        :defaultProps="$attrs.defaultProps"
        :listInterface="$attrs.listInterface"
        :listConfig="$attrs.listConfig"
        @change="onNodeClick"
      ></BizList>
    </template>
    <!-- 传入tableInterface则走内部逻辑，传入方法则对应逻辑在当前页面处理 insert|update|delete|export|import -->
    <BizTable :columnList="$attrs.columnList" :tableConfig="rightTableConfig" :tableInterface="$attrs.tableInterface" :btns="$attrs.btns"></BizTable>
  </PanelLayout>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BizList from '@/bizComponents/bizList/BizList.vue'
import BizTable from '@/bizComponents/bizTable/BizTable.vue'

export default {
  name: 'LeftListAndRightTable',
  data() {
    return {
      currentNode: null,
      rightTableConfig: {},
    }
  },
  methods: {
    onNodeClick(node) {
      this.currentNode = { ...node }
      const relationParams = { ...this.$attrs.tableConfig.relationParams }
      Object.keys(relationParams).forEach((key) => {
        if (relationParams[key] === (this.$attrs.defaultProps?.id || 'id')) {
          this.rightTableConfig.relationParams[key] = this.currentNode[this.$attrs.defaultProps?.id || 'id']
        } else this.rightTableConfig.relationParams[key] = relationParams[key]
      })
    },
  },
  components: { PanelLayout, BizList, BizTable },
  watch: {
    '$attrs.tableConfig': {
      handler(val) {
        this.rightTableConfig = JSON.parse(JSON.stringify(val))
      },
      immediate: true,
    },
  },
}
</script>
