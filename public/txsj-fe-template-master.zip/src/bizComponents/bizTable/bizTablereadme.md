## BizTable组件

> 表格组件基于 table 组件渲染，内部处理相关接口逻辑，支持透传

```shell
组件必传参数:columnList、data|tableInterface

1.组件支持传入data
    传入data同事传入tableInterface 查询在外部，增删改组件内部会自行处理
    传入data 传入对应insert|update|delete|export|import方法，组件会将事件派发到外部处理
    传入data时，需要tableConfig中传入total，默认显示tableData.length
2.组件传入tableInterface 组件自行处理接口逻辑

```

### 目前支持显示类型

> 输入框-> input

|目前支持        |类型        |
|------------|--------------|
|下拉框       |select       |
|单选框       |radio       |
|多选框       |checkbox       |
|树形下拉框       |treeselect       |
|数字框       |number       |
|文本域       |textarea       |
|输入框       |input       |
|时间选择器       |time       |
|日期选择器       |date       |
|日期时间选择器       |datetime       |
|Switch 开关       |switch       |
|slider 滑块       |slider       |
|颜色选择器       |color       |
|按钮       |button       |
|图片       |picture       |

#### 配置项详情

```js
// 必传参数
// 表格列配置
columnList = [
    // 其它类型
    {
        code: 'name', // 列prop
        label: '名称', // 名称
        type: 'input', // 类型
    },
    // select|radio|checkbox|treeselect 都支持静态类型、静态枚举、通过接口获取数据
    // 静态类型
    {
        code: 'type1',
        label: '静态类型',
        type: 'select',
        options: [
            {
                label: '成本型',
                value: 'chengbenxing',
            },
            {
                label: '效益型',
                value: 'xiaoyixing',
            },
        ],
    },
    // 静态枚举
    {
        code: 'type2',
        label: '枚举类型',
        type: 'select',
        dataType: 'enum',
        params: 'indexType',
    },
    // 接口地址
    {
        code: 'type3',
        label: '接口类型',
        type: 'select',
        dataType: 'interface',
        params: {
            service: 'XydTixiAbi',
        },
        defaultProps: {
            value: 'tixiAbiId',
            label: 'name',
        },
    },
]
data | tableInterface // 二选一
// 选择传入参数
data  // 外部传入表格数据
// 表格配置
tableConfig = {
    tableType: 'readonly', //只读表格
    total // 总数, 不传默认表格数据length
    dialogTitle: '体系能力', // 弹窗名称
    downloadFileName: '体系能力', // 下载文件名称
    relationParams: {
      // 关联查询参数
      // bindTixiAbi: 'tixiAbiId',
      // bindProject: '4c39869803e74f70837d15d39cbac651',
    },
    // 排序参数
    sortParams: [
      // {
      //   code: 'nodeValOhd',
      //   sortParams: 'buildDescSort',
      // },
    ],
}
// 表格接口 与 data 二选一
tableInterface = {
  service: 'XydTixiAbiIndex', // 表名称
  key: 'indexId', // 数据id
},
btns = [ //外部传入头部按钮  code与内部中queryBtns数组中的code一致会以为外部传入的为准 内部code['search', 'reset', 'add', 'delete', 'template', 'import', 'export'] 
  {
    code: 'search',
    type: 'primary',
    label: '查询',
    icon: 'el-icon-search',
    position: 'right', // 显示在右侧，默认显示在左侧
  },
]
```

### 示例

- Crud表格

```vue
<template>
  <div class="common-page"  >
    <BizTable :tableInterface="tableInterface" :columnList="columnList" :tableConfig="tableConfig" />
  </div>
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
export default {
  name: 'BizTable',
  components: { BizTable },
  data() {
    return {
        columnList: [
            {
                type: 'selection',
            },
            {
                type: 'index',
            },
            {
                code: 'name',
                label: '名称',
                query: true,
                required: true,
                type: 'input',
            },
            {
                code: 'code',
                label: '标识',
                type: 'input',
            },
            {
                code: 'type',
                label: '类型',
                type: 'select',
                dataType: 'enum',
                params: 'nodeType',
            },
            {
                code: 'value',
                label: '值',
                type: 'number',
            },
            {
                code: 'describe',
                label: '描述',
                type: 'textarea',
            },
            {
                label: '操作',
                type: 'button',
                width: '160',
                buttonList: [
                    {
                        emitCode: 'edit',
                        label: '编辑',
                    },
                    {
                        emitCode: 'delete',
                        type: 'danger',
                        label: '删除',
                    },
                ],
            },
        ],
        tableConfig: {
            dialogTitle: '体系能力',
            downloadFileName: '体系能力',
            relationParams: {
                // 关联查询参数
                // bindTixiAbi: 'tixiAbiId',
            },
            // 排序参数
            sortParams: [
                // {
                //   code: 'nodeValOhd',
                //   sortParams: 'buildDescSort',
                // },
            ],
        },
        tableInterface: {
            service: 'XydTixiAbiIndex',
            key: 'indexId',
        },
    },
    mounted() {
        this.setTableRelationParams()
    },
    methods: {
        // 设置关联参数
        setTableRelationParams() {
            this.tableConfig.relationParams = {
            // bindTixiAbi: 'tixiAbiId',
            bindProject: '4c39869803e74f70837d15d39cbac651',
            }
        },
    },
  }
}
</script>
```

- 只读表格

```vue
<template>
  <div class="common-page"  >
    <BizTable :tableInterface="tableInterface" :columnList="columnList" :tableConfig="tableConfig" />
  </div>
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
export default {
  name: 'BizTable',
  components: { BizTable },
  data() {
    return {
        columnList: [
            {
                type: 'selection',
            },
            {
                type: 'index',
            },
            {
                code: 'name',
                label: '名称',
                query: true,
                required: true,
                type: 'input',
            },
            {
                code: 'code',
                label: '标识',
                type: 'input',
            },
            {
                code: 'type',
                label: '类型',
                type: 'select',
                dataType: 'enum',
                params: 'nodeType',
            },
            {
                code: 'value',
                label: '值',
                type: 'number',
            },
            {
                code: 'describe',
                label: '描述',
                type: 'textarea',
            },
        ],
        tableConfig: {
            tableType: 'readonly',
            dialogTitle: '体系能力',
            downloadFileName: '体系能力',
            relationParams: {
                // 关联查询参数
                // bindTixiAbi: 'tixiAbiId',
            },
            // 排序参数
            sortParams: [
                // {
                //   code: 'nodeValOhd',
                //   sortParams: 'buildDescSort',
                // },
            ],
        },
        tableInterface: {
            service: 'XydTixiAbiIndex',
            key: 'indexId',
        },
    },
    mounted() {
        this.setTableRelationParams()
    },
    methods: {
        // 设置关联参数
        setTableRelationParams() {
            this.tableConfig.relationParams = {
            // bindTixiAbi: 'tixiAbiId',
            bindProject: '4c39869803e74f70837d15d39cbac651',
            }
        },
    },
  }
}
</script>
```

- 编辑表格

> 只要表格列中存在isEdit为true 则默认该表格为编辑表格

|目前支持        |类型          |
|------------|--------------|
|下拉框       |select       |
|单选框       |radio       |
|多选框       |checkbox       |
|树形下拉框       |treeselect       |
|数字框       |number       |
|文本域       |textarea       |
|输入框       |input       |
|时间选择器       |time       |
|日期选择器       |date       |
|日期时间选择器       |datetime       |
|Switch 开关       |switch       |
|slider 滑块       |slider       |
|颜色选择器       |color       |

```vue
<template>
  <div class="common-page"  >
    <BizTable :tableInterface="tableInterface" :columnList="columnList" :tableConfig="tableConfig" />
  </div>
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
export default {
  name: 'BizTable',
  components: { BizTable },
  data() {
    return {
         columnList: [
            {
                type: 'selection',
            },
            {
                type: 'index',
            },
            {
                code: 'name',
                label: '名称',
                query: true,
                required: true,
                type: 'input',
                isEdit: true,
            },
            {
                code: 'code',
                label: '标识',
                type: 'input',
                isEdit: true,
            },
            {
                code: 'type',
                label: '类型',
                type: 'select',
                dataType: 'enum',
                params: 'nodeType',
                isEdit: true,
            },
            {
                code: 'value',
                label: '值',
                type: 'number',
                isEdit: true,
            },
            {
                code: 'describe',
                label: '描述',
                type: 'textarea',
                isEdit: true,
            },
            {
            label: '操作',
            type: 'button',
            buttonList: [
                {
                    emitCode: 'save',
                    label: '确定',
                },
                {
                    emitCode: 'delete',
                    type: 'danger',
                    label: '删除',
                },
            ],
            },
        ],
        tableConfig: {
            dialogTitle: '体系能力',
            downloadFileName: '体系能力',
            relationParams: {
                // 关联查询参数
                // bindTixiAbi: 'tixiAbiId',
            },
            // 排序参数
            sortParams: [
                // {
                //   code: 'nodeValOhd',
                //   sortParams: 'buildDescSort',
                // },
            ],
        },
        tableInterface: {
            service: 'XydTixiAbiIndex',
            key: 'indexId',
        },
    },
    mounted() {
        this.setTableRelationParams()
    },
    methods: {
        // 设置关联参数
        setTableRelationParams() {
            this.tableConfig.relationParams = {
            // bindTixiAbi: 'tixiAbiId',
            bindProject: '4c39869803e74f70837d15d39cbac651',
            }
        },
    },
  }
}
</script>
```

- 树形表格

```vue
<template>
  <div class="common-page">
    <BizTable
      :data="tableData"
      :columnList="tableColumns"
      :tableConfig="tableConfig"
      :tableInterface="tableInterface"
      @queryTable="queryTableData"
      default-expand-all
      row-key="organizationId"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
    />
  </div>
</template>
<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import { listToTree } from '@/utils/treeTool'

export default {
  name: 'OrganizationalManagement',
  data() {
    return {
      tableData: [],
      tableColumns: [
        {
          type: 'index',
        },
        {
          code: 'organizationName',
          label: '组织名称',
          type: 'input',
          query: true,
        },
        {
          code: 'organizationCode',
          label: '组织标识',
          type: 'input',
        },
        {
          code: 'parentId',
          label: '上级组织',
          type: 'treeselect',
          isColumnHide: true,
        },
        {
          code: 'organizationManNum',
          label: '人员数量',
          type: 'input',
        },
        {
          code: 'organizationPosition',
          label: '位置',
          type: 'input',
        },
        {
          code: 'organizationIcon',
          label: '图标',
          type: 'picture',
        },
        {
          code: 'organizationDescription',
          label: '描述',
          type: 'textarea',
        },
        {
          label: '操作',
          type: 'button',
          width: '160',
          buttonList: [
            {
              emitCode: 'edit',
              label: '编辑',
            },
            {
              emitCode: 'delete',
              type: 'danger',
              label: '删除',
            },
          ],
        },
      ],
      tableConfig: {
        dialogTitle: '组织',
        downloadFileName: '组织',
        showPagination: false,
        relationParams: {
          // 关联查询参数
          // bindTixiAbi: 'tixiAbiId',
          // bindProject: '4c39869803e74f70837d15d39cbac651',
        },
        // 排序参数
        sortParams: [
          // {
          //   code: 'nodeValOhd',
          //   sortParams: 'buildDescSort',
          // },
        ],
      },
      tableInterface: {
        service: 'BqtyOrganization', // 表名称
        key: 'organizationId', // 数据id
      },
    }
  },
  async created() {
    await this.queryTableData()
    this.$nextTick(() => {
      const index = this.tableColumns.findIndex((item) => item.code === 'parentId')
      this.tableColumns[index].options = this.tableData
    })
  },
  methods: {
    async queryTableData() {
      let queryCondition = QueryConditionBuilder.getInstanceNoPage()
      const { data } = await this.onQueryTableDataAPI(queryCondition)
      const listData = (data || []).map((item) => {
        return {
          ...item,
          id: item.organizationId,
          label: item.organizationName,
        }
      })
      this.tableData = listToTree(listData, { idKey: 'organizationId' })
    },
    // 获取表格数据API
    async onQueryTableDataAPI(queryCondition) {
      return await this.$getInterface(this.tableInterface.service, 'query')(queryCondition)
    },
  },
  components: { BizTable },
}
</script>
```

- 合并表格

```vue
<template>
  <div class="common-page"  >
   <BizTable :data="tableData" :columnList="tableColumns" />
   <!-- 树形表格 -->
   <!-- <BizTable :data="tableData" :columnList="tableColumns" row-key="id" default-expand-all :tree-props="{ children: 'children', hasChildren: 'hasChildren' }" /> -->
  </div>
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
export default {
  name: 'BizTable',
  components: { BizTable },
  data() {
    return {
        tableColumns: [
        {
          code: 'name',
          label: '姓名',
          type: 'input',
          query: true,
          coalitionId: 'coalitionId', // 合并条件
        },
        {
          code: 'date',
          label: '日期',
          type: 'date',
        },
        {
          code: 'address',
          label: '地址',
          type: 'textarea',
        },
      ],
     tableData: [
        {
          id: 1,
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          coalitionId: '1',
        },
        {
          id: 2,
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄',
          coalitionId: '1',
        },
        {
          id: 3,
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄',
          coalitionId: '3',
          children: [
            {
              id: 31,
              date: '2016-05-01',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1519 弄',
              coalitionId: '31',
            },
            {
              id: 32,
              date: '2016-05-01',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1519 弄',
              coalitionId: '31',
            },
          ],
        },
        {
          id: 4,
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄',
          coalitionId: '4',
        },
      ],
    },
  }
}
</script>
```
### 方法

- insert 外部传入新增逻辑
- update 外部传入更新逻辑
- delete 外部传入删除逻辑
- export 外部传入导出逻辑
- import 外部传入导入逻辑
- exportTemp 外部传入新导出模板逻辑
- save 行内编辑表格外部传入保存逻辑

自定义的操作栏按钮也会根据code派发出来
