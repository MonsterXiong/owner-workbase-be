<template>
  <TableLayout ref="tableLayoutRef">
    <template #query>
      <InlineForm v-if="config.isQueryForm" :formItems="formItems" :btnList="queryFormBtns" @btnFn="handleBtnFn"></InlineForm>
    </template>
    <Table
      ref="tableRef"
      v-bind="$attrs"
      v-on="$listeners"
      :height="tableHeight"
      :columnList="tableColumns"
      :data="tableData"
      :total="total"
      :config="config"
      :span-method="objectSpanMethod"
      border
      @btnClick="handleBtnClick"
      @selection-change="handleSelectionChange"
      @updateTable="handleUpdateTable"
    >
      <template v-for="item in tableColumns" v-slot:[item.code]="{ scope }">
        <slot :name="item.code" :scope="scope"></slot>
      </template>
    </Table>
    <FileUpload ref="fileUploadRef" @callBack="onUploadFile" />
    <slot name="dialog">
      <FormDialog ref="tableFormDialogRef" :config="config" @update="onFormDialogUpdate" />
    </slot>
  </TableLayout>
</template>

<script>
import TableLayout from '@/baseComponents/tableLayout/TableLayout.vue'
import Table from '@/components/basicTable/Table.vue'
import InlineForm from '@/components/basicForm/InlineForm.vue'
import FileUpload from '@/components/upload/uploadDialog.vue'
import FormDialog from '@/components/basicForm/FormDialog.vue'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import { isFunction, mergeObj, exportFile, isObject } from '@/utils/commonUtil.js'
import { listToTree, treeToList } from '@/utils/treeTool'
import configData from '@/utils/config'
import tools from '@/utils/tools'
import moment from 'moment'
import { uuid } from '@/utils/commonUtil'

const baseTableConfig = {
  showPagination: true,
  isQueryForm: true,
}

// 头部默认按钮的显示
const queryBtnVisible = {
  search: true,
  reset: true,
  add: true,
  delete: true,
  template: true,
  import: true,
  export: true,
}

export default {
  name: 'BizTable',
  props: {
    data: {
      type: Array,
    },
    columnList: {
      type: Array,
      default: () => [],
    },
    btns: {
      type: Array,
      default: () => [],
    },
    tableConfig: {
      type: Object,
      default: () => {},
    },
    tableInterface: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      queryForm: {},
      tableData: [],
      queryBtns: [
        {
          code: 'search',
          type: 'primary',
          label: '查询',
          icon: 'el-icon-search',
        },
        {
          code: 'reset',
          label: '重置',
          icon: 'el-icon-refresh-right',
        },
        {
          code: 'add',
          type: 'success',
          label: '新增',
          icon: 'el-icon-circle-plus-outline',
        },
        {
          code: 'delete',
          type: 'danger',
          label: '批量删除',
          icon: 'el-icon-delete',
          disabled: this.deleteDisabled,
        },
        {
          code: 'template',
          type: 'primary',
          label: '下载模板',
          icon: 'el-icon-download',
        },
        {
          code: 'import',
          type: 'primary',
          label: '导入',
          icon: 'el-icon-upload',
        },
        {
          code: 'export',
          type: 'primary',
          label: '导出',
          icon: 'el-icon-download',
          // position: 'right',
        },
      ],
      multipleSelection: [],
      formItems: [],
      pageInfo: {
        page: 1,
        rows: 20,
      },
      total: 0,
      tableHeight: 300,
      columnIndexList: [],
    }
  },
  computed: {
    config() {
      return mergeObj(baseTableConfig, queryBtnVisible, this.tableConfig)
    },
    tableColumns() {
      if (this.tableConfig?.tableType === 'readonly') {
        return this.columnList.filter((item) => item.type !== 'button' && !item.isColumnHide)
      } else {
        return this.columnList.filter((item) => !item.isColumnHide)
      }
    },
    queryFormBtns() {
      let queryBtns = this.queryBtns.filter((item) => this.config[item.code] && !this.btns.find((btn) => btn.code === item.code)).concat(this.btns)
      if (this.config.tableType === 'readonly') {
        queryBtns = queryBtns.filter((item) => !['add', 'delete'].includes(item.code))
      }
      return queryBtns
    },
    tableInterfaceUrl() {
      return this.tableInterface.service
    },
    // 外部传入表格数据
    isExternalData() {
      return this.data
    },
  },
  created() {},
  async mounted() {
    // 等待column中options设置完毕
    await this.setColumnOptions()
    await this.queryTableData()
    this.$nextTick(() => {
      this.formItems = [...this.columnList]
      // 防止表格计算高度后显示滚动条
      let timer = setTimeout(() => {
        this.setTableHeight()
        clearTimeout(timer)
      }, 0)
    })
  },
  methods: {
    async queryTableData() {
      // 外部表格数据赋值
      if (this.isExternalData) {
        this.tableData = [...this.data]
        this.total = this.tableConfig?.total || this.tableData.length
        return
      }
      try {
        // 获取表格数据
        const { data, count } = await this.onQueryTableDataAPI(this.getQueryParams())
        this.tableData = data || []
        this.total = count
      } catch (error) {
        console.error(error)
      }
    },
    // 设置查询条件
    getQueryParams() {
      let params = this.config.showPagination
        ? QueryConditionBuilder.getInstance(this.pageInfo.page, this.pageInfo.rows)
        : QueryConditionBuilder.getInstanceNoPage()

      // params.buildAscSort('sysSort')
      Object.keys(this.queryForm).forEach((key) => {
        if (this.queryForm[key] || this.queryForm[key] == 0) {
          params.buildLikeQuery(key, this.queryForm[key])
        }
      })
      // 排序参数
      if (this.config.sortParams) {
        this.config.sortParams.forEach((item) => {
          params[item.sortParams](item.code)
        })
      }
      // 关联参数
      if (this.config.relationParams) {
        Object.keys(this.config.relationParams).forEach((key) => {
          if (this.config.relationParams[key] || this.config.relationParams[key] == 0) {
            if (this.config.relationParams[key] === (this.$attrs.defaultProps?.id || 'id'))
              params.buildEqualQuery(key, this.currentNode[this.config.relationParams[key]])
            else params.buildEqualQuery(key, this.config.relationParams[key])
          }
        })
      }
      // 自定义查询条件
      if (this.config.getParamsHook && isFunction(this.config.getParamsHook)) {
        params = this.config.getParamsHook()
        if (this.config.showPagination) mergeObj(params, this.pageInfo)
      }
      return params
    },
    // 设置column中的options
    async setColumnOptions() {
      const instanceItems = this.columnList.filter((item) => item.dataType === 'interface')
      const enumItems = this.columnList.filter((item) => item.dataType === 'enum')
      // 枚举
      enumItems.forEach((ele) => {
        const index = this.columnList.findIndex((item) => item.code === ele.code)
        this.columnList[index] = {
          ...this.columnList[index],
          options: [...this.$enum.getOption(ele.params)],
        }
      })
      // 接口
      const instanceMap = new Map()
      instanceItems.forEach((item) => {
        const optService = item.params.service
        instanceMap.set(optService, instanceMap.get(optService) ? instanceMap.get(optService).concat(item.code) : [item.code])
      })
      for (const iterator of instanceMap) {
        const { data } = await this.getInstanceOption(iterator[0])
        if (iterator[1]?.length > 0) {
          // 设置columns
          iterator[1].forEach((code) => {
            const index = this.columnList.findIndex((item) => item.code === code)
            const itemData = this.columnList[index]
            let optionData = [...data]
            // 处理树形数据
            if (['treeselect'].includes(itemData.type)) {
              const listData = data.map((item) => {
                return {
                  ...item,
                  id: item[itemData.defaultProps.id],
                  label: item[itemData.defaultProps.label],
                  parentId: item[itemData.defaultProps.parentId],
                }
              })
              optionData = listToTree(listData)
              console.log(optionData, 'optionData-----')
            }
            this.columnList[index] = {
              ...this.columnList[index],
              options: optionData,
            }
          })
        }
      }
    },
    // 行内表单操作事件
    handleBtnFn(code, data) {
      switch (code) {
        case 'search':
          this.handleSearch(data)
          break
        case 'reset':
          this.handleReset()
          break
        case 'add':
          this.handleAdd()
          break
        case 'delete':
          this.handleDeleteBatch()
          break
        case 'template':
          this.handleTemplateExport()
          break
        case 'import':
          this.handleImport()
          break
        case 'export':
          this.handleExport()
          break
        default:
          // 处理行内表单其它事件
          this.$emit(code, data)
          break
      }
    },
    handleSearch(formData) {
      this.queryForm = { ...formData }
      this.handleExternalData()
      this.queryTableData()
    },
    handleReset() {
      this.queryForm = {}
      this.pageInfo = {
        page: 1,
        rows: 20,
      }
      this.handleExternalData()
      this.queryTableData()
    },
    handleAdd() {
      if (this.$listeners.add) return this.$emit('add')
      const formData = {}
      // 设置多选框|多选下拉框为数组
      this.handleFormItemAttrValue(formData)
      // 表格项中存一个编辑项则默认为编辑表格
      const isEdit = this.columnList.find((item) => item.isEdit)
      if (isEdit) {
        if (this.isFunction(this.$listeners.editTableInsertPrams)) return this.$emit('editTableInsertPrams', formData)
        // 行内新增默认只增加数据id
        this.tableData.push({
          _id: uuid(),
        })
      } else {
        this.$refs.tableFormDialogRef.show(`新增${this.config.dialogTitle}`, this.columnList, formData)
      }
    },
    handleEdit(row) {
      const rowData = { ...row }
      if (this.$listeners.edit) return this.$emit('edit', rowData)
      this.handleFormItemAttrValue(rowData, row)
      this.$refs.tableFormDialogRef.show(`编辑${this.config.dialogTitle}`, this.columnList, rowData)
    },
    // 编辑表格保存
    async handleSave(row) {
      const formData = this.handlerSubmitParams(row)
      if (isFunction(this.$listeners.save)) return this.$emit('save', formData)
      await this.onSaveDataAPI(formData)
      this.$nextTick(() => {
        tools.message('操作成功')
        this.handleExternalData()
        this.queryTableData()
      })
    },
    async onFormDialogUpdate(data, code) {
      const formData = this.handlerSubmitParams(data)
      if (isFunction(this.$listeners.insert)) return this.$emit('insert', formData)
      if (isFunction(this.$listeners.update)) return this.$emit('update', formData)
      if (formData[this.tableInterface.key]) {
        // 编辑
        await this.onUpdateDataAPI(formData)
      } else {
        await this.onInsertDataAPI(formData)
      }
      this.$nextTick(() => {
        tools.message('操作成功')
        this.handleExternalData()
        this.queryTableData()
      })
    },
    // 简单处理提交之前的参数
    handlerSubmitParams(data) {
      const formData = { ...data }
      this.handleFormItemAttrValue(formData, data, 'update')
      const timeItems = this.columnList.filter((item) => ['time', 'date', 'datetime'].includes(item.type))
      timeItems.forEach((item) => {
        const formatCode = item.dataFormat ? item.dataFormat : item.type === 'time' ? 'HH:mm:ss' : item.type === 'date' ? 'YYYY-MM-DD' : 'YYYY-MM-DD HH:mm:ss'
        formData[item.code] = data[item.code] ? moment(data[item.code]).format(formatCode) : ''
      })
      // 处理关联参数
      for (const key in this.config.relationParams) {
        formData[key] = this.config.relationParams[key]
      }
      return formData
    },
    // 表格操作
    handleBtnClick(code, row) {
      switch (code) {
        case 'edit':
          this.handleEdit(row)
          break
        case 'delete':
          this.handleDelete(row)
          break
        case 'save':
          this.handleSave(row)
          break
        default:
          // 其它事件
          this.$emit(code, row)
          break
      }
    },
    handleDeleteBatch() {
      const ids = this.multipleSelection.map((item) => item[this.tableInterface.key])
      this.onDeleteDataFn(ids)
    },
    handleDelete(row) {
      this.onDeleteDataFn(row[this.tableInterface.key])
    },
    async onDeleteDataFn(ids) {
      try {
        await tools.confirm('请确认是否删除')
        if (isFunction(this.$listeners.delete)) return this.$emit('delete', ids)
        await this.ondeleteDataAPI(ids)
        this.$nextTick(() => {
          tools.message('操作成功')
          this.handleExternalData()
          this.queryTableData()
        })
      } catch (error) {
        console.error(error)
      }
    },
    async handleTemplateExport() {
      if (isFunction(this.$listeners.exportTemp)) return this.$emit('exportTemp')
      const fileData = await this.onDownloadTemplateAPI()
      if (fileData) exportFile(`${this.config.downloadFileName}模板.xlsx`, fileData, 'application/vnd.ms-excel')
    },
    handleImport() {
      // 显示导入文件弹窗
      this.$refs.fileUploadRef.show()
    },
    async handleExport() {
      await tools.confirm('请确认是否导出')
      if (isFunction(this.$listeners.export)) return this.$emit('export')
      let queryCondition = QueryConditionBuilder.getInstanceNoPage()
      let fileData = await this.onExportAPI(queryCondition)
      this.$nextTick(() => {
        if (fileData) exportFile(`${this.config.downloadFileName}.xlsx`, fileData, 'application/vnd.ms-excel')
      })
    },
    async onUploadFile(fileList) {
      if (fileList.length === 0) return tools.message('请选择导入文件', { type: 'warning' })
      let file = fileList[0].raw
      try {
        if (isFunction(this.$listeners.import)) return this.$emit('import', file)
        let res = await this.onImportAPI(file)
        this.queryTableData()
        tools.message(res.message, { type: res.code == 200 ? 'success' : 'warning' })
      } catch (error) {
        console.error(error)
      }
    },
    // 处理多选和switch的值
    handleFormItemAttrValue(formData, data = {}, type) {
      const formItems = this.columnList.filter((item) => item.type === 'checkbox' || (item.type === 'select' && item.multiple))
      const switchItems = this.columnList.filter((item) => item.type === 'switch')
      formItems.forEach((item) => {
        formData[item.code] = data[item.code]?.join(',') || []
      })
      switchItems.forEach((item) => {
        formData[item.code] = data[item.code] == 1 && data[item.code] == true ? (type ? 1 : true) : type ? 0 : false
      })
      const multipleFile = this.columnList.filter((item) => ['picture'].includes(item.type) && item.multiple)
      multipleFile.forEach((item) => {
        if (item.fileViewList && type) {
          formData[item.code] = item.fileViewList.map((ele) => ele.url.replace(configData.baseUrl, '')).join(',')
        } else {
          item.fileViewList = (data[item.code]?.split(',') || []).map((url) => {
            return {
              url: url.replace(configData.baseUrl, ''),
            }
          })
          formData[item.code] = item.fileViewList[0]?.url || ''
        }
      })
    },
    objectSpanMethod({ rowIndex, columnIndex }) {
      let spanArr = []
      if (this.columnList[columnIndex]) {
        if (this.columnList[columnIndex].coalitionId) {
          let data = JSON.parse(JSON.stringify(this.tableData))
          if (isObject(this.$attrs['tree-props'])) data = treeToList(data)
          spanArr = this.setSpanArr(data, this.columnList[columnIndex].coalitionId)
        }
        if (this.columnIndexList.includes(columnIndex)) {
          const _row = spanArr[rowIndex]
          const _col = _row > 0 ? 1 : 0
          return {
            rowspan: _row,
            colspan: _col,
          }
        }
      }
    },
    setSpanArr(data, codeId) {
      // 初始化
      let spanArr = []
      let pos = 0
      for (let i = 0; i < data.length; i++) {
        // 第一条数据
        if (i === 0) {
          spanArr.push(1)
          pos = 0
        } else {
          // 判断当前行的任务codeId与上一行的任务codeId是否相同
          if (data[i][codeId] === data[i - 1][codeId]) {
            spanArr[pos] += 1
            spanArr.push(0)
          } else {
            spanArr.push(1)
            pos = i
          }
        }
      }
      return spanArr
    },
    setColumnArr(array) {
      this.columnIndexList.length = 0
      for (let i = 0; i < array.length; i++) {
        const element = array[i]
        if (element.coalitionId) {
          this.columnIndexList.push(i)
        }
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    deleteDisabled() {
      return this.multipleSelection.length < 1
    },
    // 处理分页
    handleUpdateTable(pageInfo) {
      if (this.isExternalData) {
        // 给父组件派发事件
        this.$emit('updateTable', { ...pageInfo })
      } else {
        this.pageInfo = { ...pageInfo }
        this.queryTableData()
      }
    },
    // 外部查询
    handleExternalData() {
      if (this.isExternalData) return this.$emit('queryTable', { ...this.queryForm, pageInfo: { ...this.pageInfo } })
    },
    setTableHeight() {
      console.log(this.$refs.tableLayoutRef.$el.offsetHeight)
      this.tableHeight = this.$refs.tableLayoutRef.$el.offsetHeight - (this.config.isQueryForm ? 98 : 20)
    },
    async getInstanceOption(optInterface, params) {
      return await this.$getInterface(optInterface, 'query')(params)
    },
    // 获取表格数据API
    async onQueryTableDataAPI(queryCondition) {
      return await this.$getInterface(this.tableInterfaceUrl, 'query')(queryCondition)
    },
    // 新增API
    async onInsertDataAPI(params) {
      return await this.$getInterface(this.tableInterfaceUrl, 'insert')(params)
    },
    // 编辑API
    async onUpdateDataAPI(params) {
      return await this.$getInterface(this.tableInterfaceUrl, 'update')(params)
    },
    // 删除API
    async ondeleteDataAPI(ids) {
      return await this.$getInterface(this.tableInterfaceUrl, 'deleteBatch')(ids)
    },
    // 保存API
    async onSaveDataAPI(params) {
      return await this.$getInterface(this.tableInterfaceUrl, 'save')(params)
    },
    // 下载模板API
    async onDownloadTemplateAPI() {
      return await this.$getInterface(this.tableInterfaceUrl, 'download')()
    },
    // 导入API
    async onImportAPI(file) {
      return await this.$getInterface(this.tableInterfaceUrl, 'import')(file)
    },
    // 导出API
    async onExportAPI(queryCondition) {
      return await this.$getInterface(this.tableInterfaceUrl, 'export')(queryCondition)
    },
  },
  components: { TableLayout, InlineForm, Table, FileUpload, FormDialog },
  watch: {
    tableConfig: {
      handler() {
        this.queryTableData()
      },
      deep: true,
    },
    columnList: {
      handler(val) {
        if (val) {
          this.setColumnArr(val)
        }
      },
      immediate: true,
    },
    data() {
      this.queryTableData()
    },
  },
}
</script>

<style lang="less" scoped></style>
