<template>
  <PanelLayout>
    <template v-slot:left>
      <BizTree
        :listTitle="$attrs.listTitle"
        :treeListConfig="$attrs.treeListConfig"
        :treeListNodeConfig="treeListNodeConfig"
        :defaultSelId="$attrs.defaultSelId"
        @changeCurrentNode="onNodeClick"
      ></BizTree>
    </template>
    <!-- 传入tableInterface则走内部逻辑，传入方法则对应逻辑在当前页面处理 insert|update|delete|export|import -->
    <BizOrg
      ref="bizOrgRef"
      :nodeConfig="orgNodeConfig"
      :mode="$attrs.mode || ''"
      :forbidDeleteIds="$attrs.forbidDeleteIds || []"
      :textList="$attrs.textList || []"
      v-on="$listeners"
    ></BizOrg>
  </PanelLayout>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BizTree from '@/bizComponents/bizTree/BizTree.vue'
import BizOrg from '@/bizComponents/bizOrg/BizOrg.vue'
import { mergeObj } from '@/utils/commonUtil'

export default {
  name: 'LeftTreeAndRightTable',
  props: {
    treeListNodeConfig: {
      type: Array,
    },
    nodeConfig: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      currentNode: null,
      tableData: [],
      pageInfo: {
        page: 1,
        rows: 20,
      },
      orgNodeConfig: [],
      queryForm: {},
    }
  },
  watch: {
    nodeConfig: {
      handler(val) {
        this.orgNodeConfig = JSON.parse(JSON.stringify(val))
      },
      immediate: true,
    },
  },
  methods: {
    onNodeClick(node) {
      this.currentNode = { ...node }
      let config = this.treeListNodeConfig[0] || null
      if (node.type) {
        config = this.treeListNodeConfig.find((ele) => ele.code == node.type) || null
      }
      if (config) {
        let params = {}
        if (config.queryRelateCondition) {
          for (const key in config.queryRelateCondition) {
            params[key] = node[config.queryRelateCondition[key]]
          }
        } else {
          params[config.defaultProps.id] = node.id
        }
        console.log(params, 8888)
        this.orgNodeConfig.forEach((ele) => {
          let element = this.nodeConfig.find((i) => i.code == ele.code)
          let relationParams = { ...element?.relationParams }
          for (const key in params) {
            if (ele?.relationParams[key] != undefined) {
              relationParams[key] = params[key]
            }
          }
          ele.relationParams = { ...relationParams }
        })
        this.$refs.bizOrgRef.formatData()
        this.$emit('nodeClick', { ...node })
      }
      console.log(this.transTableConfig, config, 'hahahahh')
    },
  },
  components: { PanelLayout, BizTree, BizOrg },
}
</script>
