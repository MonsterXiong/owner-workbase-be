<template>
  <PanelLayout>
    <template v-slot:left>
      <BizList
        :listTitle="$attrs.listTitle"
        :formItems="$attrs.formItems"
        :defaultProps="defaultProps"
        :listInterface="$attrs.listInterface"
        :listConfig="$attrs.listConfig"
        @change="onNodeClick"
      ></BizList>
    </template>
    <BizOrg
      ref="bizOrgRef"
      :nodeConfig="orgNodeConfig"
      :mode="$attrs.mode || ''"
      :forbidDeleteIds="$attrs.forbidDeleteIds || []"
      :textList="$attrs.textList || []"
      v-on="$listeners"
    ></BizOrg>
  </PanelLayout>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BizList from '@/bizComponents/bizList/BizList.vue'
import BizOrg from '@/bizComponents/bizOrg/BizOrg.vue'

export default {
  name: 'LeftListAndRightTable',
  props: {
    nodeConfig: {
      type: Array,
      default: () => [],
    },
    defaultProps: {
      type: Object,
    },
  },
  data() {
    return {
      currentNode: null,
      tableData: [],
      pageInfo: {
        page: 1,
        rows: 20,
      },
      orgNodeConfig: [],
      queryForm: {},
    }
  },
  watch: {
    nodeConfig: {
      handler(val) {
        this.orgNodeConfig = JSON.parse(JSON.stringify(val))
      },
      immediate: true,
    },
  },
  methods: {
    onNodeClick(node) {
      this.currentNode = { ...node }
      this.orgNodeConfig.forEach((ele) => {
        if (ele?.relationParams[this.defaultProps.id] != undefined) {
          ele.relationParams = {
            ...ele?.relationParams,
            [this.defaultProps.id]: node[this.defaultProps.id],
          }
        }
      })
      this.$refs.bizOrgRef.formatData()
      this.$emit('nodeClick', { ...node })
    },
  },
  components: { PanelLayout, BizList, BizOrg },
}
</script>
