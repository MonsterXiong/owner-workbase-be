## 列表组件

> 基于list组件渲染，内部处理相关接口逻辑

### 示例

```vue
<template>
    <div class="common-page">
        <BizList
            :listTitle="listTitle"
            :formItems="formItems"
            :defaultProps="defaultProps"
            :listInterface="listInterface"
            :listConfig="listConfig"
            @change="onNodeClick"
        ></BizList>
    </div>
</template>

<script>
import BizList from '@/bizComponents/bizList/BizList.vue'
export default {
  name: 'BizList',
  data() {
    return {
      currentNode: null, // 当前选中节点数据
      listTitle: 'xxx列表', // 列表名称
      // 列表表单配置项
      formItems: [
        {
          code: 'name',
          label: '能力名称',
          required: true,
          type: 'input',
        },
        {
          code: 'code',
          label: '能力标识',
          required: true,
          type: 'input',
        },
        {
          code: 'description',
          label: '能力描述',
          type: 'textarea',
        },
      ],
      // 列表数据配置
      defaultProps: {
        id: 'tixiAbiId',
        name: 'name',
      },
      // 列表接口
      listInterface: {
        service: 'XydTixiAbi',
        key: 'tixiAbiId',
      },
      listConfig: {
        dialogTitle: '作战能力',
        // isEdit: true,
        // allowAdd: true,
        // isFilter: true,
      },
    }
  },
  methods: {
    // 节点点击事件
    onNodeClick(node) {
      this.currentNode = { ...node }
    },
  },
}
</script>
```

### 配置项详情

```javascript
// 必传参数
listTitle = '能力列表' //列表头部名称
data | listInterface //二选一
// 选中传入参数
data // 列表数据
formItems = [ // 弹窗表单配置项
    {
        code: 'name',
        label: '能力名称',
        required: true,
        type: 'input',
    },
]
// 列表数据配置
defaultProps = {
    id: 'tixiAbiId',
    name: 'name',
},
// 列表接口
listInterface = {
    service: 'XydTixiAbi',
    key: 'tixiAbiId',
},
// 列表配置项
listConfig = {
    dialogTitle: '作战能力', // 弹窗名称
    isEdit: true, // 显示编辑、删除图标按钮
    allowAdd: true, // 显示头部添加按钮
    isFilter: true, // 显示搜索
},

```

### 方法

- change 点击节点
- insert 外部新增逻辑
- update 外部更新逻辑
- delete 外部删除逻辑
自定义的按钮事件会根据对应code派发出来