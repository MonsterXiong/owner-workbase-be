<template>
  <div class="common-page">
    <List
      :title="listTitle"
      :data="listData"
      :defaultProps="defaultProps"
      :config="config"
      @change="onNodeClick"
      @iconClick="onIconClick"
      @add="onAdd"
      @query="onQuery"
    />
    <slot name="dialog">
      <FormDialog ref="listDialogRef" @update="onFormDialogUpdate" />
    </slot>
  </div>
</template>

<script>
import List from '@/components/list/List.vue'
import FormDialog from '@/components/basicForm/FormDialog.vue'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import { isFunction, mergeObj, exportFile } from '@/utils/commonUtil.js'
import tools from '@/utils/tools'
import moment from 'moment'

const baseConfig = {
  isFilter: false,
  allowAdd: false,
  isEdit: false,
}

export default {
  name: 'BizList',
  props: {
    listTitle: {
      type: String,
    },
    data: {
      type: Array,
      default: () => [],
    },
    formItems: {
      type: Array,
      default: () => [],
    },
    defaultProps: {
      type: Object,
      default: () => {},
    },
    listConfig: {
      type: Object,
      default: () => {},
    },
    listInterface: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      searchVal: '',
      listData: [],
      currentNode: null,
    }
  },
  computed: {
    config() {
      return mergeObj(baseConfig, this.listConfig)
    },
    listInterfaceUrl() {
      return this.listInterface.service
    },
    listFormItems() {
      return this.formItems
    },
  },
  mounted() {
    console.log(this.$listeners, 'listeners--------------')
    this.queryListData()
  },
  methods: {
    onNodeClick(data) {
      // console.log(data, 'onNodeClick-------------')
      this.currentNode = { ...data }
      this.$emit('change', this.currentNode)
    },
    onIconClick({ code, data }) {
      // console.log(code, data, 'onIconClick-------------')
      switch (code) {
        case 'add':
          this.onAdd()
          break
        case 'edit':
          this.onEdit(data)
          break
        case 'delete':
          this.onDeleteDataFn(data[this.listInterface.key])
          break
        default:
          this.$emit(code, { ...data })
          break
      }
    },
    async queryListData() {
      if (this.data.length) return (this.listData = [...this.data])
      try {
        // 获取列表数据
        const { data } = await this.onQueryListDataAPI(this.getQueryParams())
        this.listData = (data || []).map((item) => {
          return {
            ...item,
            [this.defaultProps?.id || 'id']: item[this.defaultProps?.id || 'id'],
            [this.defaultProps?.name || 'name']: item[this.defaultProps?.name || 'name'],
            icons: this.config.isEdit
              ? [
                  // { icon: 'el-icon-circle-plus-outline', name: '新增', code: 'add' },
                  { icon: 'el-icon-edit', name: '编辑', code: 'edit' },
                  { icon: 'el-icon-delete', name: '删除', code: 'delete' },
                ]
              : null,
          }
        })
      } catch (error) {
        console.error(error)
      }
    },
    onQuery(val) {
      this.searchVal = val
      this.queryListData()
    },
    onAdd() {
      const fomrData = {}
      this.handleFormItemMultipleOrSwitch(fomrData)
      this.$refs.listDialogRef.show(`新增${this.config.dialogTitle}`, this.listFormItems, fomrData)
    },
    onEdit(row) {
      const rowData = { ...row }
      this.handleFormItemMultipleOrSwitch(rowData, row)
      this.$refs.listDialogRef.show(`编辑${this.config.dialogTitle}`, this.listFormItems, this.currentIconNode, rowData)
    },
    async onFormDialogUpdate(data) {
      const formData = { ...data }
      this.handleFormItemMultipleOrSwitch(formData, data)
      const timeItems = this.formItems.filter((item) => ['time', 'date', 'datetime'].includes(item.type))
      timeItems.forEach((item) => {
        const formatCode = item.dataFormat ? item.dataFormat : item.type === 'time' ? 'HH:mm:ss' : item.type === 'date' ? 'YYYY-MM-DD' : 'YYYY-MM-DD HH:mm:ss'
        formData[item.code] = data[item.code] ? moment(data[item.code]).format(formatCode) : ''
      })
      // 处理关联参数
      for (const key in this.config.relationParams) {
        formData[key] = this.config.relationParams[key]
      }
      if (isFunction(this.$listeners.insert)) return this.$emit('insert', formData)
      if (isFunction(this.$listeners.update)) return this.$emit('update', formData)
      if (formData[this.listInterface.key]) {
        // 编辑
        await this.onUpdateDataAPI(formData)
      } else {
        await this.onInsertDataAPI(formData)
      }
      this.$nextTick(() => {
        tools.message('操作成功')
        this.queryListData()
      })
    },
    async onDeleteDataFn(ids) {
      try {
        await tools.confirm('请确认是否删除')
        if (isFunction(this.$listeners.delete)) return this.$emit('delete', ids)
        await this.ondeleteDataAPI(ids)
        this.$nextTick(() => {
          tools.message('操作成功')
          this.queryListData()
        })
      } catch (error) {
        console.error(error)
      }
    },
    // 处理多选和switch的值
    handleFormItemMultipleOrSwitch(formData, data = {}) {
      const formItems = this.formItems.filter((item) => item.type === 'checkbox' || (item.type === 'select' && item.multiple))
      const switchItems = this.formItems.filter((item) => item.type === 'switch')
      formItems.forEach((item) => {
        formData[item.code] = data[item.code]?.join(',') || []
      })
      switchItems.forEach((item) => {
        formData[item.code] = data[item.code] == 1 && data[item.code] == true ? 1 : 0
      })
    },
    // 设置查询条件
    getQueryParams() {
      let params = QueryConditionBuilder.getInstanceNoPage()
      if (this.defaultProps?.name) params.buildLikeQuery(this.defaultProps.name, this.searchVal)
      // 关联参数
      if (this.config.relationParams) {
        Object.keys(this.config.relationParams).forEach((key) => {
          if (this.config.relationParams[key] || this.config.relationParams[key] == 0) {
            if (this.config.relationParams[key] === (this.$attrs.defaultProps?.id || 'id'))
              params.buildEqualQuery(key, this.currentNode[this.config.relationParams[key]])
            else params.buildEqualQuery(key, this.config.relationParams[key])
          }
        })
      }
      // 自定义查询条件
      if (this.config.getParamsHook && isFunction(this.config.getParamsHook)) {
        params = this.config.getParamsHook()
      }
      return params
    },
    // 获取列表数据API
    async onQueryListDataAPI(queryCondition) {
      return await this.$getInterface(this.listInterfaceUrl, 'query')(queryCondition)
    },
    // 新增API
    async onInsertDataAPI(params) {
      return await this.$getInterface(this.listInterfaceUrl, 'insert')(params)
    },
    // 编辑API
    async onUpdateDataAPI(params) {
      return await this.$getInterface(this.listInterfaceUrl, 'update')(params)
    },
    // 删除API
    async ondeleteDataAPI(ids) {
      return await this.$getInterface(this.listInterfaceUrl, 'deleteBatch')(ids)
    },
  },
  components: { List, FormDialog },
}
</script>

<style lang="less" scoped>
</style>
