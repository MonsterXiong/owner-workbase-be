<template>
  <div class="pro-select">
    <div class="select-input" @click.stop="showSelectTree">
      <span style="display: inline-block">{{ currentSelectName || placeholder }}</span>
      <i class="el-icon-caret-bottom"></i>
    </div>
    <div class="tree-container" v-show="isShow" v-click-outside="hide">
      <el-input
        v-model="filterText"
        placeholder="请输入关键词过滤"
        size="small"
        prefix-icon="el-icon-search"
        ref="inputRef"
        clearable
        @keyup.enter.native="onSearch"
      ></el-input>
      <el-tree :data="treeList" :props="treeProps" default-expand-all ref="treeRef" @node-click="selectNode">
        <span slot-scope="{ data }" :class="data[treeProps.id] === value ? 'active' : ''">
          {{ data[treeProps.label] }}
        </span>
      </el-tree>
      <el-pagination
        small
        layout="prev,pager,next"
        @size-change="handlePageSizeChange"
        @current-change="handleCurrentPageChange"
        :current-page="this.pageInfo.pageNumber"
        :page-sizes="[10, 20, 50, 100, 200]"
        :page-size="this.pageInfo.pageSize"
        :total="data.length"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      required: true,
    },
    placeholder: {
      type: String,
      default: '请选择',
    },
    props: {
      type: Object,
      default: () => ({
        children: 'children',
        label: 'name',
        id: 'id',
      }),
    },
    data: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      isShow: false,
      filterText: '',
      pageInfo: {
        pageSize: 10,
        pageNumber: 1,
        total: 0,
      },
    }
  },
  computed: {
    treeProps() {
      return {
        id: 'id',
        children: 'children',
        label: 'name',
        ...this.props,
      }
    },
    currentSelectName() {
      const findSelect = this.data.find((item) => item[this.treeProps.id] === this.value)
      if (findSelect) {
        return findSelect[this.treeProps.label]
      }
      return ''
    },
    filterData() {
      return this.data.filter((item) => item[this.treeProps.label].includes(this.filterText))
    },
    treeList() {
      return this.filterData.slice((this.pageInfo.pageNumber - 1) * this.pageInfo.pageSize, this.pageInfo.pageNumber * this.pageInfo.pageSize)
    },
  },
  methods: {
    onSearch() {},
    showSelectTree() {
      this.$nextTick(() => {
        this.isShow = true
        this.$nextTick(() => {
          this.$refs['inputRef'].focus()
        })
      })
    },
    handlePageSizeChange(rows) {
      this.pageInfo.pageSize = rows
    },
    handleCurrentPageChange(page) {
      this.pageInfo.pageNumber = page
    },
    selectNode(data) {
      this.$emit('input', data[this.treeProps.id])
      this.$emit('change', data[this.treeProps.id], data)
    },
    hide() {
      this.isShow = false
    },
  },
}
</script>

<style scoped lang="less">
.pro-select {
  position: relative;
  .select-input {
    width: 210px;
    display: inline-block;
    border: 1px solid @font-color;
    padding: 2px 10px;
    height: 28px;
    font-size: 14px;
    border-radius: 2px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-radius: 4px;
    cursor: pointer;
  }

  .tree-container {
    position: absolute;
    min-width: 200px;
    max-width: 263px;
    background-color: @background-color-layout;
    // max-height: 250px;
    position: absolute;
    left: 0;
    top: 29px;
    z-index: 3000;
  }
  .active {
    // width: 100%;
    color: @font-color-active;
    cursor: not-allowed;
  }
}
::v-deep {
  .el-tree {
    max-height: 230px;
    overflow: auto;
    background: transparent;
    color: @font-color;

    .el-tree-node__content {
      border: 1px solid transparent;
    }
  }
  .el-tree-node__content:hover,
  .el-upload-list__item:hover {
    background-image: linear-gradient(to right, @linear-bg-color-dark, @linear-bg-color-light);
    border: 1px solid @base-theme-color;
  }

  .el-tree-node:focus > .el-tree-node__content {
    background-color: transparent;
  }

  .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content {
    background-image: linear-gradient(to right, @linear-bg-color-dark, @linear-bg-color-light);
    border: 1px solid @base-theme-color;
  }
  .el-input__inner,
  .el-input-group__append,
  .el-input-group__prepend {
    background-color: transparent;
    color: @font-color;
    border-color: @font-color-theme-light;
  }
  .el-input__prefix {
    color: @font-color-active;
  }
  .el-input-group__append:hover,
  .el-input-group__prepend:hover {
    background-color: @base-theme-color;
  }
  .el-pagination {
    margin-top: 0px;
    padding-top: 5px;
    color: @font-color;
    line-height: 22px;
    button {
      background: transparent;
      color: @font-color;
    }
    button:disabled {
      background: transparent;
    }
    .el-pager li {
      background: transparent;
    }
  }

  ::-webkit-scrollbar-thumb {
    border-radius: 1em;
    background-color: rgba(214, 214, 214, 0.3);
  }
  ::-webkit-scrollbar-track {
    border-radius: 1em;
    background-color: rgba(233, 233, 233, 0.1);
  }
}
</style>
