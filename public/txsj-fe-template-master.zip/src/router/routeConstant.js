import extendRouteConstant from './extend/extendRouteConstant'
import baseRoutesConstant from './base/baseRoutesConstant'
export const routesConstant = { ...extendRouteConstant, ...baseRoutesConstant }
