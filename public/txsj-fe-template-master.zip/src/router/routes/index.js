export { default as systemRoutes } from './systemRoutes'
export { default as projectRoutes } from './projectRoutes'
export { default as designRoutes } from './designRoutes'
