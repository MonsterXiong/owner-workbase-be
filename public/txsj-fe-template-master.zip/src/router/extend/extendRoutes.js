import extendRouteConstant from './extendRouteConstant'

const routes = [
  {
    ...extendRouteConstant.WELCOME,
    component: () => import('@/views/welcome/index.vue'),
  },
  {
    ...extendRouteConstant.EXTEND,
    component: () => import('@/views/baseModule/extend/Extend.vue'),
    meta: {
      title: 'extend',
    },
  },
  {
    ...extendRouteConstant.PROJECT_MANAGE,
    component: () => import('@/pages/projectManage/ProjectManageCard.vue'),
    meta: {
      title: '项目管理',
    },
  },
  {
    path: '/test',
    name: 'Test',
    component: () => import('@/views/test/index.vue'),
  },
  {
    path: '/orgSample',
    name: 'OrgSample',
    component: () => import('@/example/orgSample/TreeOrgSample.vue'),
    // component: () => import('@/example/bizTreeSample/BizTreeTableSample.vue'),
  },
  {
    path: '/lazyTree',
    name: 'LazyTree',
    component: () => import('@/components/LazyTree/sample.vue'),
  },
]

export default routes
