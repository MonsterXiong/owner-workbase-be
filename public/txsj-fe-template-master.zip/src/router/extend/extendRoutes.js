import extendRouteConstant from './extendRouteConstant'

const routes = [
  {
    ...extendRouteConstant.WELCOME,
    component: () => import('@/views/welcome/index.vue'),
  },
  {
    ...extendRouteConstant.PROJECT_MANAGE,
    component: () => import('@/pages/projectManage/ProjectManage.vue'),
    meta: {
      title: '项目管理',
    },
  },
]

export default routes
