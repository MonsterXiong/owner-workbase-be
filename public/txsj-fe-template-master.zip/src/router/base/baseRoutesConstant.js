const routesConstant = Object.freeze({

})

export default routesConstant
