import baseRoutesConstant from './baseRoutesConstant'

const baseRoutes = [

]
export default baseRoutes
