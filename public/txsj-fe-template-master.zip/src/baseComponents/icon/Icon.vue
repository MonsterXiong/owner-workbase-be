<template>
  <div class="universal-icon">
    <svg class="icon" :style="{ fill: fill }" aria-hidden="true" v-if="iconType == toolbarIconType.SVG">
      <use :xlink:href="`#${iconName}`"></use>
    </svg>
    <span class="iconfont" :class="iconName || ''" v-if="iconType == toolbarIconType.ICONFONT" :style="{ color: fill }" />
    <i :class="iconName" v-if="iconType == toolbarIconType.EL" :style="{ color: fill }"></i>
    <img :src="iconName" v-if="iconType == toolbarIconType.IMG" style="width: 25px; height: 25px; display: inline-block" />
  </div>
</template>

<script>
const toolbarIconType = {
  SVG: 'svg',
  IMG: 'img',
  ICONFONT: 'iconfont',
  EL: 'el',
}
// <BaseIcon :iconName="require('@/assets/image/gfzhfx/logo.png')" fill="#fff" />
// <BaseIcon iconName="el-icon-delete" fill="#fff" />
// <BaseIcon iconName="icon-shujufenxi" fill="#fff" />
export default {
  props: {
    iconName: {
      type: String,
      require: true,
    },
    fill: {
      type: String,
      require: false,
    },
    type: {
      type: String,
      require: false,
    },
  },
  data() {
    return {
      iconType: 'svg',
      toolbarIconType,
    }
  },
  watch: {
    iconName: {
      immediate: true,
      handler() {
        this.setIconType()
      },
    },
    type() {
      this.setIconType()
    },
  },
  methods: {
    setIconType() {
      if (this.type) {
        this.iconType = this.type
        return
      }
      if (this.iconName.includes('el-icon-')) {
        this.iconType = toolbarIconType.EL
      } else if (this.iconName.includes('icon-')) {
        this.iconType = toolbarIconType.ICONFONT
      } else if (this.iconName.includes('.')) {
        this.iconType = toolbarIconType.IMG
      } else this.iconType = toolbarIconType.SVG
    },
  },
}
</script>

<style lang="less">
.universal-icon {
  display: inline-block;
  .iconfont,
  i {
    font-size: 16px;
  }
}
.icon {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  overflow: hidden;
  fill: currentColor;
}
</style>
