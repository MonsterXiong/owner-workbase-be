import services from '@/services'

// 基础接口生成版本
const serviceConfig = {
  // 最新版本具体根据后端接口
  last: {
    query: 'query{}DTOByCondition',
    insert: 'insert{}',
    update: 'update{}',
    updateBatch: 'update{}Batch',
    deleteBatch: 'delete{}Batch',
    save: 'save{}',
    saveBatch: 'save{}Batch',
    download: 'download{}Template',
    import: 'import{}Excel',
    export: 'export{}Excel',
  },
  v4: {
    query: 'query{}ByCondition',
    insert: 'insert{}',
    update: 'update{}',
    updateBatch: 'update{}Batch',
    deleteBatch: 'delete{}Batch',
    save: 'save{}',
    saveBatch: 'save{}Batch',
    download: 'download{}Template',
    import: 'import{}Excel',
    export: 'export{}',
  },
}

export default function getInterfaceName(serviceName, type, version) {
  const currentVersion = version || 'last'
  const currentServiceTemplate = serviceConfig[currentVersion]
  const serviceData = {}
  for (const key in currentServiceTemplate) {
    serviceData[key] = currentServiceTemplate[key].replace('{}', serviceName)
  }
  return services[`${serviceName}Service`][serviceData[type]]
}
