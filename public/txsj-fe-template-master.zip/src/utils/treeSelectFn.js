import { treeToList } from '@/utils/treeTool'

export function getTreeNodeValue(node) {
  if (node) {
    let label = node.nestedSearchLabel
    let arr = node.nestedSearchLabel ? node.nestedSearchLabel.split(' ') : []
    if (!node.parentNode) return node.label
    let parentArr = treeToList([node.parentNode])
    let parr = findParent(parentArr, [], node.id)
    if (parr.length === 0) label = arr.join('/')
    else label = parr.map((ele) => ele.label).join('/')
    return label
  } else return ''
}

export function findParent(list, arr, id) {
  let pEle = list.find((ele) => {
    return ele.id === id
  })
  if (pEle) {
    arr.unshift(pEle)
    if (!pEle.isRootNode) {
      findParent(list, arr, pEle.parentNode.id)
    }
  }
  return arr
}
