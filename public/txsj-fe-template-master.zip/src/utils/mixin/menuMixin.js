import { mapGetters } from 'vuex'

export default {
  data() {
    return {}
  },
  computed: {
    ...mapGetters({
      allMenuList: 'menu/getMenuList',
      topMenuList: 'menu/getTopMenuList',
      leftMenuList: 'menu/getLeftMenuList',
    }),
  },
  methods: {
    // 初始化menuList
    initMenu() {
      this.$store.dispatch('menu/initmenuList')
    },
    // 设置menuList
    setMenuList(data) {
      this.$store.dispatch('menu/setmenuList', data)
    },
  },
}
