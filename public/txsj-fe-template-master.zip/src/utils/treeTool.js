export function listToTree(list, { idKey = 'id', pidKey = 'parentId', childKey = 'children' } = {}) {
  if (!Array.isArray(list)) {
    return []
  }
  const idMap = {}
  const tree = []
  list.forEach((item) => {
    idMap[item[idKey]] = item
  })
  list.forEach((item) => {
    const parent = idMap[item[pidKey]]
    if (parent) {
      ; (parent[childKey] || (parent[childKey] = [])).push(item)
    } else {
      tree.push(item)
    }
  })
  return tree
}

export function treeToList(tree, { childKey = 'children' } = {}) {
  if (Array.isArray(tree))
    return tree.reduce((res, item) => {
      const children = item[childKey]
      const { ...i } = item
      Reflect.deleteProperty(i, childKey)
      return res.concat(i, children && children.length ? treeToList(children) : [])
    }, [])
  else return []
}

export function setTreeLevel(tree, initialLevel = 0, { childKey = 'children' } = {}) {
  _treeSetLevelInner(tree, initialLevel)

  function _treeSetLevelInner(tree, level) {
    if (!tree || tree.length === 0) return
    tree.forEach((node) => {
      node.__level = level
      _treeSetLevelInner(node[childKey], level + 1)
    })
  }
}

export function setTreeNodeParent(tree, { parentKey = '__parent', childKey = 'children' } = {}) {
  if (!tree || tree.length === 0) return []
  tree.forEach((node) => {
    const children = node[childKey]
    if (children && children.length > 0) {
      children.forEach((child) => (child[parentKey] = node))
      setTreeNodeParent(children, {
        parentKey,
        childKey,
      })
    }
  })
}

export function findLeafNode(tree, { childKey = 'children' } = {}) {
  return filterTree(tree, (item, tree) => !item[childKey] || item[childKey].length === 0, childKey) || []
}

function filterTree(tree, predict = () => true, childKey = 'children') {
  let arr = []
  if (tree && tree.length > 0) {
    for (let i = 0, len = tree.length; i < len; i++) {
      const object = tree[i]
      if (predict(object, tree)) {
        arr.push(object)
      }
      const childs = object[childKey]
      if (childs && childs.length > 0) {
        const carr = filterTree(childs, predict)
        arr = arr.concat(carr)
      }
    }
  }
  return arr
}
