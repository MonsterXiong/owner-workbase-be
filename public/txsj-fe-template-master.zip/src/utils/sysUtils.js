import store from '@/store'

function getIsCollapse() {
  return store.state.setting.isCollapseGuidance || false
}

function getMemo() {
  return store.state.setting.memo || ''
}

export { getIsCollapse, getMemo }
