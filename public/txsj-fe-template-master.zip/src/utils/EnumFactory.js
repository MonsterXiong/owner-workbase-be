class EnumFactory {
  constructor(enums) {
    this.enums = enums
    this.labels = enums.map((item) => item.label)
    this.values = enums.map((item) => item.value)
  }
  getValueByLabel(label) {
    if (!label) {
      return ''
    }
    const index = this.labels.indexOf(label)
    return index < 0 ? '' : this.values[index]
  }
  getLabelByValue(value) {
    if (!value) {
      return ''
    }
    const index = this.values.indexOf(value)
    return index < 0 ? value || '' : this.labels[index]
  }
  getItemByValueOrLabel(valueOrLabel) {
    let index = this.values.indexOf(valueOrLabel)
    if (index < 0) {
      index = this.labels.indexOf(valueOrLabel)
    }
    return this.enums[index]
  }
  getLabelsByValue(value) {
    if (!value) {
      return ''
    }
    let result = ''
    let valueArr = value
    if (!Array.isArray(valueArr)) {
      valueArr = value.split(',')
    }
    valueArr.forEach((valueItem, index) => {
      result += this.getLabelByValue(valueItem)
      if (valueArr.length - 1 != index) {
        result += ','
      }
    })
    return result
  }
  getLabelsByValueJson(value) {
    if (!value) {
      return ''
    }
    let result = ''
    const valueArr = JSON.parse(value)
    valueArr.forEach((valueItem, index) => {
      result += this.getLabelByValue(valueItem)
      if (valueArr.length - 1 != index) {
        result += ','
      }
    })
    return result
  }
  getEnum() {
    return this.enums
  }
}

function getOption(list, { labelKey = 'name', valueKey = 'id' }) {
  return list.map((item) => {
    return {
      label: item[labelKey],
      value: item[valueKey],
    }
  })
}

export function genEnumByList(list, config = {}) {
  return new EnumFactory(getOption(list, config))
}

export function genEnumByOption(list) {
  return new EnumFactory(list)
}
