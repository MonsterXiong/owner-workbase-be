<template>
  <section class="aside-nav">
    <aside>
      <ul class="first-menu">
        <li :class="menu_setActiveClass(menu)" v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" @click="menu_onMenuClick(menu)">
          <span :class="`iconfont ${menu.icon}`" />{{ menu.name }}
        </li>
      </ul>
      <div class="side-bar-togggle" :title="isCollapseGuidance ? '展开' : '收缩'">
        <i :class="[isCollapseGuidance ? 'el-icon-d-arrow-right' : 'el-icon-d-arrow-left']" @click="onToggleAsideNav" style="font-size: 18px"></i>
      </div>
    </aside>
    <nav>
      <header><span :class="`iconfont ${menu_activeFirstData.icon}`" /> {{ menu_activeFirstData.name || '' }}</header>
      <ul class="second-menu">
        <template v-for="menu in menu_secondTreeData">
          <li :class="[menu_setActiveClass(menu), setArrowClass(menu)]" :key="menu[MenuKeyConfig.idKey]" @click="onToggleSecondMenu(menu)">
            <span :class="`iconfont ${menu.icon}`" /> {{ menu.name }}
            <i class="el-icon-arrow-down"></i>
          </li>
          <el-collapse-transition :key="menu[MenuKeyConfig.idKey] + '_child'" v-if="Array.isArray(menu.children) && menu.children.length > 0">
            <ul class="second-menu-children" v-show="!menu._collapse">
              <li
                v-for="childMenu in menu.children"
                :class="menu_setActiveClass(childMenu)"
                :key="childMenu[MenuKeyConfig.idKey]"
                @click="menu_onMenuClick(childMenu)"
              >
                <span :class="`iconfont ${childMenu.icon}`" /> {{ childMenu.name }}
              </li>
            </ul>
          </el-collapse-transition>
        </template>
      </ul>
    </nav>
  </section>
</template>

<script>
import menuMixin from '@/layout/menuMixin'
import { MenuKeyConfig } from '@/common/constants'

export default {
  mixins: [menuMixin],
  inject: ['layout_VueRef'],
  data() {
    return {
      MenuKeyConfig,
    }
  },
  computed: {
    isCollapseGuidance() {
      return !!this.layout_VueRef?.layout_isCollapseSideBar
    },
  },
  watch: {
    menu_secondTreeData: {
      handler(val) {
        this.$emit('collapseSideBar', val.length > 0 ? false : true)
      },
      immediate: true,
    },
  },
  methods: {
    onToggleAsideNav() {
      if (!this.layout_VueRef) return
      this.layout_VueRef.layout_isCollapseSideBar = !this.layout_VueRef.layout_isCollapseSideBar
    },
    onToggleSecondMenu(menu) {
      menu._collapse = !menu._collapse
      this.menu_onMenuClick(menu)
    },
    setArrowClass(menu) {
      if (Array.isArray(menu.children) && menu.children.length > 0) {
        return 'hasSon ' + (menu._collapse ? 'collapse' : '')
      }
      return ''
    },
  },
}
</script>

<style scoped lang="less">
.text-ellipsis() {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}

.aside-nav {
  height: 100%;
  display: flex;
  color: #fff;
  > aside {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;

    width: var(--aside-min-width, 46px);
    overflow: auto;
    background-image: url('~@/assets/image/sidebar-bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;

    .side-bar-togggle {
      padding: 5px;
      cursor: pointer;
    }
    padding-bottom: 15px;
  }
  > nav {
    width: calc(100% - var(--aside-min-width, 46px));
    background-image: url('~@/assets/image/guidance-bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    > header {
      font-size: 16px;
      border-bottom: 1px solid #1a538f;
      width: calc(100% - 2px);
      padding: 12px 20px 4px;
      .text-ellipsis();
    }
  }

  .first-menu {
    height: calc(100% - 30px);
    padding: 15px 0px;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
    > li {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-bottom: 20px;
      width: 30px;
      cursor: pointer;
      font-size: 12px;
      .iconfont {
        height: 30px;
        width: 30px;
        text-align: center;
        line-height: 30px;
        border-radius: 50%;
      }
      &.active .iconfont,
      .iconfont:hover {
        background: #409eff;
      }
    }
  }

  .second-menu {
    padding: 8px;
    line-height: 32px;
    font-size: 16px;
    li {
      position: relative;
      cursor: pointer;
      border: 1px solid transparent;
      .text-ellipsis();
      &:hover,
      &.active {
        border-color: #409eff;
        background-image: linear-gradient(90deg, #002c6f, #1b6dd9) !important;
      }
      &.hasSon {
        border-image: linear-gradient(180deg, #1e7ec7, #0f4897) 1 !important;
        background-image: linear-gradient(90deg, #002c6f, #1b6dd9) !important;
        .el-icon-arrow-down {
          visibility: visible;
        }
        &.collapse {
          .el-icon-arrow-down {
            transform: rotate(180deg);
          }
        }
        &.collapse + .second-menu-children {
          height: 0px;
          overflow: hidden;
        }
      }
      > .el-icon-arrow-down {
        visibility: hidden;
        transform: rotate(0deg);
        line-height: 32px;
        width: 30px;
        text-align: center;
        right: 0;
        position: absolute;
        transition: transform 0.3s;
        font-size: 13px;
      }
    }
    > li {
      padding: 0px 30px 0px 15px;
    }
    .second-menu-children {
      font-size: 14px;
      > li {
        padding: 0px 20px 0px 39px;

        &::before {
          content: '';
          position: absolute;
          width: 9px;
          height: 10px;
          border-left: 1px solid #fff;
          border-bottom: 1px solid #fff;
          left: 23px;
          top: 6px;
        }
      }
    }
  }
}
</style>
