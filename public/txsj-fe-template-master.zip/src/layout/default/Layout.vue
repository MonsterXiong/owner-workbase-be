<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header"></Header>
    <!-- 主页面 -->
    <Splitpanes class="layout-page">
      <pane :size="layout_isCollapseSideBar ? 0 : 15" class="layout-aside">
        <!-- 侧边导航栏 -->
        <SideBar @collapseSideBar="collapseSideBar"></SideBar>
      </pane>
      <pane :size="layout_isCollapseSideBar ? 100 : 85" class="layout-right-panel">
        <section>
          <!-- 路由页面 -->
          <router-view class="layout-view"></router-view>
        </section>
      </pane>
    </Splitpanes>
    <ModalAll />
  </section>
</template>

<script>
import Header from './header/Header.vue'
import ModalAll from '@/views/modalAll/index.vue'
import { Splitpanes, Pane } from 'splitpanes'
import 'splitpanes/dist/splitpanes.css'
import SideBar from './sideBar/SideBar'

export default {
  name: 'Layout',
  provide() {
    return {
      layout_VueRef: this,
      echartTheme: null,
    }
  },
  components: {
    Header,
    ModalAll,
    SideBar,
    Splitpanes,
    Pane,
  },
  data() {
    return {
      layout_isCollapseSideBar: false, // 是否收起侧边导航栏
    }
  },
  methods: {
    collapseSideBar(status) {
      this.layout_isCollapseSideBar = status
    },
  },
}
</script>

<style lang="less" scoped>
@header-height: 50px;
@background-color-layout: var(--background-color-layout, #002150);
@panel-border-color: var(--panel-border-color, #2d75c2);

.layout {
  height: 100%;
  background-color: @background-color-layout;
  .layout-header {
    height: @header-height;
    margin-bottom: 10px;
  }
  .layout-page {
    height: calc(100% - @header-height - 10px);
    overflow: auto;

    // 防止初始化时宽度变化过大
    .layout-aside {
      --aside-min-width: 46px;
      min-width: var(--aside-min-width);
      width: 15%;
    }
    .layout-right-panel {
      position: relative;
      width: 85%;
      background-color: @panel-border-color !important;
      clip-path: polygon(0 16px, 9px 0px, 100% 0%, 100% 100%, 0 100%);
      padding: 2px 0px 0px 2px;
      > section {
        height: 100%;
        background: #fff;
        clip-path: polygon(0 15px, 8.5px 0px, 100% 0%, 100% 100%, 0 100%);
      }
    }
    ::v-deep {
      > .splitpanes__splitter {
        width: 5px;
        border-left: none;
        border-right: none;
        &:hover {
          border-left: none;
          border-right: none;
        }
      }
    }
  }
  .layout-view {
    height: 100%;
    padding: 10px;
    overflow: hidden;
  }
}
@import './style/index.less';
</style>
