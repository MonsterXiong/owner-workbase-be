<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header"></Header>
    <!-- 主页面 -->
    <main class="layout-page">
      <router-view style="height: 100%" />
    </main>
  </section>
</template>

<script>
import Header from './header/Header.vue'
import 'splitpanes/dist/splitpanes.css'
export default {
  components: { Header },
}
</script>

<style lang="less" scoped>
.layout {
  height: 100%;
  .layout-header {
    position: absolute;
    top: 0px;
    left: 0px;
    z-index: 1;
    width: 100%;
    height: 120px;
  }
  .layout-page {
    padding: 120px 10px 10px;
    background-image: url('~@/assets/image/gfzhfx-dark/homeBg.png');
    height: 100vh;
  }
}
</style>
