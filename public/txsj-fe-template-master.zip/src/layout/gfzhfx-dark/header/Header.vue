<template>
  <div class="header-container">
    <img class="bg-img" src="@/assets/image/gfzhfx-dark/headDark.png" />

    <div class="left">
      <div class="logo">
        <img class="big-image" src="@/assets/image/gfzhfx-dark/logo.png" alt="" />
        <img class="small-image" src="@/assets/image/gfzhfx-dark/logo.png" alt="" />
      </div>

      <span class="title"> {{ configData.systemName }} </span>
    </div>

    <div class="center" style="display: flex; flex-direction: column">
      <div class="top-wrapper">
        <span :class="menu_setActiveClass(menu)" v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" @click="menu_onMenuClick(menu)">
          <span v-if="menu.icon" :class="`iconfont ${menu.icon}`" />{{ menu.name }}</span
        >
      </div>
      <div class="bottom-wrapper">
        <span :class="menu_setActiveClass(menu)" v-for="menu in menu_secondTreeData" :key="menu[MenuKeyConfig.idKey]" @click="menu_onMenuClick(menu)">
          <span v-if="menu.icon" :class="`iconfont ${menu.icon}`" />
          {{ menu.name }}
        </span>
      </div>
    </div>
    <div class="right">
      <Setting style="margin: 0 5px" />
      <Logout></Logout>
    </div>
  </div>
</template>

<script>
import Setting from '../components/Setting.vue'
import Logout from '../components/Logout'
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import { MenuKeyConfig } from '@/common/constants'

export default {
  mixins: [menuMixin],
  data() {
    return {
      configData,
      MenuKeyConfig,
    }
  },
  methods: {
    // 二级菜单点击事件 如果有旗下的第三级菜单则弹出
    onSecondMenuClick(menu, ev) {
      this.menu_onMenuClick(menu)
      if (menu?.children) this.childrenList = menu.children || []
      else {
        this.childrenList = []
      }
      this.position.x = ev.clientX + 4 - 700
      this.position.y = 90
    },
    onSecondMenuClickOutside() {
      this.childrenList = []
    },
  },
  components: {
    Logout,
    Setting,
  },
}
</script>

<style lang="less" scoped>
@bg-color-linear--primary: linear-gradient(to bottom, #195070, #527edf);
@font-color--primary: #356491;
@menu-hover-color: #e7effe;
@white-color: #fff;
@bg-color-hover--primary: #d5e0fb;
@background-color-header-hover: #264b90;

@fontSizeLarge: 32px;
@fontSizeMiddle: 26px;
@fontSizeSmall: 20px;

@keyframes infinite-rotation {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
.header-container {
  position: relative;
  box-shadow: 0px 6px 8px #3569cb66;
  height: 100%;
  display: flex;
  .logo {
    position: relative;
    display: flex;
    align-items: center;
    .big-image {
      height: 90px;
      animation: infinite-rotation 5s linear infinite;
    }

    .small-image {
      position: absolute;
      height: 90px;
      margin-right: 0px;
      clip-path: circle(34px at 50% 50%);
      left: 1px;
      z-index: 1;
    }
  }
  .bg-img {
    position: absolute;
    height: 100%;
    width: 100%;
    z-index: 0;
  }

  .left {
    width: 27%;
    font-size: @fontSizeLarge;
    font-weight: bold;
    margin-left: 20px;
    display: flex;
    align-items: center;
    height: 94px;
    z-index: 2;
    .title {
      font-family: 'ALIMAMASHUHEITI-BOLD';
      color: transparent;
      font-weight: bold;
      font-size: 35px;
      background-image: linear-gradient(180deg, #fff, #84c5ff);
      background-clip: text;
    }
    img {
      margin-right: 10px;
      height: 50px;
    }
  }
  .center {
    color: @font-color--primary;
    flex: 1;
    letter-spacing: 1px;
    z-index: 2;
    .top-wrapper {
      height: 60px;
      font-size: 24px;
      display: flex;
      align-items: center;
      font-weight: bold;
      > span {
        display: flex;
        align-items: center;
        margin-right: 40px;

        font-family: Heavy;
        color: transparent;
        background: none;
        background-image: linear-gradient(to bottom, #ffffff, #ffffff);
        -webkit-background-clip: text;
        background-clip: text;
        cursor: pointer;

        > span {
          margin-right: 5px;
          font-size: 28px;
        }
        &.active {
          > span {
            color: transparent;
          }

          background-image: linear-gradient(to bottom, #ffffff, #4efbf3);
        }
      }
      .nav-icon {
        vertical-align: middle;
        height: 28px;
        width: 30px;
      }
    }
    .bottom-wrapper {
      height: 34px;
      font-size: 16px;
      display: flex;
      align-items: center;
      font-weight: bold;
      color: #fff;
      > span {
        display: flex;
        align-items: center;
        cursor: pointer;

        padding: 5px 33px 5px 20px;
        margin-right: 0px;
        background: url('~@/assets/image/gfzhfx-dark/Arr.png');
        background-repeat: no-repeat;
        background-position: right;
        .img {
          height: 21px;
          width: 21px;
          margin-top: 3px;
          fill: aliceblue;
          margin-right: 5px;
          background-color: #fff;
        }
        > span {
          margin-right: 4px;
        }
        &:hover {
          background: url('~@/assets/image/gfzhfx-dark/activeArr.png');
          background-repeat: no-repeat;
          background-position: right;
        }
        &:first-child {
          margin-left: 0px;
          padding-left: 10px;
        }
      }
      .active {
        background: url('~@/assets/image/gfzhfx-dark/activeArr.png');
        background-repeat: no-repeat;
        background-position: right;

        color: #4efbf3;
        font-weight: bold;

        .img {
          background-color: #4efbf3;
        }

        > span {
          color: #4efbf3;
        }
      }
    }
  }
  .right {
    height: 60px;
    line-height: 60px;
    display: flex;
    justify-content: flex-end;
    padding-right: 20px;
    z-index: 2;
    font-size: 24px;
  }
}
</style>
