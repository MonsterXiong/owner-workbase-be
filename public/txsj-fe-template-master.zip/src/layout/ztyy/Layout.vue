<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header" v-show="!noHeader" :menu_TreeData="menu_TreeData" @onFirstMenuClick="onFirstMenuClick"></Header>
    <!-- 主页面 -->
    <Splitpanes class="layout-page" :class="noHeader ? 'layout-page-noheader' : ''">
      <pane :size="layout_isCollapseAsideNav ? 0 : 15" class="layout-aside">
        <!-- 侧边导航栏 -->
        <AsideNav :menu_secondTreeData="menu_secondTreeData" :menu_ActiveCodeChain="menu_ActiveCodeChain" @onSecondMenuClick="onSecondMenuClick"></AsideNav>
      </pane>
      <pane :size="layout_isCollapseAsideNav ? 100 : 85" class="layout-right-panel">
        <section>
          <!-- tag页 -->
          <nav></nav>
          <!-- 路由页面 -->
          <router-view class="layout-view"></router-view>
        </section>
      </pane>
    </Splitpanes>
    <ModalAll />
  </section>
</template>

<script>
import Header from './header/Header.vue'
import ModalAll from '@/views/modalAll/index.vue'
import { Splitpanes, Pane } from 'splitpanes'
import 'splitpanes/dist/splitpanes.css'
import AsideNav from './asideNav/AsideNav'
import menuMixin from '../menuMixin'
import configData from '@/utils/config'

export default {
  name: 'Layout',
  mixins: [menuMixin],
  provide() {
    return {
      layout_VueRef: this,
      nodeTemp: null,
      linkTemp: null,
      taskNodeTemp: null,
      colorConfig: null,
      strokeColor: null,
      activityColor: [],
      echartTextColor: null,
      orgNodeType: 'node3',
    }
  },
  components: {
    Header,
    ModalAll,
    AsideNav,
    Splitpanes,
    Pane,
  },
  watch: {
    menu_TreeData: {
      handler(val) {
        console.log(val, 888888)
      },
    },
    menu_secondTreeData: {
      handler(val) {
        this.layout_isCollapseAsideNav = this.menu_secondTreeData.length == 0 ? true : false
      },
    },
  },
  data() {
    return {
      noHeader: configData.hasHeader == 0 ? true : false,
      layout_isCollapseAsideNav: false, // 是否收起侧边导航栏
    }
  },
  mounted() {
    // setTimeout(() => {
    //   this.$emitter.emit('refreshActiveMenu')
    // }, 500)
  },
  methods: {
    onFirstMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    onSecondMenuClick(menu, ev) {
      this.menu_onMenuClick(menu)
      if (menu?.children) this.childrenList = menu.children || []
      else {
        this.childrenList = []
      }
      this.position.x = ev.clientX + 4 - 40
      this.position.y = 90 - 14
    },
  },
}
</script>

<style lang="less" scoped>
@header-height: 50px;
@background-color-layout: var(--background-color-layout, #002150);
@panel-border-color: var(--panel-border-color, #2d75c2);

.layout {
  height: 100%;
  .layout-header {
    height: @header-height;
  }
  .layout-page {
    height: calc(100% - @header-height - 0px);
    overflow: auto;

    // 防止初始化时宽度变化过大
    .layout-aside {
      // --aside-min-width: 46px;
      // min-width: var(--aside-min-width);
      width: 15%;
    }
    .layout-right-panel {
      position: relative;
      width: 85%;
      padding: 2px 0px 0px 2px;
      > section {
        height: 100%;
        background: #fff;
      }
    }
    ::v-deep {
      > .splitpanes__splitter {
        width: 5px;
        border-left: none;
        border-right: none;
        background-color: #bbbbbb62;
        &:hover {
          border-left: none;
          border-right: none;
        }
      }
    }
  }

  .layout-page-noheader {
    height: 100%;
  }
  .layout-view {
    height: 100%;
    padding: 10px;
    overflow: hidden;
  }
}
</style>

<style lang="less">
@import './style/index.less';
</style>
