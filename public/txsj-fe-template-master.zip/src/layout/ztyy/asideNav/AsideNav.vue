<template>
  <div class="side-bar">
    <div class="side-bar-wrap" v-show="!isCollapse">
      <el-menu
        :default-active="activeMenuId"
        class="el-menu-vertical"
        :default-openeds="openMenuList"
        :collapse-on-click="true"
        background-color="transparent"
        text-color="#333"
        active-text-color="#fff"
        ref="generalSideBarRef"
      >
        <MenuBarItem v-for="item in menuList" :menuItem="item" :key="item[MenuKeyConfig.idKey]" @menuClick="onSecondMenuClick" />
      </el-menu>
    </div>
    <div class="side-bar-collapse" v-show="isCollapse">
      <div class="menu-collapse-box" v-for="menuItem in menuList" :key="menuItem[MenuKeyConfig.idKey]" :title="menuItem.name" @click="onCollapseChange">
        <span class="hover-span"></span>
        <span :class="['iconfont', menuItem.icon ? menuItem.icon : 'icon-wenjian']" class="inline-icon" />
      </div>
    </div>
  </div>
</template>

<script>
import MenuBarItem from './MenuBarItem.vue'
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import { treeToList } from '@/utils/treeTool'
import { MenuKeyConfig } from '@/common/constants'

export default {
  name: 'generalSideBar',
  props: {
    menu_secondTreeData: {
      type: Array,
    },
    menu_ActiveCodeChain: {
      type: Array,
    },
  },
  data() {
    return {
      systemName: configData.systemName,
      activeMenuId: '',
      openMenuList: [],
      menuList: [],
      MenuKeyConfig,
      isCollapse: false,
    }
  },
  watch: {
    menu_secondTreeData: {
      handler(val) {
        this.getMenuList([...val])
      },
    },
    menu_ActiveCodeChain: {
      handler(val) {
        this.activeMenuId = val ? val[val.length - 1] : ''
      },
    },
  },
  mounted() {},
  methods: {
    onSecondMenuClick(menu, ev) {
      this.$emit('onSecondMenuClick', menu)
    },
    getMenuList(data) {
      this.menuList = data || []
      this.setOpenMenuList()
    },
    setOpenMenuList() {
      let arr = treeToList(this.menuList)
      this.openMenuList = arr.map((ele, index) => ele[MenuKeyConfig.idKey])
    },
    onCollapseChange() {},
  },
  components: {
    MenuBarItem,
  },
}
</script>

<style lang="less" scoped>
@background-color-white: #fff;
.side-bar {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  background: @background-color-white;
  color: @font-color;
  .side-bar-wrap {
    flex: 1;
    width: 100%;
    overflow-y: auto;
  }
  .side-bar-collapse {
    width: 50px;
    height: 100%;
    overflow: auto;
    .menu-collapse-box {
      width: 100%;
      height: 50px;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      position: relative;
      cursor: pointer;
      .hover-span {
        display: inline-block;
        height: 100%;
        width: 5px;
        position: absolute;
        top: 0;
        left: 0;
      }
    }
    .menu-collapse-box:hover {
      .hover-span {
        // background: @background-color-layout;
      }
    }
  }
}
::v-deep {
  .el-menu {
    border-right: none;
  }
  .el-submenu__title {
    font-size: 16px;
  }
  .el-menu-item.is-active {
    background: #3f85ed !important;
  }
  .el-submenu__title:hover,
  .el-menu-item:hover {
    color: @font-color-light !important;
    background: #409eff !important;
  }
}
</style>
