<template>
  <div class="header">
    <div class="header-left">
      <div class="system-name-wrap gradient-text">{{ systemName }}</div>
      <div class="header-menu">
        <ul class="first-menu">
          <li v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" :class="menu_setActiveClass(menu)" @click="onFirstMenuClick(menu)">
            {{ menu.name }}
          </li>
        </ul>
      </div>
    </div>
    <system-menus class="header-menus"></system-menus>
  </div>
</template>

<script>
import configData from '@/utils/config'
import SystemMenus from './components/SystemMenus.vue'
import { MenuKeyConfig } from '@/common/constants'

export default {
  name: 'Header',
  props: {
    menu_TreeData: {
      type: Array,
    },
  },
  inject: ['menu_setActiveClass'],
  data() {
    return {
      systemName: configData.systemName,
      MenuKeyConfig,
    }
  },
  watch: {
    menu_TreeData: {
      handler(val) {},
      immediate: true,
    },
  },
  methods: {
    onFirstMenuClick(menu) {
      this.$emit('onFirstMenuClick', menu)
    },
  },
  components: {
    SystemMenus,
  },
}
</script>

<style scoped lang="less">
.header {
  text-align: center;
  width: 100%;
  height: calc(100% - 0px);
  position: relative;
  display: flex;
  justify-content: start;
  color: @font-color-light;
  .header-left {
    width: calc(100% - 118px);
    padding: 0 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .header-menu {
      height: 100%;
      padding: 0 10px;
      > ul {
        display: flex;
        overflow-x: auto;
      }
      .first-menu {
        margin-left: 28px;
        width: calc(100% - 28px);
        > li {
          height: 100%;
          margin: 0 20px;
          font-family: '微软雅黑 Bold', '微软雅黑 Regular', '微软雅黑';
          font-size: 16px;
          line-height: 48px;
          cursor: pointer;
          border-bottom: 2px solid transparent;

          &.active,
          &:hover {
            color: #fffbd1;
            border-color: #fffbd1;
          }
        }
      }
    }
  }
  .system-name-wrap {
    line-height: 50px;
    position: relative;
    font-family: @font-family;
    font-size: 24px;
    // color: @font-color-light;
    color: transparent !important;
    background-clip: text !important;
    background-image: linear-gradient(to bottom, @background-color-light, @font-color-light) !important;
  }
  .header-menus {
    position: absolute;
    right: 10px;
    line-height: 49px;
    // background: red;
  }
  .menus-button-wrap:hover {
    color: @base-theme-color;
  }

  .system-menus {
    .el-menu--horizontal > .el-submenu .el-submenu__title {
      i,
      .icon {
        color: @font-color-light;
      }
    }

    .el-menu--horizontal > .el-submenu .el-submenu__title:hover {
      i,
      .icon {
        color: @base-theme-color;
      }
    }
  }
  .gradient-text {
    background: linear-gradient(@font-color-theme-light 28%, @font-color-light 50%);
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }
}
</style>
