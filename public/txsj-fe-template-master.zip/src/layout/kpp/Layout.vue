<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header" :class="getPageClass(true)" @changeHeight="onChangeHeaderHeight"></Header>
    <!-- 主页面 -->
    <main class="layout-page" :class="getPageClass(false)">
      <router-view style="height: 100%" />
    </main>
    <ModalAll />
  </section>
</template>

<script>
import Header from './header/Header.vue'
import ModalAll from '@/views/modalAll/index.vue'
import 'splitpanes/dist/splitpanes.css'
import { linkTemplate, nodeVerticalTemplate, taskNodeTemp, typeColorConfig } from './diagramTemplate/Template'
import walen from '@/assets/js/walden.json'

export default {
  name: 'Layout',
  provide() {
    return {
      nodeTemp: null,
      linkTemp: null,
      taskNodeTemp: taskNodeTemp,
      colorConfig: typeColorConfig,
      strokeColor: '#37d0f9',
      echartTheme: walen,
      orgNodeType: '',
    }
  },
  data() {
    return {
      isShowThirdMenu: true,
    }
  },
  methods: {
    onChangeHeaderHeight(flag) {
      this.isShowThirdMenu = flag
    },
    getPageClass(header) {
      if (header) {
        if (this.isShowThirdMenu) return 'with-third-menu-header'
        else return ''
      }
      if (this.isShowThirdMenu) return 'with-third-menu-page'
      else return ''
    },
  },
  components: {
    Header,
    ModalAll,
  },
}
</script>

<style lang="less" scoped>
@header-height: 70px;
@background-color-layout: var(--background-color-layout, #fff);

.layout {
  height: 100%;
  background-color: #fff;
  // background-image: url('~@/assets/image/xydLayout/bg.png');
  .layout-header {
    height: @header-height;
  }
  .layout-page {
    height: calc(100% - @header-height);
    overflow: auto;
    padding: 10px;
  }
  .with-third-menu-page {
    height: calc(100% - 105px);
  }
  .with-third-menu-header {
    height: 105px;
  }
}
@import './style/index.less';
// @import './style/componentStyle.less';
</style>

<style lang="less">
// @import './style/elementStyle.less';
// @import './style/listStyle.less';
</style>
