<template>
  <header class="layout-header" ref="xydHeaderRef">
    <div class="top-wrap">
      <h1 class="header-title" :style="'width:' + titleWidth + 'px'">
        <img src="../../../assets/image/xydLayout/headIcon.png" alt="" />
        <span class="head-text">{{ title }}</span>
      </h1>
      <nav class="nav-menu" :style="'width:' + rightWidth + 'px;left:' + (titleWidth - 50) + 'px'">
        <ul class="first-menu">
          <li v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" :class="menu_setActiveClass(menu)" @click="onFirstMenuClick(menu)">
            {{ menu.name }}
          </li>
        </ul>
        <ul class="second-menu" ref="secondMenuRef">
          <li
            v-for="menu in menu_secondTreeData"
            :key="menu[MenuKeyConfig.idKey]"
            :class="menu_setActiveClass(menu)"
            @click.stop="(ev) => onSecondMenuClick(menu, ev)"
          >
            <div class="li-inner">
              {{ menu.name }}
            </div>
          </li>
        </ul>
      </nav>
    </div>
    <ul class="third-menu" v-show="menu_thirdTreeData.length > 0" v-click-outside="onThirdMenuClickOutside">
      <li
        class="third-menu-item"
        v-for="menu in menu_thirdTreeData"
        :key="menu[MenuKeyConfig.idKey]"
        :class="menu_setActiveClass(menu)"
        @click.stop="(ev) => onThirdMenuClick(menu, ev)"
      >
        <div class="li-inner">
          {{ menu.name }}
        </div>
      </li>
    </ul>
    <TopMenus
      ref="TopMenus"
      class="top-menu-com"
      v-show="childrenList.length > 0"
      :menuList="childrenList"
      :style="{ left: position.x + 'px', top: position.y + 'px' }"
      @onMenuClick="menu_onMenuClick"
    />
  </header>
</template>

<script>
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import TopMenus from '@/layout/components/TopMenus'
import { MenuKeyConfig } from '@/common/constants'
import ElementResizeDetectorMaker from 'element-resize-detector'

export default {
  mixins: [menuMixin],
  components: { TopMenus },
  data() {
    return {
      title: configData.systemName,
      childrenList: [],
      position: { x: -1, y: -1 },
      titleWidth: '0px',
      rightWidth: '0px',
      MenuKeyConfig,
    }
  },
  watch: {
    menu_thirdTreeData: {
      handler(val) {
        this.$emit('changeHeight', val.length !== 0)
      },
      immediate: true,
    },
  },
  computed: {},
  mounted() {
    let erd = ElementResizeDetectorMaker()
    erd.listenTo(this.$refs.xydHeaderRef, (ele) => {
      this.calculateWidth()
    })
    this.mouseWheelChange('secondMenuRef')
  },
  methods: {
    calculateWidth() {
      this.titleWidth = this.title.length * 32 + 72 + 50
      this.rightWidth = this.$refs.xydHeaderRef.offsetWidth - this.titleWidth + 50
    },
    mouseWheelChange(refName) {
      let div = this.$refs[refName]
      div.addEventListener('wheel', (e) => {
        let left = -e.wheelDelta || e.deltaY / 2
        console.log('wheelDelta', -e.wheelDelta, 'deltaY', e.deltaY)
        div.scrollLeft = div.scrollLeft + left
      })
    },
    onFirstMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    // 二级菜单点击事件 如果有旗下的第三级菜单则弹出
    onSecondMenuClick(menu, ev) {
      if (menu.parent && menu.children && menu.children.length > 0) {
        // 点击第二级别菜单，存在子节点的时候默认选中第三集别
        this.menu_onMenuClick(menu.children[0])
        return
      }
      this.menu_onMenuClick(menu)
    },
    onThirdMenuClick(menu, ev) {
      console.log(menu, '++++++++++')
      this.menu_onMenuClick(menu)
      if (menu?.children) this.childrenList = menu.children || []
      else {
        this.childrenList = []
      }
      this.position.x = ev.clientX + 4 - 40
      this.position.y = 90 - 14
    },
    onThirdMenuClickOutside() {
      this.childrenList = []
    },
  },
}
</script>

<style scoped lang="less">
@font-face {
  font-family: 'ALIMAMASHUHEITI-BOLD';
  src: url('~@/assets/font/ALIMAMASHUHEITI-BOLD.TTF') format('truetype');
}

.layout-header {
  .top-wrap {
    height: 70px;
    display: flex;
    background-image: url('~@/assets/image/kppLayout/head-bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }

  .header-title {
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin: 0;
    img {
      width: 42px;
      height: 42px;
      margin: 0 15px;
    }
    .head-text {
      font-family: 'ALIMAMASHUHEITI-BOLD';
      font-weight: 700;
      font-size: 32px;
      color: #fff;
      text-shadow: 1px 2px 2px #000;
    }
  }
  .third-menu {
    height: 35px;
    width: 100%;
    left: 0;
    position: absolute;
    top: 70px;
    cursor: pointer;
    display: flex;
    overflow-x: auto;
    .third-menu-item {
      height: 100%;
      min-width: 120px;
      line-height: 35px;
      clip-path: polygon(18px 0px, calc(100% - 0px) 0px, calc(100% - 18px) 100%, 0px 100%);
      margin-left: -16px;
      background: linear-gradient(to bottom, #8bcbf9, #8bcbf9);
      color: #356491;
      font-size: 16px;
      &.active {
        background: linear-gradient(to bottom, #8bcbf9, #21e2fb);
        .li-inner {
          background: linear-gradient(to bottom, #a7d8ff, #75b9ea);
        }
      }
      .li-inner {
        padding: 0 20px;
        text-align: center;
        // background: @xyd-menu-bg-color;
        clip-path: polygon(19px 1px, calc(100% - 2px) 1px, calc(100% - 19px) calc(100% - 1px), 1px calc(100% - 1px));
        background: linear-gradient(to bottom, #addbfc 10%, #cce9ff 70%, #addbfc 100%);
      }
    }
    .third-menu-item:first-of-type {
      clip-path: polygon(0px 0px, calc(100% - 0px) 0px, calc(100% - 18px) 100%, 0px 100%);
      margin: 0;
      &.active {
      }
      .li-inner {
        padding-left: 10px;
        clip-path: polygon(0px 1px, calc(100% - 2px) 1px, calc(100% - 18px) calc(100% - 1px), 0px calc(100% - 1px));
      }
    }
  }
  .third-menu::-webkit-scrollbar {
    display: none;
  }
  .nav-menu {
    height: 80px;
    position: absolute;
    clip-path: polygon(49px 0%, 100% 0%, 100% 100%, -2px 100%);
    overflow: hidden;
    > ul {
      display: flex;
      overflow-x: auto;
    }
    .first-menu {
      height: 36px;
      margin-left: 34px;
      width: calc(100% - 28px);
      padding: 4px 0;
      > li {
        margin: 0 20px;
        padding: 0 20px;
        font-family: '微软雅黑 Bold', '微软雅黑 Regular', '微软雅黑';
        // font-weight: 700;
        font-size: 20px;
        line-height: 27px;
        color: #356491;
        cursor: pointer;

        &.active {
          font-weight: 600;
        }
      }
    }
    .second-menu {
      height: 34px;
      margin-left: 9px;
      width: calc(100% - 9px);
      background-image: url('~@/assets/image/kppLayout/menu2-bg.png');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      padding: 1px 0;
      > li {
        font-family: '微软雅黑';
        font-weight: 400;
        font-size: 16px;
        color: #356491;
        line-height: 32px;
        cursor: pointer;
        position: relative;
        text-align: center;
        text-overflow: ellipsis;
        white-space: nowrap;
        position: relative;
        text-align: center;
        background-image: url('~@/assets/image/kppLayout/menu2-btn.png');
        background-repeat: no-repeat;
        background-size: auto 100%;
        background-position-x: 100%;
        clip-path: polygon(45px 0%, 100% 0%, 100% 100%, 0 100%);
        .li-inner {
          padding: 0 40px;
        }
        &.active {
          font-weight: 700;
          background-image: url('~@/assets/image/kppLayout/menu2-btn-active.png');
          background-repeat: no-repeat;
          background-size: 100% 100%;
          .li-inner {
            background: transparent;
          }
        }
      }
    }
    .second-menu::-webkit-scrollbar {
      display: none;
    }
  }
}
</style>
