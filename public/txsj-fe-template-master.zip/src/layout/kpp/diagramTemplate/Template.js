import * as go from 'gojs'
import Vue from 'vue'
const $ = go.GraphObject.make

const typeImageConfig = {
  red: 'static/treeSvgIcon/equip.svg',
  orange: 'static/treeSvgIcon/organization.svg',
  yellow: 'static/treeSvgIcon/organization.svg',
  pink: 'static/treeSvgIcon/ability.svg',
  green: 'static/treeSvgIcon/function.svg',
  blueGreen: 'static/treeSvgIcon/index.svg',
  hazeBlue: 'static/treeSvgIcon/structure.svg',
  default: 'static/treeSvgIcon/engineering.svg',
}

export const treeGraphContextMenu = $(go.HTMLInfo, {
  show: (obj, diagram, tool) => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuShow', {
      obj,
      diagram,
      tool,
    })
  },
  hide: () => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuHide')
  },
})

export function nodeVerticalTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      selectionAdorned: true,
      ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(
        go.Picture,
        {},
        new go.Binding('source', '', function (nodeData) {
          return require('@/assets/image/xydLayout/01.png')
        })
      ),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },

          $(go.Shape, 'Rectangle', {
            fill: 'transparent',
            strokeWidth: 1,
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Horizontal',
            {},
            new go.Binding('visible', '', function (nodeData) {
              return nodeData.tag ? true : false
            }), // only visible when info is expanded
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 0, 4, 0),
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(6, 0, 4, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#35cef6',
              },
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              }),
              new go.Binding('stroke', '', function (nodeData, targetObj) {
                const typeValue = nodeData._type || 'default'
                return typeColorConfig[typeValue].deep
              })
            )
          )
        ),
        $(
          go.Shape,
          'LineH',
          {
            stroke: '#05a9ff',
            strokeWidth: 1,
            height: 1,
            stretch: go.GraphObject.Horizontal,
          },
          new go.Binding('visible', '', function (nodeData) {
            return nodeData.tag ? true : false
          }) // only visible when info is expanded
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
            width: 118,
          },
          $(go.Shape, 'Rectangle', {
            strokeWidth: 0,
            fill: 'transparent',
          }),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(18, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              width: 100,
            },
            // new go.Binding('text', 'name'),
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              // return '#35cef6'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),

    $(
      'TreeExpanderButton',
      {
        // alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        ..._iconButtonStyle(),
        alignment: options?.angle != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.23, 0, 0), //new go.Spot(1.13, 0.5, 0, 0),
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.23, 0, 0)
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

function _iconButtonStyle() {
  return {
    'ButtonBorder.figure': 'Circle',
    'ButtonBorder.fill': 'transparent',
    'ButtonBorder.stroke': '#035ca2',
    'ButtonIcon.stroke': '#035ca2',
  }
}

export function linkTemplate(isBezier = true) {
  if (isBezier)
    return $(
      go.Link,
      {
        curve: go.Link.Bezier,
        toEndSegmentLength: 30,
        fromEndSegmentLength: 30,
        corner: 0,
        // routing: go.Link.Orthogonal,
        // corner: 0,
        fromSpot: go.Spot.RightCenter,
        toSpot: go.Spot.LeftCenter,
        reshapable: false,
        resegmentable: false,
      },
      // new go.Binding('fromEndSegmentLength', 'fromEndSegmentLength'),
      // new go.Binding('toEndSegmentLength', 'toEndSegmentLength'),
      $(go.Shape, {
        strokeWidth: 1.5,
        // stroke: '#2155c3',
        stroke: '#03a4ea',
      })
    )
  else
    return $(
      go.Link,
      { routing: go.Link.Orthogonal, corner: 5 },
      $(go.Shape, {
        toArrow: 'Standard',
        stroke: '#03a4ea',
      })
    )
}

function getTextBlock(array) {
  let res = array.map((ele) => {
    return $(
      go.TextBlock,
      textStyle(ele.code),
      new go.Binding('margin', '', () => new go.Margin(3, 5)),
      new go.Binding('text', '', (code, targetObj) => {
        const properties = targetObj.part.data.properties
        return ele.title + '：' + (properties[ele.code] || '')
      })
      // new go.Binding('visible', '', (code, targetObj) => {
      //   const properties = targetObj.part.data.properties
      //   return properties[ele.code] ? true : false
      // })
    )
  })
  return res
}
function textStyle(field) {
  return [
    {
      font: '14px Roboto, sans-serif',
      stroke: 'rgba(0, 0, 0, .60)',
      stretch: go.GraphObject.Horizontal,
      maxLines: 1,
      // maxSize: new go.Size(NaN, NaN),
      overflow: go.TextBlock.OverflowEllipsis,
      // visible: false, // only show textblocks when there is corresponding data for them
    },
    new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
      const nodeData = targetObj.part.data
      const typeValue = nodeData._type || 'default'
      return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
    }).ofObject(),
  ]
}
export const typeColorConfig = {
  red: { deep: '#e04f61', shallow: '#fff5f6' },
  orange: { deep: '#e67d31', shallow: '#fff8f3' },
  yellow: { deep: '#ffe346', shallow: '#fffdf4' },
  amaranth: { deep: '#ef4eb9', shallow: '#fcf4f9' },
  green: { deep: '#30e07e', shallow: '#f5fff9' },
  blueGreen: { deep: '#4db6c5', shallow: '#eefafc' },
  hazeBlue: { deep: '#37d0f9', shallow: '#f4f7ff' },
  default: { deep: '#1485cd', shallow: '#f2faff' },
}
export function taskNodeTemp(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      // ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(
        go.Picture,
        {},
        new go.Binding('source', '', function (nodeData) {
          return require('@/assets/image/xydLayout/01.png')
        })
      ),
      $(go.Shape, {
        stroke: 'transparent',
        fill: 'transparent',
      }),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
          width: 208,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },
          $(go.Shape, 'Rectangle', {
            fill: 'transparent',
            strokeWidth: 1,
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Horizontal',
            {},
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 4),
                width: 16,
                height: 16,
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(5, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#fff',
                font: 'bold 16px sans-serif',
              },
              new go.Binding('stroke', '', function (nodeData, targetObj) {
                const typeValue = nodeData._type || 'default'
                return typeColorConfig[typeValue].deep
              }),
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              })
            )
          )
        ),
        $(go.Shape, 'LineH', {
          stroke: '#05a9ff',
          strokeWidth: 1,
          height: 1,
          stretch: go.GraphObject.Horizontal,
        }),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
          },
          $(go.Shape, 'Rectangle', {
            strokeWidth: 1,
            fill: 'transparent',
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Vertical',
            {
              name: 'INFO', // identify to the PanelExpanderButton
              stretch: go.GraphObject.Horizontal,
              // margin: new go.Margin(12, 10),
              defaultAlignment: go.Spot.Left,
            },
            ...getTextBlock(options?.textList || []),
            new go.Binding('visible', '', function (nodeData, targetObj) {
              const parentId = nodeData.data.parentId
              return parentId == '' ? false : true
            }).ofObject()
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(14, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
            },
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject(),
            new go.Binding('visible', '', function (nodeData, targetObj) {
              const parentId = nodeData.data.parentId
              return parentId == '' ? true : false
            }).ofObject()
          )
        )
      )
    ),

    $(
      'TreeExpanderButton',
      {
        // alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        ..._iconButtonStyle(),
        alignment: new go.Spot(0.5, 1.15, 0, 0),
      },
      new go.Binding('alignment', 'angle', function (value) {
        // return value != 90 ? go.Spot.Right : go.Spot.Bottom
        return value != 90 ? new go.Spot(1.08, 0.5, 0, 0) : new go.Spot(0.5, 1.15, 0, 0)
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}
