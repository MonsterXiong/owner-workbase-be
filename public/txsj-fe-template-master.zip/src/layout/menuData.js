import { routesConstant } from '@/router/routeConstant'

export const MENU_TYPE = {
  MODULE: 'module', // 模块 父级菜单,用于分组
  PAGE: 'page', // 页面
}

// top_menu 和 left_menu

export const menuList = [
  {
    parent: '',
    code: 'jcsj',
    name: '基础数据',
    icon: 'icon-xinjian-copy',
    targetType: 'null',
    location: 'top_menu',
    menuType: MENU_TYPE.MODULE,
  },
  {
    parent: '',
    code: 'TXZZ_xm111',
    name: '组织示例图',
    icon: 'icon-xinjian-copy',
    targetType: '0',
    location: 'top_menu',
    menuType: 'page',
    menuParams: '/orgSample',
  },
  {
    parent: '',
    code: 'project',
    name: '项目',
    icon: 'icon-xiangmu_xiangmuguanli-copy',
    targetType: 'null',
    location: 'left_menu',
    menuType: MENU_TYPE.MODULE,
  },
  {
    parent: 'project',
    code: 'projectListManage1',
    name: '项目清单管理0',
    icon: 'icon-shiyongwendang',
    targetType: '0',
    location: 'left_menu',
    menuType: MENU_TYPE.MODULE,
  },
  {
    parent: 'project',
    code: 'projectListManage2',
    name: '测试123456',
    icon: 'icon-shiyongwendang',
    targetType: '0',
    location: 'left_menu',
    menuType: MENU_TYPE.MODULE,
  },
  {
    parent: 'projectListManage1',
    code: 'projectListManageceshi',
    name: '测试',
    icon: 'icon-shiyongwendang',
    targetType: '0',
    location: 'left_menu',
    menuType: 'page',
    menuParams: '/welcome',
  },
  {
    parent: 'projectListManage1',
    code: 'projectListManageceshi2',
    name: 'lazyTree',
    icon: 'icon-shiyongwendang',
    targetType: '0',
    location: 'left_menu',
    menuType: 'page',
    menuParams: '/lazyTree',
  },
  {
    id: 'ceshi123',
    parent: 'jcsj',
    code: 'SOURCE_MANAGE',
    name: '网络节点',
    icon: 'icon-xingzhuangjiehe',
    menuType: 'extend',
    location: 'left_menu',
    menuParams: 'http://192.168.2.204:8022/html/index.html#/nodeList?tagName=节点清单',
  },
]

// 如果需要从后台获取菜单数据 则逻辑写在这里
export const getMenuList = () => {
  return new Promise((res, rej) => {
    let menuData = [...menuList]
    res(menuData)
  })
}
