<template>
  <div class="sysML-header">
    <h1 class="header-title">
      <img src="~@/assets/image/sysmlLayout/logo.png" alt="" />
      <!-- <span class="head-text">{{ title }}</span> -->
    </h1>
    <ul class="sysMl-tab">
      <li v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" :class="menu_setActiveClass(menu)" @click="onFirstMenuClick(menu)">
        <base-icon class="tab-item-icon" :iconName="menu?.icon || ''" style="margin-right: 0px" v-show="menu?.icon"></base-icon>
        {{ menu.name }}
      </li>
    </ul>
    <system-menus class="header-menus">
      <div class="menus-button-wrap">
        <span @click="(ev) => onMenuClick(ev)" v-click-outside="hideManageList">
          <span class="iconfont icon-biaozhun" />
          {{ '管理' }}
        </span>
        <TopMenus
          ref="TopMenus"
          class="top-menu-com"
          :menuList="manageList"
          v-show="showManageList"
          :style="{ left: position.x + 'px', top: position.y + 'px' }"
          @onMenuClick="menu_onMenuClick"
        />
      </div>
    </system-menus>
  </div>
</template>

<script>
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import SystemMenus from './components/SystemMenus.vue'
import { MenuKeyConfig } from '@/common/constants'
import TopMenus from '@/layout/components/TopMenus'
export default {
  mixins: [menuMixin],
  data() {
    return {
      title: configData.systemName,
      MenuKeyConfig,
      position: { x: -1, y: -1 },
      manageList: [
        {
          id: 'guanli101',
          parent: '',
          code: 'guanli',
          name: '管理页面',
          icon: 'icon-xingzhuangjiehe',
          menuType: 'extend',
          location: 'top_menu',
          menuParams: 'http://192.168.2.204:8022/html/index.html#/nodeList?tagName=节点清单',
        },
      ],
      showManageList: false,
    }
  },
  methods: {
    onFirstMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    onMenuClick(ev) {
      this.showManageList = !this.showManageList
      this.position.x = 10
      this.position.y = 20
    },
    hideManageList() {
      this.showManageList = false
    },
  },
  components: {
    SystemMenus,
    TopMenus,
  },
}
</script>

<style lang="less" scoped>
.sysML-header {
  // background: #0a4c9a;
  background: url(~@/assets/image/sysmlLayout/head.png) no-repeat;
  background-size: 100% 100%;
  position: relative;
  // overflow: hidden;
  .header-title {
    width: 100%;
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    img {
      // width: 32px;
      height: 100%;
      // margin: 0 15px;
    }
    .head-text {
      font-family: 'ALIMAMASHUHEITI-BOLD';
      font-weight: 700;
      font-size: 32px;
      color: #fff;
      background-clip: text;
    }
  }
  .sysMl-tab {
    width: 80%;
    // height: 30px;
    position: absolute;
    bottom: -1px;
    left: 10px;
    z-index: 3;
    li {
      display: inline-block;
      height: 100%;
      padding: 10px;
      border-radius: 3px 3px 0 0px;
      user-select: none;
      cursor: pointer;
      // line-height: 30px;
      color: #fff;
      margin-right: 25px;
      &.active {
        background: #e6f2ff;
        color: #016dc9;
        font-weight: bold;
      }
    }
  }

  .header-menus {
    position: absolute;
    bottom: 10px;
    right: 0px;
    z-index: 4;
    .menus-button-wrap {
      position: relative;
    }
  }
}
::v-deep {
  .system-menus {
    .top-menu-com {
      position: absolute;
      left: 20px;
      top: 35px;
      min-width: 120px;
      max-width: 250px;
      border-radius: 4px;
      // background-color: #f4f9ff;
      padding: 0px;
      z-index: 99;
    }
  }
  .system-menus .menus-button-wrap {
    margin: 0 10px 0 15px;
  }
}
</style>
