<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header"></Header>
    <!-- 主页面 -->
    <main class="layout-page">
      <router-view style="height: 100%" />
    </main>
    <ModalAll />
  </section>
</template>

<script>
import Header from './header/Header.vue'
import ModalAll from '@/views/modalAll/index.vue'
import 'splitpanes/dist/splitpanes.css'
// import { linkTemplate, nodeVerticalTemplate, taskNodeTemp, typeColorConfig } from './diagramTemplate/Template'
import walen from '@/assets/js/walden.json'

export default {
  name: 'Layout',
  provide() {
    return {
      nodeTemp: null,
      linkTemp: null,
      taskNodeTemp: null,
      colorConfig: null,
      strokeColor: '#888',
      echartTheme: walen,
      orgNodeType: '',
    }
  },
  components: {
    Header,
    ModalAll,
  },
}
</script>

<style lang="less" scoped>
@header-height: 70px;
@background-color-layout: var(--background-color-layout, #002150);

.layout {
  height: 100%;
  background-color: #e6f2ff;
  .layout-header {
    height: @header-height;
  }
  .layout-page {
    height: calc(100% - @header-height);
    overflow: auto;
    padding: 10px;
  }
}
</style>
