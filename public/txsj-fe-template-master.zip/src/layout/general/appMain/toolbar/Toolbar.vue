<template>
  <div class="header-tool-bar">
    <div class="tool-wrap-left">
      <span class="tool-icon" title="收起" v-show="!isCollapse"><i class="el-icon-s-fold" @click="onChangeCollapse" /></span>
      <span class="tool-icon" title="展开" v-show="isCollapse"><i class="el-icon-s-unfold" @click="onChangeCollapse" /></span>
      <span class="tool-icon" title=" 刷新"><i class="el-icon-refresh-right" @click="onRefresh" /></span>
    </div>
    <div class="tool-wrap-right">
      <!-- <span class="tool-icon" title=" 换肤" v-click-outside="onClickOutside" v-show="isShowTheme" @click="showThemeList">
        <span class="iconfont icon-genghuanpifu" />
        <ThemeSelect class="theme-select-com" v-show="isSelectTheme" />
      </span> -->
      <span class="tool-icon" v-click-outside="onMemoClose">
        <i class="el-icon-collection" title="便签" @click="onMemoShow" />
        <Memo class="memo-com" ref="memoRef" />
      </span>

      <span class="tool-icon" :title="'首页'"><span class="iconfont icon-shouye1" @click="goHomePage" /></span>
      <span class="tool-icon" :title="isFullScreen ? '退出全屏' : '全屏'"><span class="iconfont icon-quanping" @click="onChangeFullScreen" /></span>
      <el-dropdown>
        <div class="user-info">
          {{ userInfo?.name }}
          <i class="el-icon-arrow-down el-icon--right"></i>
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item @click.native="onQuit">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
import { SettingMutations } from '@/store/modules/setting'
import { getIsCollapse } from '@/utils/sysUtils'
import { mapState } from 'vuex'
// import ThemeSelect from '@/components/themeSelect/index.vue'
import configData from '@/utils/config'
import Memo from '@/components/memo/Memo.vue'
export default {
  props: {
    isFullScreen: {
      type: Boolean,
    },
  },
  data() {
    return {
      isShowTheme: configData.themeSet,
      isSelectTheme: false,
    }
  },
  computed: {
    isCollapse() {
      return getIsCollapse()
    },
    ...mapState('user', ['userInfo']),
  },
  mounted() {
    console.log(this.userInfo, 555)
  },
  methods: {
    onChangeCollapse() {
      this.$store.commit(`setting/${SettingMutations.SET_IS_COLLAPSE_GUIDANCE}`, !this.isCollapse)
    },
    onChangeFullScreen() {
      this.$emit('fullScreen')
      // this.isFullScreen = !this.isFullScreen
    },
    onRefresh() {
      this.$emit('refresh')
    },
    goHomePage() {
      this.$router.push('/')
    },
    async onQuit() {
      // 退出登录事件
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirectUrl=${this.$router.currentRoute.fullPath}`)
    },
    showThemeList() {
      this.isSelectTheme = !this.isSelectTheme
    },
    onClickOutside() {
      this.isSelectTheme = false
    },
    onMemoShow() {
      this.$refs.memoRef.show()
    },
    onMemoClose() {
      this.$refs.memoRef.close()
    },
  },
  components: {
    // ThemeSelect,
    Memo,
  },
}
</script>

<style lang="less" scoped>
.header-tool-bar {
  height: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .tool-wrap-left,
  .tool-wrap-right {
    height: 100%;
    display: flex;
  }
  .tool-icon {
    width: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;

    i,
    svg,
    .iconfont {
      cursor: pointer;
      font-size: 18px;
    }
    i:hover,
    svg:hover,
    .iconfont:hover {
      color: @font-color-active;
    }
  }
  .user-info {
    height: 50px;
    padding: 0 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
  }

  .theme-select-com {
    position: absolute;
    left: 0px;
    top: 35px;
    z-index: 19;
    border-radius: 4px;
    padding: 5px 0px;
    background-color: @background-color-base;
    box-shadow: 0px 0px 5px @shadow-color-base; //0px
  }
  .memo-com {
    right: 150;
    position: absolute;
    top: 35px;
    z-index: 19;
    border-radius: 4px;
    // padding: 5px 0px;
    background-color: @background-color-base;
    box-shadow: 0px 0px 5px @shadow-color-base; //0px
  }
}
</style>
