<template>
  <div class="app-main">
    <div class="tool-bar">
      <Toolbar :isFullScreen="isFullScreen" @fullScreen="fullScreen" @refresh="refresh" />
    </div>
    <div class="main-container">
      <TagsView class="main-container-tagsview"></TagsView>
      <div class="main-container-content">
        <transition name="fade-transform" mode="out-in">
          <keep-alive :include="cachedViews">
            <router-view :key="key" style="height: 100%" />
          </keep-alive>
        </transition>
      </div>
    </div>
  </div>
</template>

<script>
import screenfull from 'screenfull'
import Toolbar from './toolbar/Toolbar.vue'
import TagsView from '@/components/tagsView/index.vue'
export default {
  name: 'MainContainer',
  components: { TagsView, Toolbar },
  data() {
    return {
      isFullScreen: false,
    }
  },
  computed: {
    cachedViews() {
      return this.$store.state.tagsView.cachedViews
    },
    key() {
      return this.$route.path
    },
  },
  methods: {
    fullScreen() {
      screenfull.toggle()
      this.isFullScreen = !this.isFullScreen
    },
    refresh() {
      console.log('页面刷新')
      this.$router.go(0)
    },
  },
}
</script>

<style lang="less" scoped>
.app-main {
  height: 100%;
  .tool-bar {
    height: 50px;
    border-bottom: 1px solid @border-color-base;
  }
  .main-container {
    height: calc(100% - 50px);

    &-tagsview {
      height: 34px;
    }
    &-content {
      height: calc(100% - 34px);
      background: #fff;
      > div {
        overflow-y: auto;
      }
    }
  }
}
</style>
