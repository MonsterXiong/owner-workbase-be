<template>
  <section class="layout">
    <nav>
      <SideBar />
    </nav>
    <main>
      <AppMain />
    </main>
    <ModalAll />
  </section>
</template>

<script>
import ModalAll from '@/views/modalAll/index.vue'
import SideBar from './sideBar/SideBar.vue'
import AppMain from './appMain/AppMain.vue'
import 'splitpanes/dist/splitpanes.css'

export default {
  name: 'Layout',
  components: {
    ModalAll,
    SideBar,
    AppMain,
  },
  data() {
    return {}
  },
  computed: {},
  methods: {},
}
</script>

<style lang="less" scoped>
.layout {
  height: 100%;
  display: flex;
  nav {
    height: 100%;
  }
  main {
    flex: 1;
    height: 100%;
  }
}
</style>
