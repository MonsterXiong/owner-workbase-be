<template>
  <div>
    <template v-if="!menuItem.children">
      <el-menu-item :index="menuItem[MenuKeyConfig.idKey]" @click="onMenuClick(menuItem)" class="menu-item-menus">
        <BaseIcon :iconName="menuItem?.icon || 'icon-wenjian'" class="inline-icon" />
        <span slot="title">{{ menuItem.name }}</span>
      </el-menu-item>
    </template>
    <el-submenu v-else :index="menuItem[MenuKeyConfig.idKey]" :class="menuItem.children && menuItem.children.length ? 'submenu-menus' : ''">
      <template slot="title">
        <div :class="menuItem.menusClass ? 'menu-item-menus' : ''">
          <BaseIcon :iconName="menuItem?.icon || 'icon-wenjian'" class="inline-icon" />
          <span slot="title">{{ menuItem.name }}</span>
        </div>
      </template>
      <template v-for="childMenu in menuItem.children">
        <MenuBarItem
          v-if="childMenu.children && childMenu.children.length"
          :menuItem="childMenu"
          :key="childMenu[MenuKeyConfig.idKey]"
          @menuClick="onMenuClick"
        />
        <el-menu-item
          :class="childMenu[MenuKeyConfig.idKey]"
          class="header-el-menu-item"
          v-else
          :key="childMenu[MenuKeyConfig.idKey] + 'else'"
          :index="childMenu[MenuKeyConfig.idKey]"
          @click="onMenuClick(childMenu)"
        >
          <BaseIcon :iconName="childMenu?.icon || 'icon-wenjian'" class="inline-icon" />
          <span slot="title">{{ childMenu.name }}</span>
        </el-menu-item>
      </template>
    </el-submenu>
  </div>
</template>

<script>
import { MenuKeyConfig } from '@/common/constants'
export default {
  name: 'MenuBarItem',
  props: {
    menuItem: { type: Object, required: true },
  },
  data() {
    return { MenuKeyConfig }
  },
  methods: {
    onMenuClick(menu) {
      this.$emit('menuClick', menu)
    },
  },
}
</script>

<style lang="less" scoped>
.menu-item-menus {
  span {
    font-size: 16px;
  }
  .el-submenu__title {
  }
}
</style>
