<template>
  <header class="layout-header" ref="xydHeaderRef">
    <h1 class="header-title" :style="'width:' + titleWidth + 'px'">
      <img src="../../../assets/image/xydLayout/headIcon.png" alt="" />
      <span class="head-text">{{ title }}</span>
    </h1>
    <nav class="nav-menu" :style="'width:' + rightWidth + 'px;left:' + (titleWidth - 50) + 'px'">
      <ul class="first-menu">
        <li v-for="menu in menu_TreeData" :key="menu[MenuKeyConfig.idKey]" :class="menu_setActiveClass(menu)" @click="onFirstMenuClick(menu)">
          {{ menu.name }}
        </li>
      </ul>
      <ul class="second-menu" v-click-outside="onSecondMenuClickOutside" ref="secondMenuRef">
        <li
          v-for="menu in menu_secondTreeData"
          :key="menu[MenuKeyConfig.idKey]"
          :class="menu_setActiveClass(menu)"
          @click.stop="(ev) => onSecondMenuClick(menu, ev)"
        >
          <div class="li-inner">
            {{ menu.name }}
          </div>
        </li>
      </ul>
    </nav>
    <TopMenus
      ref="TopMenus"
      class="top-menu-com"
      v-show="childrenList.length > 0"
      :menuList="childrenList"
      :style="{ left: position.x + 'px', top: position.y + 'px' }"
      @onMenuClick="menu_onMenuClick"
    />
  </header>
</template>

<script>
import configData from '@/utils/config'
import menuMixin from '@/layout/menuMixin'
import TopMenus from '@/layout/components/TopMenus'
import { MenuKeyConfig } from '@/common/constants'
import ElementResizeDetectorMaker from 'element-resize-detector'

export default {
  mixins: [menuMixin],
  components: { TopMenus },
  data() {
    return {
      title: configData.systemName,
      childrenList: [],
      position: { x: -1, y: -1 },
      titleWidth: '0px',
      rightWidth: '0px',
      MenuKeyConfig,
    }
  },
  computed: {},
  mounted() {
    let erd = ElementResizeDetectorMaker()
    erd.listenTo(this.$refs.xydHeaderRef, (ele) => {
      this.calculateWidth()
    })
    this.mouseWheelChange('secondMenuRef')
  },
  methods: {
    calculateWidth() {
      this.titleWidth = this.title.length * 32 + 72 + 50
      this.rightWidth = this.$refs.xydHeaderRef.offsetWidth - this.titleWidth + 50
    },
    mouseWheelChange(refName) {
      let div = this.$refs[refName]
      div.addEventListener('wheel', (e) => {
        let left = -e.wheelDelta || e.deltaY / 2
        console.log('wheelDelta', -e.wheelDelta, 'deltaY', e.deltaY)
        div.scrollLeft = div.scrollLeft + left
      })
    },
    onFirstMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    // 二级菜单点击事件 如果有旗下的第三级菜单则弹出
    onSecondMenuClick(menu, ev) {
      this.menu_onMenuClick(menu)
      if (menu?.children) this.childrenList = menu.children || []
      else {
        this.childrenList = []
      }
      this.position.x = ev.clientX + 4 - 40
      this.position.y = 90 - 14
    },
    onSecondMenuClickOutside() {
      this.childrenList = []
    },
  },
}
</script>

<style scoped lang="less">
@import '../style/varColorStyle.less';
@font-face {
  font-family: 'ALIMAMASHUHEITI-BOLD';
  src: url('~@/assets/font/ALIMAMASHUHEITI-BOLD.TTF') format('truetype');
}

.layout-header {
  display: flex;
  // background-image: url('~@/assets/image/xydLayout/head.png');
  background-repeat: no-repeat;

  background-size: 106% 115%;
  background-position-x: -115px;

  .header-title {
    // width: 510px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin: 0;
    background-image: url('~@/assets/image/xydLayout/headL.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding-bottom: 10px;
    clip-path: polygon(0 0%, 100% 0%, calc(100% - 50px) 100%, 0 100%);
    img {
      width: 42px;
      height: 42px;
      margin: 0 15px;
    }
    .head-text {
      font-family: 'ALIMAMASHUHEITI-BOLD';
      font-weight: 700;
      font-size: 32px;
      color: transparent;
      background-image: linear-gradient(to bottom, @xyd-header-font-color-light, @xyd-header-font-color-dark);
      background-clip: text;
    }
  }

  .nav-menu {
    // position: relative;
    height: 100%;
    position: absolute;
    // width: calc((100% - 510px));
    background-image: url('~@/assets/image/xydLayout/headRight.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding-bottom: 10px;
    clip-path: polygon(49px 0%, 100% 0%, 100% 100%, -2px 100%);
    > ul {
      display: flex;
      overflow-x: auto;
    }
    .first-menu {
      // margin-left: 35px;
      // height: 51px;
      // width: calc(100% - 35px);
      height: 44px;
      margin-left: 28px;
      width: calc(100% - 28px);
      > li {
        margin: 0 20px;
        font-family: '微软雅黑 Bold', '微软雅黑 Regular', '微软雅黑';
        font-weight: 700;
        font-size: 18px;
        line-height: 48px;
        color: @xyd-font-color-white;
        cursor: pointer;

        &.active {
          color: @xyd-menu-font-color-active;
        }
      }
    }
    .second-menu {
      // height: 34px;
      // margin-left: 14px;
      // width: calc(100% - 14px);
      height: 31px;
      margin-left: 9px;
      width: calc(100% - 9px);
      clip-path: polygon(18px 0%, 100% 0%, 100% 100%, 0 100%);
      > li {
        // min-width: 190px;
        font-family: '微软雅黑';
        font-weight: 400;
        font-size: 16px;
        color: @xyd-font-color-white;
        line-height: 31px;
        // padding: 0 20px;
        cursor: pointer;
        // background-image: url('~@/assets/image/xydLayout/menuBg.png');
        // background-repeat: no-repeat;
        // background-size: 100% 100%;
        position: relative;
        text-align: center;
        text-overflow: ellipsis;
        white-space: nowrap;
        position: relative;
        text-align: center;
        background: linear-gradient(to bottom, @xyd-menu-bg-color-active, @xyd-menu-bg-color);
        clip-path: polygon(18px 0%, 100% 0%, calc(100% - 18px) 100%, 0 100%);
        .li-inner {
          padding: 0 20px;
          background: @xyd-menu-bg-color;
          clip-path: polygon(19px 1px, calc(100% - 2px) 1px, calc(100% - 18px) 100%, -1px 100%);
        }
        &.active {
          color: @xyd-menu-font-color-active;
          // background-image: url('~@/assets/image/xydLayout/menuActive.png');
          // background-repeat: no-repeat;
          // background-size: 100% 100%;
          .li-inner {
            background: transparent;
            background-image: url('~@/assets/image/xydLayout/menuBtnActive.png');
            background-repeat: no-repeat;
            background-size: 100% 100%;
          }

          &::after {
            content: '';
            position: absolute;
            width: 45px;
            height: 4px;
            border-radius: 10px 10px 0 0;
            background-color: @xyd-menu-font-color-active;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
          }
        }
      }
    }
    .second-menu::-webkit-scrollbar {
      display: none;
    }
  }
}

.top-menu-com {
  position: absolute;
  left: 20px;
  top: 35px;
  z-index: 2000;
  min-width: 200px;
  max-width: 250px;
  border-radius: 4px;
  background-color: @xyd-table-header-bgcolor-light; //#158dc1;
  box-shadow: 1px 1px 3px @xyd-box-shadow-color;
  z-index: 1999;
  ::v-deep {
    .el-menu {
      background-color: @xyd-table-header-bgcolor-light; //#116191;
      .el-menu-item {
        color: @xyd-font-color-white !important;
        background-color: @xyd-table-header-bgcolor-light; //#1277aa;
        &:hover,
        &:focus {
          background-color: @xyd-table-bgcolor-hover; //#158dc1;
        }
        &.is-active {
          color: @xyd-menu-font-color-active; //#7dfbf5 !important;
          background-color: @xyd-table-bgcolor-hover; //#158dc1;
          border-color: @xyd-table-bgcolor-hover; // #158dc1;
        }
      }
    }
  }
}
</style>
