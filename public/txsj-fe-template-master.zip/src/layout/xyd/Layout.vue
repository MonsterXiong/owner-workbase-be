<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header"></Header>
    <!-- 主页面 -->
    <main class="layout-page">
      <router-view style="height: 100%" />
    </main>
    <ModalAll />
  </section>
</template>

<script>
import Header from './header/Header.vue'
import ModalAll from '@/views/modalAll/index.vue'
import 'splitpanes/dist/splitpanes.css'
import { linkTemplate, nodeVerticalTemplate, taskNodeTemp, typeColorConfig } from './diagramTemplate/Template'
import walen from '@/assets/js/walden.json'

export default {
  name: 'Layout',
  provide() {
    return {
      nodeTemp: nodeVerticalTemplate,
      linkTemp: linkTemplate,
      taskNodeTemp: taskNodeTemp,
      colorConfig: typeColorConfig,
      strokeColor: '#37d0f9',
      echartTheme: walen,
      orgNodeType: '',
    }
  },
  components: {
    Header,
    ModalAll,
  },
}
</script>

<style lang="less" scoped>
@header-height: 90px;
@background-color-layout: var(--background-color-layout, #002150);

.layout {
  height: 100%;
  background-color: @background-color-layout;
  background-image: url('~@/assets/image/xydLayout/bg.png');
  .layout-header {
    height: @header-height;
  }
  .layout-page {
    height: calc(100% - @header-height);
    overflow: auto;
  }
}
@import './style/index.less';
@import './style/componentStyle.less';
</style>

<style lang="less">
@import './style/elementStyle.less';
@import './style/listStyle.less';
</style>
