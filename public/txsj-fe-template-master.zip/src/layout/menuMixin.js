import { MenuKeyConfig } from '@/common/constants'
import { menuList, getMenuList } from '@/layout/menuData'
import { handleNavMenuClick } from '@/utils/navMenuUtil'
import { listToTree } from '@/utils/treeTool'

export default {
  provide() {
    return {
      menu_ListData: this.menu_ListData,
      menu_TreeData: this.menu_TreeData,
      menu_setActiveClass: this.menu_setActiveClass,
      menu_thirdTreeData: this.menu_thirdTreeData,
      menu_ActiveCodeChain: this.menu_ActiveCodeChain,
      menu_onMenuClick: this.menu_onMenuClick,
    }
  },
  data() {
    this.handlerTimer = null
    return {
      menu_ListData: [], // 所有菜单平铺
      menu_TreeData: [], // 菜单树
      menu_ActiveCodeChain: [], // 当前选中的code链
    }
  },
  computed: {
    // 当前激活的第一层菜单
    menu_activeFirstData() {
      const findMenu = this.menu_TreeData.find((item) => this.menu_ActiveCodeChain[0] === item[MenuKeyConfig.idKey])
      return findMenu || {}
    },
    // 第二级菜单树
    menu_secondTreeData() {
      const findMenu = this.menu_TreeData.find((item) => this.menu_ActiveCodeChain[0] === item[MenuKeyConfig.idKey])
      return findMenu?.children || []
    },
    // 第三级菜单树
    menu_thirdTreeData() {
      const menu1 = this.menu_TreeData.find((item) => this.menu_ActiveCodeChain[0] === item[MenuKeyConfig.idKey])?.children || []
      let findMenu = menu1.find((item) => this.menu_ActiveCodeChain[1] === item[MenuKeyConfig.idKey])
      return findMenu?.children || []
    },
  },
  created() {
    getMenuList().then((data) => {
      this.menu_initMenuData(data)
    })
  },
  watch: {
    menu_TreeData() {
      this.menu_setDefaultActiveMenu()
    },
  },
  methods: {
    // 初始化菜单数据,洗成树结构
    menu_initMenuData(data) {
      // this.menu_ActiveCodeChain = []
      this.menu_ListData = (Array.isArray(data) ? data : []).map((item) => ({
        ...item,
        _collapse: false,
      }))
      this.menu_TreeData = listToTree(this.menu_ListData, {
        idKey: MenuKeyConfig.idKey,
        pidKey: MenuKeyConfig.pidKey,
      })
      this.menu_handleSetCodeChain(this.menu_TreeData)
    },
    // 菜单点击事件
    menu_onMenuClick(menu) {
      this.menu_ActiveCodeChain = menu?._codeChain || []
      // TODO 在这里处理判断菜单类型处理菜单点击事件

      this.handlerTimer && clearTimeout(this.handlerTimer)
      this.handlerTimer = setTimeout(() => {
        // 如果有点击事件 触发点击事件
        if (menu.handler) {
          menu.handler()
        } else {
          handleNavMenuClick(menu)
        }
        this.handlerTimer = null
      }, 0)
      return menu?._codeChain || []
    },
    // 应用于设置class="active"类名 菜单是否高亮
    menu_setActiveClass(menu) {
      // return this.menu_activeCodeChain ? (this.menu_activeCodeChain.includes(menu[MenuKeyConfig.idKey]) ? 'active' : '') : ''
      if (this.menu_ActiveCodeChain.find((ele) => ele === menu[MenuKeyConfig.idKey])) return 'active'
      else return ''
    },
    // 递归设置树的节点code链
    menu_handleSetCodeChain(arr, parent) {
      if (Array.isArray(arr)) {
        arr.forEach((item) => {
          item._codeChain = parent?._codeChain ? [...parent?._codeChain, item[MenuKeyConfig.idKey]] : [item[MenuKeyConfig.idKey]]
          if (Array.isArray(item.children)) {
            this.menu_handleSetCodeChain(item.children, item)
          }
        })
      }
    },
    // 设置默认的激活菜单, 一般应用于`mounted`内
    async menu_setDefaultActiveMenu() {
      await this.$nextTick()
      // 如果是外部页面,则找到对应的菜单
      const { url } = this.$route.query
      if (url) {
        const urlPage = decodeURIComponent(url)
        const findMenu = this.menu_ListData.find((item) => item.menuParams === urlPage || item.menuParams === url)
        if (findMenu) {
          this.menu_onMenuClick(findMenu)
          return
        }
      }
      // 根据当前页面路由找到对应的菜单 优先匹配全量的路径 `fullPath`
      const findMenu1 = this.menu_ListData.find((item) => item.menuParams === this.$route.fullPath)
      const findMenu2 = this.menu_ListData.find((item) => item.menuParams === this.$route.path)
      if (findMenu1 || findMenu2) {
        this.menu_onMenuClick(findMenu1 || findMenu2)
        return
      }
      // 默认选第一个菜单的第一个子菜单 或者第一个菜单
      // this.menu_onMenuClick(this.menu_TreeData[0]?.children[0] || this.menu_TreeData[0])
    },
  },
}
