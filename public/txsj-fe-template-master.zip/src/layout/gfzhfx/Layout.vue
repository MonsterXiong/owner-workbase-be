<template>
  <section class="layout">
    <!-- 头部 -->
    <Header class="layout-header"></Header>
    <!-- 主页面 -->
    <main class="layout-page">
      <router-view style="height: 100%" />
    </main>
  </section>
</template>

<script>
import Header from './header/Header.vue'
import 'splitpanes/dist/splitpanes.css'
export default {
  components: { Header },
}
</script>

<style lang="less" scoped>
@header-height: 80px;

.layout {
  height: 100%;
  .layout-header {
    height: @header-height;
  }
  .layout-page {
    height: calc(100% - @header-height);
    padding: 10px;
    background: #e5eefd;
    overflow: auto;
  }
}
</style>
