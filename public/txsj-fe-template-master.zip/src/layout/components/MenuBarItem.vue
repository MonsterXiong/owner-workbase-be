<template>
  <div>
    <template v-if="getMenuShow(menuItem)">
      <el-menu-item :index="menuItem.code" @click="onMenuClick(menuItem)" class="menu-item-menus">
        <MenuIcon :icon="menuItem?.icon || 'icon-wenjian'" />
        <span slot="title">{{ menuItem.title || menuItem.name }}</span>
      </el-menu-item>
    </template>
    <el-submenu v-else :index="menuItem.code" :class="menuItem.children && menuItem.children.length ? 'submenu-menus' : ''">
      <template slot="title">
        <div :class="menuItem.menusClass ? 'menu-item-menus' : ''">
          <MenuIcon class="inline-icon" :icon="menuItem?.icon || 'icon-wenjian'" />
          <span slot="title">{{ menuItem.title || menuItem.name }}</span>
        </div>
      </template>
      <template v-for="childMenu in menuItem.children">
        <MenuBarItem v-if="childMenu.children && childMenu.children.length" :menuItem="childMenu" :key="childMenu.code" />
        <el-menu-item
          :class="childMenu.code"
          class="header-el-menu-item"
          v-else
          :key="childMenu.code + 'else'"
          :index="childMenu.code"
          @click="onMenuClick(childMenu)"
        >
          <MenuIcon class="inline-icon" :icon="childMenu?.icon || 'icon-wenjian'" />
          <span slot="title">{{ childMenu.title || childMenu.name }}</span>
        </el-menu-item>
      </template>
    </el-submenu>
  </div>
</template>

<script>
import MenuIcon from '@/layout/components/menuIcon.vue'

export default {
  inject: ['menu_onMenuClick'],
  name: 'MenuBarItem',
  props: {
    menuItem: { type: Object, required: true },
  },
  methods: {
    onMenuClick(menu) {
      this.menu_onMenuClick(menu)
    },
    getMenuShow(data) {
      let list = data.children || []
      return list.length == 0 ? true : false
    },
  },
  components: {
    MenuIcon,
  },
}
</script>

<style lang="less" scoped>
.menu-item-menus {
  span {
    font-size: 16px;
  }
  .el-submenu__title {
    border: 1px solid red;
  }
}
// v-deep {
.icon-wrap {
  margin-right: 3px;
}
// }
</style>
