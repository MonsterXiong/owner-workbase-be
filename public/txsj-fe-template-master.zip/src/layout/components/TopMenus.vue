<template>
  <div class="menu-wrap">
    <el-menu
      :default-active="routeMenuId"
      class="el-menu-vertical-demo"
      :default-openeds="menuList.map((ele, index) => ele[MenuKeyConfig.idKey])"
      :collapse-on-click="true"
    >
      <MenuBarItem v-for="item in menuList" :menuItem="item" :key="item[MenuKeyConfig.idKey]" :routeMenuId="routeMenuId" />
    </el-menu>
  </div>
</template>

<script>
import MenuBarItem from '@/layout/components/MenuBarItem.vue'
import { MenuKeyConfig } from '@/common/constants'

export default {
  name: 'TopMenu',
  components: { MenuBarItem },
  props: {
    menuList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      routeMenuId: '',
      activeMenuId: '',
      MenuKeyConfig,
    }
  },
  watch: {
    $route: {
      handler: function (newRoute) {
        if (!newRoute) {
          return
        }
        this.setActiveMenu()
        this.routeMenuId = this.$route.query.menuId
      },
      immediate: true,
    },
    menuList: {
      handler() {
        this.setActiveMenu()
      },
      immediate: true,
    },
  },
  methods: {
    setActiveMenu() {
      if (!this.$route) return
      const activeMenu = this.menuList.find((menu) => menu.url && (menu.url === this.$route.path || menu.url.split('?')[0] === this.$route.path))
      if (activeMenu) this.activeMenuId = activeMenu[MenuKeyConfig.idKey] ?? ''
      this.menuList.map((item) => {
        this.$set(item, 'menusClass', true)
      })
    },
  },
}
</script>

<style lang="less" scoped>
@background-color-light: var(--background-color-light, #f4f9ff);
@background-color-light-hover: var(--background-color-light-hover, #dfeeff);
@font-color-dark-gray: var(--font-color-dark-gray, #333);
@background-color-base: var(--background-color-base, #fff);
@background-color-echart-dark: var(--background-color-echart-dark, #edf6ff);
@border-color-light: var(--border-color-light, #d8dce5);
@font-size--middle: var(--font-size-middle, 16px);

::v-deep {
  .el-menu {
    background: transparent !important;
    border: none;
    padding: 0 !important;
    // border: 1px solid transparent;
    text-align: left;
    .submenu-menus:first-child {
      .el-submenu__title {
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
      }
    }

    .el-submenu__title:hover,
    .el-menu-item:hover {
      background-color: @background-color-light;
    }
    .el-menu-item,
    .el-submenu__title {
      color: @font-color-dark-gray !important;
      border: 1px solid transparent;
      background: @background-color-base;
      padding-top: 15px;
      padding-bottom: 15px;
      height: auto !important;
      line-height: 0 !important;
      min-width: 150px !important;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    .submenu-menus {
      .el-submenu__title {
        background-color: @background-color-echart-dark;
        border-color: @border-color-light;
      }
    }
    .el-menu-item.is-active {
      background-color: @background-color-light;
      border-color: @border-color-light;
    }
    .el-submenu__icon-arrow {
      color: @font-color-dark-gray;
    }
    .menu-item-menus {
      font-size: @font-size--middle;
    }
  }
}
</style>
