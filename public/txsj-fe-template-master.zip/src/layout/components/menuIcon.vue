<template>
  <div class="menu-icon-wrapper icon-wrap">
    <span :class="getMenuIcon()" v-if="checkIconShow('icon-')" />
    <i :class="icon" v-else-if="checkIconShow('el-')"></i>
    <BaseIcon v-else :iconName="icon" />
  </div>
</template>

<script>
export default {
  props: {
    icon: {
      type: String,
      default: '',
    },
  },
  methods: {
    checkIconShow(key) {
      if (this.icon.startsWith(key)) {
        return true
      } else return false
    },
    getMenuIcon() {
      return ['iconfont', this.icon || 'icon--_dakaixiangmu-copy']
    },
  },
}
</script>

<style lang="less" scoped>
.menu-icon-wrapper {
  display: inline-block;
  // background-color: @border-color-base;
  // color: @font-color-dark-gray;
}
</style>
