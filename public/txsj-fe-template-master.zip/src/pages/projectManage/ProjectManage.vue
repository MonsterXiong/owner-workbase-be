<template>
  <TableLayout>
    <template #query>
      <ProjectManageQuery @onEvent="onEvent" :queryForm.sync="queryForm"></ProjectManageQuery>
    </template>
    <ProjectManageTable
      :pageInfo.sync="pageInfo"
      :tableData="tableData"
      :total="total"
      @onOpen="onOpen"
      @onEdit="onEdit"
      @onDelete="onDelete"
      @selection-change="onSelectionChange"
    ></ProjectManageTable>
    <ProjectManageDialog ref="projectManageDialogRef" @submit="onSubmit"></ProjectManageDialog>
  </TableLayout>
</template>

<script>
import { XydProjectService } from '@/services'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import ProjectManageDialog from './components/ProjectManageDialog.vue'
import ProjectManageTable from './components/ProjectManageTable.vue'
import ProjectManageQuery from './components/ProjectManageQuery.vue'

export default {
  name: 'ProjectManage',
  components: {
    ProjectManageTable,
    ProjectManageQuery,
    ProjectManageDialog,
  },
  data() {
    return {
      tableData: [],
      queryForm: {},
      total: 0,
      pageInfo: {
        page: 1,
        rows: 20,
      },
      multipleSelection: [],
    }
  },
  mounted() {
    this.init()
  },
  watch: {
    pageInfo: {
      handler() {
        this.getTableData()
      },
      deep: true,
    },
  },
  methods: {
    async initProjectList() {
      return await this.$store.dispatch('project/initProjectList')
    },
    init() {
      this.getTableData()
    },
    // 多选
    onSelectionChange(val) {
      this.multipleSelection = val
    },
    // 查询
    onQuery() {
      this.getTableData()
    },
    // 重置
    onReset() {
      Object.keys(this.queryForm).forEach((key) => {
        this.queryForm[key] = ''
      })
      // pageInfo修改会触发查询功能
      this.pageInfo = { page: 1, rows: 20 }
    },
    // 新增
    onAdd() {
      this.$refs.projectManageDialogRef.show()
    },
    onOpen(row) {
      this.$store.dispatch('project/setCurrentProject', row)
    },
    // 编辑
    onEdit(row) {
      this.$refs.projectManageDialogRef.show(row)
    },
    // 删除
    async onDelete(row) {
      try {
        await this.$tools.confirm('请确认是否删除？')
        const { code } = await this.onDeleteAPI(row.projectId)
        if (code === 200) this.$tools.message('删除成功')
        this.getTableData()
        this.initProjectList()
      } catch (e) {
        if (e == 'cancel') return this.$tools.message('已取消删除', { type: 'info' })
        console.error('删除失败', e)
      }
    },
    // 批量删除
    async onBatchDelete() {
      const ids = this.multipleSelection.map((item) => item.projectId)
      if (!ids.length) {
        return this.$message.warning('请先选择需要删除的内容')
      }
      try {
        await this.$tools.confirm('请确认是否删除？')
        const { code } = await this.onBatchDeleteAPI(ids)
        if (code === 200) this.$tools.message('删除成功')
        this.getTableData()
        this.initProjectList()
      } catch (e) {
        if (e == 'cancel') return this.$tools.message('已取消删除', { type: 'info' })
        console.error('删除失败', e)
      }
    },
    // 处理query组件触发的方法
    onEvent(type) {
      switch (type) {
        case 'query':
          this.onQuery()
          break
        case 'reset':
          this.onReset()
          break
        case 'add':
          this.onAdd()
          break
        case 'batchDelete':
          this.onBatchDelete()
          break
        default:
          console.log('不支持的方法类型')
          break
      }
    },
    async getTableData() {
      this.tableData = [{ projectName: 'projectName假数据' }]
      this.total = 30
      // const queryCondition = QueryConditionBuilder.getInstance(this.pageInfo.page, this.pageInfo.rows)
      // Object.keys(this.queryForm).forEach((key) => {
      //   if (this.queryForm[key] || this.queryForm[key] == 0) {
      //     queryCondition.buildLikeQuery(key, this.queryForm[key])
      //   }
      // })
      // const { data, count } = await this.onQueryListAPI(queryCondition)
      // this.tableData = data
      // this.total = count
    },
    async onSubmit(formData) {
      try {
        await this.onSaveAPI(formData)
        this.getTableData()
        this.initProjectList()
        this.$message.success('操作成功')
      } catch (error) {
        this.$message.error('操作失败，请联系管理员或者重试')
      }
    },
    // 查询列表API
    async onQueryListAPI(queryCondition) {
      return await XydProjectService.queryXydProjectByCondition(queryCondition)
    },
    // 删除API
    async onDeleteAPI(id) {
      return await XydProjectService.deleteXydProject(id)
    },
    // 批量删除API
    async onBatchDeleteAPI(ids) {
      return await XydProjectService.deleteXydProjectBatch(ids)
    },
    // 保存API
    async onSaveAPI(param) {
      return await XydProjectService.saveXydProject(param)
    },
    // 新增API
    async onInsertAPI(param) {
      return await XydProjectService.insertXydProject(param)
    },
    // 更新API
    async onUpdateAPI(param) {
      return await XydProjectService.updateXydProject(param)
    },
  },
}
</script>

<style lang="less" scoped></style>
