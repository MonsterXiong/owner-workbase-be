<template>
  <Splitpanes class="proj-page">
    <pane :size="15" class="layout-aside" :minSize="13">
      <div class="proj-side-list">
        <el-input v-model.trim="queryForm.projectName" placeholder="请输入项目名称" size="small">
          <el-button slot="append" icon="el-icon-search" @click="onQuery"></el-button>
        </el-input>

        <div class="btn-wrap">
          <div class="btn-box" v-for="btn in btnList" :key="btn.code" @click="onBtnClick(btn.code)">
            <div class="btn-left">
              <div class="btn-icon-wrap" :style="{ background: btn.color }">
                <base-icon class="btn-item-icon" :iconName="btn?.icon || ''" style="margin-right: 0px" v-show="btn?.icon"></base-icon>
              </div>
              <div class="btn-text-wrap">
                <div class="btn-title">{{ btn.name }}</div>
                <div class="btn-subtitle">{{ btn.subhead }}</div>
              </div>
            </div>
            <i class="el-icon-plus" />
          </div>
        </div>
      </div>
    </pane>
    <pane :size="85" class="layout-right-panel">
      <div class="project-manage-card">
        <main>
          <div class="tab-wrap">
            <span v-for="item in tabList" :key="item.code" @click="onTabClick(item.code)" :class="item.code == activeTab ? 'active' : ''">
              {{ item.name }}
            </span>
            <el-button plain type="danger" size="mini" style="position: absolute; right: 10px; top: 1px" icon="el-icon-delete" @click="onSetDelete"
              >批量删除</el-button
            >
          </div>
          <div class="card-container">
            <div
              class="card-wrap"
              v-for="(item, index) in tableData"
              :key="item.projectId"
              :class="(index + 1) % 5 == 0 ? 'card-wrap1' : ''"
              @click="onProjectClick(item)"
            >
              <img src="./sampleGraph.png" alt="" />
              <div class="card-title">
                <i class="el-icon-view" v-show="cardState == 'open'" />
                <el-checkbox v-model="item.checked" v-show="cardState == 'delete'"></el-checkbox>
                {{ item.projectName }}
              </div>
              <div class="card-subtitle">
                <span>{{ item?.projectName || '' }}</span>
                <span>{{ item?.projectName || '' }}</span>
              </div>
            </div>
          </div>
        </main>
        <div class="pagination-wrapper" ref="paginationRef">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageInfo.page"
            :page-sizes="[10, 20, 50, 100, 200]"
            :page-size="pageInfo.rows"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
          >
          </el-pagination>
        </div>
      </div>
    </pane>
    <ProjectManageDialog ref="projectManageDialogRef" @submit="onSubmit" />
  </Splitpanes>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import { XydProjectService } from '@/services'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import ProjectManageDialog from './components/ProjectManageDialog.vue'
import { Splitpanes, Pane } from 'splitpanes'

export default {
  name: 'ProjectManage',
  components: { Splitpanes, Pane, ProjectManageDialog },
  data() {
    return {
      tableData: [],
      queryForm: {},
      total: 0,
      pageInfo: {
        page: 1,
        rows: 20,
      },
      multipleSelection: [],
      btnList: [
        { name: '新建项目', code: 'add', subhead: 'DoDAF、Chank', color: '#016dc9', icon: 'el-icon-folder-add' },
        { name: '打开项目', code: 'open', subhead: '历史项目、已创建项目', color: '#ecb736', icon: 'el-icon-tickets' },
        { name: '项目流程', code: 'flow', subhead: '各项目流程信息', color: '#01c9b9', icon: 'iconfont icon-xiangxia' },
      ],
      activeTab: 'all',
      tabList: [
        { name: '全部文件', code: 'all' },
        { name: '更新时间', code: 'time' },
      ],
      cardState: '',
    }
  },
  mounted() {
    this.init()
  },
  watch: {
    pageInfo: {
      handler() {
        this.getTableData()
      },
      deep: true,
    },
  },
  methods: {
    onTabClick(code) {
      if (this.activeTab != code) {
        this.getTableData()
        this.activeTab = code
      }
    },
    onSetDelete() {
      if (this.cardState == 'delete') {
        this.multipleSelection = this.tableData.filter((ele) => ele.checked)
        this.onBatchDelete()
      } else this.cardState = 'delete'
    },
    onBtnClick(code) {
      if (code == 'add') {
        this.onAdd()
      } else if (code == 'open') {
        this.cardState = 'open'
        // this.onOpen()
        console.log('打开项目')
      } else if (code == 'flow') {
        console.log('项目流程')
      }
    },
    onProjectClick(row) {
      if (this.cardState == 'open') {
        this.onOpen(row)
      }
    },
    async initProjectList() {
      return await this.$store.dispatch('project/initProjectList')
    },
    init() {
      this.getTableData()
    },
    // 多选
    onSelectionChange(val) {
      this.multipleSelection = val
    },
    // 查询
    onQuery() {
      this.getTableData()
    },
    // 重置
    onReset() {
      Object.keys(this.queryForm).forEach((key) => {
        this.queryForm[key] = ''
      })
      // pageInfo修改会触发查询功能
      this.pageInfo = { page: 1, rows: 20 }
    },
    // 新增
    onAdd() {
      this.$refs.projectManageDialogRef.show()
    },
    onOpen(row) {
      this.$store.dispatch('project/setCurrentProject', row)
      this.cardState = ''
    },
    // 编辑
    onEdit(row) {
      this.$refs.projectManageDialogRef.show(row)
    },
    // 删除
    async onDelete(row) {
      try {
        await this.$tools.confirm('请确认是否删除？')
        const { code } = await this.onDeleteAPI(row.projectId)
        if (code === 200) this.$tools.message('删除成功')
        this.getTableData()
        this.initProjectList()
      } catch (e) {
        if (e == 'cancel') return this.$tools.message('已取消删除', { type: 'info' })
        console.error('删除失败', e)
      }
    },
    // 批量删除
    async onBatchDelete() {
      const ids = this.multipleSelection.map((item) => item.projectId)
      if (!ids.length) {
        return this.$message.warning('请先选择需要删除的内容')
      }
      try {
        await this.$tools.confirm('请确认是否删除？')
        const { code } = await this.onBatchDeleteAPI(ids)
        if (code === 200) this.$tools.message('删除成功')
        this.getTableData()
        this.initProjectList()
      } catch (e) {
        if (e == 'cancel') return this.$tools.message('已取消删除', { type: 'info' })
        console.error('删除失败', e)
      } finally {
        this.cardState = ''
      }
    },
    // 处理query组件触发的方法
    onEvent(type) {
      switch (type) {
        case 'query':
          this.onQuery()
          break
        case 'reset':
          this.onReset()
          break
        case 'add':
          this.onAdd()
          break
        case 'batchDelete':
          this.onBatchDelete()
          break
        default:
          console.log('不支持的方法类型')
          break
      }
    },
    async getTableData() {
      // this.tableData = [{ projectName: 'projectName假数据' }]
      // this.total = 30
      const queryCondition = QueryConditionBuilder.getInstance(this.pageInfo.page, this.pageInfo.rows)
      Object.keys(this.queryForm).forEach((key) => {
        if (this.queryForm[key] || this.queryForm[key] == 0) {
          queryCondition.buildLikeQuery(key, this.queryForm[key])
        }
      })
      if (this.activeTab == 'time') {
        queryCondition.buildAscSort('sysUpdateTime')
      }
      const { data, count } = await this.onQueryListAPI(queryCondition)
      this.tableData = data
      this.total = count
    },
    async onSubmit(formData) {
      try {
        await this.onSaveAPI(formData)
        this.getTableData()
        this.initProjectList()
        this.$message.success('操作成功')
      } catch (error) {
        this.$message.error('操作失败，请联系管理员或者重试')
      }
    },

    handleSizeChange(rows) {
      this.pageInfo.rows = rows
    },
    handleCurrentChange(page) {
      this.pageInfo.page = page
    },
    // 查询列表API
    async onQueryListAPI(queryCondition) {
      return await XydProjectService.queryXydProjectByCondition(queryCondition)
    },
    // 删除API
    async onDeleteAPI(id) {
      return await XydProjectService.deleteXydProject(id)
    },
    // 批量删除API
    async onBatchDeleteAPI(ids) {
      return await XydProjectService.deleteXydProjectBatch(ids)
    },
    // 保存API
    async onSaveAPI(param) {
      return await XydProjectService.saveXydProject(param)
    },
    // 新增API
    async onInsertAPI(param) {
      return await XydProjectService.insertXydProject(param)
    },
    // 更新API
    async onUpdateAPI(param) {
      return await XydProjectService.updateXydProject(param)
    },
  },
}
</script>

<style lang="less" scoped>
.proj-side-list {
  width: 100%;
  height: 100%;
  background: #fff;
  border-radius: 3px;
  ::v-deep {
    .el-input-group__append,
    .el-input-group__prepend {
      border-color: #91c4ff;
      background: #d6e9fb;
      color: #91c4ff;
      padding: 0 10px;
      .el-button {
        padding: 10px;
      }
    }
    .el-input__inner {
      border-color: #91c4ff;
      background: #d6e9fb;
      border-right: none;
    }
  }
  .btn-wrap {
    // height: 55px;
    // display: flex;
    padding: 10px;
    .btn-box {
      padding: 10px;
      background: #fff;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
      border: 1px solid #d7e9fd;
      border-radius: 3px;
      cursor: pointer;
      .btn-left {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .btn-icon-wrap {
        height: 35px;
        width: 35px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        .btn-item-icon {
          color: #fff;
          font-size: 18px !important;
        }
      }
      .btn-text-wrap {
        min-width: 120px;
        margin: 0 25px 0 5px;
        .btn-title {
          font-weight: bold;
          color: #45505d;
        }
        .btn-subtitle {
          color: #999;
          font-size: 12px;
        }
      }
      .el-icon-plus {
        color: #00a8ff;
      }
    }
    .btn-box:hover {
      border-color: #00a8ff;
      // .el-icon-plus {
      //   color: #016dc9;
      // }
    }
  }
}
.project-manage-card {
  margin-left: 10px;
  height: 100%;
  //
  background: #fff;
  main {
    height: calc(100% - 50px);
    .tab-wrap {
      height: 32px;
      border: 1px solid #91c4ff;
      background: #d6e9fb;
      line-height: 30px;
      position: relative;
      span {
        padding: 0 10px;
        cursor: pointer;
      }
      .active {
        font-weight: 600;
        color: #0870d1;
      }
    }
    .card-container {
      height: calc(100% - 54px);
      overflow: auto;
      padding: 10px;
      .card-wrap {
        display: inline-block;
        height: calc(33% - 10px);
        width: calc(20% - 8px);
        background: #d5e6f6;
        margin-right: 10px;
        margin-bottom: 8px;
        border-radius: 5px;
        padding: 6px;
        cursor: pointer;
        img {
          width: 100%;
          height: calc(100% - 50px);
          border-radius: 3px;
        }
        .card-title {
          padding: 6px;
          font-weight: bold;
        }
        .card-subtitle {
          padding: 0 6px;
          color: #b9b9b9;
          font-size: 12px;
          display: flex;
          justify-content: space-between;
          span {
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
      .card-wrap1 {
        margin-right: 0px;
      }
    }
  }
}
::v-deep {
  .splitpanes__splitter {
    border-color: transparent;
    background-color: transparent;
  }
}
</style>
