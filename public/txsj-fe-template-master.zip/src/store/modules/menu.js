import store from 'storejs'
import { LocalStorageItems, locationType } from '@/common/constants.js'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import { XydProjectService } from '@/services'
import { getMenuFilter } from '@/utils/navMenuUtil'

export const MenuMutations = {
  SET_MENULIST: 'SET_MENULIST',
}

const localMenu = store.get(LocalStorageItems.MENU)

const state = {
  menuList: localMenu ? JSON.parse(localMenu) : [],
}

const getters = {
  getMenuList: (state) => state.menuList,
  getTopMenuList: (state) => {
    let list = state.menuList || []
    return getMenuFilter(list, locationType.TOP_MENU)
  },
  getLeftMenuList: (state) => {
    let list = state.menuList || []
    return getMenuFilter(list, locationType.LEFT_MENU)
  },
}

const mutations = {
  [MenuMutations.SET_MENULIST]: (state, list) => {
    state.menuList = list || []
    store.set(LocalStorageItems.MENU, JSON.stringify(state.menuList))
  },
}

const actions = {
  async initmenuList({ commit }) {
    const initQueryCondition = QueryConditionBuilder.getInstanceNoPage()
    initQueryCondition.buildAscSort('sysSort')
    // .buildDescSort('sysCreateTime')
    // const { data, count } = await XydProjectService.queryXydProjectByCondition(initQueryCondition)
    // commit(MenuMutations.SET_MENULIST, data)
    commit(MenuMutations.SET_MENULIST, [])
  },
  setmenuList({ commit }, data) {
    commit(MenuMutations.SET_MENULIST, data)
  },
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
}
