import store from 'storejs'
import { LocalStorageItems } from '@/common/constants.js'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder'
import XydProjectService from '@/services/module/base/XydProjectService'

export const ProjectMutations = {
  ADD_PROJECT: 'ADD_PROJECT',
  SET_PROJECTLIST: 'SET_PROJECTLIST',
  SET_CURRENT_PROJECT: 'SET_CURRENT_PROJECT',
  SET_CURRENT_PROJECT_ID: 'SET_PROJECT_ID',
}

const localCurrentProject = store.get(LocalStorageItems.CURRENT_PROJECT)

const state = {
  projectList: [],
  currentProject: localCurrentProject || null,
  currentProjectId: localCurrentProject?.projectId || '',
}

const getters = {}

const mutations = {
  [ProjectMutations.SET_PROJECTLIST]: (state, list) => {
    state.projectList = list || []
    if (state.currentProjectId) {
      const findProject = state.projectList.find((item) => item.projectId === state.currentProjectId)
      if (findProject) {
        state.currentProject = findProject
        state.currentProjectId = findProject.projectId
      } else if (state.projectList.length > 0) {
        state.currentProject = state.projectList[0]
        state.currentProjectId = state.projectList[0].projectId
      } else {
        state.currentProject = null
        state.currentProjectId = ''
      }
      store.set(LocalStorageItems.CURRENT_PROJECT, state.currentProject)
    }
  },
  [ProjectMutations.SET_CURRENT_PROJECT]: (state, data) => {
    state.currentProject = data
    state.currentProjectId = data.projectId
    store.set(LocalStorageItems.CURRENT_PROJECT, state.currentProject)
  },
  [ProjectMutations.SET_CURRENT_PROJECT_ID]: (state, id) => {
    const findProject = state.projectList.find((item) => item.projectId === id)
    if (findProject) {
      state.currentProject = findProject
      state.currentProjectId = id
    } else {
      state.currentProject = null
      state.currentProjectId = ''
    }
    store.set(LocalStorageItems.CURRENT_PROJECT, state.currentProject)
  },
}

const actions = {
  async initProjectList({ commit }) {
    const initQueryCondition = QueryConditionBuilder.getInstanceNoPage()
    initQueryCondition.buildAscSort('sysSort')
    const { data, count } = await XydProjectService.queryXydProjectByCondition(initQueryCondition)
    commit(ProjectMutations.SET_PROJECTLIST, data)
  },
  setProjectList({ commit }, data) {
    commit(ProjectMutations.SET_PROJECTLIST, data)
  },
  setCurrentProject({ commit }, data) {
    commit(ProjectMutations.SET_CURRENT_PROJECT, data)
  },
  setCurrentProjectId({ commit }, id) {
    commit(ProjectMutations.SET_CURRENT_PROJECT_ID, id)
  },
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
}
