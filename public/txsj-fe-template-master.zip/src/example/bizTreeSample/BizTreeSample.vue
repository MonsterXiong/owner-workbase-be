<template>
  <div class="biz-tree-sample">
    <PanelLayout>
      <template slot="left">
        <BizTree :listTitle="'任务列表'" :treeListNodeConfig="treeListNodeConfig" :treeListConfig="treeListConfig" @insert="onInsert" />
      </template>
    </PanelLayout>
  </div>
</template>

<script>
import BizTree from '@/bizComponents/bizTree/BizTree.vue'
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
export default {
  name: 'BizTreeSample',
  data() {
    return {
      treeListConfig: {
        isFilter: true,
        allowAdd: true,
        readOnly: false,
        type: '',
      },
      treeListNodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'icon-order-fill-copy',
          icons: [{ icon: 'el-icon-circle-plus-outline', name: '添加任务', code: 'insert', addType: 'task' }],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          defaultAdd: true,
          queryRelateCondition: {
            bindProject: 'id',
          },
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '任务名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'el-icon-s-management',
          icons: [
            // { icon: 'el-icon-edit', name: '编辑', code: 'update' },
            // { icon: 'el-icon-delete', name: '删除', code: 'delete' },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          queryRelateCondition: {
            bindTask: 'id',
          },
        },
      ],
    }
  },
  methods: {
    onInsert(data) {
      console.log(data, 'insert 哈哈哈哈')
    },
  },
  components: { BizTree, PanelLayout },
}
</script>

<style></style>
