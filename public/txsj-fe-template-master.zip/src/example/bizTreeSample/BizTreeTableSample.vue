<template>
  <div class="biz-tree-sample">
    <LeftTreeAndRightTable
      :listTitle="'任务列表'"
      :treeListNodeConfig="treeListNodeConfig"
      :treeListConfig="treeListConfig"
      :defaultSelId="defaultSelId"
      :columnList="columnList"
      :tableInterface="tableInterface"
      :tableConfig="tableConfig"
      @insert="onInsert"
    ></LeftTreeAndRightTable>
  </div>
</template>

<script>
import LeftTreeAndRightTable from '@/bizComponents/leftTreeAndRightTable/LeftTreeAndRightTable.vue'
export default {
  name: 'BizTreeSample',
  data() {
    return {
      treeListConfig: {
        isFilter: true,
        allowAdd: false,
        readOnly: false,
        isSelectOneNode: true,
        type: '',
      },
      defaultSelId: '',
      treeListNodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'icon-order-fill-copy',
          icons: [{ icon: 'el-icon-circle-plus-outline', name: '添加任务', code: 'add', addType: 'task' }],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          defaultAdd: true,
          queryRelateCondition: {
            bindProject: 'id',
          },
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '任务名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'el-icon-s-management',
          icons: [
            // { icon: 'el-icon-edit', name: '编辑', code: 'edit' },
            // { icon: 'el-icon-delete', name: '删除', code: 'delete' },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          queryRelateCondition: {
            taskId: 'id',
          },
        },
      ],

      columnList: [
        {
          type: 'selection',
        },
        {
          type: 'index',
        },
        {
          code: 'taskName',
          label: '任务名称',
          query: true,
          required: true,
          type: 'input',
        },
        {
          label: '操作',
          type: 'button',
          buttonList: [
            {
              emitCode: 'edit',
              label: '编辑',
            },
            {
              emitCode: 'delete',
              type: 'danger',
              label: '删除',
            },
          ],
        },
      ],
      tableInterface: {
        service: 'XydTask',
        key: 'taskId',
      },
      tableConfig: {
        dialogTitle: '任务',
        downloadFileName: '任务',
        relationParams: {
          // 关联查询参数
          // bindProject: '3587f47eae444cd08154741eeed70275',
        },
      },
      // relationParams: {
      //   // 关联查询参数
      //   bindProject: 'id',
      // },
    }
  },
  methods: {
    onInsert(data) {
      console.log(data, 'insert 哈哈哈哈')
    },
  },
  components: { LeftTreeAndRightTable },
}
</script>

<style></style>
