<template>
  <div class="common-page" v-loading="loading">
    <div class="tree-wrap">
      <div class="head-wrap">
        <div class="head-title">{{ title }}</div>
      </div>
      <div class="tree-content">
        <base-tree :data="treeData" :props="defaultProps" :node-key="nodeKey"></base-tree>
      </div>
    </div>
  </div>
</template>

<script>
import BaseTree from '@/components/tree/Tree.vue'
import { listToTree } from '@/utils/treeTool'

export default {
  name: 'Welcome',
  data() {
    return {
      loading: false,
      title: 'xx树形结构',
      defaultProps: {
        children: 'children',
        label: 'label',
      },
      nodeKey: 'id',
      parentId: 'parentId',
      defaultData: [
        {
          id: '1',
          label: '一级 1',
          treeIcon: 'http://192.168.2.204:8027//file/2024-05/db71afbc31344da7a8e984274efad90e.jpg', // 图标
          iconType: 'img', // 图标类型
        },
        {
          id: '1-1',
          label: '二级 1-1',
          parentId: '1',
        },
        {
          id: '1-1-1',
          label: '三级 1-1-1',
          parentId: '1-1',
        },
        {
          id: '2',
          label: '一级 2',
        },
        {
          id: '2-1',
          label: '二级 2-1',
          parentId: '2',
        },
        {
          id: '2-1-1',
          label: '三级 2-1-1',
          parentId: '2-1',
        },
        {
          id: '2-2',
          label: '二级 2-2',
          parentId: '2',
        },
        {
          id: '2-2-1',
          label: '三级 2-2-1',
          parentId: '2-2',
        },
        {
          id: '3',
          label: '一级 3',
        },
        {
          id: '3-1',
          label: '二级 3-1',
          parentId: '3',
        },
        {
          id: '3-1-1',
          label: '三级 3-1-1',
          parentId: '3-1',
        },
        {
          id: '3-2',
          label: '二级 3-2',
          parentId: '3',
        },
        {
          id: '3-2-1',
          label: '三级 3-2-1',
          parentId: '3-2',
        },
      ],
      treeData: [],
    }
  },
  mounted() {
    this.getTreeData()
  },
  methods: {
    async getTreeData() {
      try {
        this.loading = true
        const { data } = await this.onQueryTreeDataAPI()
        this.treeData = listToTree(data || this.defaultData, {
          idkey: this.nodeKey,
          pidKey: this.parentId,
          childKey: this.defaultProps.children,
        })
      } catch (error) {
        console.error(error)
      } finally {
        this.loading = false
      }
    },
    async onQueryTreeDataAPI() {
      // return await ModelService.login(params)
      return { data: null }
    },
  },
  components: {
    BaseTree,
  },
}
</script>

<style lang="less" scoped>
@base-border-color: var(--base-border-color, #56adeb);
@font-color-light: var(--font-color-light, #fff);
@font-color-active: var(--font-color-active, #1990ff);
@linear-to-color: var(--linear-to-color, #1b6dd9);
@linear-right-color: var(--linear-to-color, #002150);
.tree-wrap {
  width: 100%;
  height: 100%;
  border: 1px solid @base-border-color;
  .head-wrap {
    padding: 0 10px;
    width: 100%;
    height: 36px;
    line-height: 36px;
    // background-image: url();
    // background-size: 100% 100%;
    background-image: linear-gradient(to right, @linear-to-color, @linear-right-color);
    .head-title {
      width: 100%;
      height: 100%;
      font-size: 18px;
      color: @font-color-light;
      font-weight: 600;
      letter-spacing: 0.1em;
    }
  }
  .tree-content {
    padding-top: 10px;
    height: calc(100% - 36px);
  }
}
</style>
