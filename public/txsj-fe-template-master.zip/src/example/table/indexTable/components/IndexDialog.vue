<template>
  <base-dailog :title="dialogTitle" :visible.sync="dialogVisible" :width="width" :before-close="hide">
    <template slot="footer">
      <el-button size="medium" @click="hide()">取 消</el-button>
      <el-button size="medium" type="primary" @click="onSubmit">确 定</el-button>
    </template>
  </base-dailog>
</template>

<script>
import { DialogWidths } from '@/common/baseConstants'
export default {
  name: 'IndexDialog',
  data() {
    return {
      dialogTitle: '新增',
      dialogVisible: false,
      width: DialogWidths.MEDIUM_FORM,
      row: null,
    }
  },
  methods: {
    show(row, title) {
      if (row) {
        this.row = row
      }
    },
    onSubmit() {},
    hide() {
      this.dialogVisible = false
    },
  },
}
</script>

<style lang="less" scoped>
</style>
