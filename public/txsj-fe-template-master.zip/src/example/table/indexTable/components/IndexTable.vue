<template>
  <div class="childTable-container" :style="{ 'margin-left': `${tabLevel * 16}px` }">
    <div class="leftLine"></div>
    <div class="index-container">
      <el-table :data="data" border stripe row-key="indexId">
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
        <el-table-column
          v-for="item in indexTableColumn"
          :key="item.prop"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :align="item.align"
        ></el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="{ row }">
            <el-button @click="onEditRow(row)" type="primary" icon="el-icon-edit" size="small">编辑</el-button>
            <el-button @click="onDeleteRow(row)" type="danger" icon="el-icon-delete" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import { indexTableColumn, indexTableData } from '../index'
export default {
  name: 'TableCom',
  props: {
    abilityId: {
      type: String,
    },
    tabLevel: {
      type: Number,
    },
    data: {
      type: Array,
      default: () => indexTableData,
    },
  },
  data() {
    return {
      indexTableColumn,
    }
  },
  created() {
    console.log(this.data)
  },
  methods: {
    onEditRow(row) {
      this.$emit('editRow', row)
    },
    onDeleteRow(row) {
      this.$emit('deleteRow', row)
    },
  },
}
</script>

<style lang="less" scoped>
@table-left-line-color: var(--table-left-line-color, #409eff);
.childTable-container {
  display: flex;
  // width: 100%;
  .leftLine {
    width: 20px;
    height: 25px;
    border-left: 1px solid @table-left-line-color;
    border-bottom: 1px solid @table-left-line-color;
  }
  .menu-container {
    margin: 10px 0;
    width: 60px;
    .menu-item {
      padding: 6px 15px;
      cursor: pointer;
    }
  }
  .index-container {
    margin: 10px 0;
    width: calc(100% - 80px);
  }
}
</style>
