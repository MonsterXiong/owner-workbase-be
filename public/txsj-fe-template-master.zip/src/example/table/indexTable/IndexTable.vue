<template>
  <div class="common-page" v-loading="loading" ref="indexTableRef">
    <div class="toolbar" ref="toolbarRef"></div>
    <div :style="{ overflowY: 'auto', height: tableHeight }">
      <MultiLevelExpandTable ref="multiLevelExpandTableRef" :data="tableData" :config="config" stripe :header-cell-style="{ 'text-align': 'center' }">
        <template #expandPanel="{ row }">
          <IndexTable :tabLevel="row.__level" :abilityId="row[config.idKey]" @editRow="onIndexEditRow" @deleteRow="onIndexDeleteRow" />
        </template>
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
        <el-table-column
          v-for="item in tableColumn"
          :key="item.prop"
          :prop="item.prop"
          :label="item.label"
          :width="item.width"
          :align="item.align"
        ></el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="{ row }">
            <el-button @click="onIndexAddRow(row)" type="success" icon="el-icon-circle-plus-outline" size="small" v-if="row.isLeaf">新增指标</el-button>
            <el-button @click="onEditRow(row)" type="primary" icon="el-icon-edit" size="small">编辑</el-button>
            <el-button @click="onDeleteRow(row)" type="danger" icon="el-icon-delete" size="small">删除</el-button>
          </template>
        </el-table-column>
      </MultiLevelExpandTable>
    </div>
    <IndexDialog ref="indexDialogRef" @update="onIndexUpdate" />
  </div>
</template>

<script>
import MultiLevelExpandTable from '@/components/multiLevelExpandTable/MultiLevelExpandTable.vue'
import IndexTable from './components/IndexTable.vue'
import IndexDialog from './components/IndexDialog.vue'
import { tableColumn, tableData } from './index'

export default {
  name: 'ProjectListManage',
  data() {
    return {
      loading: false,
      tableColumn,
      tableHeight: '300px',
      config: {
        idKey: 'abilityId',
        parentIdKey: 'parentId',
        childKey: '__list',
      },
      tableData: [],
      multiLevelExpandTableChildrenList: [],
    }
  },
  provide() {
    return {
      childrenList: this.multiLevelExpandTableChildrenList,
    }
  },
  mounted() {
    this.queryTableData()
    this.setTableHeight()
    window.addEventListener('resize', this.setTableHeight)
  },
  methods: {
    async queryTableData() {
      const { data } = await this.onQueryTableDataAPI()
      this.tableData = data || tableData
    },
    onEditRow(row) {
      console.log('onEditRow', row)
    },
    onDeleteRow(row) {
      console.log('onDeleteRow', row)
    },
    onIndexEditRow(row) {
      console.log('onIndexEditRow', row)
    },
    onIndexDeleteRow(row) {
      console.log('onIndexDeleteRow', row)
    },
    onIndexUpdate(data) {
      console.log('onIndexUpdate', data)
    },
    setTableHeight() {
      this.$nextTick(() => {
        this.tableHeight = this.$refs.indexTableRef?.offsetHeight - this.$refs.toolbarRef?.offsetHeight + 'px'
      })
    },
    async onQueryTableDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.setTableHeight)
  },
  components: { MultiLevelExpandTable, IndexTable, IndexDialog },
}
</script>

<style lang="less" scoped>
::v-deep {
  .multi-level-expand-table {
    overflow-y: auto;
  }
  .el-table__expanded-cell {
    padding: 0;
  }
}
</style>
