export const tableColumn = [
  {
    label: '能力名称',
    prop: 'abilityName',
    align: 'center',
  },
  {
    label: '能力编码',
    prop: 'abilityCode',
    align: 'center',
  },
  {
    label: '类别',
    prop: 'abilityType',
    align: 'center',
  },
  {
    label: '能力描述',
    prop: 'abilityDescribe',
    // align: 'center',
  },
]

export const tableData = [
  {
    abilityId: '1',
    abilityName: '城市清剿装备维修保障',
    abilityCode: 'A001',
    abilityType: '打击能力',
    abilityDescribe: '主要是根据城市清剿装备维修保障需求对城市清剿装备进行维修保障',
    parentId: null,
    isLeaf: true,
  },
  {
    abilityId: '2',
    abilityName: '远箱火打击弹药保障能力',
    abilityCode: 'A002',
    abilityType: '打击能力',
    abilityDescribe: '主要根据远箱火打击弹药保障需求对远箱火打击弹药进行保障',
    parentId: null,
    isLeaf: true,
  },
  {
    abilityId: '3',
    abilityName: '空中精确打击保障能力',
    abilityCode: 'A003',
    abilityType: '打击能力',
    abilityDescribe: '主要根据空中精确打击保障需求完成对空中精确打击保障',
    parentId: null,
    isLeaf: true,
  },
  {
    abilityId: '4',
    abilityName: '远箱火装填车油料保障能力',
    abilityCode: 'A004',
    abilityType: '打击能力',
    abilityDescribe: '主要是根据攻台打台装备保障任务中远箱火装填车油料保障需求信息完成对远箱火装填车油料的保障',
    parentId: null,
    isLeaf: true,
  },
  {
    abilityId: '5',
    abilityName: '侦察预警能力',
    abilityCode: 'A005',
    abilityType: '侦察能力',
    abilityDescribe: '',
    parentId: null,
  },
  {
    abilityId: '6',
    abilityName: '战略侦察能力',
    abilityCode: 'A006',
    abilityType: '侦察能力',
    abilityDescribe: '',
    parentId: '5',
  },
  {
    abilityId: '7',
    abilityName: '战略情报获取能力',
    abilityCode: 'A007',
    abilityType: '侦察能力',
    abilityDescribe: '',
    parentId: '6',
    isLeaf: true,
  }
]

export const indexTableColumn = [
  {
    prop: 'indexName',
    label: '指标名称',
  },
  {
    prop: 'indexCode',
    label: '指标标识',
  },
  {
    prop: 'indexValue',
    label: '指标值',
  },
  {
    prop: 'indexDimension',
    label: '指标单位',
  },
  {
    prop: 'indexDescription',
    label: '指标描述',
  },
]

export const indexTableData = [
  {
    indexName: '无人设备维修耗时',
    indexCode: 'wrsbwxhs',
    indexValue: '20',
    indexDimension: 'min',
    indexDescription: '',
  },
  {
    indexName: '物资运输时长',
    indexCode: 'wzyssc',
    indexValue: '10',
    indexDimension: 'min',
    indexDescription: '',
  },
  {
    indexName: '充电耗时',
    indexCode: 'cdhs',
    indexValue: '15',
    indexDimension: 'min',
    indexDescription: '',
  },
  {
    indexName: '物资载重量',
    indexCode: 'wzzzl',
    indexValue: '5',
    indexDimension: 't',
    indexDescription: '',
  },
]
