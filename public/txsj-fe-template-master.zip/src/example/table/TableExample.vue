<template>
  <!-- 树形表格 -->
  <!-- <BizTable :data="tableData" :columnList="tableColumns" row-key="id" default-expand-all :tree-props="{ children: 'children', hasChildren: 'hasChildren' }" /> -->
  <BizTable :tableInterface="tableInterface" :columnList="columnList" :tableConfig="tableConfig" />
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
import { getCurrentProjectId } from '@/utils/sysUtils'

export default {
  name: 'welcome',
  data() {
    return {
      columnList: [
        {
          type: 'selection',
        },
        {
          type: 'index',
        },
        {
          code: 'indexName',
          label: '指标名称',
          query: true,
          required: true,
          type: 'input',
          isEdit: true, // 编辑表格
        },
        {
          code: 'bindTixiAbi',
          label: '所属能力',
          query: true,
          required: true,
          type: 'select',
          dataType: 'interface',
          params: {
            service: 'XydTixiAbi',
          },
          defaultProps: {
            value: 'tixiAbiId',
            label: 'name',
          },
        },
        {
          code: 'indexValue',
          label: '指标值',
          type: 'number',
        },
        {
          code: 'select',
          label: '静态类型',
          type: 'select',
          options: [
            {
              label: '成本型',
              value: 'chengbenxing',
            },
            {
              label: '效益型',
              value: 'xiaoyixing',
            },
          ],
        },
        // 静态枚举
        // {
        //   code: 'enum',
        //   label: '枚举类型',
        //   type: 'select',
        //   dataType: 'enum',
        //   params: 'indexType',
        // },
        // 接口地址
        // {
        //   code: 'interface',
        //   label: '接口类型',
        //   type: 'select',
        //   dataType: 'interface',
        //   params: {
        //     service: 'XydTixiAbi',
        //   },
        //   defaultProps: {
        //     value: 'tixiAbiId',
        //     label: 'name',
        //   },
        // },
        // treeselect
        // {
        //   code: 'treeselect',
        //   label: 'treeselect组件',
        //   type: 'treeselect',
        //   options: [
        //     {
        //       id: 'fruits',
        //       label: 'Fruits',
        //       children: [
        //         {
        //           id: 'apple',
        //           label: 'Apple 🍎',
        //           isNew: true,
        //         },
        //         {
        //           id: 'grapes',
        //           label: 'Grapes 🍇',
        //         },
        //         {
        //           id: 'pear',
        //           label: 'Pear 🍐',
        //         },
        //         {
        //           id: 'strawberry',
        //           label: 'Strawberry 🍓',
        //         },
        //         {
        //           id: 'watermelon',
        //           label: 'Watermelon 🍉',
        //         },
        //       ],
        //     },
        //     {
        //       id: 'vegetables',
        //       label: 'Vegetables',
        //       children: [
        //         {
        //           id: 'corn',
        //           label: 'Corn 🌽',
        //         },
        //         {
        //           id: 'carrot',
        //           label: 'Carrot 🥕',
        //         },
        //         {
        //           id: 'eggplant',
        //           label: 'Eggplant 🍆',
        //         },
        //         {
        //           id: 'tomato',
        //           label: 'Tomato 🍅',
        //         },
        //       ],
        //     },
        //   ],
        //   defaultProps: {
        //     id: 'id',
        //     label: 'label',
        //     children: 'children',
        //   },
        // },
        // 图片
        // {
        //   code: 'picture',
        //   label: '图片',
        //   type: 'picture',
        // },
        {
          code: 'radio',
          label: '单选框',
          type: 'radio',
          options: [
            {
              label: '成本型',
              value: 'chengbenxing',
            },
            {
              label: '效益型',
              value: 'xiaoyixing',
            },
          ],
        },
        {
          code: 'checkbox',
          label: '复选框',
          type: 'checkbox',
          options: [
            {
              label: '成本型',
              value: 'chengbenxing',
            },
            {
              label: '效益型',
              value: 'xiaoyixing',
            },
          ],
        },
        {
          label: '操作',
          type: 'button',
          buttonList: [
            {
              emitCode: 'save',
              label: '确定',
            },
            {
              emitCode: 'delete',
              type: 'danger',
              label: '删除',
            },
          ],
        },
      ],
      tableConfig: {
        // tableType: 'readonly', // readonly只读
        dialogTitle: '体系能力',
        downloadFileName: '体系能力',
        relationParams: {
          // 关联查询参数
          // bindTixiAbi: 'tixiAbiId',
        },
        // 排序参数
        sortParams: [
          // {
          //   code: 'nodeValOhd',
          //   sortParams: 'buildDescSort',
          // },
        ],
      },
      tableInterface: {
        service: 'XydTixiAbiIndex',
        key: 'indexId',
      },
      // 合并表格列
      tableColumns: [
        {
          code: 'name',
          label: '姓名',
          type: 'input',
          query: true,
          coalitionId: 'coalitionId', // 合并条件
        },
        {
          code: 'date',
          label: '日期',
          type: 'date',
        },
        {
          code: 'address',
          label: '地址',
          type: 'textarea',
        },
      ],
      // 合并表格数据
      tableData: [
        {
          id: 1,
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄',
          coalitionId: '1',
        },
        {
          id: 2,
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄',
          coalitionId: '1',
        },
        {
          id: 3,
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄',
          coalitionId: '3',
          children: [
            {
              id: 31,
              date: '2016-05-01',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1519 弄',
              coalitionId: '31',
            },
            {
              id: 32,
              date: '2016-05-01',
              name: '王小虎',
              address: '上海市普陀区金沙江路 1519 弄',
              coalitionId: '31',
            },
          ],
        },
        {
          id: 4,
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄',
          coalitionId: '4',
        },
      ],
    }
  },
  computed: {
    currentProjectId() {
      return '4c39869803e74f70837d15d39cbac651'
    },
  },
  mounted() {
    this.setTableRelationParams()
  },
  methods: {
    setTableRelationParams() {
      this.tableConfig.relationParams = {
        // bindTixiAbi: 'tixiAbiId',
        bindProject: '4c39869803e74f70837d15d39cbac651',
      }
    },
  },
  components: { BizTable },
}
</script>
