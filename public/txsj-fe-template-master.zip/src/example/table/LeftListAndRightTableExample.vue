<template>
  <LeftListAndRightTable
    :listTitle="listTitle"
    :formItems="formItems"
    :defaultProps="defaultProps"
    :listInterface="listInterface"
    :listConfig="listConfig"
    :columnList="columnList"
    :tableInterface="tableInterface"
    :tableConfig="tableConfig"
    :btns="tableBtns"
  >
  </LeftListAndRightTable>
</template>

<script>
import LeftListAndRightTable from '@/bizComponents/LeftListAndRightTable/LeftListAndRightTable.vue'

export default {
  name: 'welcome',
  data() {
    return {
      listTitle: '体系能力列表',
      formItems: [
        {
          code: 'name',
          label: '能力名称',
          required: true,
          type: 'input',
        },
        {
          code: 'code',
          label: '能力标识',
          required: true,
          type: 'input',
        },
        {
          code: 'description',
          label: '能力描述',
          type: 'textarea',
        },
      ],
      defaultProps: {
        id: 'tixiAbiId',
        name: 'name',
      },
      listInterface: {
        service: 'XydTixiAbi',
        key: 'tixiAbiId',
      },
      listConfig: {
        dialogTitle: '作战能力',
        isEdit: true,
        allowAdd: true,
        isFilter: true,
      },

      columnList: [
        {
          type: 'selection',
        },
        {
          type: 'index',
        },
        {
          code: 'indexName',
          label: '指标名称',
          query: true,
          required: true,
          type: 'input',
        },
        {
          code: 'indexValue',
          label: '指标值',
          type: 'input',
        },
        {
          code: 'type1',
          label: '静态类型',
          type: 'select',
          options: [
            {
              label: '成本型',
              value: 'chengbenxing',
            },
            {
              label: '效益型',
              value: 'xiaoyixing',
            },
          ],
        },
        // 静态枚举
        {
          code: 'type2',
          label: '枚举类型',
          type: 'select',
          dataType: 'enum',
          params: 'indexType',
        },
        // 接口地址
        {
          code: 'type3',
          label: '接口类型',
          type: 'select',
          dataType: 'interface',
          params: {
            service: 'XydTixiAbi',
          },
          defaultProps: {
            value: 'tixiAbiId',
            label: 'name',
          },
        },
        {
          label: '操作',
          type: 'button',
          buttonList: [
            {
              emitCode: 'edit',
              label: '编辑',
            },
            {
              emitCode: 'delete',
              type: 'danger',
              label: '删除',
            },
          ],
        },
      ],
      tableInterface: {
        service: 'XydTixiAbiIndex',
        key: 'indexId',
      },
      tableConfig: {
        dialogTitle: '体系能力',
        downloadFileName: '体系能力',
        relationParams: {
          // 关联查询参数
          bindTixiAbi: 'tixiAbiId',
        },
      },
      tableBtns: [
        {
          code: 'export',
          type: 'primary',
          label: '导出',
          icon: 'el-icon-download',
          position: 'right',
        },
      ],
    }
  },
  created() {
    this.initRelationParams()
  },
  methods: {
    // 初始化关联参数 需要在created中
    initRelationParams() {
      this.setListRelationParams()
      this.setTableRelationParams()
    },
    setListRelationParams() {
      this.listConfig.relationParams = {
        bindProject: '4c39869803e74f70837d15d39cbac651',
      }
    },
    setTableRelationParams() {
      this.tableConfig.relationParams = {
        bindTixiAbi: 'tixiAbiId',
        bindProject: '4c39869803e74f70837d15d39cbac651',
      }
    },
  },
  components: { LeftListAndRightTable },
}
</script>
