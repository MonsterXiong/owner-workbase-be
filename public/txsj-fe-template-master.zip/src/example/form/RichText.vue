<template>
  <div class="common-page" ref="rtfRef" v-loading="loading">
    <RichText v-model="editorData" :isSaveBtn="isSaveBtn" @save="onSaveEditor" />
  </div>
</template>

<script>
import RichText from '@/components/richText/RichText.vue'
import tools from '@/utils/tools'

export default {
  name: 'welcome',
  data() {
    return {
      loading: false,
      isSaveBtn: true,
      defaultData:
        'MoDAF由全视图（AVs）、战略视图（StVs）、作战视图（OV）、系统视图（SV）、技术视图（TV）、采办视图（AcVs）、面向服务的视角（SOVs）7种视图组成。',
      editorData: '',
    }
  },
  mounted() {
    this.geEditorData()
  },
  methods: {
    async geEditorData() {
      const { data } = await this.onQueryEditorAPI()
      this.editorData = data?.content || this.defaultData
    },
    async onSaveEditor(data) {
      console.log(data)
      try {
        this.loading = true
        // 带标签的文本内容
        const { code } = await this.onSaveEditorAPI(data)
        if (code === 200) tools.message('保存成功')
      } catch (error) {
        console.error(error)
      } finally {
        this.loading = false
      }
    },
    async onQueryEditorAPI() {
      // return await ModelService.login()
      return { data: null }
    },
    async onSaveEditorAPI(params) {
      // return await ModelService.login(params)
      return { data: null, code: 200 }
    },
  },
  components: { RichText },
}
</script>

<style lang="less" scoped>
.common-page {
  position: relative;
  padding: 35px 20px 10px !important;
}
</style>
