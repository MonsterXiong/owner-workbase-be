<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
import * as echarts from 'echarts' // 渐变色等其它属性需要echarts
export default {
  name: 'BarEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        category: 'category', // 类别key
        label: 'label',
        value: 'value',
      },
      colors: [], // [['#83bff6', '#188df0']]
      defaultData: [
        {
          category: 'Direct', // 类别
          data: [
            { label: 'Mon', value: 302 },
            { label: 'Tue', value: 301 },
            { label: 'Wed', value: 334 },
            { label: 'Thu', value: 390 },
            { label: 'Fri', value: 330 },
            { label: 'Sat', value: 320 },
            { label: 'Sun', value: 210 },
          ],
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ legendData, axisData, seriesData }) {
      const baseConfig = {
        title: {
          text: '默认标题',
          left: 'center',
          show: false,
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
          formatter: (params) => {
            let legendStr = ''
            params.forEach((item) => {
              legendStr += `${item.marker} ${legendData.length > 1 ? item.seriesName : ''}&nbsp;&nbsp;&nbsp;<span style="font-weight: bold">${
                item.value
              }</span><br />`
            })
            return `${legendData.length > 1 ? params[0].name + '<br />' : ''}${legendStr}`
          },
        },
        legend: {
          data: legendData,
          show: legendData.length > 1 ? true : false,
        },
        series: seriesData,
      }

      const config = this.handleConfig()
      if (config.axisPlace === 'x') {
        baseConfig.xAxis = {
          type: 'category',
          data: axisData,
        }
        baseConfig.yAxis = {
          type: 'value',
        }
      } else {
        baseConfig.xAxis = {
          type: 'value',
        }
        baseConfig.yAxis = {
          type: 'category',
          data: axisData,
        }
      }
      console.log(baseConfig, 'baseConfig===========')
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let legendData = [],
        axisData = [],
        seriesData = []
      data.forEach((ele, index) => {
        if (ele[this.defaultProps.category]) legendData.push(ele[this.defaultProps.category])

        const itemData = []
        axisData = []
        ele.data.forEach((item) => {
          axisData.push(item[this.defaultProps.label])
          itemData.push({
            value: item[this.defaultProps.value],
          })
        })
        seriesData.push({
          name: ele[this.defaultProps.category] || '',
          type: 'bar',
          label: {
            show: true,
          },
          barWidth: 40,
          itemStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
              { offset: 0, color: this.colors[index] ? this.colors[index][0] : '#7ed3f4' },
              { offset: 1, color: this.colors[index] ? this.colors[index][1] : '#2347a8' },
            ]),
          },
          data: itemData,
        })
      })
      return { legendData, seriesData, axisData }
    },
    handleConfig() {
      const config = {
        axisPlace: 'x',
      }
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
