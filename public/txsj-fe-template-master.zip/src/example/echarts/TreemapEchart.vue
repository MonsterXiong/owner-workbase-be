<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
import { listToTree } from '@/utils/treeTool'
export default {
  name: 'TreeMapEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        value: 'value',
        id: 'id',
        parentId: 'parentId',
        children: 'children',
      },
      colors: ['#0accff', '#0091fe'], // 目前颜色根据第一层节点的颜色进行设置
      defaultData: [
        { id: '1', label: 'nodeA', value: 10 },
        { id: '1-1', parentId: '1', label: 'nodeAa', value: 4 },
        { id: '1-2', parentId: '1', label: 'nodeAb', value: 6 },
        { id: '2', label: 'nodeB', value: 20 },
        { id: '2-1', parentId: '2', label: 'nodeBa', value: 20 },
        { id: '2-1-1', parentId: '2-1', label: 'nodeBa1', value: 20 },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ seriesData }) {
      const baseConfig = {
        tooltip: {},
        series: [
          {
            type: 'treemap',
            data: seriesData,
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      const TreeData = listToTree(data || this.defaultData, {
        idkey: this.defaultProps.id,
        pidKey: this.defaultData.parentId,
        childKey: this.defaultData.children,
      })
      return this.handleData(TreeData)
    },
    handleData(data) {
      let seriesData = []
      const _this = this
      function mapDataItem(data, parentNode) {
        console.log()
        if (data && data.length > 0) {
          return data.map((item, index) => {
            const itemData = {
              name: item[_this.defaultProps.label],
              value: item[_this.defaultProps.value],
              itemStyle: {
                color: parentNode ? parentNode.itemStyle.color : _this.colors[index],
              },
            }
            itemData.children = mapDataItem(item[_this.defaultProps.children], { ...itemData })
            return itemData
          })
        }
        return []
      }
      seriesData = mapDataItem(data)

      return { seriesData }
    },
    handleConfig() {
      const config = {
        visualMap: {
          show: false,
          inRange: {
            color: ['red', 'green'],
          },
        },
      }
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
