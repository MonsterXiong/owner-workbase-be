<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import * as echarts from 'echarts' // 渐变色等其它属性需要echarts
import { mergeObj } from '@/utils/commonUtil'

export default {
  name: 'RadarEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        category: 'category',
        categoryData: 'data',
        label: 'label',
        value: 'value',
      },
      // 颜色配置使用rgb 不使用透明度可不使用rgb
      colors: ['84, 112, 198', '145, 204, 117'],
      defaultData: [
        {
          category: '预算分配',
          data: [
            { label: '销售', value: 8500 },
            { label: '管理', value: 4000 },
            { label: '信息技术', value: 4000 },
            { label: '客服', value: 5000 },
            { label: '研发', value: 4000 },
            { label: '市场', value: 9000 },
          ],
        },
        {
          category: '实际开销',
          data: [
            { label: '销售', value: 6500 },
            { label: '管理', value: 2000 },
            { label: '信息技术', value: 2000 },
            { label: '客服', value: 2000 },
            { label: '研发', value: 2000 },
            { label: '市场', value: 2000 },
          ],
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ legendData, seriesData, indicatorData }) {
      const baseConfig = {
        legend: {
          data: legendData,
          show: legendData.length > 1,
        },
        tooltip: {
          trigger: 'item',
        },
        radar: {
          indicator: indicatorData,
        },
        series: [
          {
            type: 'radar',
            label: {
              show: true,
            },
            data: seriesData,
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let legendData = [],
        seriesData = [],
        indicatorData = []

      const maxNum = _.max(data.map((item) => _.max(item[this.defaultProps.categoryData].map((ele) => ele[this.defaultProps.value]))))
      data.forEach((item, index) => {
        const itemData = {
          name: item[this.defaultProps.category],
          itemStyle: {
            color: `rgba(${this.colors[index] || '255, 145, 124'})`,
          },
        }
        legendData.push({ ...itemData })
        seriesData.push({
          ...itemData,
          value: item[this.defaultProps.categoryData].map((dataItem) => dataItem[this.defaultProps.value]),
          areaStyle: {
            color: new echarts.graphic.RadialGradient(0.1, 0.6, 1, [
              {
                color: `rgba(${this.colors[index] || '255, 145, 124'}, 0.1)`,
                offset: 0,
              },
              {
                color: `rgba(${this.colors[index] || '255, 145, 124'}, 0.9)`,
                offset: 1,
              },
            ]),
          },
        })
        if (index === 0) {
          item[this.defaultProps.categoryData].forEach((dataItem) => {
            indicatorData.push({
              name: dataItem[this.defaultProps.label],
              max: maxNum,
            })
          })
        }
      })

      return { legendData, seriesData, indicatorData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
