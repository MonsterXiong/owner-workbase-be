<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import 'echarts-gl'
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'

export default {
  name: 'Bar3DEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        yName: 'time',
        x: 'x',
        y: 'y',
        z: 'z',
      },
      colors: ['#313695', '#4575b4', '#74add1', '#abd9e9', '#e0f3f8', '#ffffbf', '#fee090', '#fdae61', '#f46d43', '#d73027', '#a50026'],
      defaultData: [
        {
          x: 0,
          y: 0,
          z: 5,
          time: 'Saturday',
          label: '12a',
        },

        {
          x: 1,
          y: 1,
          z: 6,
          time: 'Friday',
          label: '1a',
        },
        {
          x: 2,
          y: 2,
          z: 7,
          time: 'Thursday',
          label: '2a',
        },
        {
          x: 3,
          y: 3,
          z: 8,
          time: 'Wednesday',
          label: '3a',
        },
        {
          x: 4,
          y: 2,
          z: 5,
          time: 'Tuesday',
          label: '4a',
        },
        {
          x: 5,
          y: 3,
          z: 5,
          time: 'Monday',
          label: '5a',
        },
        {
          x: 6,
          y: 4,
          z: 5,
          time: 'Sunday',
          label: '6a',
        },
        {
          x: 7,
          y: 5,
          z: 5,
          time: 'Saturday',
          label: '7a',
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ seriesData, xData, yData }) {
      const baseConfig = {
        tooltip: {},
        visualMap: {
          max: 20,
          inRange: {
            color: this.colors,
          },
        },
        xAxis3D: {
          type: 'category',
          data: xData,
        },
        yAxis3D: {
          type: 'category',
          data: yData,
        },
        zAxis3D: {
          type: 'value',
        },
        grid3D: {
          boxWidth: 200,
          boxDepth: 80,
          light: {
            main: {
              intensity: 1.2,
              shadow: true,
            },
            ambient: {
              intensity: 0.3,
            },
          },
        },
        series: [
          {
            type: 'bar3D',
            data: seriesData.map(function (item) {
              return {
                value: [item[1], item[0], item[2]],
              }
            }),
            shading: 'lambert',
            label: {
              fontSize: 16,
              borderWidth: 1,
            },
            emphasis: {
              label: {
                fontSize: 20,
                color: '#900',
              },
              itemStyle: {
                color: '#900',
              },
            },
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let seriesData = []
      let xData = new Set()
      let yData = new Set()
      seriesData = data.map((item) => {
        xData.add(item[this.defaultProps.label])
        yData.add(item[this.defaultProps.yName])
        return [item[this.defaultProps.x], item[this.defaultProps.y], item[this.defaultProps.z]]
      })

      return { seriesData, xData: [...xData], yData: [...yData] }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
