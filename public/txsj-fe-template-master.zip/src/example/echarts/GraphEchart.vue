<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'

const nodeColors = [
  '#3a68cb',
  '#d2732e',
  '#c93749',
  '#2f9059',
  '#2497a8',
  '#817fdf',
  '#1c769f',
  '#209ad9',
  '#dca623',
  '#ca3c7b',
  '#7ea71d',
  '#dc4b4b',
  '#715bb3',
]

export default {
  name: 'GraphEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        id: 'id',
        label: 'label',
        value: 'value',
        categoryId: 'category',
        categoryName: 'categoryName',
        source: 'source',
        target: 'target',
      },
      colors: ['#5470c6', '#91cc75'],
      defaultData: {
        nodes: [
          {
            id: '1',
            label: 'Myriel',
            value: 28.685715,
            category: 0,
            categoryName: '类目1',
          },
          {
            id: '2',
            label: 'Myriel-2',
            value: 21.685715,
            category: 0,
            categoryName: '类目1',
          },
          {
            id: '3',
            label: 'Myriel-3',
            value: 22.685715,
            categoryName: '类目1',
            category: 0,
          },
          {
            id: '4',
            label: 'Myriel-4',
            value: 24.685715,
            categoryName: '类目1',
            category: 0,
          },
          {
            id: '5',
            label: 'Myriel-5',
            value: 58.685715,
            categoryName: '类目1',
            category: 0,
          },
          {
            id: '6',
            label: 'tow',
            value: 68.685715,
            categoryName: '类目2',
            category: 1,
          },
          {
            id: '7',
            label: 'tow-1',
            value: 48.685715,
            categoryName: '类目2',
            category: 1,
          },
          {
            id: '8',
            label: 'tow-2',
            value: 98.685715,
            categoryName: '类目2',
            category: 1,
          },
          {
            id: '9',
            label: 'tow-3',
            value: 58.685715,
            categoryName: '类目2',
            category: 1,
          },
          {
            id: '10',
            label: 'tow-4',
            value: 52.685715,
            categoryName: '类目2',
            category: 1,
          },
        ],
        links: [
          {
            source: '1',
            target: '2',
          },
          {
            source: '1',
            target: '3',
          },
          {
            source: '1',
            target: '4',
          },
          {
            source: '1',
            target: '5',
          },
          {
            source: '6',
            target: '7',
          },
          {
            source: '6',
            target: '8',
          },

          {
            source: '6',
            target: '9',
          },
          {
            source: '6',
            target: '10',
          },
        ],
      },
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ links, nodes, categories, legendData }) {
      const baseConfig = {
        tooltip: {},
        legend: [
          {
            data: legendData,
            show: legendData.length > 1 ? true : false,
          },
        ],
        series: [
          {
            type: 'graph',
            layout: 'force',
            data: nodes,
            links: links,
            categories: categories,
            symbolSize: 30,
            draggable: true,
            roam: true,
            label: {
              position: 'right',
              show: true,
            },
            force: {
              repulsion: 200,
            },
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let colors = {}
      const categoryMap = new Map()
      data.nodes.map((item) => {
        categoryMap.set(item[this.defaultProps.categoryId], item[this.defaultProps.categoryId])
      })
      for (const key of categoryMap) {
        colors[key[0]] = this.colors[key[0]]
      }
      let nodes = [],
        links = [],
        categories = [],
        legendData = []
      nodes = data.nodes.map((item, index) => {
        const itemData = {
          name: item[this.defaultProps.label],
          itemStyle: {
            color: colors[item[this.defaultProps.categoryId]],
          },
        }
        return {
          ...itemData,
          value: item[this.defaultProps.value],
          id: item[this.defaultProps.id],
          category: item[this.defaultProps.categoryId],
        }
      })
      links = data.links.map((item) => {
        return {
          source: item[this.defaultProps.source],
          target: item[this.defaultProps.target],
        }
      })
      data.nodes.forEach((item) => {
        let index = categories.findIndex((cat) => cat.name === item[this.defaultProps.categoryName])
        if (index === -1) {
          categories.push({
            name: item[this.defaultProps.categoryName],
            id: item[this.defaultProps.categoryId],
            itemStyle: {
              color: colors[item[this.defaultProps.categoryId]],
            },
          })
        }
      })
      legendData = categories.map((item) => item.name)

      return { links, nodes, categories, legendData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
