<template>
  <div class="common-page">
    <EchartContainer autoHighlight :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
export default {
  name: 'PieEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        value: 'value',
      },
      colors: [],
      defaultData: [
        { value: 1048, label: '搜索引擎' },
        { value: 735, label: '直接访问' },
        { value: 580, label: '邮件营销' },
        { value: 484, label: '联盟广告' },
        { value: 300, label: '视频广告' },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ legendData, seriesData }) {
      const baseConfig = {
        title: {
          text: '默认标题',
          left: 'center',
          show: false,
        },
        tooltip: {
          trigger: 'item',
        },
        legend: {
          data: legendData,
        },
        series: [
          {
            type: 'pie',
            radius: '50%',
            data: seriesData,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let legendData = [],
        seriesData = []
      data.forEach((item, index) => {
        const itemData = {
          name: item[this.defaultProps.label],
          itemStyle: {
            color: this.colors[index],
          },
        }
        legendData.push({ ...itemData })
        seriesData.push({
          ...itemData,
          value: item[this.defaultProps.value],
        })
      })
      return { legendData, seriesData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
