<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
export default {
  name: 'ScatterEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        x: 'xValue',
        y: 'yValue',
      },
      color: '',
      defaultData: [
        {
          label: 'a1',
          xValue: 10,
          yValue: 8,
        },
        {
          label: 'a2',
          xValue: 3,
          yValue: 2,
        },
        {
          label: 'a3',
          xValue: 5,
          yValue: 5,
        },
        {
          label: 'a4',
          xValue: 2,
          yValue: 8,
        },
        {
          label: 'a5',
          xValue: 4,
          yValue: 1,
        },
        {
          label: 'a6',
          xValue: 8,
          yValue: 2,
        },
        {
          label: 'a7',
          xValue: 8,
          yValue: 5,
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ seriesData }) {
      const baseConfig = {
        tooltip: {
          position: 'top',
          formatter: (params) => {
            console.log(params)
            return `${params.name}：(${params.value[0]}，${params.value[1]})`
          },
        },
        xAxis: {},
        yAxis: {},
        series: [
          {
            symbolSize: 20,
            data: seriesData,
            type: 'scatter',
            itemStyle: {
              color: this.color,
            },
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let seriesData = []
      seriesData = data.map((item) => {
        return {
          name: item[this.defaultProps.label],
          value: [item[this.defaultProps.x], item[this.defaultProps.y]],
        }
      })

      return { seriesData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
