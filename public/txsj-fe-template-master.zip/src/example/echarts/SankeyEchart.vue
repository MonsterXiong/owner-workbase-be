<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
export default {
  name: 'SankeyEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        source: 'source',
        target: 'target',
        value: 'value',
      },
      lineColors: ['#ffc3ef', '#adbdec', '#adbdec', '#adbdec'],
      defaultData: {
        data: [
          {
            label: 'a',
          },
          {
            label: 'b',
          },
          {
            label: 'a1',
          },
          {
            label: 'a2',
          },
          {
            label: 'b1',
          },
          {
            label: 'c',
          },
        ],
        links: [
          {
            source: 'a',
            target: 'a1',
            value: 5,
          },
          {
            source: 'a',
            target: 'a2',
            value: 3,
          },
          {
            source: 'b',
            target: 'b1',
            value: 8,
          },
          {
            source: 'a',
            target: 'b1',
            value: 3,
          },
          {
            source: 'b1',
            target: 'a1',
            value: 1,
          },
          {
            source: 'b1',
            target: 'c',
            value: 2,
          },
        ],
      },
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ seriesData, links }) {
      const baseConfig = {
        tooltip: {},

        series: {
          type: 'sankey',
          layout: 'none',
          emphasis: {
            focus: 'adjacency',
          },
          data: seriesData,
          links: links,
        },
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData({ data, links }) {
      let seriesData = []
      seriesData = data.map((item) => {
        return {
          name: item[this.defaultProps.label],
          itemStyle: {},
        }
      })
      links = links.map((link, index) => {
        return {
          value: link[this.defaultProps.value],
          target: link[this.defaultProps.target],
          source: link[this.defaultProps.source],
          lineStyle: {
            color: this.lineColors[index],
          },
        }
      })
      return { seriesData, links }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
