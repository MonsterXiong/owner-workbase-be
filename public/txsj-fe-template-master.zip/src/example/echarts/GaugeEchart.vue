<template>
  <div class="common-page">
    <EchartContainer :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'

export default {
  name: 'GaugeEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        label: 'label',
        value: 'value',
      },
      defaultData: [
        {
          value: 50,
          label: 'SCORE',
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ seriesData }) {
      const baseConfig = {
        tooltip: {
          formatter: '{a} <br/>{b} : {c}%',
        },
        series: [
          {
            name: 'Pressure',
            type: 'gauge',
            progress: {
              show: true,
            },
            detail: {
              formatter: '{value}',
            },
            data: seriesData,
          },
        ],
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let seriesData = []
      seriesData = data.map((item) => {
        return {
          name: item[this.defaultProps.label],
          value: item[this.defaultProps.value],
        }
      })

      return { seriesData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
