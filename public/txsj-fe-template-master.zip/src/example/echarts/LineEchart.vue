<template>
  <div class="common-page">
    <EchartContainer autoAloneHighlight :option="option" />
  </div>
</template>

<script>
import EchartContainer from '@/components/echartContainer/EchartContainer.vue'
import { mergeObj } from '@/utils/commonUtil'
export default {
  name: 'LineEchart',
  data() {
    return {
      option: {},
      defaultProps: {
        category: 'category',
        categoryData: 'data',
        label: 'label',
        value: 'value',
      },
      colors: [],
      defaultData: [
        {
          category: '邮件营销',
          data: [
            {
              label: '周一',
              value: 120,
            },
            {
              label: '周二',
              value: 132,
            },
            {
              label: '周三',
              value: 101,
            },
            {
              label: '周四',
              value: 134,
            },
            {
              label: '周五',
              value: 90,
            },
            {
              label: '周六',
              value: 230,
            },
            {
              label: '周日',
              value: 210,
            },
          ],
        },
        {
          category: '联盟广告',
          data: [
            {
              label: '周一',
              value: 140,
            },
            {
              label: '周二',
              value: 152,
            },
            {
              label: '周三',
              value: 41,
            },
            {
              label: '周四',
              value: 133,
            },
            {
              label: '周五',
              value: 45,
            },
            {
              label: '周六',
              value: 400,
            },
            {
              label: '周日',
              value: 200,
            },
          ],
        },
        {
          category: '视频广告',
          data: [
            {
              label: '周一',
              value: 180,
            },
            {
              label: '周二',
              value: 12,
            },
            {
              label: '周三',
              value: 151,
            },
            {
              label: '周四',
              value: 124,
            },
            {
              label: '周五',
              value: 190,
            },
            {
              label: '周六',
              value: 130,
            },
            {
              label: '周日',
              value: 110,
            },
          ],
        },
      ],
    }
  },
  mounted() {
    let time = setTimeout(async () => {
      const echartData = await this.getEchartData()
      this.option = this.geOption(echartData)
      clearTimeout(time)
    }, 200)
  },
  methods: {
    geOption({ legendData, seriesData, xAxisData }) {
      const baseConfig = {
        tooltip: {
          trigger: 'axis',
          formatter: (params) => {
            let legendStr = ''
            params.forEach((item) => {
              legendStr += `${item.marker} ${legendData.length > 1 ? item.seriesName : ''}&nbsp;&nbsp;&nbsp;<span style="font-weight: bold">${
                item.value
              }</span><br />`
            })
            return `${legendData.length > 1 ? params[0].name + '<br />' : ''}${legendStr}`
          },
        },
        legend: {
          data: legendData,
          show: legendData.length > 1 ? true : false,
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: xAxisData,
          },
        ],
        yAxis: [
          {
            type: 'value',
          },
        ],
        series: seriesData,
      }
      const config = this.handleConfig()
      const option = mergeObj(baseConfig, config)
      return option
    },
    async getEchartData() {
      const { data } = await this.onQueryEchartDataAPI()
      return this.handleData(data || this.defaultData)
    },
    handleData(data) {
      let legendData = [],
        seriesData = [],
        xAxisData = []
      data.forEach((item, index) => {
        const itemData = {
          name: item[this.defaultProps.category],
          type: 'line',
        }
        legendData.push({ ...itemData })
        function getSeriesDataValues(data = [], { label, value }) {
          // 将数据根据名称排列
          data.sort((a, b) => {
            return a[label] - b[label] > 0 ? -1 : 1
          })
          return data.map((dataItem) => {
            if (index === 0) {
              xAxisData.push(dataItem[label])
            }
            return dataItem[value]
          })
        }
        seriesData.push({
          ...itemData,
          data: getSeriesDataValues(item[this.defaultProps.categoryData], this.defaultProps),
          itemStyle: {
            normal: {
              color: this.colors[index],
              lineStyle: {
                color: this.colors[index],
              },
            },
          },
        })
      })

      return { legendData, seriesData, xAxisData }
    },
    handleConfig() {
      const config = {}
      return config
    },
    async onQueryEchartDataAPI() {
      // return await UserService.login()
      return { data: null }
    },
  },
  components: { EchartContainer },
}
</script>
