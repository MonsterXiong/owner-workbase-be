<template>
  <base-dialog title="系统选择" :visible.sync="dialogVisible" :before-close="onClose" :width="width">
    <el-form :model="formData">
      <el-form-item label="节点名称">
        <el-input v-model="formData.name"></el-input>
      </el-form-item>
    </el-form>
    <template slot="footer">
      <el-button size="small" @click="onClose">取 消</el-button>
      <el-button size="small" type="primary" @click="onSubmit">确 定</el-button>
    </template>
  </base-dialog>
</template>

<script>
import { DialogWidths } from '@/common/baseConstants'
export default {
  name: 'QuoteDialog',
  data() {
    return {
      dialogVisible: false,
      width: DialogWidths.FORM,
      formData: {
        name: '',
      },
    }
  },
  methods: {
    show() {
      this.dialogVisible = true
    },
    onSubmit() {
      this.$emit('submit', this.formData)
    },
    onClose() {
      this.dialogVisible = false
    },
  },
}
</script>

<style lang="less" scoped>
</style>
