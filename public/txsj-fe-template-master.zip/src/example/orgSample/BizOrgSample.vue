<template>
  <div class="common-page" ref="OrgDiagramIndexRef">
    <PanelLayout ref="panelLayoutRef" :showLeftPanel="true" :defaultRightWidth="22">
      <template v-slot:left>
        <span style="color: gray">这是左边</span>
      </template>
      <BizOrg :nodeConfig="nodeConfig" :mode="'save'" @setCurrentNodeData="setCurrentNodeData" @export="onExport" />
      <!--  @update="onUpdate"
        @updateBatch="onUpdateBatch"
        @insert="onInsert"
        @delete="onDelete" -->
    </PanelLayout>
  </div>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BizOrg from '@/bizComponents/bizOrg/BizOrg.vue'
export default {
  name: 'OrgSample', //数据链系统功能性能指标组成模型
  data() {
    return {
      nodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          allowType: ['task'],
          // tag: '平台',
          // _type: 'green',
          // category: 'node1',
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '装备名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          allowType: ['func'],
          // tag: '平台',
          _type: 'green',
          // category: 'node1',
        },
      ],
    }
  },
  mounted() {
    // this.$nextTick(() => {
    //   this.init()
    // })
  },
  methods: {
    onUpdate(data) {
      console.log(data, 'onUpdate')
    },
    onUpdateBatch(data) {
      console.log(data, 'onUpdateBatch')
    },
    onInsert(data) {
      console.log(data, 'onInsert')
    },
    onDelete(data) {
      console.log(data, 'onDelete')
    },
    setCurrentNodeData(data) {
      console.log(data, 'setCurrentNodeData')
    },
    onExport(diagram) {
      console.log(diagram, 'onExport')
    },
  },
  components: {
    PanelLayout,
    BizOrg,
  },
}
</script>

<style lang="less" scoped></style>
