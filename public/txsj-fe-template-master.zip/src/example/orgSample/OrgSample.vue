<template>
  <div class="common-page index-compose-model" ref="OrgDiagramIndexRef">
    <PanelLayout ref="panelLayoutRef" :showRightPanel="showRightPanel" :showLeftPanel="true" :defaultRightWidth="22">
      <template v-slot:left>
        <span style="color: gray">这是左边</span>
      </template>
      <OrgDiagram
        :defaultAngle="defaultAngle"
        :defaultTemplate="defaultTemplate"
        :saveMode="saveMode"
        :addToolList="addToolList"
        :addNodeConfig="addNodeConfig"
        :nodeList="nodeList"
        :textList="textList"
        @addNode="addNode"
        @deleteNode="deleteNode"
        @updateNode="updateNode"
        @saveDiagram="saveDiagramData"
        @setCurrentNodeData="setCurrentNodeData"
        ref="orgGraphRef"
      ></OrgDiagram>
      <template v-slot:right>
        <span style="color: gray">haha</span>
      </template>
    </PanelLayout>
  </div>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import OrgDiagram from '@/components/orgDiagram/OrgDiagram.vue'
import { AddNodeConfigCode, AddNodeConfig } from './index'
export default {
  name: 'IndexComposeModel', //数据链系统功能性能指标组成模型
  data() {
    return {
      platId: '',
      currentSystem: null,
      // id、name、parentId必传值，其余可不传
      nodeList: [],
      saveMode: 'monitor', //save【批量保存】 、 monitor【实时监听】 两种模式
      defaultTemplate: 'default', //horizontal,vertical,default
      defaultAngle: 0, //0 水平，90 垂直显示
      // 添加按钮替换  为空数组是toolbar显示默认添加，有数据的情况替换toolbar的默认添加展示 staticParams为添加节点的默认properties
      addToolList: [
        {
          name: '添加平台',
          code: 'add',
          icon: 'el-icon-circle-plus-outline',
          addTemplateCode: AddNodeConfigCode.PLAT,
        },
        {
          name: '添加功能',
          code: 'add',
          icon: 'el-icon-circle-plus-outline',
          addTemplateCode: AddNodeConfigCode.FUNC,
        },
      ],
      addNodeConfig: AddNodeConfig,
      currentNodeData: null,
      showRightPanel: false,
      textList: [
        { code: 'name', title: '名字' },
        { code: 'sysSort', title: '排序' },
      ],
    }
  },
  watch: {
    platId: {
      handler() {
        // this.getNodeData()
      },
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.init()
    })
  },
  methods: {
    init() {
      this.getNodeData()
    },
    async getNodeData() {
      let data = [
        {
          nodeType: 'plat',
          bindProject: '',
          bindTask: '',
          bindUnit: '',
          description: '',
          displayFlag: 1,
          platformCode: '',
          platformId: '101',
          name: '平台',
          sysSort: 1,
        },
        {
          nodeType: 'function',
          attr: '',
          bindEquip: '',
          bindPlat: '101',
          bindProject: '',
          description: '',
          functionId: '102',
          name: '功能',
          type: '',
          sysSort: 1,
        },
      ]
      this.nodeList = this.setNodeList(data)
      console.log(this.nodeList, 111)
    },
    setNodeList(list) {
      let arr = []
      if (list.length > 0) {
        arr = list.map((ele, index) => {
          let code = ele.nodeType
          let obj = {}
          if (code) {
            obj = {
              properties: { ...ele },
              nodeType: code,
            }
            for (const key in AddNodeConfig[code].matchCode) {
              const match = AddNodeConfig[code].matchCode[key]
              obj[key] = ele[match] || ''
            }
            obj._type = AddNodeConfig[code]._type
            obj.category = AddNodeConfig[code].category
            arr.push(obj)
          }
          return obj
        })
      }
      return arr
    },
    async onNodeClick(node) {},
    async saveDiagramData(nodeDataArray) {
      console.log('saveDiagramData', nodeDataArray)
    },
    async addNode(params) {
      console.log('新增节点数据', params)
    },
    deleteNode(delIdList) {
      // 删除节点 删除节点id数组
      console.log('删除节点', delIdList)
    },
    updateNode(updateNodes) {
      // 更新节点 节点数据
    },
    setCurrentNodeData(nodeData) {
      this.currentNodeData = nodeData ? { ...nodeData } : null
      console.log('nodeData', nodeData)
      this.showRightPanel = this.currentNodeData ? true : false
    },
    async submitFormData(formData) {
      this.$refs.orgGraphRef.updateActiveNodeData({ ...formData, name: formData[AddNodeConfig[this.currentNodeData.nodeType].matchCode.name] })
    },
  },
  components: {
    PanelLayout,
    OrgDiagram,
  },
}
</script>

<style lang="less" scoped></style>
