<template>
  <div class="common-page" ref="OrgDiagramIndexRef">
    <LeftTreeAndRightOrg
      :listTitle="listTitle"
      :treeListNodeConfig="treeListNodeConfig"
      :treeListConfig="treeListConfig"
      :defaultSelId="defaultSelId"
      :nodeConfig="nodeConfig"
    ></LeftTreeAndRightOrg>
  </div>
</template>

<script>
import LeftTreeAndRightOrg from '@/bizComponents/leftTreeAndRightOrg/LeftTreeAndRightOrg.vue'
export default {
  name: 'OrgSample', //数据链系统功能性能指标组成模型
  data() {
    return {
      listTitle: '体系能力列表',
      treeListConfig: {
        isFilter: true,
        allowAdd: true,
        readOnly: false,
        isSelectOneNode: true,
        type: '',
      },
      defaultSelId: '',
      treeListNodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'icon-order-fill-copy',
          icons: [{ icon: 'el-icon-circle-plus-outline', name: '添加任务', code: 'add', addType: 'task' }],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
          },
          defaultAdd: true,
          queryRelateCondition: {
            bindProject: 'id',
          },
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '任务名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          icon: 'el-icon-s-management',
          icons: [
            // { icon: 'el-icon-edit', name: '编辑', code: 'edit' },
            // { icon: 'el-icon-delete', name: '删除', code: 'delete' },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          queryRelateCondition: {
            taskId: 'id',
          },
        },
      ],
      nodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
            tixiAbiId: '',
          },
          allowType: ['task'],
          // tag: '平台',
          // _type: 'green',
          // category: 'node1',
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '装备名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '',
            taskId: '',
          },
          allowType: ['func'],
          // tag: '平台',
          _type: 'green',
          // category: 'node1',
        },
      ],
    }
  },
  mounted() {},
  methods: {},
  components: {
    LeftTreeAndRightOrg,
  },
}
</script>

<style lang="less" scoped></style>
