<template>
  <div class="common-page" ref="OrgDiagramIndexRef">
    <LeftListAndRightOrg
      :listTitle="listTitle"
      :formItems="formItems"
      :defaultProps="defaultProps"
      :listInterface="listInterface"
      :listConfig="listConfig"
      :nodeConfig="nodeConfig"
    ></LeftListAndRightOrg>
  </div>
</template>

<script>
import LeftListAndRightOrg from '@/bizComponents/leftListAndRightOrg/LeftListAndRightOrg.vue'
export default {
  name: 'OrgSample', //数据链系统功能性能指标组成模型
  data() {
    return {
      listTitle: '体系能力列表',
      formItems: [
        {
          code: 'name',
          label: '能力名称',
          required: true,
          type: 'input',
        },
        {
          code: 'code',
          label: '能力标识',
          required: true,
          type: 'input',
        },
        {
          code: 'description',
          label: '能力描述',
          type: 'textarea',
        },
      ],
      defaultProps: {
        id: 'tixiAbiId',
        name: 'name',
      },
      listInterface: {
        service: 'XydTixiAbi',
        key: 'tixiAbiId',
      },
      listConfig: {
        dialogTitle: '作战能力',
        isEdit: true,
        allowAdd: true,
        isFilter: true,
      },
      nodeConfig: [
        {
          defaultProps: {
            id: 'projectId',
            name: 'projectName',
            parentId: '',
          },
          nodeList: [],
          columnList: [
            {
              code: 'projectName',
              label: '项目名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '项目',
          code: 'project',
          interface: {
            service: 'XydProject',
            key: 'projectId',
          },
          relationParams: {
            projectId: '3587f47eae444cd08154741eeed70275',
            tixiAbiId: '',
          },
          allowType: ['task'],
          // tag: '平台',
          // _type: 'green',
          // category: 'node1',
        },
        {
          defaultProps: {
            id: 'taskId',
            name: 'taskName',
            parentId: 'bindProject',
          },
          nodeList: [],
          columnList: [
            {
              code: 'taskName',
              label: '装备名称',
              query: true,
              required: true,
              type: 'input',
            },
          ],
          name: '任务',
          code: 'task',
          interface: {
            service: 'XydTask',
            key: 'taskId',
          },
          relationParams: {
            bindProject: '3587f47eae444cd08154741eeed70275',
          },
          allowType: ['func'],
          // tag: '平台',
          _type: 'green',
          // category: 'node1',
        },
      ],
    }
  },
  mounted() {},
  methods: {},
  components: {
    LeftListAndRightOrg,
  },
}
</script>

<style lang="less" scoped></style>
