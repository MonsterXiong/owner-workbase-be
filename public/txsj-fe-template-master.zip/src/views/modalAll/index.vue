<template>
  <div>
    <IconPicker />
  </div>
</template>

<script>
import IconPicker from './iconPicker/index.vue'

export default {
  name: 'modalAll',
  components: {
    IconPicker,
  },
}
</script>
