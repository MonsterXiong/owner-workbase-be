<template>
  <div class="nb-login">
    <img style="position: absolute; width: 100%; height: 100%; z-index: 1" src="static/image/base/login9/bg.png" alt="" />
    <main>
      <header>
        <img style="position: absolute; width: 100%; height: 100%; z-index: 1" src="static/image/base/login9/head.png" alt="" />
        <img src="static/image/base/login9/logo.svg" alt="" />
        <div class="title">{{ systemName }}</div>
      </header>
      <div class="login-wrapper">
        <img src="static/image/base/login9/mainCircle.png" alt="" style="height: 740px; right: calc(50% - 370px); position: absolute; top: 0px" />
        <div class="login-form">
          <div class="login-title">账号登录</div>
          <span class="login-title-span"></span>
          <el-form ref="formAccount" :model="formAccount" status-icon :rules="formAccountRules" style="padding-top: 50px">
            <el-form-item prop="account">
              <!-- <el-input v-model="formAccount.account" placeholder="请输入登录账号">
                <i slot="prefix" class="el-input__icon el-icon-user login-icon"></i>
              </el-input> -->
              <div class="input-wrapper">
                <div class="input-title">
                  <i class="el-input__icon el-icon-user login-icon"></i>
                  <span>用户名:</span>
                </div>
                <el-input v-model="formAccount.account" placeholder="请输入登录账号"> </el-input>
              </div>
            </el-form-item>
            <el-form-item prop="pass">
              <!-- <el-input v-model="formAccount.pass" type="password" @keyup.enter.native="submitForm" placeholder="请输入密码">
                <i slot="prefix" class="el-input__icon el-icon-lock login-icon"></i>
              </el-input> -->
              <div class="input-wrapper">
                <div class="input-title">
                  <i class="el-input__icon el-icon-lock login-icon"></i>
                  <span>密&nbsp;&nbsp;&nbsp;码:</span>
                </div>
                <el-input v-model="formAccount.pass" type="password" @keyup.enter.native="submitForm" placeholder="请输入密码"> </el-input>
              </div>
            </el-form-item>
            <el-form-item class="login-buttons">
              <!-- <div style="margin-bottom: 4px; font-size: 14px">
                <el-checkbox v-model="isRemember">记住用户名及密码</el-checkbox>
              </div> -->
              <el-button type="primary" @click="submitForm()" style="margin-left: calc(50% - 150px)"> 登 录 </el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import loginMixin from './loginMixin'
export default {
  name: 'Login9',
  mixins: [loginMixin],
}
</script>

<style lang="less" scoped>
.text-title() {
  background: linear-gradient(to bottom, #d3f1ff, #1592ff);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.nb-login {
  height: 100%;
  overflow: auto;
  min-height: 850px;
  // background-image: url(../../../../public/static/image/base/login9/bg.png);
  main {
    header {
      margin: 0 auto;
      width: 780px;
      height: 80px;
      padding-bottom: 5px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      > img {
        height: 60px;
      }
      .title {
        margin-left: 5px;
        font-size: 36px;
        line-height: 36px;
        font-family: 'ALIMAMASHUHEITI-BOLD';
        text-shadow: 2px 3px 1px rgba(0, 0, 0, 0.25);
        .text-title();
      }
    }
    // height: 554px;
    width: 100%;
    position: absolute;
    top: 0;
    z-index: 3;
    .login-wrapper {
      height: 710px;
      padding-top: 45px;
      position: relative;
      .login-form {
        height: 710px;
        width: 710px;
        position: absolute;
        right: calc(50% - 360px);
        // background: red;
        padding: 160px;
        .login-title {
          text-align: center;
          font-size: 30px;
          line-height: 30px;
          font-family: 'ALIMAMASHUHEITI-BOLD';
          color: #fff;
          margin-bottom: 15px;
        }
        .login-title-span {
          width: 30px;
          height: 4px;
          display: inline-block;
          background: #02d7fc;
          margin: 0 auto;
          position: absolute;
          right: calc(50% - 15px);
        }
      }
      .input-wrapper {
        width: 390px;
        height: 45px;
        border: 1px solid #00c8fc;
        border-radius: 5px;
        background-color: #02d6fc23;
        color: #02cdf4;
        font-size: 16px;
        line-height: 45px;
        padding: 0 10px;
        display: flex;
        .input-title {
          width: 99px;
        }
      }
    }
  }
}
::v-deep {
  .el-input__inner {
    height: 40px;
    line-height: 40px;
    font-size: 16px;
  }
  .el-input__inner {
    background: transparent;
    border: none;
    color: #02cdf4;
  }
  .el-checkbox__inner {
    background-color: #02d6fc23;
    border-color: #0680ba;
    color: #02cdf4;
  }
  .el-input__prefix,
  .el-input__suffix,
  .el-checkbox__input.is-checked + .el-checkbox__label {
    color: #02cdf4;
  }

  .el-checkbox__input.is-checked .el-checkbox__inner,
  .el-checkbox__input.is-indeterminate .el-checkbox__inner {
    background-color: #02cdf4;
    border-color: #02cdf4;
  }

  .el-checkbox {
    color: #fff;
  }

  .el-button--primary {
    // background: linear-gradient(to bottom, #02d7f0, #02d8fd);
    background: linear-gradient(to bottom, #02d8fd, #01a9f0);
    border-color: #02d7f0;
    color: #fff;
    padding: 16px 20px;
    padding-left: 130.79px;
    padding-right: 130.78px;
    margin-top: 5px;
  }
  .el-button--primary:focus,
  .el-button--primary:hover {
    // background: linear-gradient(to bottom, #02d8fd, #01a9f0);
    background: linear-gradient(to bottom, #02d7f0, #02d8fd);
  }
  .el-form-item {
    margin-bottom: 25px;
  }
  .el-button {
    font-size: 16px;
  }
}
</style>
