<template>
  <div class="login" style="position: relative">
    <img class="login-bg" style="position: absolute; width: 100%; height: 100%; left: 0px; z-index: 0" src="static/image/base/login7/bg-login.jpg" />
    <div class="Login7-title"><img class="logo" src="static/image/base/logo3.png" /> {{ systemName }}</div>
    <img class="login-box" src="static/image/base/login7/login-box.png" />
    <el-form ref="formAccount" class="form" :rules="formAccountRules" :model="formAccount">
      <el-form-item class="username input-box" prop="account">
        <i class="el-icon-user"></i>
        <el-input class="username-input input" v-model="formAccount.account" placeholder="请输入用户名" />
      </el-form-item>
      <el-form-item class="password input-box" prop="pass">
        <i class="el-icon-lock"></i>
        <el-input class="password-input input" v-model="formAccount.pass" type="password" placeholder="请输入密码" />
      </el-form-item>
      <el-form-item class="button">
        <img class="login-button" src="static/image/base/login7/login-button.png" />
        <div class="login-text" @click="submitForm()">登录</div>
        <!-- <el-button @click="submitForm()">登录</el-button> -->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import mixin from './loginMixin.js'
export default {
  mixins: [mixin],
  name: 'Login7',
}
</script>

<style scoped lang="less">
.login {
  width: 100%;
  height: 100%;
}
//标题logo及文字设置
.Login7-title {
  position: absolute;
  display: flex;
  width: 100%;
  top: 150px;
  //设置背景渐变
  background: linear-gradient(to bottom, white, rgb(126, 217, 248));
  //将背景限定在文字内容上
  -webkit-background-clip: text;
  //将文字颜色设为透明
  -webkit-text-fill-color: transparent;
  height: 35px;
  line-height: 35px;
  justify-content: center;
  z-index: 1;
  font-size: 30px;
  font-family: 'ALIMAMASHUHEITI-BOLD';
  font-weight: 700;
  .logo {
    height: 35px;
    width: 40px;
    margin-right: 15px;
  }
}
//登录框图
.login-box {
  position: absolute;
  top: 270px;
  z-index: 2;
  transform: translate(-50%);
  left: 50%;
}
//登录表单
.form {
  position: absolute;
  top: 390px;
  transform: translate(-50%);
  left: 50%;
  z-index: 3;
  width: 320px;
}
//输入框外部容器
.input-box {
  border: 0;
  display: flex;
  border-bottom: 1px solid rgb(25, 80, 104);
  padding-bottom: 12px;
  margin-bottom: 40px;
}
/deep/ .el-input__inner::-webkit-input-placeholder {
  color: #fff;
}
/deep/ .el-form-item__content {
  display: flex;
}
:focus {
  outline: 0;
}
.button {
  height: 42px;
  width: 320px;
  position: relative;
  cursor: pointer;
  .login-button {
    position: absolute;
    z-index: 0;
    top: 0;
    left: 0;
  }
  .login-text {
    text-align: center;
    z-index: 1;
    font-size: 20px;
    width: 100%;
    height: 100%;
    color: #fff;
    line-height: 42px;
  }
}
/deep/ .el-input__inner {
  height: 16px;
  width: 300px;
  font-size: 16px;
  line-height: 16px;
  padding: 0px 12px;
  color: #fff;
  border: none;
  background-color: transparent !important;
}
/deep/ .el-form-item__content {
  line-height: 16px;
}
/deep/ .el-form-item__error {
  top: calc(100% + 13px);
  left: 30px;
  font-size: 14px;
}
/deep/ .el-icon-user {
  color: rgb(73, 170, 205);
}
/deep/ .el-icon-lock {
  color: rgb(73, 170, 205);
}
</style>
