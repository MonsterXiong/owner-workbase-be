<template>
  <div class="xyd-login">
    <img style="position: absolute; width: 100%; height: 100%; z-index: 1" src="static/image/base/login10/bg.png" alt="" />
    <main class="login-main">
      <header>
        <img src="static/image/base/login10/head.png" alt="" style="width: 100%; height: 100%" />

        <div class="head-title">
          <img src="static/image/base/login10/headIcon.png" alt="" />
          {{ systemName }}
        </div>
      </header>
      <div class="login-card">
        <div class="card-wrap">
          <img class="card-bg" src="static/image/base/login10/login-main.png" alt="" />
          <div class="info-card">
            <el-form ref="formAccount" :model="formAccount" status-icon :rules="formAccountRules">
              <el-form-item prop="account">
                <div class="input-wrapper">
                  <div class="input-title">
                    <img src="static/image/base/login10/user.png" alt="" />
                  </div>
                  <el-input v-model="formAccount.account" @keyup.enter.native="submitForm" placeholder="请输入用户名"> </el-input>
                </div>
              </el-form-item>
              <el-form-item prop="pass">
                <div class="input-wrapper">
                  <div class="input-title">
                    <img src="static/image/base/login10/pass.png" alt="" />
                  </div>
                  <el-input v-model="formAccount.pass" type="password" @keyup.enter.native="submitForm" placeholder="请输入密码"> </el-input>
                </div>
              </el-form-item>
            </el-form>
            <el-button type="primary" @click="submitForm()"> 登 录 </el-button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import loginMixin from './loginMixin'
export default {
  name: 'login10',
  mixins: [loginMixin],
}
</script>

<style lang="less" scoped>
.text-title() {
  background-image: linear-gradient(to bottom, #e8feff, #1592ff);
  -webkit-background-clip: text;
  color: transparent;
}
.xyd-login {
  height: 100%;
  position: relative;
  min-height: 716px;
  overflow: auto;
  .login-main {
    position: absolute;
    z-index: 2;
    height: 100%;
    width: 100%;
    header {
      height: 84px;
      position: relative;
      margin-bottom: 100px;
      .head-title {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        top: 0;
        width: 100%;
        text-align: center;
        font-size: 36px;
        font-family: 'ALIMAMASHUHEITI-BOLD';
        font-weight: 700;
        text-shadow: 2px 3px 1px rgba(0, 0, 0, 0.25);
        .text-title();
        img {
          height: 36px;
          width: 36px;
          margin-right: 10px;
        }
      }
    }
    .login-card {
      width: 100%;
      display: flex;
      justify-content: center;
      .card-bg {
        min-width: 989px;
      }
      .card-wrap {
        position: relative;
      }
      .info-card {
        position: absolute;
        // padding-top: 150px;
        top: 150px;
        right: 70px;
        width: 380px;
        .input-wrapper {
          width: 380px;
          height: 58px;
          border: 1px solid #4dc9f7;
          // background-color: #02d6fc23;
          color: #02cdf4;
          display: flex;
          .input-title {
            img {
              width: 56px;
              height: 56px;
            }
          }
        }
      }
    }
  }
}
::v-deep {
  .el-input__inner {
    height: 56px;
    line-height: 56px;
    font-size: 20px;
  }
  .el-input__inner {
    background: transparent !important;
    border: none;
    color: #02cdf4;
  }

  .el-input__prefix,
  .el-input__suffix,
  .el-checkbox__input.is-checked + .el-checkbox__label {
    color: #02cdf4;
  }

  .el-button--primary {
    background: linear-gradient(to right bottom, #38a8e9, #2973a3);
    border: 1px solid #4dc9f7;
    color: #fff;
    margin-top: 10px;
    width: 380px;
    height: 58px;
    font-size: 20px !important;
  }
  .el-button--primary:focus,
  .el-button--primary:hover {
    background: linear-gradient(to bottom, #38a8e9, #38a8e9);
  }
  .el-form-item {
    margin-bottom: 30px;
  }
  .el-button {
    font-size: 16px;
  }
}
</style>
