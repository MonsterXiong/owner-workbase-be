<template>
  <div class="login" style="position: relative">
    <el-carousel class="bg-card" :interval="5000">
      <el-carousel-item v-for="item in loginImageList" height="100%" :key="item">
        <div class="bg-img" :style="`background-image: url(${item})`" alt="" />
      </el-carousel-item>
    </el-carousel>
    <main class="login-card">
      <h1 class="login-title">
        <img src="static/image/base/logo1.png" style="max-height: 50px" />
        <div>{{ systemName }}</div>
      </h1>

      <el-form style="width: 400px; margin-bottom: 150px" ref="formAccount" :model="formAccount" status-icon :rules="formAccountRules">
        <h3 class="form-title">登录您的账户</h3>
        <el-form-item prop="account">
          <el-input v-model="formAccount.account" placeholder="请输入登录账号">
            <i slot="prefix" class="el-input__icon el-icon-user login-icon"></i>
          </el-input>
        </el-form-item>
        <el-form-item prop="pass">
          <el-input v-model="formAccount.pass" type="password" @keyup.enter.native="submitForm" placeholder="请输入密码">
            <i slot="prefix" class="el-input__icon el-icon-lock login-icon"></i>
          </el-input>
        </el-form-item>
        <div style="line-height: 20px">
          <el-checkbox v-model="isRemember">记住我</el-checkbox>
        </div>
        <el-form-item style="margin-top: 30px">
          <el-button class="login-button" size="ol" type="primary" @click="submitForm()">登录</el-button>
        </el-form-item>
      </el-form>

      <footer class="login-footer">
        <template v-if="companyName && companyName.trim().length > 0">
          Copyright
          <i>
            <svg viewBox="64 64 896 896" focusable="false" class data-icon="copyright" width="1em" height="1em" fill="currentColor" aria-hidden="true">
              <path
                d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372zm5.6-532.7c53 0 89 33.8 93 83.4.3 4.2 3.8 7.4 8 7.4h56.7c2.6 0 4.7-2.1 4.7-4.7 0-86.7-68.4-147.4-162.7-147.4C407.4 290 344 364.2 344 486.8v52.3C344 660.8 407.4 734 517.3 734c94 0 162.7-58.8 162.7-141.4 0-2.6-2.1-4.7-4.7-4.7h-56.8c-4.2 0-7.6 3.2-8 7.3-4.2 46.1-40.1 77.8-93 77.8-65.3 0-102.1-47.9-102.1-133.6v-52.6c.1-87 37-135.5 102.2-135.5z"
              />
            </svg>
          </i>
        </template>

        {{ companyName }}
      </footer>
    </main>
  </div>
</template>

<script>
import mixin from './loginMixin.js'
export default {
  mixins: [mixin],
  name: 'Login8',
  data() {
    return {
      loginImageList: ['static/image/base/login8/image1.jpg', 'static/image/base/login8/image2.jpg', 'static/image/base/login8/image3.jpg'],
    }
  },
}
</script>

<style scoped lang="less">
img {
  user-select: none;
  -webkit-user-drag: none;
}

.login {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  display: flex;
  ::v-deep {
    .el-carousel__container {
      height: 100%;
    }
    .el-carousel--horizontal,
    .el-carousel__item {
      overflow: visible;
    }

    .el-input__inner {
      height: 50px;
      line-height: 50px;
      font-size: 15px;
    }
    .el-input__icon {
      line-height: 50px;
      font-size: 15px;
    }
  }
  .bg-card {
    width: 54%;
    height: 100%;
    .bg-img {
      // transform: translateX(-50%);
      height: 100%;
      width: 100%;
      background-size: 100% auto;
    }
  }
  .login-card {
    position: relative;
    width: 46%;
    height: 100%;
    padding: 40px 130px;
    background-color: #fff;
    box-shadow: 1px 3px 12px -1px rgb(99, 99, 99);
    z-index: 2;
    border-radius: 15px 0 0 15px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    .login-title {
      font-size: 50px;
      text-align: center;
      font-weight: bold;
    }
    .form-title {
      text-align: center;
      font-size: 22px;
      letter-spacing: 2px;
      margin: 0px 0px 40px;
    }
    .login-button {
      width: 100%;
      margin-top: 6px;
      letter-spacing: 15px;
      font-weight: bold;
      font-size: 18px;
      padding: 16px 20px;
    }
    .login-footer {
      width: 100%;
      text-align: center;
      color: #7f7e7f;
      font-size: 13px;
      i {
        vertical-align: -2px;
      }
    }
  }
}
</style>
