<template>
  <ExternalUrl :url="url"></ExternalUrl>
</template>

<script>
import ExternalUrl from '@/components/externalUrl/ExternalUrl.vue'
export default {
  name: 'Extend',
  components: { ExternalUrl },
  data() {
    return {
      url: '',
    }
  },
  watch: {
    $route: {
      handler(val) {
        this.url = val.query?.url || ''
      },
      immediate: true,
    },
  },
}
</script>
