<template>
  <div class="page">
    <InputMatrixTable
      :xData="xData"
      :xProps="xyProps"
      :yData="yData"
      :yProps="xyProps"
      :data="data"
      :dataProps="dataProps"
      :titles="titles"
      :minColumnWidth="200"
    />
  </div>
</template>

<script>
import { InputMatrixTable } from '@/components/matrixTable1'
import { treeData, headerData, data } from './mock'
import { treeToList } from '@/utils/treeTool'
export default {
  name: 'Test',
  components: {
    InputMatrixTable,
  },
  data() {
    return {
      xData: treeToList(treeData),
      yData: treeToList(headerData),
      xyProps: {
        name: 'nodeName',
        id: 'nodeId',
        parentId: 'parentId',
      },
      dataProps: {
        x: 'bindActIndex',
        y: 'bindTixiAbiIndex',
        value: 'relDegree',
      },
      titles: ['体系能力', '作战活动'],
      data,
    }
  },

  methods: {},
}
</script>

<style scoped lang="less">
.page {
  height: 100%;
  padding: 10px;
  overflow: hidden;
}
</style>
