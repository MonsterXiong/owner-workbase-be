<template>
  <div class="common-page">
    <BizTable :columnList="columnList" :btns="queryBtns" :tableConfig="tableConfig" :tableInterface="tableInterface" />
  </div>
</template>

<script>
import BizTable from '@/bizComponents/bizTable/BizTable.vue'
export default {
  name: 'Welcome',
  components: {
    BizTable,
  },
  data() {
    return {
      columnList: [
        {
          type: 'selection',
        },
        {
          type: 'index',
        },
        {
          code: 'name',
          label: '能力名称',
          query: true,
          required: true,
          type: 'input',
        },
        {
          code: 'code',
          label: '标识',
          type: 'input',
        },
        {
          code: 'description',
          label: '描述',
          type: 'textarea',
        },
        // {
        //   code: 'bindType',
        //   label: '类型',
        //   type: 'select',
        //   options: [
        //     {
        //       label: '成本型',
        //       value: 'chengbenxing',
        //     },
        //     {
        //       label: '效益型',
        //       value: 'xiaoyixing',
        //     },
        //   ],
        // },
        {
          label: '操作',
          type: 'button',
          buttonList: [
            {
              emitCode: 'edit',
              label: '编辑',
            },
            {
              emitCode: 'delete',
              type: 'danger',
              label: '删除',
            },
          ],
        },
      ],
      queryBtns: [
        // {
        //   code: 'search',
        //   type: 'primary',
        //   label: '查询',
        //   icon: 'el-icon-search',
        // },
      ],
      tableConfig: {
        dialogTitle: '体系能力',
        downloadFileName: '体系能力',
        relationParams: {},
      },
      tableInterface: {
        service: 'XydTixiAbi', //   query queryList
        key: 'tixiAbiId',
      },
    }
  },
  created() {
    this.setTableRelationParams()
  },
  methods: {
    setTableRelationParams() {
      this.tableConfig.relationParams.bindProject = '4c39869803e74f70837d15d39cbac651'
    },
  },
}
</script>
