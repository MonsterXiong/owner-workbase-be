<template>
  <div class="basic-graph-page" v-loading="loading">
    <PanelLayout :defaultRightWidth="22" :showRightPanel="currentNodeData != null">
      <!-- 简单普通绘图组件 -->
      <BasicGraphDiagram
        ref="basicGraphDiagramRef"
        :diagramData="diagramData"
        :diagramConfig="diagramConfig"
        :metaToolConfig="metaToolConfig"
        @saveDiagram="onSaveDiagram"
        @selectNode="onSelectNode"
      ></BasicGraphDiagram>
      <template slot="right">
        <div class="edit-panel">
          <div class="edit-panel-title">基础属性</div>
          <main>
            <div class="form-wrap">
              <div class="form-main">
                <el-form label-position="left" label-width="80px" :model="formData" size="small" :rules="formRules" ref="attrFormRef">
                  <el-form-item label="能力名称" prop="abiName">
                    <el-input v-model="formData.name" placeholder="请输入名称"></el-input>
                  </el-form-item>
                </el-form>
              </div>
              <footer>
                <el-button size="small" type="primary" @click="onSubmitForm">保存</el-button>
              </footer>
            </div>
          </main>
        </div>
      </template>
    </PanelLayout>
  </div>
</template>

<script>
import PanelLayout from '@/components/panelLayout/PanelLayout.vue'
import BasicGraphDiagram from '@/components/basicGraphDiagram/BasicGraphDiagram.vue'
import { baseConfig } from '@/components/basicGraphDiagram/config'
import { QueryConditionBuilder } from '@/utils/queryConditionBuilder.js'
import { PhysicsStatusService, PhysicsStatusLineService } from '@/services'
import { uuid } from '@/utils/commonUtil'
import tools from '@/utils/tools'

export default {
  name: 'ProjectListManage',
  data() {
    return {
      loading: false,
      diagramData: {
        nodes: [],
        links: [],
      },
      diagramConfig: {
        nodeTextKey: 'statusName',
        nodeKeyProperty: 'statusId',
        linkTextKey: 'lineName',
        linkFromKeyProperty: 'sourceId',
        linkToKeyProperty: 'targetId',
        processTextKey: 'statusName', // 泳道头部名称
        linkRouting: 'Orthogonal', // 连线方式
        // 连线方法
        linkDrawnAfterHook: function (fromNode, toNode, linkDrawnEvent, metaTool, finallyConfig) {
          if (!metaTool) return
          const { subject, diagram } = linkDrawnEvent
          let linkData = {
            id: uuid(),
            [diagram.model.linkFromKeyProperty]: subject.data[diagram.model.linkFromKeyProperty],
            [diagram.model.linkToKeyProperty]: subject.data[diagram.model.linkToKeyProperty],
            ...metaTool.goJsProperty,
            objData: {
              [finallyConfig.linkTextKey]: metaTool.goJsProperty[finallyConfig.linkTextKey],
              [diagram.model.linkFromKeyProperty]: fromNode.data[finallyConfig.nodeKeyProperty],
              [diagram.model.linkToKeyProperty]: toNode.data[finallyConfig.nodeKeyProperty],
            },
          }
          // console.log(linkData, metaTool, 'linkData-----------')
          return linkData
        },
      },
      // 工具栏节点数据
      metaToolConfig: [],
      currentNodeData: null,
      formRules: {},
      formData: {
        name: '',
      },
      oldNodes: [],
      oldLinks: [],
    }
  },
  computed: {
    currentProjectId() {
      // return getCurrentProjectId()
      return '5c5d80e17bf5404e9ab644b207a82caa'
    },
  },
  methods: {
    getQueryCondition() {
      return QueryConditionBuilder.getInstanceNoPage().buildEqualQuery('bindProject', this.currentProjectId)
    },
    async queryDiagramData() {
      const { data: nodes } = await this.onQueryPhysicsStatusList(this.getQueryCondition())
      const { data: links } = await this.onQueryPhysicsStatusLineList(this.getQueryCondition())
      this.oldNodes = [...nodes]
      this.oldLinks = [...links]
      let { nodeData, linkData } = this.handleQueryNodesOrLinks(nodes, links)
      this.diagramData = {
        nodeData,
        linkData,
      }
    },
    handleQueryNodesOrLinks(nodeDataArray, linkDataArray) {
      let nodeData = [],
        linkData = []
      nodeData = nodeDataArray.map((item) => {
        const nodeItem = _.cloneDeep(item)
        delete nodeItem.style
        return {
          ...JSON.parse(item.style || '{}'),
          objData: { ...nodeItem },
        }
      })
      linkData = linkDataArray.map((item) => {
        const linkItem = _.cloneDeep(item)
        delete linkItem.style
        return {
          ...JSON.parse(item.style || '{}'),
          objData: { ...linkItem },
        }
      })
      return { nodeData, linkData }
    },
    onSaveDiagram(nodeDataArray, linkDataArray) {
      const { nodes, links } = this.handleSaveNodesOrLinks(nodeDataArray, linkDataArray)
      try {
        this.loading = true
        Promise.all([
          this.onSavePhysicsStatusBatch({
            newDTOList: nodes,
            oldDTOIdList: this.oldNodes.map((item) => item.statusId),
          }),
          this.onSavePhysicsStatusLineBatch({
            newDTOList: links,
            oldDTOIdList: this.oldLinks.map((item) => item.lineId),
          }),
        ])
        tools.message('保存成功')
      } catch (error) {
        console.error(error)
      } finally {
        this.loading = false
      }
    },
    handleSaveNodesOrLinks(nodeDataArray, linkDataArray) {
      let nodes = [],
        links = []
      nodes = nodeDataArray.map((item) => {
        const nodeItem = _.cloneDeep(item)
        delete nodeItem.objData
        return {
          ...item.objData,
          bindProject: item.objData.bindProject ? item.objData.bindProject : this.currentProjectId,
          bindResource: item.objData.bindResource ? item.objData.bindResource : this.currentEquipId,
          type: item._node_status_type, // 状态类型
          style: JSON.stringify(nodeItem),
        }
      })
      links = linkDataArray.map((item) => {
        const linkItem = _.cloneDeep(item)
        delete linkItem.objData
        return {
          ...item.objData,
          bindProject: item.objData.bindProject ? item.objData.bindProject : this.currentProjectId,
          bindResource: item.objData.bindResource ? item.objData.bindResource : this.currentEquipId,
          style: JSON.stringify(linkItem),
        }
      })
      return { nodes, links }
    },
    onSelectNode(nodeData) {
      // console.log('onSelectNode----------', nodeData)
      this.currentNodeData = nodeData ? { ...nodeData } : null
      if (this.currentNodeData) {
        this.formData = { ...nodeData.objData }
        this.$set(
          this.formData,
          'name',
          nodeData.objData[nodeData[baseConfig.nodeCategoryProperty] === 'link' ? this.diagramConfig.linkTextKey : this.diagramConfig.nodeTextKey]
        )
      }
    },
    onSubmitForm() {
      this.$refs.attrFormRef.validate(async (valid) => {
        if (valid) {
          // 更新节点数据
          let formData = { ...this.formData }
          const nodeOrLinkName =
            this.currentNodeData[baseConfig.nodeCategoryProperty] === 'link'
              ? this.diagramConfig.linkTextKey || baseConfig.linkTextKey
              : this.diagramConfig.nodeTextKey || baseConfig.nodeTextKey

          this.$refs.basicGraphDiagramRef.onUpdateNodeOrLinkData({
            [nodeOrLinkName]: formData.name,
            objData: { ...formData, [nodeOrLinkName]: formData.name },
          })
        }
      })
    },
    // 查询物理状态列表API
    async onQueryPhysicsStatusList(queryCondition) {
      return await PhysicsStatusService.baseQueryPhysicsStatusList(queryCondition)
    },
    // 保存物理状态API
    async onSavePhysicsStatusBatch(params) {
      return await PhysicsStatusService.savePhysicsStatusBatch(params)
    },
    // 查询物理状态线列表API
    async onQueryPhysicsStatusLineList(queryCondition) {
      return await PhysicsStatusLineService.baseQueryPhysicsStatusLineList(queryCondition)
    },
    // 保存物理状态线API
    async onSavePhysicsStatusLineBatch(params) {
      return await PhysicsStatusLineService.savePhysicsStatusLineBatch(params)
    },
  },
  components: { PanelLayout, BasicGraphDiagram },
}
</script>

<style lang="less" scoped>
.basic-graph-page {
  height: 100%;
  .edit-panel {
    height: 100%;
    // border-left: 1px solid #d8d8d8;
    .edit-panel-title {
      height: 50px;
      line-height: 50px;
      text-align: center;
      font-weight: 600;
      font-size: 16px;
      color: #fff;
      background: #1485cd;
    }
    main {
      height: calc(100% - 50px);
      overflow-y: auto;
    }

    .form-wrap {
      height: 100%;
      .form-main {
        height: calc(100% - 50px);
        overflow-y: auto;
        padding: 10px;
      }
      footer {
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }
  }
}
</style>
