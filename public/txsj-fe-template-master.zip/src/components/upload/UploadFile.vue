<template>
  <el-upload
    class="upload-file upload-box"
    ref="uploadRef"
    :on-change="onUploadChange"
    :file-list="fileViewList"
    :auto-upload="false"
    :limit="limit"
    :show-file-list="showFileList"
    :on-exceed="onExceedFile"
    :accept="format"
    action="#"
    :multiple="multipleImportFile"
    :on-remove="onFileRemove"
  >
    <template v-if="!multipleImportFile && fileName">
      <el-image v-if="fileType === 'img'" :src="fileName" fit="contain" />
      <div class="file-name-text" v-else>{{ fileName }}</div>
    </template>
    <template v-else>
      <template v-if="$slots.uploadText"> <slot name="uploadText"></slot></template>
      <i v-else class="el-icon-upload"></i>
    </template>
  </el-upload>
</template>

<script>
// import tools from '@/utils/tools'
export default {
  props: {
    filePath: {
      type: String,
      default: '',
    },
    fileType: {
      type: String,
      default: 'img',
    },
    uploadSlot: {
      type: Boolean,
      default: false,
    },
    multipleImportFile: {
      type: Boolean,
      default: false,
    },
    limit: {
      type: Number,
      default: 2,
    },
    fileViewList: {
      type: Array,
      default: () => [],
    },
    showFileList: {
      type: Boolean,
      default: false,
    },
    itemData: {
      type: Object,
    },
  },
  watch: {
    fileType() {
      this.setFormat()
    },
    filePath() {
      this.setFileName()
    },
  },
  data() {
    return {
      fileList: [],
      fileName: '',
      format: 'image/*',
    }
  },
  mounted() {
    this.setFormat()
    this.setFileName()
  },
  methods: {
    setFormat() {
      switch (this.fileType) {
        case 'xml':
          this.format = 'text/xml,charset=UTF-8'
          break
        case 'pdf':
          this.format = '.pdf'
          break
        case 'word':
          this.format = '.doc,.docx'
          break
        case 'text':
          this.format = '.text'
          break
        case 'excel':
        case 'xlsx':
        case 'xls':
          this.format = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,'
          break
        case 'zip':
          this.format = 'application/zip'
          break
        case 'img':
          this.format = 'image/*'
          break
        default:
          this.format = '*'
          break
      }
    },

    onUploadChange(file) {
      // 拖拽上传时设置accept过滤文件类型，不会触发onChange事件
      // let text = this.handleFileTypeCheckout(file.raw)
      // if (text) return tools.message(text, { type: 'warning' })
      if (this.multipleImportFile) {
        this.fileList.push(file)
      } else {
        this.fileList = [file]
        if (this.fileType === 'img') {
          this.fileName = URL.createObjectURL(file.raw)
        } else {
          this.fileName = file.name
        }
      }
      this.$emit('upload', file, this.itemData)
    },
    // @TODO 根据对应文件类型处理文件校验
    handleFileTypeCheckout(file) {
      let text = ''
      switch (this.fileType) {
        case 'xml':
          if (file.type !== 'text/xml') text = '请选择xml文件'
          break
        case 'pdf':
          if (file.type !== 'application/pdf') text = '请选择pdf文件'
          break
        case 'word':
          if (!['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(file.type))
            text = '请选择word文档文件'
          break
        case 'text':
          if (file.type !== 'text/plain') text = '请选择text文本文件'
          break
        case 'excel':
        case 'xlsx':
        case 'xls':
          if (!['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'].includes(file.type))
            text = '请选择excel|xlsx|xls表格文件'
          break
        case 'zip':
          if (file.type !== 'application/x-zip-compressed') text = '请选择zip压缩文件'
          break
        case 'img':
          if (!['image/png'].includes(file.type)) text = '请选择png图片文件'
          break
        default:
          this.format = '*'
          break
      }
      return text
    },

    onExceedFile(files) {
      if (files && files.length > 0) {
        let file = files[0]
        this.onUploadChange({ name: file.name, raw: file })
      }
    },

    setFileName() {
      if (this.filePath) {
        this.fileName = this.filePath
      } else {
        this.fileName = ''
      }
    },
    onFileRemove(file, fileList) {
      this.$emit('removeUploadFileList', fileList)
    },
    getFileList() {
      return this.fileList
    },
  },
}
</script>

<style lang="less" scoped>
.upload-file {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  &:hover {
    border-color: #409eef;
  }
  width: 100px;
  height: 100px;

  .el-image {
    width: 100%;
    height: 100%;
  }

  ::v-deep {
    .el-upload {
      width: 100%;
      height: 100%;
    }
    // .el-upload-dragger {
    //   width: 100%;
    //   height: 100%;
    //   min-width: 40px;
    //   min-height: 40px;

    .el-icon-upload {
      margin: 10px 0;
      font-size: 40px;
    }
    // }
    .file-name-text {
      width: 100%;
      position: absolute;
      text-align: center;
      transform: translateY(-50%);
      top: 50%;
    }
  }
}
</style>
