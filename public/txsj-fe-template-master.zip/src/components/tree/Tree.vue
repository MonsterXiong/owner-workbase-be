<template>
  <div class="tree-container" ref="treeContainerRef">
    <div class="search-wrap" v-if="config.isFilter" ref="searchRef">
      <el-input v-model="filterText" size="mini" placeholder="请输入名称" clearable></el-input>
    </div>
    <el-tree :class="{ 'custom-tree': config.customTree }" v-bind="mergeObj(defaultOptions, $data.$_attrs)" v-on="$data.$_listeners" ref="elTreeRef">
      <template slot-scope="scope">
        <slot v-bind="scope">
          <span
            :title="!scope.data.disabled ? scope.data[$data.$_attrs.props?.label ? $data.$_attrs.props?.label : 'label'] : ''"
            :class="scope.data.disabled && 'is-disabled'"
            class="label"
            @click="(e) => itemClick(e, scope.data)"
          >
            <SvgIcon v-if="getIconType(scope.data) === iconType.SVG" :class="scope.data.treeIcon" :fill="scope.data.svgFill" />
            <img v-if="getIconType(scope.data) === iconType.IMG" :src="scope.data.treeIcon" alt="" />
            <i v-if="getIconType(scope.data) === iconType.DEFAULT" :class="getClassName(scope.data)"></i>
            {{ scope.data[$data.$_attrs.props?.label ? $data.$_attrs.props?.label : 'label'] }}
          </span>
        </slot>
      </template>
    </el-tree>
  </div>
</template>

<script>
import SvgIcon from '@/baseComponents/svgIcon/SvgIcon.vue'
import { mergeObj } from '@/utils/commonUtil'
export default {
  name: 'Tree',
  data() {
    return {
      $_attrs: {},
      $_listeners: {},
      filterText: '',
      defaultOptions: Object.freeze({
        defaultExpandAll: true,
        isFilter: false, // 是否显示搜索
        filterNodeMethod: this.filterNode,
        customTree: true, // 是否自定义样式
      }),
      iconType: {
        SVG: 'svg',
        IMG: 'img',
        DEFAULT: 'ICON',
      },
    }
  },
  computed: {
    config() {
      return mergeObj(this.defaultOptions, this.$data.$_attrs)
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.setTreeHeight()
    })
  },
  methods: {
    filterNode(value, data) {
      if (!value) return true
      return data[this.config.props.label].indexOf(value) !== -1
    },
    setCurrentKey(id) {
      this.$refs.elTreeRef.setCurrentKey(id)
    },
    getIconType(data) {
      let type = null
      switch (data.iconType) {
        case this.iconType.SVG:
          type = this.iconType.SVG
          break
        case this.iconType.IMG:
          type = this.iconType.IMG
          break
        default:
          type = this.iconType.DEFAULT
          break
      }
      return type
    },
    getClassName(data) {
      return data.treeIcon ? data.treeIcon : 'el-icon-tickets'
    },
    itemClick(e, data) {
      this.$emit('nodeLabelClick', { e, data })
    },
    setTreeHeight() {
      this.$refs.elTreeRef.$el.style.height = this.$refs.treeContainerRef.offsetHeight - this.$refs.searchRef?.offsetHeight + 'px'
    },
    mergeObj,
  },
  components: { SvgIcon },
  watch: {
    $attrs: {
      immediate: true,
      handler(val) {
        Object.keys(val).forEach((k) => {
          this.$set(this.$data.$_attrs, k, val[k])
        })
      },
    },
    $listeners: {
      immediate: true,
      handler(val) {
        Object.keys(val).forEach((k) => {
          this.$set(this.$data.$_listeners, k, val[k])
        })
      },
    },
    filterText(val) {
      this.$refs.elTreeRef.filter(val)
    },
  },
}
</script>

<style scoped lang="less">
@treeBorderColor: var(--tree-border-color, #4386c6);
@treeIconColor: var(--tree-icon-color, #1389bc);

.tree-container {
  height: 100%;
  overflow: auto;
  .search-wrap {
    padding: 10px 16px;
  }
}
.el-tree {
  &.custom-tree {
    ::v-deep {
      .el-tree-node {
        position: relative;
        padding-left: 16px;
        span.label {
          padding-left: 6px;
          width: 100%;
          display: inline-block;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        &__children {
          padding-left: 16px;
          .el-tree-node__content {
            padding-left: 0 !important;
            width: 100%;
            display: flex;
            align-items: center;
          }
        }

        &:last-child::before {
          height: 38px;
        }

        &::before,
        &::after {
          content: '';
          left: -7px;
          position: absolute;
          right: auto;
          border-width: 1px;
        }

        &:before {
          border-left: 1px dashed @treeBorderColor;
          bottom: 0px;
          height: 100%;
          top: -25px;
          width: 1px;
        }

        &:after {
          border-top: 1px dashed @treeBorderColor;
          height: 20px;
          top: 12px;
          width: 18px;
        }

        &__expand-icon {
          padding: 0;
          &.is-leaf {
            display: none;
          }

          &.expanded {
            transform: rotate(0deg);

            &.el-icon-caret-right:before {
              content: '\e722';
              font-size: 16px;
              color: @treeIconColor;
            }
          }
        }

        .el-icon-caret-right:before {
          content: '\e723';
          font-size: 16px;
          color: @treeIconColor;
        }
      }

      > .el-tree-node {
        &::before {
          border-left: none;
        }

        &::after {
          border-top: none;
        }
      }
    }
  }
  ::v-deep {
    .el-tree-node {
      img {
        width: 16px;
      }
    }
  }
}
</style>
