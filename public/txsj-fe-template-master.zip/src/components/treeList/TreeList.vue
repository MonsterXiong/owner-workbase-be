<template>
  <div class="common-page list-wrap" ref="listWrapRef">
    <div class="head-wrap" ref="headWrapRef" :style="headStyle()">
      <div class="head-title">
        <span>{{ title }}</span>
        <i class="el-icon-plus" v-if="listConfig.allowAdd && !listConfig.readOnly" @click="onAddNode"></i>
      </div>
    </div>
    <div class="list-content" :style="{ height: contentHeight }">
      <div class="search-wrap" v-if="listConfig.isFilter">
        <el-input placeholder="输入关键字进行过滤" v-model="filterText" size="mini"> </el-input>
      </div>
      <div class="tree-wrap" :style="{ height: treeHeight }">
        <el-tree
          ref="treeRef"
          :data="data"
          node-key="id"
          default-expand-all
          :expand-on-click-node="false"
          :highlight-current="true"
          :props="defaultProps"
          :filter-node-method="filterNode"
        >
          <span class="custom-tree-node" slot-scope="{ node, data }" style="width: 100%">
            <div class="node-wrap" style="width: 100%; padding: 0px; display: flex; align-items: center" @click="onNodeClick(data)">
              <!-- -->
              <base-icon class="tree-list-icon" :iconName="data.icon" style="margin-right: 4px" v-show="data.icon"></base-icon>
              <span :style="getTextStyle(data, node)" :title="node.label">{{ node.label }}</span>
              <span v-show="!listConfig.readOnly">
                <base-icon
                  class="tree-list-icon"
                  v-for="item in data.icons"
                  :key="item.code"
                  :iconName="item.icon"
                  :title="item.name"
                  style="margin-left: 4px"
                  @click.native.stop="onIconClick(data, item)"
                ></base-icon>
              </span>
            </div>
          </span>
        </el-tree>
      </div>
    </div>
    <div class="footer-btn" ref="footerBtnRef">
      <slot name="footer"></slot>
    </div>
  </div>
</template>

<script>
import { mergeObj } from '@/utils/commonUtil'
import { treeToList } from '@/utils/treeTool'

export default {
  name: 'List',
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    title: {
      type: String,
      default: 'xx列表',
    },
    initSel: {
      type: String,
      default: '',
    },
    config: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      searchName: '',
      currentNodeId: '',
      selectNode: null,
      baseConfig: {
        isFilter: true, // 搜索
        // headStyle: { backgroundImage: 'url(' + require('./image/list-hed-bg.png') + ')', backgroundSize: '100% 100%' }, // 头部背景
        isSelectOneNode: true, // 选中第一个节点
        isEdit: false, // 是否编辑
        allowAdd: false,
        readOnly: false,
      },
      contentHeight: '',
      treeHeight: '',
      filterText: '',
      defaultProps: {
        children: 'children',
        label: 'name',
      },
    }
  },
  computed: {
    listConfig() {
      return mergeObj(this.baseConfig, this.config)
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.setContentHeight()
    })
  },
  methods: {
    getTextStyle(data, node) {
      let len = data.icons?.length || 0
      // if (data.icon)
      len += 1
      let iconW = len * 20
      return {
        display: 'inline-block',
        width: `calc(100% - ${iconW}px)`,
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        textOverflow: 'ellipsis',
      }
    },
    filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    onQueryList() {
      this.$emit('query', this.searchName)
    },
    onNodeClick(data) {
      // console.log(data, 'onNodeClick--------------')
      if (this.listConfig.type && data.type != this.listConfig.type) {
        this.$refs.treeRef.setCurrentKey(null)
        return
      }
      if (!data || this.currentNodeId === data.id) return
      this.currentNodeId = data.id
      this.selectNode = data.nodeData
      this.$nextTick(() => {
        this.$refs.treeRef.setCurrentKey(data.id)
      })
      this.$emit('nodeClick', data)
    },
    onIconClick(data, icon) {
      let code = icon.code
      if (icon.addType) {
        this.$emit('iconClick', { data, code, addType: icon.addType })
      } else this.$emit('iconClick', { data, code })
    },
    onAddNode() {
      this.$emit('add')
    },
    headStyle() {
      return mergeObj(this.listConfig.headStyle)
    },
    setContentHeight() {
      let height = this.$refs.listWrapRef.offsetHeight - this.$refs.headWrapRef.offsetHeight - this.$refs.footerBtnRef.offsetHeight - 20
      this.contentHeight = height + 'px'
      this.treeHeight = height - 38 + 'px'
    },
    setCurrentNodeByKey(key) {
      this.$refs.treeRef.setCurrentKey(key)
    },
  },
  watch: {
    filterText(val) {
      this.$refs.treeRef.filter(val)
    },
    currentNodeId() {
      this.$emit('input', this.currentNodeId)
      this.$emit('change', this.selectNode)
    },
    initSel: {
      handler(val) {
        console.log('initSel', val)
        if (val) {
          setTimeout(() => {
            let arr = treeToList(this.data)
            const itemData = arr.find((item) => item.id === val)
            this.onNodeClick(itemData)
          }, 300)
        }
      },
      immediate: true,
    },
    'listConfig.isSelectOneNode': {
      handler(val) {
        if (val && !this.initSel) {
          setTimeout(() => {
            if (this.data.length > 0) this.onNodeClick(this.data[0])
          }, 300)
        }
      },
      immediate: true,
    },
  },
}
</script>

<style lang="less" scoped>
@base-border-color: var(--base-border-color, #b5d9f3);
@font-color-light: var(--font-color-light, #fff);
@font-color-active: var(--font-color-active, #1990ff);
@linear-to-color: var(--linear-to-color, #1b6dd9);
@linear-right-color: var(--linear-to-color, #002150);
@padding-num: 10px;
.list-wrap {
  width: 100%;
  height: 100%;
  border: 1px solid @base-border-color;
  // display: flex;
  // flex-direction: column;
  .head-wrap {
    padding: 0 10px;
    height: 36px;
    line-height: 36px;
    width: 100%;
    position: relative;
    display: flex;
    align-items: center;
    background-image: linear-gradient(to right, @linear-to-color, @linear-right-color);
    .head-title {
      width: 100%;
      height: 100%;
      position: relative;
      font-size: 18px;
      color: @font-color-light;
      span {
        position: relative;
        font-weight: 600;
        letter-spacing: 0.1em;
      }
      i {
        padding: 2px;
        border: 1px solid @font-color-light;
        border-radius: 2px;
        font-size: 16px;
        position: absolute;
        top: 50%;
        right: 0;
        transform: translateY(-50%);
        cursor: pointer;
      }
    }
  }
  .list-content {
    // flex: 1;
    height: calc(100% - 36px);
    display: flex;
    flex-direction: column;
    padding: @padding-num;
    .search-wrap {
      padding-bottom: @padding-num;
    }
    .tree-wrap {
      flex: 1;
      overflow-y: auto;
    }
  }
  .footer-btn {
    display: flex;
    justify-content: center;
  }
}
::v-deep {
  .tree-list-icon {
    i,
    .iconfont {
      font-size: 14px !important;
    }
  }
  .el-tree-node__content {
    width: 100%;
    box-sizing: border-box;
  }
  .custom-tree-node {
    display: block;
    width: 100%;
    overflow: hidden;
  }
}
</style>
