<template>
  <div class="memo" v-show="isShow">
    <header>
      <span>{{ title }}</span>
      <!-- <span >x</span> -->
      <i class="el-icon-close" @click="close" />
    </header>
    <main>
      <el-input
        type="textarea"
        v-model="memo"
        style="height: 132px; width: 100%"
        placeholder="便签中的内容会存储在本地，这样即便你关掉了浏览器，在下次打开时，依然会读取到上一次的记录。是个非常小巧实用的本地备忘录"
      ></el-input>
    </main>
  </div>
</template>

<script>
import { getMemo } from '@/utils/sysUtils'
import { SettingMutations } from '@/store/modules/setting'
export default {
  data() {
    return {
      title: '便签',
      memo: '',
      isShow: false,
    }
  },
  mounted() {},
  methods: {
    show() {
      this.isShow = true
      this.memo = getMemo()
    },
    setMemo() {
      this.$store.commit(`setting/${SettingMutations.SET_MEMO}`, this.memo)
    },
    close() {
      this.setMemo()
      this.isShow = false
    },
  },
}
</script>

<style lang="less" scoped>
.memo {
  width: 300px;
  color: @font-color;
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    // background-image: linear-gradient(to right, @linear-bg-color-light, @linear-bg-color-dark);
    background: @background-color-layout;
    padding: 10px;
    i {
      cursor: pointer;
    }
    i:hover {
      color: @font-color-active;
    }
  }
}
::v-deep {
  .el-textarea__inner {
    height: 100%;
  }
}
</style>
