/**
 * 专门用来数据处理
 */

import { uuid } from '@/utils/commonUtil'
import { listToTree } from '@/utils/treeTool'
import { defaultCountryTypeProps, defaultNodeTypeProps, defaultNodeProps, defaultLineTypeProps, defaultLineProps } from './defaultProps'

let resourceTimer = null
let deployTimer = null
let lineTimer = null

export default {
  props: {
    // 国家类型定义
    countryTypeProps: {
      type: Object,
      default: () => ({
        ...defaultCountryTypeProps,
      }),
    },
    // 节点类型参数定义
    nodeTypeProps: {
      type: Object,
      default: () => ({
        ...defaultNodeTypeProps,
      }),
    },
    // 树节点参数定义
    nodeProps: {
      type: Object,
      default: () => ({
        ...defaultNodeProps,
      }),
    },
    // 连线类型参数定义
    lineTypeProps: {
      type: Object,
      default: () => ({
        ...defaultLineTypeProps,
      }),
    },
    // 连线参数定义
    lineProps: {
      type: Object,
      default: () => ({
        ...defaultLineProps,
      }),
    },

    // 节点类型列表
    nodeTypeList: {
      type: Array,
      default: () => [],
    },
    // 国家类别列表
    countryTypeList: {
      type: Array,
      default: () => [],
    },
    // 资源列表
    resourceDataList: {
      type: Array,
      default: () => [],
    },
    // 部署数据列表
    deployDataList: {
      type: Array,
      default: () => [],
    },
    // 连线类型列表
    lineTypeList: {
      type: Array,
      default: () => [],
    },
    // 连线列表
    lineList: {
      type: Array,
      default: () => [],
    },
  },
  computed: {
    // 刷新资源树的参数
    refreshResourceTreeParams() {
      return {
        countryTypeList: this.countryTypeList,
        nodeTypeList: this.nodeTypeList,
        resourceDataList: this.resourceDataList,
      }
    },
    // 刷新部署树的参数
    refreshDeployTreeParams() {
      return {
        countryTypeList: this.countryTypeList,
        nodeTypeList: this.nodeTypeList,
        deployDataList: this.deployDataList,
      }
    },
    // 刷新地图连线的参数
    refreshLineParams() {
      return {
        lineTypeList: this.lineTypeList,
        lineList: this.lineList,
      }
    },
    _countryTypeProps() {
      return {
        ...defaultCountryTypeProps,
        ...this.countryTypeProps,
      }
    },
    _nodeTypeProps() {
      return {
        ...defaultNodeTypeProps,
        ...this.nodeTypeProps,
      }
    },
    _nodeProps() {
      return {
        ...defaultNodeProps,
        ...this.nodeProps,
      }
    },
    _lineTypeProps() {
      return {
        ...defaultLineTypeProps,
        ...this.lineTypeProps,
      }
    },
    _lineProps() {
      return {
        ...defaultLineProps,
        ...this.lineProps,
      }
    },
  },
  watch: {
    refreshResourceTreeParams() {
      if (resourceTimer) {
        clearTimeout(resourceTimer)
        resourceTimer = null
      }
      resourceTimer = setTimeout(() => {
        this.data_initResourceTreeData()
      }, 100)
    },
    refreshDeployTreeParams() {
      if (deployTimer) {
        clearTimeout(deployTimer)
        deployTimer = null
      }
      deployTimer = setTimeout(() => {
        this.data_initDeployTreeData()
      }, 100)
    },
    refreshLineParams() {
      if (lineTimer) {
        clearTimeout(lineTimer)
        lineTimer = null
      }
      lineTimer = setTimeout(() => {
        this.data_initLineData()
      }, 100)
    },
  },
  data() {
    return {
      data_Res_CountryTypeList: [], // 资源列表
      data_Dep_CountryTypeList: [], // 部署列表
      data_lineTypeList: [],
    }
  },
  methods: {
    // 初始化资源树数据
    data_initResourceTreeData() {
      // 如果没有国家类型,则默认整一个
      const countryTypeList =
        this.countryTypeList.length === 0
          ? [
              {
                id: uuid(), // id
                name: '', // 国家类型名称
                color: '#7a4445', // 颜色
              },
            ]
          : this.countryTypeList
      const resourceDataList = this.resourceDataList.map((item) => this._transFormNodeData(item))
      this.data_Res_CountryTypeList = countryTypeList.map((countryType) => {
        const nodeTypeList = this.nodeTypeList.map((item) => this._transFormData(item, this._nodeTypeProps))
        const resource = resourceDataList
          .filter((resource) => resource.countryType === countryType.id)
          .map((resource) => ({
            ...resource,
            color: resource.color || countryType.color,
          }))
        const equipTreeData = this._filterEquipTree(listToTree([...nodeTypeList, ...resource], { idKey: 'id', pidKey: 'parentId' }))
        return {
          ...this._transFormData(countryType, this._countryTypeProps),
          nodeList: resource,
          nodeTypeList,
          equipTreeData,
        }
      })
    },
    data_initDeployTreeData() {
      // 如果没有国家类型,则默认整一个
      const countryTypeList =
        this.countryTypeList.length === 0
          ? [
              {
                id: uuid(), // id
                name: '', // 国家类型名称
                color: '#7a4445', // 颜色
              },
            ]
          : this.countryTypeList
      this.data_Dep_CountryTypeList = countryTypeList.map((countryType) => {
        const nodeTypeList = this.nodeTypeList.map((item) => this._transFormData(item, this._nodeTypeProps))
        return {
          ...this._transFormData(countryType, this._countryTypeProps),
          nodeList: [],
          nodeTypeList,
          equipTreeData: [],
        }
      })
      const editCountryType = new Map()
      this.deployDataList.forEach((item) => {
        const data = this._transFormNodeData(item)
        const pos = [data.lon || 0, data.lat || 0]
        const CountryType = this.data_Dep_CountryTypeList.find((item) => item.id === data.countryType)
        if (CountryType) {
          data.color = data.color || CountryType.color
          CountryType.nodeList.push(data)
          this.olMap.drawEvent.addNode(data, pos)
          editCountryType.set(CountryType.id, CountryType)
        }
      })
      setTimeout(() => {
        this.data_initLineData()
      }, 100)
      editCountryType.forEach((CountryType) => {
        CountryType.equipTreeData = this._filterEquipTree(
          listToTree([..._.cloneDeep(CountryType.nodeTypeList), ...CountryType.nodeList], { idKey: 'id', pidKey: 'parentId' })
        )
      })
    },
    data_initLineData() {
      this.data_lineTypeList = this.lineTypeList.map((item) => {
        const transformType = this._transFormData(item, this._lineTypeProps)
        return {
          ...transformType,
          id: transformType.id || 'default',
          _type: 'line',
        }
      })
      const lineList = this.lineList.map((item) => this._transFormData(item, this._lineProps))
      lineList.forEach((item) => {
        const lineType = this.data_lineTypeList.find((type) => type.id === item.type || (type.id === 'default' && !item.type))
        if (lineType) {
          const line = {
            ...lineType,
            ...item,
            color: item.color || lineType.color,
          }
          this.addLine(line)
        }
      })
    },
    // 将数据根据定义洗成组件需要的渲染数据
    _transFormData(data, props) {
      return Object.keys(props).reduce(
        (obj, key) => {
          obj[key] = data[props[key]] || ''
          return obj
        },
        {
          ...data,
        }
      )
    },
    // 将节点数据根据定义洗成组件需要的渲染数据
    _transFormNodeData(data) {
      return {
        ...this._transFormData(data, this._nodeProps),
        isEquip: true,
        _type: 'node',
      }
    },
    // 将节点数据转换为原始业务数据
    data_recoverNodeData(data) {
      const props = this._nodeProps
      return Object.keys(props).reduce((obj, key) => {
        obj[props[key]] = data[key] || ''
        if (props[key] !== key) {
          delete obj[key]
        }
        return obj
      }, _.cloneDeep(data))
    },
    data_recoverLineData(data) {
      const props = this._lineProps
      return Object.keys(props).reduce((obj, key) => {
        obj[props[key]] = data[key] || ''
        if (props[key] !== key) {
          delete obj[key]
        }
        return obj
      }, _.cloneDeep(data))
    },
    // 树剪枝,剪去没有装备的分类, 顺便给装备绑定上分类的部分数据
    _filterEquipTree(tree, parent = {}) {
      const result = []
      if (Array.isArray(tree)) {
        tree.forEach((item) => {
          if (parent.id) {
            item.img = item.img || parent.img || ''
            item.parentName = parent.name
            // item._parent = parent
          }
          if (item?.isEquip) {
            result.push(item)
          } else if (Array.isArray(item.children) && item.children.length > 0) {
            const newChildren = this._filterEquipTree(item.children, item)
            if (newChildren.length > 0) {
              item.children = newChildren
              result.push(item)
            }
          }
        })
      }
      return result
    },
    // 清空部署节点
    data_clearDeployNode() {
      const allData = this.olMap.getAllData()
      this.data_Dep_CountryTypeList.forEach((CountryType) => {
        CountryType.nodeList = []
        CountryType.equipTreeData = []
      })
      return allData
    },
    // 添加部署节点
    data_addDeployNode(data, pos) {
      const node = {
        ...data,
      }
      if (pos) {
        node.lon = pos[0]
        node.lat = pos[1]
      }
      const CountryType = this.data_Dep_CountryTypeList.find((item) => item.id === data.countryType)
      if (CountryType) {
        CountryType.nodeList.push(node)
        CountryType.equipTreeData = this._filterEquipTree(
          listToTree([..._.cloneDeep(CountryType.nodeTypeList), ...CountryType.nodeList], { idKey: 'id', pidKey: 'parentId' })
        )
      }
      return node
    },
    // 删除部署节点
    data_removeDeployNode(data) {
      if (!data) return
      const list = Array.isArray(data) ? data : [data]
      const editCountryType = new Map()
      list.forEach((node) => {
        const CountryType = this.data_Dep_CountryTypeList.find((item) => item.id === node.countryType)
        if (CountryType) {
          const findIndex = CountryType.nodeList.findIndex((item) => item.id === node.id)
          if (findIndex >= 0) {
            CountryType.nodeList.splice(findIndex, 1)
            editCountryType.set(CountryType.id, CountryType)
          }
        }
      })
      editCountryType.forEach((CountryType) => {
        CountryType.equipTreeData = this._filterEquipTree(
          listToTree([..._.cloneDeep(CountryType.nodeTypeList), ...CountryType.nodeList], { idKey: 'id', pidKey: 'parentId' })
        )
      })
    },
  },
}
