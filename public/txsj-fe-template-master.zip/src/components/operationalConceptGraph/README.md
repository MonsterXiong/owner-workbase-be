# 二维模型部署组件组件

## 所有数据 支持配置选项，类似于el-tree的props属性

例如

```js
  <template>
    <OperationalConceptGraph
      :nodeTypeProps="nodeTypeProps"
      :nodeTypeList="nodeTypeList"
    />
  </template>

  <script>
    export default {
      data() {
        return {
          nodeTypeProps: {
            id: 'typeId', // id
            parent: 'parent', // 父级
            name: 'typeName', // 节点类型名称
            img: 'typeImg', // 节点类型图片
          },
          nodeTypeList: [{
            typeId: 'asdasdsa',
            parent: '',
            typeName: '车辆',
            typeImg: 'static/car.png'
          }],
        }
      },
    }
  </script>
```

更多参数配置详情见dataMange.js defaultProps.js

保存数据时会洗成原本的数据,不需要二次洗数据,并且额外的属性都会返回
