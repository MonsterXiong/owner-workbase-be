const defaultCountryTypeProps = Object.freeze({
  id: 'id', // id
  name: 'name', // 国家类型名称
  color: 'color', // 颜色
})

const defaultNodeTypeProps = Object.freeze({
  id: 'id', // id
  parentId: 'parentId', // 父级
  name: 'name', // 节点类型名称
  img: 'img', // 节点类型图片
  elIcon: 'elIcon', // el-icon
})

const defaultNodeProps = Object.freeze({
  id: 'id', // id
  resourceId: 'resourceId', // 资源id
  name: 'name', // 节点名称
  countryType: 'countryType', // 国家类型ID (红方, 蓝方)
  parentId: 'parentId', // 父级
  color: 'color', // 颜色
  img: 'img', // 节点图片
  elIcon: 'elIcon', // el-icon
  lon: 'lon', // 经度
  lat: 'lat', // 纬度
  data: 'data', // 节点 原始业务数据
})

const defaultLineTypeProps = Object.freeze({
  id: 'id', // id
  name: 'name', // 连线类型名称
  color: 'color', // 颜色
})

const defaultLineProps = Object.freeze({
  id: 'id', // id
  name: 'name', // 连线名称
  from: 'from', // 开始节点ID
  to: 'to', // 结束节点ID
  type: 'type', // 类型
  color: 'color', // 颜色
})

export { defaultCountryTypeProps, defaultNodeTypeProps, defaultNodeProps, defaultLineTypeProps, defaultLineProps }
