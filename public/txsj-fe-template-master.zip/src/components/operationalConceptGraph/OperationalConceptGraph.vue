<template>
  <main class="ol-page">
    <!-- 地图实例 -->
    <div class="ol-map" ref="olMapRef" id="mapId" style="height: 100%" @drop="onMapDrop" @dragover.prevent></div>
    <!-- 浮在地图上的窗口 -->
    <panelLayout ref="panelLayoutRef" absolute class="map-panel-layout">
      <!-- 左侧 部署面板 -->
      <template slot="left-title">
        <slot name="left-title"> 部署节点 </slot>
      </template>
      <template slot="left">
        <LeftPanel ref="leftPanelRef" :countryTypeList="data_Dep_CountryTypeList" :selectDatas="selectDatas">
          <template slot="edit">
            <EditPanel :selectDatas="selectDatas">
              <template slot-scope="params">
                <slot name="edit-ext" v-bind="params"></slot>
              </template>
            </EditPanel>
          </template>
        </LeftPanel>
      </template>
      <!-- 地图上的工具栏 -->
      <MapToolBar ref="toolBarRef" :selectDatas="selectDatas" :lineTypeList="data_lineTypeList"> </MapToolBar>
      <!-- 地图下的提示栏 -->
      <div id="ol-mouse-position">
        <div style="position: absolute; left: 10px">按住ctr键,多选目标</div>
        <div class="unfoldIcon" style="position: absolute; right: 10px" @click="onChangePanelVisible">
          <i class="el-icon-sunrise-1" title="隐藏面板"></i>
        </div>
      </div>
      <!-- 右侧 资源面板 -->
      <template slot="right-title"> 资源 </template>
      <template slot="right">
        <RightPanel ref="RightPanelRef" :countryTypeList="data_Res_CountryTypeList" />
      </template>
    </panelLayout>
    <ContextMenu ref="contextMenuRef" />
    <i v-show="!panelVisible" @click="onChangePanelVisible" class="el-icon-sunny" title="打开面板"></i>
  </main>
</template>

<script>
import screenfull from 'screenfull'
import panelLayout from '@/components/panelLayout/PanelLayout'
import LeftPanel from './components/leftPanel/LeftPanel.vue'
import EditPanel from './components/leftPanel/EditPanel.vue'
import RightPanel from './components/rightPanel/RightPanel.vue'
import MapToolBar from './components/MapToolBar.vue'
import ContextMenu from './components/ContextMenu.vue'
import OlMapClass from './map/olMap'
import dataManage from './dataManage'
import tools from '@/utils/tools'
import { uuid } from '@/utils/commonUtil'

export default {
  mixins: [dataManage],
  components: {
    panelLayout,
    LeftPanel,
    EditPanel,
    RightPanel,
    MapToolBar,
    ContextMenu,
  },
  data() {
    this.olMap = new OlMapClass()
    return {
      panelVisible: true, // 面板显隐
      selectDatas: [], // 地图选择的数据
      routePath: '',
    }
  },
  provide() {
    return {
      olMap: this.olMap,
    }
  },
  computed: {
    editData() {
      return this.selectDatas[0] || {}
    },
  },
  mounted() {
    this.routePath = this.$route.path
    window.addEventListener('keydown', this.handleEvent)
    // 初始化地图
    this.initMap()
  },
  beforeDestroy() {
    window.removeEventListener('keydown', this.handleEvent)
    this.olMap.destroy()
  },
  methods: {
    // 初始化地图
    initMap() {
      this.olMap.initMap(this.$refs.olMapRef, this)
      // 设置地图选择事件
      this.olMap.mouseEvent.onSelectCallBack = ({ datas, features }) => {
        this.selectDatas = datas
        // 如果是单选需要跟左侧面板联动,
        if (Array.isArray(datas) && datas.length === 1 && datas[0]._type === 'node') {
          this.$nextTick(() => {
            // 设置树当前节点
            this.$refs.leftPanelRef.$refs.treeRef.setActiveNode(datas[0])
          })
        } else {
          this.$refs.leftPanelRef.$refs.treeRef.setActiveNode(null)
        }
      }
      // 绑定 绘制连线监听事件 添加连线
      this.olMap.drawEvent.onDrawCallBack = ({ data, from, to, event }) => {
        this.addLine({
          ...data,
          type: data.id,
          from: from,
          to: to,
          id: uuid(),
        })
      }
      // 绑定地图右键事件
      this.olMap.mouseEvent.onContextMenuCallBack = (event, data, feature) => {
        this.onCloseMapAction()
        if (!data) {
          this.$refs.contextMenuRef.hide()
          return
        }
        let menuList = [
          data._type === 'node'
            ? {
                name: '删除该节点',
                elIcon: 'el-icon-delete',
                params: data,
                action: this.removeNode,
                key: Symbol('key'),
              }
            : {
                name: '删除该关系',
                elIcon: 'el-icon-delete',
                params: data,
                action: this.removeLine,
                key: Symbol('key'),
              },
          {
            name: '批量删除所选元素',
            elIcon: 'el-icon-folder-delete',
            action: this.removeSelect,
            hide: this.selectDatas.length <= 1,
            key: Symbol('key'),
          },
        ]
        this.$refs.contextMenuRef.show(menuList)
      }
    },
    // 监听拖拽新增节点事件
    onMapDrop(event) {
      if (!this.olMap.map) return
      const pos = this.olMap.map.getCoordinateFromPixel([event.layerX, event.layerY], true)
      const data = JSON.parse(event.dataTransfer.getData('data'))
      this.addNode(data, pos)
    },
    // 添加节点
    addNode(data, pos) {
      this.data_addDeployNode(data, pos)
      this.olMap.drawEvent.addNode(data, pos)
    },
    // 添加连线
    addLine(data) {
      this.olMap.drawEvent.addLine(data)
    },
    // 选择节点
    selectNode(data) {
      this.olMap.mouseEvent.onSelectNode(data)
    },
    // 选择连线
    selectLine(data) {
      this.olMap.mouseEvent.onSelectLine(data)
    },
    // 定位节点
    fitNode(data) {
      this.selectNode(data)
      this.olMap.fitNodeById(data.id)
    },
    // 改变地图面板显隐状态
    onChangePanelVisible() {
      if (this.panelVisible) {
        document.querySelector('.map-panel-layout').style.filter = 'opacity(0)'
        setTimeout(() => {
          document.querySelector('.map-panel-layout').style.display = 'none'
          this.panelVisible = !this.panelVisible
        }, 300)
      } else {
        document.querySelector('.map-panel-layout').style.display = 'flex'
        document.querySelector('.map-panel-layout').style.filter = 'opacity(1)'
        this.panelVisible = !this.panelVisible
      }
    },
    // 设置全屏
    setFullScreen() {
      if (!screenfull.enabled) {
        this.$message('该浏览器不支持全屏功能，请使用其他浏览器')
        return
      } else {
        screenfull.toggle(this.$el)
      }
    },
    // 保存数据
    saveData() {
      const allData = this.olMap.getAllData()
      console.log('allData', {
        lines: allData.lines.map((item) => this.data_recoverLineData(item)),
        nodes: allData.nodes.map((item) => this.data_recoverNodeData(item)),
      })
      this.$emit('saveData', {
        lines: allData.lines.map((item) => this.data_recoverLineData(item)),
        nodes: allData.nodes.map((item) => this.data_recoverNodeData(item)),
      })
    },
    // 刷新
    refresh() {
      this.clear()
      this.$emit('refresh')
    },
    // 清空地图元素
    clear() {
      this.data_clearDeployNode()
      this.olMap.clear()
      this.onCloseMapAction()
    },
    // 结束 地图操作
    onCloseMapAction() {
      // 关闭连线绘制
      this.$refs.toolBarRef.refresh()
      this.olMap.closeDrawLine()
    },
    // 删除节点
    removeNode(data) {
      if (data) {
        tools.confirm('是否确定删除: ' + `${data.name}`).then(() => {
          this.olMap.drawEvent.removeNodeById(data.id)
          this.data_removeDeployNode(data)
        })
      }
    },
    // 删除线
    removeLine(data) {
      const feature = this.olMap.findLineById(data?.id)
      if (data && feature) {
        tools.confirm('是否确定删除: ' + `${data.name}`).then(() => {
          if (feature) this.olMap.drawEvent.removeLines([feature])
        })
      }
    },
    // 删除地图所选元素
    removeSelect() {
      if (this.selectDatas.length === 0) return
      const confirmText = this.selectDatas.reduce((text, data, index) => {
        text += `<br/> ${index + 1}. ${data.name} ${index === this.selectDatas.length - 1 ? '。' : '；'}`
        return text
      }, '是否确定删除:')
      tools
        .confirm(confirmText, {
          dangerouslyUseHTMLString: true,
        })
        .then(() => {
          this.data_removeDeployNode(this.selectDatas)
          this.olMap.drawEvent.removeSelect()
        })
    },
    // 键盘监听事件
    handleEvent(event) {
      if (this.$route.path !== this.routePath) return
      if (event.ctrlKey && event.keyCode === 83) {
        event.preventDefault()
        console.log('ctr + s 保存')
        this.saveData()
      } else if (event.keyCode === 46) {
        console.log('Delete 删除')
        this.removeSelect()
      }
    },
  },
}
</script>

<style scoped lang="less">
@import './variable.less';

.ol-page {
  position: relative;
  height: 100%;
  width: 100%;
  overflow: hidden;
  background-color: #182a5c;
}
#ol-mouse-position {
  background-color: @map-panel-background-color;
  color: @font-color;
  font-size: 15px;
  width: 100%;
  height: 30px;
  position: absolute;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;

  .unfoldIcon {
    visibility: visible;
    cursor: pointer;
    pointer-events: initial;
    font-size: 18px;
    filter: opacity(1);
  }
}
.el-icon-sunny {
  cursor: pointer;
  position: absolute;
  right: 10px;
  bottom: 10px;
  color: #fff;
}
::v-deep {
  .ol-drag-box {
    background-color: #b3c5db4f;
    border: 1px solid #b3c5db;
  }
  .side-header {
    background: @map-panel-title-background-color;
  }
  .panel-layout .right-side .side-nav {
    overflow: visible;
    overflow-x: visible;
  }
  .map-panel-layout {
    transition: filter 0.3s;
    .side-header {
      color: @font-color;
    }
    .el-tree {
      background: transparent;
      color: @font-color;
    }
    .el-tree__empty-text {
      color: @font-color;
    }
    .el-input__inner,
    .el-form-item__label {
      background-color: transparent;
      color: @font-color;
    }
    .splitpanes--horizontal > .splitpanes__splitter {
      position: relative;

      &::before {
        content: '';
        position: absolute;
        left: 0;
        top: -5px;
        height: 6px;
        width: 100%;
      }
    }
  }
  .equip-li {
    width: 100%;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
  }
}
</style>
