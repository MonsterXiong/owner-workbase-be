/**
 * 地图绘制相关事件类
 */
import * as ol from 'ol'
import { LineString, Polygon } from 'ol/geom.js'
import { Feature, Map, View } from 'ol'
import { transform, fromLonLat } from 'ol/proj'
import { Point } from 'ol/geom'
import { Snap, Draw, DragRotate } from 'ol/interaction'
import { setImgNodeStyle, setLineStyle } from './olMapStyle'

class olMapDrawEvent {
  constructor(map = new Map(), nodeLayer, lineLayer, olMap) {
    this.olMap = olMap
    this.map = map
    this.nodeLayer = nodeLayer
    this.lineLayer = lineLayer
    this.drawLineInteraction = null

    this.multipleTempNode = null
    this.multipleClickListener = null
    this.multiplePointermoveListener = null
    this.multipleContextmenumoveListener = null

    this._drawLineData = {} // 绘制连线的入参
    this._drawLineToFrom = [] // 绘制连线的起始结束节点
    this.onDrawCallBack = () => {}
    this.snapInteraction = null
    this._layers = {}
  }
  // 添加节点
  addNode(data, pos) {
    if (!this.nodeLayer) return
    return new Promise((res, rej) => {
      let node = new Feature({
        geometry: new Point(pos),
        rotate: true,
        data: data,
        id: data.id || '',
      })
      node._type = 'node'
      node.setId(data.id)
      setImgNodeStyle(data, node).then((style) => {
        const source = this.nodeLayer.getSource()
        source.addFeature(node)
        node.setStyle(style)
        res(node)
      })
      node.getGeometry().on('change', this._updateLinePos.bind(this))
    })
  }
  editNode(data, pos) {
    if (!this.nodeLayer) return
    const node = this.olMap.findNodeById(data.id)
    if (!node) return
    node.getGeometry().setCoordinates(fromLonLat(pos, this.olMap.mapProj))
    Object.keys(data).forEach((key) => {
      node.values_.data[key] = data[key]
    })
    setImgNodeStyle(data, node).then(() => {
      node.setStyle(node._selectStyle)
    })
  }
  // 更新线的位置
  _updateLinePos() {
    const lines = this.lineLayer.getSource().getFeatures()
    const disposeLines = []
    lines.forEach((line) => {
      const fromNode = line._fromNode
      const toNode = line._toNode
      if (fromNode && !fromNode.disposed && toNode && !toNode.disposed) {
        const points = [fromNode.getGeometry().getCoordinates(), toNode.getGeometry().getCoordinates()]
        line.getGeometry().setCoordinates(points)
      } else {
        line._fromNode = null
        line._toNode = null
        disposeLines.push(line)
      }
    })
    this.removeLines(disposeLines)
  }
  addLine(data) {
    if (!this.lineLayer) return
    const fromNode = this.olMap.findNodeById(data.from)
    const toNode = this.olMap.findNodeById(data.to)
    if (fromNode && toNode) {
      data._lineName = `${fromNode.getProperties().data.name} -> ${toNode.getProperties().data.name}`
      const points = [fromNode.getGeometry().getCoordinates(), toNode.getGeometry().getCoordinates()]
      let line = new Feature({
        geometry: new LineString(points),
        data,
        id: data.id || '',
      })
      line._type = 'line'
      line.setId(data.id)
      line.setStyle(setLineStyle(data, line))
      const source = this.lineLayer.getSource()
      source.addFeature(line)
      line._fromNode = fromNode
      line._toNode = toNode
    }
  }
  editLine(data) {
    if (!this.lineLayer) return
    const line = this.olMap.findLineById(data.id)
    if (!line) return
    Object.keys(data).forEach((key) => {
      line.values_.data[key] = data[key]
    })
    setLineStyle(data, line)
    line.setStyle(line._selectStyle)
  }
  // 删除所选实例
  removeSelect() {
    if (!this.olMap.mouseEvent.selectInteraction) return
    const arr = [...this.olMap.mouseEvent.selectInteraction.getFeatures().getArray()]
    this.removeNodes(arr)
    this.removeLines(arr)
  }
  // 根据id删除实例
  removeNodeById(id) {
    if (!this.nodeLayer) return
    const node = this.nodeLayer.getSource().getFeatureById(id)
    if (node) this.removeNodes([node])
  }
  // 删除指定实例
  removeNodes(features) {
    if (!this.nodeLayer || !Array.isArray(features) || features.length <= 0) return
    features.forEach((feature) => {
      this.nodeLayer.getSource().removeFeature(feature)
      this.olMap.mouseEvent?.selectInteraction.getFeatures().remove(feature)
      feature.dispose()
    })
    this.olMap.mouseEvent?.selectInteraction.dispatchEvent('select')
    this._updateLinePos()
  }
  removeLines(features) {
    if (!this.lineLayer || !Array.isArray(features) || features.length <= 0) return
    features.forEach((feature) => {
      this.lineLayer.getSource().removeFeature(feature)
      this.olMap.mouseEvent?.selectInteraction.getFeatures().remove(feature)
      feature.dispose()
    })
    this.olMap.mouseEvent?.selectInteraction.dispatchEvent('select')
  }
  // 初始化绘制线事件
  initDrawLineEvent() {
    this._drawLineToFrom = []
    this.drawLineInteraction = new Draw({
      type: 'LineString',
      stopClick: true,
      maxPoints: 2,
      minPoints: 2,
      condition: (event) => {
        let flag = false
        let features = this.map.getFeaturesAtPixel(event.pixel)
        const source = this.nodeLayer.getSource()
        features.some((feature) => {
          if (source.hasFeature(feature)) {
            flag = true
            this._drawLineToFrom.push(feature)
            return true
          }
        })
        return flag // 限制,必须连到节点才允许连线
      },
    })
    this.snapInteraction = new Snap({
      source: this.nodeLayer.getSource(),
      pixelTolerance: 20,
    })
    this.drawLineInteraction.on('drawend', (event) => {
      if (typeof this.onDrawCallBack === 'function') {
        if (this._drawLineToFrom.length < 2 || this._drawLineToFrom[0] === this._drawLineToFrom[1]) {
          this._drawLineToFrom = []
          return
        }
        const fromData = this._drawLineToFrom[0].getProperties().data
        const toData = this._drawLineToFrom[1].getProperties().data
        this.onDrawCallBack({
          fromData,
          toData,
          from: fromData.id,
          to: toData.id,
          data: this._drawLineData,
          event,
        })
      }
      this._drawLineToFrom = []
    })
  }
  // 允许绘制线
  allowDrawLineEvent(data) {
    this._drawLineData = data || {}
    this.forbidDrawLineEvent()
    this.map.addInteraction(this.drawLineInteraction)
    this.map.addInteraction(this.snapInteraction)
  }
  // 禁止绘制线
  forbidDrawLineEvent() {
    this.map.removeInteraction(this.drawLineInteraction)
    this.map.removeInteraction(this.snapInteraction)
  }
  // 允许点击地图批量新增节点
  async allowMultipleAddNode(data, addCallBack = () => {}, onDestroy = () => {}) {
    this.forbidMultipleAddNode()
    this.multipleTempNode = await this.addNode(data, [0, 0])
    this.multipleTempNode._isTemp = true
    // 鼠标点击事件
    this.multipleClickListener = this.map.on('click', (event) => {
      const coordinate = event.coordinate
      addCallBack(coordinate)
    }).listener
    this.multiplePointermoveListener = this.map.on('pointermove', (event) => {
      const coordinate = event.coordinate
      if (this.multipleTempNode) this.multipleTempNode.getGeometry().setCoordinates(fromLonLat(coordinate, this.olMap.mapProj))
    }).listener
    // 右键取消
    this.multipleContextmenumoveListener = this.map.on('contextmenu', () => {
      if (this.multipleTempNode) {
        this.removeNodes([this.multipleTempNode])
        this.multipleTempNode = null
      }
      onDestroy()
    }).listener
  }
  forbidMultipleAddNode() {
    if (this.multipleTempNode) {
      this.removeNodes([this.multipleTempNode])
      this.multipleTempNode = null
    }
    // 卸载鼠标点击事件
    this.multipleClickListener && this.map.un('click', this.multipleClickListener)
    this.multipleClickListener = null
    // 卸载鼠标移动事件
    this.multiplePointermoveListener && this.map.un('pointermove', this.multiplePointermoveListener)
    this.multiplePointermoveListener = null
    // 卸载鼠标右键事件
    this.multipleContextmenumoveListener && this.map.un('contextmenu', this.multipleContextmenumoveListener)
    this.multipleContextmenumoveListener = null
  }
  // 刷新
  refresh() {}
}

export default olMapDrawEvent
