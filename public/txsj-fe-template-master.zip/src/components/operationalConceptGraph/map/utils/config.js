import { toEPSG4326 } from 'ol/proj/epsg3857'
import { fromLonLat, toLonLat, get as getProjection, toUserCoordinate, setUserProjection, getUserProjection } from 'ol/proj'
import { add as addTransfrom, remove as removeTransform, get } from 'ol/proj/transforms'
import View from 'ol/View'

//地图类型默认的中心点
export const MapCenterPosition = Object.freeze({
  // 默认中心点 中国
  LONGITUDE: 116.435314,
  LATITUDE: 30.960521,
  HEIGHT: 5000000.0,
  // destination: new Cesium.Cartesian3.fromDegrees(116.435314, 30.960521, 5000000.0),
})

// 坐标系
export const CoordinateSystemTypes = {
  Geographic: 'EPSG:4326',
  WebMercator: 'EPSG:3857',
}

// 地图默认设置
export const InitMapSetConfig = Object.freeze({
  zoom: 5,
  center: [MapCenterPosition.LONGITUDE, MapCenterPosition.LATITUDE],
  rotation: 1,
})

export function fixTo4326(input, optOutput, optDimension) {
  const output = toEPSG4326(input, optOutput, optDimension)
  const { length } = output
  const dimension = optDimension > 1 ? optDimension : 2
  for (let i = 0; i < length; i += dimension) {
    output[i] %= 360
    if (output[i] < -180) {
      output[i] += 360
    }
    if (output[i] > 180) {
      output[i] -= 360
    }
  }
  return output
}
export function limit4326(input, optOutput, optDimension) {
  let output = optOutput || input
  if (!optOutput) {
    return output
  }
  const dimension = optDimension > 1 ? optDimension : 2
  for (let i = 0; i < dimension; i += 1) {
    output[i] %= 360
    if (output[i] < -180) {
      output[i] += 360
    }
    if (output[i] > 180) {
      output[i] -= 360
    }
  }
  return output
}

// 矫正坐标系不让其到外面
export function replaceProj(map) {
  if (!map) return
  const epsg3857 = getProjection('EPSG:3857')
  const epsg4326 = getProjection('EPSG:4326')
  removeTransform(epsg3857, epsg4326)
  removeTransform(epsg4326, epsg4326)
  addTransfrom(epsg3857, epsg4326, fixTo4326)
  addTransfrom(epsg4326, epsg4326, limit4326)

  map.getView()._getStatus = function () {
    const view = map.getView()
    const pos = [...view.getCenter()]
    return {
      center: limit4326(pos, pos, pos.length),
      zoom: view.getZoom(),
    }
  }

  map._orin_getCoordinateFromPixel = map.getCoordinateFromPixel
  // 矫正坐标系 防止超出范围
  map.getCoordinateFromPixel = (pixel, flag) => {
    let loc = map._orin_getCoordinateFromPixel(pixel)
    if (loc && flag) {
      const loc2 = toLonLat(loc, map.getView().getProjection())
      loc2[0] = loc2[0] % 360
      if (loc2[0] < -180) {
        loc2[0] += 360
      }
      if (loc2[0] > 180) {
        loc2[0] -= 360
      }
      loc = fromLonLat(loc2, map.getView().getProjection())
    }
    return loc
  }
}

// 连线箭头样式
export const LineArrowType = Object.freeze({
  SINGLEARROW: 'singleArrow',
  DOUBLEARROW: 'doubleArrow',
  NONEARROW: 'noneArrow',
})

export const lineArrTypeList = Object.freeze([
  {
    label: '双向箭头',
    value: LineArrowType.DOUBLEARROW,
  },
  {
    label: '单向箭头',
    value: LineArrowType.SINGLEARROW,
  },
  {
    label: '无箭头',
    value: LineArrowType.NONEARROW,
  },
])

export const EdefineType = Object.freeze({
  RELATION: 'relation', // 连线
  EQUIPCODE: 'Equip', // 装备定义code  metaEobjectModelList -> edefineCode === 'Equip'
  REDCOUNTRY: 'China', // 红方
  BLUECOUNTRY: 'Other', // 蓝方

  EQUIPTYPE: 'equipType', // 装备类型
  EQUIPRESOURCE: 'equipResource', // 装备资源
})

export const CountryColor = Object.freeze({
  [EdefineType.REDCOUNTRY]: '#e2555a',
  [EdefineType.BLUECOUNTRY]: '#3e99fa',
})

export const CountryTypeList = Object.freeze([
  {
    code: EdefineType.REDCOUNTRY,
    name: '红方',
    color: CountryColor[EdefineType.REDCOUNTRY],
  },
  {
    code: EdefineType.BLUECOUNTRY,
    name: '蓝方',
    color: CountryColor[EdefineType.BLUECOUNTRY],
  },
])

export const TabTypeCode = Object.freeze({
  PROPERTY: 'property',
  STYLE: 'style',
})

const config = {
  baseUrl: process.env.VUE_APP_URL,
  baseOlMapTileData: process.env.VUE_APP_BASE_OL_MAP_TILE_DATA
    ? JSON.parse(process.env.VUE_APP_BASE_OL_MAP_TILE_DATA)
    : {
        url: 'http://192.168.2.204:5005/wmts/geearth/{selfZ}/{x}/{y}.png',
        projection: 'EPSG:4326',
      }, // 地图配置
}

try {
  const baseConfigData = require('@/utils/config') || {}
  Object.keys(baseConfigData.default).forEach((key) => {
    config[key] = baseConfigData.default[key]
  })
} catch (err) {
  console.error('无法读取系统配置 @/utils/config')
} finally {
  console.log('config', config)
}

export default config
