import { fromLonLat, toLonLat, get as getProjection } from 'ol/proj'
import { Map, View, Feature } from 'ol'
import { Tile as TileLayer, Vector as VectorLayer } from 'ol/layer'
import { OSM, XYZ, Vector as VectorSource } from 'ol/source'
import { defaults, MousePosition } from 'ol/control'
import { createStringXY } from 'ol/coordinate'

import configData from './utils/config'
import { Message } from 'element-ui'
import ElementResizeDetectorMaker from 'element-resize-detector'

import { replaceProj, CoordinateSystemTypes, InitMapSetConfig } from './utils/config'
import olMapMouseEvent from './utils/olMapMouseEvent'
import olMapDrawEvent from './utils/olMapDrawEvent'

class OlMapClass {
  constructor() {
    this.vueRef = null // 挂载地图的vue实例
    this.map = null // 地图实例
    this.mapProj = ''
    this.mousePosition = null
    this._layerCollection = {} // 所有图层集合
    this.localLayer = null
    this.nodeLayer = null // 默认图层, 图片+文字形式
    this.lineLayer = null // 默认图层, 连线
    this.drawEvent = null // 绘制事件
    this.mouseEvent = null // 移动事件

    this.el = null
    this.resizeListen = null
    this.timerInterval = null
  }
  // 初始化地图
  initMap(id, ref) {
    if (!id) return
    if (this.map) {
      this.map.dispose() // 防止多次初始化地图
      this.map = null
    }
    this.el = id
    this.vueRef = ref
    // 初始化图层
    let baseMapTileData = configData.baseOlMapTileData
    if (!baseMapTileData) {
      Message.warning('无法读取到地图配置, 请设置config文件-> baseOlMapTileData')
    }
    const isTileMapService = baseMapTileData?.isTileMapService
    this.localLayer = new TileLayer({
      source: new XYZ({
        url: isTileMapService ? baseMapTileData?.url : null,
        tileUrlFunction: isTileMapService
          ? null
          : function (tilecoord) {
              const selfZ = tilecoord[0] - 1
              const x = tilecoord[1]
              const y = tilecoord[2]
              const z = tilecoord[0]
              let url = baseMapTileData?.url
              url = url.replace('{z}', z).replace('{y}', y).replace('{x}', x).replace('{selfZ}', selfZ)
              return url
            },
        projection: baseMapTileData?.projection ? baseMapTileData?.projection : CoordinateSystemTypes.Geographic,
        crossOrigin: 'anonymous',
      }),
    })
    this.nodeLayer = new VectorLayer({
      zIndex: 2,
      source: new VectorSource(),
    })
    this.lineLayer = new VectorLayer({
      zIndex: 1,
      source: new VectorSource(),
    })
    // 初始化地图实例
    const locStatus = JSON.parse(localStorage.getItem(this.vueRef.$route.name + '_MapStatus') || '{}')
    this.map = new Map({
      target: id,
      layers: [this.localLayer, this.nodeLayer, this.lineLayer],
      view: new View({
        center: locStatus?.center || InitMapSetConfig.center,
        zoom: locStatus?.zoom || InitMapSetConfig.zoom,
        constrainResolution: true,
        rotation: InitMapSetConfig.rotation * (Math.PI / 180),
        minZoom: 3, // 最小缩放级别
        maxZoom: 15, // 最大缩放级别
        projection: baseMapTileData.projection ? baseMapTileData.projection : CoordinateSystemTypes.WebMercator,
      }),
      controls: defaults({
        // 设置地图控件，默认的三个控件都不显示
        attribution: false,
        zoom: false,
        rotate: false,
      }),
    })
    this.mapProj = this.map.getView().getProjection()
    // 修正坐标系,防止超出范围
    replaceProj(this.map)
    // 初始化地图事件
    this.drawEvent = new olMapDrawEvent(this.map, this.nodeLayer, this.lineLayer, this)
    this.drawEvent.initDrawLineEvent() // 初始化绘制线条事件
    this.mouseEvent = new olMapMouseEvent(this.map, this.nodeLayer, this.lineLayer, this)
    this.mouseEvent.initDefaultEvent() // 初始化默认事件(鼠标移动,鼠标右键)
    this.mouseEvent.initTranslateEvent() // 初始化拖拽事件
    this.mouseEvent.initSelectEvent() // 初始化选择事件
    this.mouseEvent.initDrawBoxSelectEvent() // 初始化框选事件
    // 显示当前鼠标所在位置
    setTimeout(() => {
      if (document.getElementById('ol-mouse-position')) {
        this.mousePosition = new MousePosition({
          coordinateFormat: createStringXY(4), //坐标格式
          projection: CoordinateSystemTypes.Geographic, //地图投影坐标系
          className: `custom-mouse-position 11`, //坐标信息显示样式,cN:自定义类名
          target: document.getElementById('ol-mouse-position'), // 显示鼠标位置信息的目标容器
          undefinedHTML: '不在范围内', //未定义坐标的标记
        })
        this.map.addControl(this.mousePosition)
      }
    }, 0)
    // 监听窗口变化,使地图自适应填充
    this.resizeListen = ElementResizeDetectorMaker()
    this.resizeListen.listenTo(id, () => {
      if (this.map) this.map.updateSize()
    })
    // 每五秒保存一次地图状态 (地图中心点, 层级) 日后也可改成保存才触发
    this.timerInterval = setInterval(() => {
      this.saveMapStatus()
    }, 1000 * 5)
  }
  // 提取地图元素的数据
  getFeatureData(feature) {
    if (feature) {
      const position = toLonLat(feature.getGeometry().getCoordinates(), this.mapProj)
      feature.values_.data.lon = position[0]
      feature.values_.data.lat = position[1]
      return {
        ...feature.values_.data,
        position,
      }
    }
  }
  // 获取所有地图元素数据
  getAllData() {
    const nodes = this.nodeLayer
      .getSource()
      .getFeatures()
      .map((feature) => this.getFeatureData(feature))
    const lines = this.lineLayer
      .getSource()
      .getFeatures()
      .map((feature) => feature.getProperties().data)
    return {
      nodes,
      lines,
    }
  }
  // 根据ID获取指定地图元素的data数据
  getDataById(id) {
    const node = this.findNodeById(id)
    const line = this.findLineById(id)
    const feature = node || line
    return this.getFeatureData(feature)
  }
  findNodeById(id) {
    return this.nodeLayer.getSource().getFeatureById(id)
  }
  findLineById(id) {
    return this.lineLayer.getSource().getFeatureById(id)
  }
  // 根据ID定位节点
  fitNodeById(id) {
    const feature = this.findNodeById(id)
    if (feature) {
      const extend = feature.getGeometry()
      this.map.getView().fit(extend, {
        maxZoom: 6,
      })
    }
  }
  // 刷新(清空)
  clear() {
    this.mouseEvent.refresh()
    this.drawEvent.refresh()
    this.nodeLayer.getSource().refresh()
    this.lineLayer.getSource().refresh()

    this.initMapEvent()
  }
  // 保存地图当前状态
  saveMapStatus() {
    if (this.vueRef && this.map) {
      const view = this.map.getView()
      localStorage.setItem(this.vueRef.$route.name + '_MapStatus', JSON.stringify(view._getStatus()))
    }
  }
  /**
   * @description 打开绘制连线事件
   * @param {data} 连线的业务数据
   * 屏蔽 节点选择和节点拖拽以及默认事件
   */
  openDrawLine(data) {
    this.drawEvent.allowDrawLineEvent(data)

    this.mouseEvent.refresh()
    this.drawEvent.forbidMultipleAddNode()
    this.mouseEvent.forbidTranslateEvent()
    this.mouseEvent.forbidSelectEvent()
    this.mouseEvent.forbidDrawBoxSelectEvent()
  }
  // 关闭绘制模式 恢复 节点选择功能和节点拖拽功能 以及默认事件
  closeDrawLine() {
    this.drawEvent.forbidDrawLineEvent()

    this.mouseEvent.allowTranslateEvent()
    this.mouseEvent.allowSelectEvent()
    this.mouseEvent.allowDrawBoxSelectEvent()
  }
  // 打开批量新增节点
  openMultipleAddNode(data, addCallBack = () => {}) {
    this.drawEvent.allowMultipleAddNode(data, addCallBack, () => {
      this.closeMultipleAddNode()
    })

    this.drawEvent.forbidDrawLineEvent()
    this.mouseEvent.refresh()
    this.mouseEvent.forbidTranslateEvent()
    this.mouseEvent.forbidSelectEvent()
    this.mouseEvent.forbidDrawBoxSelectEvent()
  }
  // 关闭批量新增节点
  closeMultipleAddNode() {
    this.drawEvent.forbidMultipleAddNode()

    this.mouseEvent.allowTranslateEvent()
    this.mouseEvent.allowSelectEvent()
    this.mouseEvent.allowDrawBoxSelectEvent()
  }
  initMapEvent() {
    this.drawEvent.forbidDrawLineEvent()
    this.drawEvent.forbidMultipleAddNode()

    this.mouseEvent.allowTranslateEvent()
    this.mouseEvent.allowSelectEvent()
    this.mouseEvent.allowDrawBoxSelectEvent()
  }
  destroy() {
    this.drawEvent.forbidDrawLineEvent()
    this.drawEvent.forbidMultipleAddNode()
    this.mouseEvent.refresh()
    this.mouseEvent.forbidTranslateEvent()
    this.mouseEvent.forbidSelectEvent()
    this.mouseEvent.forbidDrawBoxSelectEvent()
    if (this.map) {
      this.map.dispose() // 防止多次初始化地图
      this.map = null
    }
    if (this.resizeListen) {
      this.resizeListen.uninstall(this.$el)
      this.resizeListen = null
    }
    if (this.timerInterval) {
      clearInterval(this.timerInterval)
      this.timerInterval = null
    }
  }
}

// const olMap = new OlMapClass()

export default OlMapClass
