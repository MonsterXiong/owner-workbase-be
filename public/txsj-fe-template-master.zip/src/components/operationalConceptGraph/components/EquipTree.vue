<template>
  <main class="redBlueTree">
    <ul class="tree-header" v-show="countryTypeList.length > 1">
      <li
        v-for="item in countryTypeList"
        :style="item.id === activeCountryType ? `color: ${item.color}` : ''"
        :class="{ active: item.id === activeCountryType }"
        @click="setActiveCountryType(item.id)"
        :key="item.id"
      >
        {{ item.name }}
      </li>
    </ul>
    <div class="search-line">
      <el-input size="mini" placeholder="输入关键字搜索" @keyup.enter.native="onFilterTree" v-model="filterTreeText"></el-input>
      <el-button type="primary" size="mini" @click="onFilterTree">搜索</el-button>
    </div>
    <el-tree
      class="tree-content"
      ref="treeRef"
      :data="treeData"
      node-key="id"
      icon-class="el-icon-arrow-right"
      :highlight-current="false"
      :props="treeProps"
      :filter-node-method="_filterNode"
      default-expand-all
    >
      <template slot-scope="{ data }">
        <slot name="treeNode" :data="data"></slot>
      </template>
    </el-tree>
    <slot></slot>
  </main>
</template>

<script>
export default {
  props: {
    countryTypeList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      treeProps: {
        children: 'children',
        label: 'name',
      },
      activeCountryType: '', // 当前显示的国家类型
      filterTreeText: '', // 用来过滤树
    }
  },
  watch: {
    countryTypeList: {
      handler() {
        if (this.countryTypeList.length > 0 && (this.activeCountryType || !this.countryTypeList.find((item) => item.id === this.activeCountryType))) {
          this.activeCountryType = this.countryTypeList[0].id
        }
      },
      immediate: true,
    },
  },
  computed: {
    // 这里判定 显示红方 还是 蓝方
    treeData() {
      const countryType = this.countryTypeList.find((item) => item.id === this.activeCountryType)
      if (countryType && Array.isArray(countryType.equipTreeData)) {
        return countryType.equipTreeData
      }
      return []
    },
  },
  methods: {
    // 设置显示哪个国家类型的装备
    setActiveCountryType(id) {
      this.activeCountryType = id
    },
    // 设置当前选中节点
    setActiveNode(data) {
      if (data) {
        this.setActiveCountryType(data.countryType)
        this.$nextTick(() => {
          this.$refs.treeRef.setCurrentKey(data.id)
          this.$nextTick(() => {
            const curNode = this.$el.querySelector('.is-current')
            if (curNode) {
              curNode.scrollIntoView(false)
            }
          })
        })
      } else {
        this.$refs.treeRef.setCurrentKey(null)
      }
    },
    // 根据关键字过滤树节点
    onFilterTree() {
      this.$refs.treeRef.filter(this.filterTreeText)
    },
    // elTree过滤节点函数
    _filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
  },
}
</script>

<style scoped lang="less">
@import '../variable.less';
.redBlueTree {
  position: relative;
  height: 100%;

  .tree-header {
    display: flex;
    border-bottom: 1px solid @base-border-color;
    > li {
      min-width: max-content;
      padding: 4px 0;
      font-size: 16px;
      flex: 1;
      text-align: center;
      cursor: pointer;
      &.active {
        font-weight: bold;
        background-color: @map-panel-tab-active-background-color;
      }
    }
  }

  .search-line {
    padding: 3px;
    display: flex;
    gap: 3px;
  }

  .tree-content {
    height: calc(100% - 30px - 34px);
    overflow-y: auto;
  }
}
</style>
