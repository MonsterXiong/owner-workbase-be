<template>
  <EquipTree ref="treeRef" :countryTypeList="countryTypeList">
    <template slot="treeNode" slot-scope="{ data }">
      <div class="equip-li" :title="data.name" v-if="data.children">
        <img v-if="data.img" style="vertical-align: middle; margin-bottom: 2px" width="16px" height="16px" :src="data.img" />
        <i v-else :class="data.elIcon || 'el-icon-folder'"></i>
        {{ data.name }}
      </div>
      <div class="equip-li" draggable @dragstart="onDragStart($event, data)" @contextmenu="onResourceContextMenu(data)" :title="data.name" v-else>
        <i class="el-icon-document"></i> {{ data.name }}
      </div>
    </template>
    <div class="multiple" v-show="multipleAddShow">
      <div class="multiple-title">批量部署</div>
      <el-form size="mini" :model="addDataForm" :rules="addDataFormRules" label-width="auto">
        <el-form-item label="资源" style="margin-bottom: 12px">
          {{ resourceName }}
        </el-form-item>
        <el-form-item prop="name" label="名称">
          <el-input v-model="addDataForm.name"></el-input>
        </el-form-item>
        <el-row>
          <el-col :span="12">
            <el-form-item prop="lon" label="经度">
              <el-input-number v-model="addDataForm.lon" controls-position="right" style="width: 100%" :step="0.1" :max="180" :min="-180"></el-input-number>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="lat" label="纬度">
              <el-input-number v-model="addDataForm.lat" controls-position="right" style="width: 100%" :step="0.1" :max="90" :min="-90"></el-input-number>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <footer>
        <el-button size="mini" @click="onCancelMultiple">取消</el-button>
        <el-button @click="handleMapAdd" icon="el-icon-thumb" size="mini" type="primary" plain>点击地图新增</el-button>
        <el-button @click="handleDataAdd" icon="el-icon-edit-outline" size="mini" type="primary">根据坐标新增</el-button>
      </footer>
    </div>
  </EquipTree>
</template>

<script>
import EquipTree from '../EquipTree'
import { uuid } from '@/utils/commonUtil'

export default {
  inject: ['olMap'],
  props: {
    countryTypeList: {
      type: Array,
      default: () => [],
    },
  },
  components: {
    EquipTree,
  },
  data() {
    return {
      resourceName: '',
      addDataForm: {
        name: '',
        lon: 0,
        lat: 0,
      },
      multipleAddShow: false,
      addDataFormRules: {
        name: [{ required: true, message: '请输入名称', trigger: 'blur' }],
      },
    }
  },
  methods: {
    // 拖拽元素到地图上
    onDragStart(event, data) {
      event.dataTransfer.setData(
        'data',
        JSON.stringify({
          ...data,
          id: uuid(), // 新增数据的id
        })
      )
    },
    // 资源右键事件
    onResourceContextMenu(data) {
      this.olMap.vueRef.$refs.contextMenuRef.show([
        {
          name: '批量新增',
          elIcon: 'el-icon-add-location',
          params: data,
          action: this.multipleAdd,
          key: Symbol('key'),
        },
      ])
    },
    // 点击地图新增
    handleMapAdd() {
      this.olMap.openMultipleAddNode(this.addDataForm, (pos) => {
        this.addDataForm.lon = pos[0]
        this.addDataForm.lat = pos[1]
        this.olMap.vueRef.addNode(
          {
            ...this.addDataForm,
            id: uuid(),
          },
          pos
        )
      })
    },
    // 根据数据新增
    handleDataAdd() {
      this.olMap.vueRef.addNode(
        {
          ...this.addDataForm,
          id: uuid(),
        },
        [this.addDataForm.lon, this.addDataForm.lat]
      )
    },
    multipleAdd(data) {
      this.resourceName = data.name
      this.addDataForm = {
        ...data,
      }
      this.olMap.vueRef.$refs.panelLayoutRef.onCollapseRight()
      this.multipleAddShow = true
    },
    onCancelMultiple() {
      this.olMap.vueRef.$refs.panelLayoutRef.onUnfoldRight()
      this.olMap.closeMultipleAddNode()
      this.multipleAddShow = false
    },
  },
}
</script>

<style scoped lang="less">
@import '../../variable.less';

.multiple {
  position: absolute;
  width: 400px;
  top: 60px;
  left: -5px;
  transform: translateX(-100%);

  border-radius: 5px;
  padding: 8px;
  border: 1px solid @base-border-color;
  background-color: @map-panel-background-color;

  .multiple-title {
    height: 20px;
    line-height: 15px;
    font-size: 14px;
    font-weight: 500;
    padding-bottom: 5px;
    border-bottom: 1.5px solid @base-border-color;
    margin-bottom: 10px;
  }

  footer {
    text-align: end;
  }
}

::v-deep {
  .el-tree-node:focus > .el-tree-node__content,
  .el-tree-node.is-current > .el-tree-node__content {
    background-color: transparent;
  }
  .el-tree-node__content:hover {
    background-color: #288efc73 !important;
  }
}
</style>
