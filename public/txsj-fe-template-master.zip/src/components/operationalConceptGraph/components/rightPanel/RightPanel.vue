<template>
  <EquipTree ref="treeRef" :countryTypeList="countryTypeList">
    <template slot="treeNode" slot-scope="{ data }">
      <div class="equip-li" :title="data.name" v-if="data.children">
        <img v-if="data.img" style="vertical-align: middle; margin-bottom: 2px" width="16px" height="16px" :src="data.img" />
        <i v-else :class="data.elIcon || 'el-icon-folder'"></i>
        {{ data.name }}
      </div>
      <div class="equip-li" draggable @dragstart="onDragStart($event, data)" :title="data.name" v-else><i class="el-icon-document"></i> {{ data.name }}</div>
    </template>
  </EquipTree>
</template>

<script>
import EquipTree from '../EquipTree'
import { uuid } from '@/utils/commonUtil'

export default {
  props: {
    countryTypeList: {
      type: Array,
      default: () => [],
    },
  },
  components: {
    EquipTree,
  },
  data() {
    return {}
  },
  methods: {
    // 拖拽元素到地图上
    onDragStart(event, data) {
      event.dataTransfer.setData(
        'data',
        JSON.stringify({
          ...data,
          id: uuid(), // 新增数据的id
        })
      )
    },
  },
}
</script>

<style scoped lang="less">
::v-deep {
  .el-tree-node:focus > .el-tree-node__content,
  .el-tree-node.is-current > .el-tree-node__content {
    background-color: transparent;
  }
  .el-tree-node__content:hover {
    background-color: #288efc73 !important;
  }
}
</style>
