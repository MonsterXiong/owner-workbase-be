<template>
  <div class="tool-bar">
    <div class="tool-bar-btn" @click="handleSaveData"><i class="el-icon-circle-check"></i> 保存</div>
    <div class="tool-bar-btn" @click="handleRefresh"><i class="el-icon-refresh"></i> 刷新</div>
    <div class="tool-bar-btn" @click="handleClear"><i class="el-icon-brush"></i> 清空</div>
    <div :class="{ disable: selectDatas.length === 0 }" class="tool-bar-btn" @click="handleRemoveSelect"><i class="el-icon-delete"></i> 删除</div>
    <i class="el-icon-full-screen" @click="setFullScreen" title="全屏"></i>
    <div class="select-line">
      <div class="tool-bar-btn" :class="{ active: item.id === activeLineType }" v-for="item in lineTypeList" :key="item.id" @click="onDrawLine(item)">
        <i class="el-icon-link" :style="`color: ${item.color}`"></i>
        {{ item.name }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  inject: ['olMap'],
  props: {
    selectDatas: {
      type: Array,
      default: () => [],
    },
    lineTypeList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      activeLineType: '',
    }
  },

  methods: {
    handleSaveData() {
      if (this.olMap.vueRef) {
        this.olMap.vueRef.saveData()
      }
    },
    handleRefresh() {
      if (this.olMap.vueRef) {
        this.olMap.vueRef.refresh()
      }
    },
    handleClear() {
      if (this.olMap.vueRef) {
        this.olMap.vueRef.clear()
      }
    },
    handleRemoveSelect() {
      if (this.olMap.vueRef && this.selectDatas.length !== 0) {
        this.olMap.vueRef.removeSelect()
      }
    },
    setFullScreen() {
      if (this.olMap.vueRef) {
        this.olMap.vueRef.setFullScreen()
      }
    },
    onDrawLine(item) {
      if (this.activeLineType === item.id) {
        this.activeLineType = ''
        this.olMap.closeDrawLine()
      } else {
        this.activeLineType = item.id
        this.olMap.openDrawLine(item)
      }
    },
    refresh() {
      this.activeLineType = ''
    },
  },
}
</script>

<style scoped lang="less">
@import '../variable.less';
.tool-bar {
  box-sizing: border-box;
  background: @map-panel-background-color;
  color: @font-color;
  pointer-events: initial;
  border-bottom: 1px solid @base-border-color;
  height: 31px;
  display: flex;
  align-items: center;
  padding: 0 30px 0 10px;
  font-size: 16px;
  position: relative;

  .el-icon-full-screen {
    position: absolute;
    right: 6px;
    cursor: pointer;
  }

  .tool-bar-btn {
    cursor: pointer;
    padding: 3px 5px;
    border-radius: 6px;

    &:not(:first-child) {
      margin-left: 2px;
    }
    &.disable {
      background: transparent !important;
      color: #cbd5e4 !important;
      cursor: not-allowed;
    }
    &.active {
      color: @font-color-active;
      background: #fff;
    }
    &:hover {
      color: @font-color-active;
      background: #fff;
    }
  }

  .select-line {
    margin-left: 6px;
    padding: 0px 6px;
    height: 100%;
    display: flex;
    align-items: center;
    border-left: 1px solid @base-border-color;
  }
}
</style>
