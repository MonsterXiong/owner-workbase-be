<template>
  <div class="edit-panel">
    <header class="title">
      {{ editData ? '属性编辑' : '所选元素' }}
    </header>
    <el-tree v-if="!editData" class="select-tree" default-expand-all @node-click="hanldeEditNode" :data="treeData">
      <template slot-scope="{ data }">
        <span>
          <img v-if="data.img" style="vertical-align: middle; margin-bottom: 2px" width="16px" height="16px" :src="data.img" />
          <i v-else-if="data.elIcon" :class="data.elIcon"></i>
          {{ data.name }}
          <div class="colorCircle" v-show="data.color" :style="`background-color: ${data.color}`"></div>
        </span>
      </template>
    </el-tree>
    <template v-else>
      <el-form class="edit-form" size="small" label-width="auto" :model="editData" :rules="formRules" ref="ruleForm">
        <el-form-item label="名称" prop="name">
          <el-input v-model="editData.name" @change="onChangeNode"></el-input>
        </el-form-item>
        <template v-if="editData._type === 'node'">
          <el-form-item label="所属阵营" prop="countryType">
            <el-select @change="onChangeCountryType" v-model="editData.countryType" style="width: 100%" placeholder="请选择阵营">
              <el-option v-for="item in countryTypeList" :label="item.name" :value="item.id" :key="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="经度" prop="lon">
            <el-input-number @change="onChangeNode" style="width: 100%" :step="0.1" v-model="editData.lon" :max="180" :min="-180"></el-input-number>
          </el-form-item>
          <el-form-item label="纬度" prop="lat">
            <el-input-number @change="onChangeNode" style="width: 100%" :step="0.1" v-model="editData.lat" :max="90" :min="-90"></el-input-number>
          </el-form-item>
        </template>
        <template v-if="editData._type === 'line'">
          <el-form-item label="开始节点" prop="fromName">
            <el-input v-model="editData.fromName" disabled></el-input>
          </el-form-item>
          <el-form-item label="结束节点" prop="toName">
            <el-input v-model="editData.toName" disabled></el-input>
          </el-form-item>
        </template>
        <slot :formData="editData" :formRules="formRules"></slot>
      </el-form>
      <footer class="edit-footer">
        <el-button size="small" @click="onCancel">取 消</el-button>
        <el-button size="small" type="primary" @click="onEdit">确 定</el-button>
      </footer>
    </template>
  </div>
</template>

<script>
export default {
  inject: ['olMap'],
  props: {
    selectDatas: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    this._old_data = null
    this._listener = () => {} // 监听节点变化的事件 用来方便卸载
    return {
      formRules: {},
      countryTypeList: [],
      editData: null,
      treeData: [],
    }
  },
  watch: {
    selectDatas: {
      handler() {
        if (this.selectDatas.length === 0 || this.selectDatas.length > 1) {
          this.editData = null
        } else if (this.selectDatas.length === 1) {
          this.editData = this.selectDatas[0]
        }
        this.treeData = [
          {
            id: 'node',
            name: '节点',
            elIcon: 'el-icon-picture-outline-round',
            children: this.selectDatas.filter((item) => item._type === 'node'),
          },
          {
            id: 'line',
            name: '关系',
            elIcon: 'el-icon-link',
            children: this.selectDatas.filter((item) => item._type === 'line'),
          },
        ]
      },
      immediate: true,
    },
    editData: {
      handler() {
        this.initForm()
      },
      immediate: true,
    },
  },
  beforeDestroy() {
    this.onCancel()
    this._unListener()
  },
  methods: {
    hanldeEditNode(data) {
      this.editData = data
    },
    initForm() {
      this._unListener()
      if (!this.editData) return
      this._old_data = _.cloneDeep(this.editData)
      if (this.editData._type === 'node') {
        if (this.olMap.vueRef) {
          this.countryTypeList = this.olMap.vueRef.data_Res_CountryTypeList.map((item) => ({
            id: item.id,
            name: item.name,
            color: item.color,
          }))
        }
        this._editFeature = this.olMap.findNodeById(this.editData.id)
        if (!this._editFeature) return
        const coordinates = this._editFeature.getGeometry().getCoordinates()
        this.editData.lon = coordinates[0]
        this.editData.lat = coordinates[1]
        // 监听地图要素坐标变更事件
        this._listener = this._editFeature.getGeometry().on('change', (event) => {
          const coordinates = event.target.getCoordinates()
          this.editData.lon = coordinates[0]
          this.editData.lat = coordinates[1]
        }).listener
      } else if (this.editData._type === 'line') {
        const fromData = this.olMap.getDataById(this.editData.from)
        const toData = this.olMap.getDataById(this.editData.to)
        this.editData.fromName = fromData.name
        this.editData.toName = toData.name
      }
    },
    onChangeCountryType() {
      const countryType = this.countryTypeList.find((item) => item.id === this.editData.countryType)
      if (countryType) {
        this.editData.color = countryType.color
        this.onChangeNode()
      }
    },
    // 实时变更节点
    onChangeNode() {
      this.olMap.drawEvent.editNode(this.editData, [this.editData.lon, this.editData.lat])
    },
    // 卸载监听
    _unListener() {
      if (this._editFeature) {
        this._editFeature.getGeometry().un('change', this._listener)
      }
      this._editFeature = null
      this._listener = () => {}
    },
    onCancel() {
      if (this._old_data) {
        this.olMap.drawEvent.editNode(this._old_data, [this._old_data.lon, this._old_data.lat])
      }
      this.editData = null
    },
    onEdit() {
      if (this.editData.countryType !== this._old_data.countryType) {
        this.olMap.vueRef.data_removeDeployNode(this._old_data)
        this.olMap.vueRef.data_addDeployNode(this.editData)
      }
      this._old_data = _.cloneDeep(this.editData)
    },
  },
}
</script>

<style scoped lang="less">
@import '../../variable.less';
.edit-panel {
  height: 100%;
  .title {
    background: #3a8ceaad;
    line-height: 30px;
    border-top: 1px solid @base-border-color;
    // border-bottom: 1px solid @base-border-color;
    text-align: center;
  }
  .select-tree {
    overflow-y: auto;
    height: calc(100% - 33px);
  }
  .edit-form {
    padding: 10px;
    overflow-y: auto;
    height: calc(100% - 75px);
  }
  .edit-footer {
    padding: 5px 10px;
    text-align: end;
  }
}

.colorCircle {
  display: inline-block;
  vertical-align: middle;
  height: 4px;
  width: 4px;
  border-radius: 50%;
}
</style>
