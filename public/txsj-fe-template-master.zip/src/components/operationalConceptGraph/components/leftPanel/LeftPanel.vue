<template>
  <Splitpanes horizontal>
    <Pane>
      <EquipTree ref="treeRef" :countryTypeList="countryTypeList">
        <template slot="treeNode" slot-scope="{ data }">
          <div class="equip-li" :title="data.name" v-if="data.children">
            <img v-if="data.img" style="vertical-align: middle; margin-bottom: 2px" width="16px" height="16px" :src="data.img" />
            <i v-else :class="data.elIcon || 'el-icon-folder'"></i>
            {{ data.name }}
          </div>
          <div
            class="equip-li"
            :title="data.name"
            @click="onTreeNodeClick(data)"
            @dblclick="onTreeNodeDbClick(data)"
            @contextmenu="onNodeContextMenu(data)"
            v-else
          >
            <i class="el-icon-document"></i>
            <span class="equipName"> {{ data.name }}</span>
          </div>
        </template>
      </EquipTree>
    </Pane>
    <Pane v-if="selectDatas.length >= 1">
      <slot name="edit"></slot>
    </Pane>
  </Splitpanes>
</template>

<script>
import { Splitpanes, Pane } from 'splitpanes'
import EquipTree from '../EquipTree'

export default {
  inject: ['olMap'],
  props: {
    countryTypeList: {
      type: Array,
      default: () => [],
    },
    selectDatas: {
      type: Array,
      default: () => [],
    },
  },
  components: {
    Splitpanes,
    Pane,
    EquipTree,
  },
  methods: {
    onTreeNodeClick(data) {
      if (this.olMap.vueRef && data) {
        this.olMap.vueRef.selectNode(data)
      }
    },
    onTreeNodeDbClick(data) {
      if (this.olMap.vueRef && data) {
        this.olMap.vueRef.fitNode(data)
      }
    },
    onNodeContextMenu(data) {
      let menuList = [
        {
          name: '定位该节点',
          elIcon: 'el-icon-position',
          params: data,
          action: this.olMap.vueRef.fitNode,
          key: Symbol('key'),
        },
        {
          name: '删除该节点',
          elIcon: 'el-icon-delete',
          params: data,
          action: this.olMap.vueRef.removeNode,
          key: Symbol('key'),
        },
      ]
      this.olMap.vueRef.$refs.contextMenuRef.show(menuList)
    },
  },
}
</script>

<style scoped lang="less">
.equipName {
  // font-weight: bold;
  font-family: '黑体';
}
::v-deep {
  .el-tree-node:focus > .el-tree-node__content,
  .el-tree-node.is-current > .el-tree-node__content,
  .el-tree-node__content:hover {
    background-color: #288efc73 !important;
  }
}
</style>
