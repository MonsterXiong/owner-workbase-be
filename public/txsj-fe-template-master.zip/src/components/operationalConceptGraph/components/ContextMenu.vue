<template>
  <div class="context-menu-box" v-show="isShow" :style="{ left: position.x + 'px', top: position.y + 'px' }" v-click-outside="hide" @click.stop>
    <el-menu :collapse="true" class="context-menu">
      <el-menu-item v-for="menu in menuList" v-show="!menu.hide" :key="menu.key || menu.code" @click="handleMenuItemClick(menu)">
        <div class="context-menu-title">
          <i style="font-size: 14px" v-show="menu.elIcon" :class="menu.elIcon"></i>
          {{ menu.name }}
        </div>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  props: {},
  data() {
    return {
      position: { x: -1, y: -1 },
      isShow: false,
      menuList: [],
    }
  },
  mounted() {
    document.addEventListener('contextmenu', this.getMousePosition)
  },
  beforeDestroy() {
    document.removeEventListener('contextmenu', this.getMousePosition)
  },
  methods: {
    getMousePosition(event) {
      this.position.x = event.clientX + 4
      this.position.y = event.clientY
      this.isShow = false
    },
    handleMenuItemClick(menuItem) {
      if (menuItem && menuItem.action) {
        menuItem.action(menuItem?.params)
      }
    },
    show(menuList) {
      if (!menuList || menuList.length < 1) return
      this.menuList = menuList
      setTimeout(() => {
        this.isShow = true
        this.$nextTick(() => {
          if (this.$el.clientHeight + this.position.y > document.body.clientHeight) {
            this.position.y = document.body.clientHeight - this.$el.clientHeight - 5
          }
        })
      }, 0)
    },
    hide() {
      this.isShow = false
    },
  },
}
</script>

<style scoped lang="less">
@import '../variable.less';

.context-menu-box {
  background-color: @base-theme-color;
  z-index: 99;
  position: fixed;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  clip-path: polygon(0 0, calc(100% - 9px) 0%, 100% 10px, 100% 100%, 0 100%);

  .context-menu {
    padding: 4px 2px 4px 2px;

    .context-menu-title {
      margin-left: 5px;
    }
  }
  .el-menu {
    background-color: @background-color-layout;
    border: 1px solid @base-theme-color;
    clip-path: polygon(
      0 0,
      calc(100% - 11px) 0%,
      100% 12px,
      100% 15px,
      calc(100% - 4px) 15px,
      calc(100% - 4px) 18px,
      100% 18px,
      100% 21px,
      calc(100% - 4px) 21px,
      calc(100% - 4px) 24px,
      100% 24px,
      100% 27px,
      calc(100% - 4px) 27px,
      calc(100% - 4px) 30px,
      100% 30px,
      100% 100%,
      0 100%
    );
  }
  .el-submenu__title,
  .el-menu-item {
    color: @font-color-light;
    &:focus,
    &:hover {
      background-color: @base-theme-color !important;
    }
  }
  .el-submenu__title i {
    color: @font-color-light;
  }
}
.el-menu--vertical.context-submenu {
  margin-left: 5px;
  background-color: @background-color-layout;
  border: 1px solid @base-theme-color;
}
.el-menu--collapse {
  width: 100% !important;
}

.el-menu-item {
  padding: 0 16px 0 10px !important;
}
.el-menu-item,
.el-submenu {
  height: 28px !important;
  line-height: 28px !important;
  > [class^='el-icon-'] {
    margin-right: 0px;
    width: auto;
    color: inherit;
    font-size: inherit;
  }
}
.el-submenu {
  & /deep/ .el-submenu__title {
    height: 28px !important;
    line-height: 28px !important;
  }

  // & /deep/ .el-submenu__title:hover {
  //   background-color: @base-hover-color;
  // }

  /deep/.el-submenu__icon-arrow {
    margin-top: -4px;
  }
}
</style>
