<template>
  <div class="multi-level-expand-table">
    <el-table ref="elTableRef" :row-key="realConfig.idKey" :data="treeData" :cell-style="icellStyle" v-bind="$attrs" v-on="$listeners">
      <el-table-column type="expand">
        <template slot-scope="props">
          <MultiLevelExpandTable
            isInner
            v-if="props.row[realConfig.childKey || '__list']"
            :show-header="false"
            :data="props.row[realConfig.childKey || '__list']"
            :config="config"
          >
            <slot></slot>
            <template slot="expandPanel" slot-scope="propsInner">
              <slot name="expandPanel" :path="props.row" :row="propsInner.row" :$index="propsInner.$index"></slot>
            </template>
          </MultiLevelExpandTable>
          <slot name="expandPanel" v-else :row="props.row" :path="props.row" :$index="props.$index"></slot>
        </template>
      </el-table-column>
      <slot></slot>
    </el-table>
  </div>
</template>

<script>
import { listToTree, setTreeLevel, setTreeNodeParent, findLeafNode } from '@/utils/treeTool'
const defaultConfig = {
  levelIndent: 10,
  idKey: 'id',
  parentIdKey: 'parentId',
  childKey: '__list',
  isExpandShowOnlyLeaf: true,
  rowLeafKey: 'isLeaf',
}
export default {
  name: 'MultiLevelExpandTable',
  inheritAttrs: false,

  props: {
    data: {
      type: Array,
      default: () => [],
    },
    isInner: {
      type: Boolean,
      default: false,
    },
    config: {
      type: Object,
      default: () => {},
    },
  },
  inject: ['childrenList'],
  data() {
    return {
      treeData: [],
    }
  },

  computed: {
    realConfig() {
      return Object.assign({}, defaultConfig, this.config)
    },
  },
  methods: {
    icellStyle({ row, column, rowIndex, columnIndex }) {
      const style = {}
      if (column.type === 'expand') {
        style.paddingLeft = `${(row.__level - 1) * (this.realConfig.levelIndent || 10)}px`
        if (this.realConfig.isExpandShowOnlyLeaf) {
          let rowLeafKey = this.realConfig.rowLeafKey
          if (_.isFunction(rowLeafKey)) {
            rowLeafKey = rowLeafKey({ row, column, rowIndex, columnIndex })
          }

          if (!row[rowLeafKey] && row.__self_isLeaf) {
            style.visibility = 'hidden'
          }
        }
      }
      return style
    },
    getFullPath(item, list) {
      if (item) {
        list.push(item[this.realConfig.idKey])
        if (item.__parent) {
          this.getFullPath(item.__parent, list)
        }
      }
    },
  },
  mounted() {
    this.data.forEach((item) => {
      const fullPathCompInstanceList = []
      this.getFullPath(item, fullPathCompInstanceList)
      const index = this.childrenList.findIndex((item) => item.key === fullPathCompInstanceList.reverse().join('-'))
      if (index < 0) {
        this.childrenList.push({
          key: fullPathCompInstanceList.reverse().join('-'),
          value: this,
        })
      } else {
        this.childrenList.splice(index, 1)
        this.childrenList.push({
          key: fullPathCompInstanceList.reverse().join('-'),
          value: this,
        })
      }
    })
  },
  watch: {
    data: {
      handler: function (newData) {
        if (!this.isInner) {
          const treeData = listToTree(this.data, {
            idKey: this.realConfig.idKey || 'id',
            parentIdKey: this.realConfig.parentIdKey || 'parentId',
            childKey: this.realConfig.childKey || '__list',
          })
          setTreeLevel(treeData, 1, { childKey: this.realConfig.childKey || '__list' })
          setTreeNodeParent(treeData, { childKey: '__list' })
          const leafNodeList = findLeafNode(treeData, { childKey: this.realConfig.childKey || '__list' })
          if (Array.isArray(leafNodeList)) {
            leafNodeList.forEach((item) => (item.__self_isLeaf = true))
          }
          this.treeData = treeData
        } else {
          this.treeData = this.data
        }
      },
      immediate: true,
    },
  },
}
</script>

<style scoped lang="less">
.multi-level-expand-table {
  ::v-deep {
    .el-table__expanded-cell {
      padding: 0;
    }
  }
}
</style>
