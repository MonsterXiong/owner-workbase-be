<template>
  <div class="graph-3d-page" ref="Graph3dChartRef"></div>
</template>

<script>
import * as echarts from 'echarts'
import 'echarts-gl'
import { mockPropsData } from './index'

export default {
  name: 'LineGraph',
  props: {
    propsData: {
      type: Object,
      default: () => {
        return mockPropsData
      },
    },
    textColor: { type: String, default: '#333' },
  },
  watch: {
    propsData: {
      handler(val) {
        this.$nextTick(() => {
          this.setSeriesData(val)
        })
      },
      immediate: true,
    },
  },
  data() {
    return {
      myChart: null,
    }
  },
  methods: {
    setSeriesData() {
      let data = this.transfer3dData(this.propsData?.nodes || [], this.propsData?.links || [], this.propsData?.categories || [])
      this.renderGraph(data)
    },
    transfer3dData(nodes, links, categories) {
      let surfaceList = [],
        scatter3DList = [],
        line3DList = [],
        nodeList = []

      let categoriesColor = ['#EA868315', '#eac88315', '#8383ea15', '#ceea8315', '#ceeaF315'],
        nodeColor = ['#5470c555', '#91cc7555', '#fac85855', '#ee666655', '#73c0de55', '#3ba27255', '#fc845255', '#9a60b455', '#ea7ccc55']
      console.log(nodes, links, categories)
      categories.map((ele, index) => {
        // if (filterDomain.indexOf(ele.name) == -1) {
        surfaceList.push({
          name: ele.name,
          type: 'surface',
          wireframe: {
            // show: false
          },
          equation: {
            x: {
              step: 2,
            },
            y: {
              step: 2,
            },
            z: function (x, y) {
              return index * 100
            },
          },
          itemStyle: {
            color: categoriesColor[index] || 'rgba(200,0,0,0.2)',
          },
        })
        let arr = nodes.filter((n) => n.category == index)
        scatter3DList.push(arr)
        // }
      })
      let R = 0.8
      scatter3DList.forEach((list, index) => {
        // let x = 0, y = 0,
        let len = list.length
        list.map((ele, i) => {
          let x = R * Math.cos((i * 360) / len),
            y = R * Math.sin((i * 360) / len),
            z = 100 * index
          nodeList.push({
            ...ele,
            value: [x, y, z],
            symbolSize: 10,
            itemStyle: {
              color: nodeColor[index],
            },
            label: {
              show: false,
            },
          })
        })
      })
      links.map((ele) => {
        let from = nodeList.find((node) => node.id === ele.source),
          to = nodeList.find((node) => node.id === ele.target)
        let color = '#ffffff20'
        if (!from || !to) return
        if (from.category != to.category) color = '#73c0ee20'
        line3DList.push({
          type: 'line3D',
          data: [
            { name: from.name + ' - ' + to.name, value: from.value },
            { name: from.name + ' - ' + to.name, value: to.value },
          ],
          zlevel: 11,
          lineStyle: {
            width: 1,
            color,
          },
        })
      })
      return [
        ...line3DList,
        ...surfaceList,
        {
          type: 'scatter3D',
          symbol: 'circle',
          zlevel: 10,
          // itemStyle: {
          //   color: '#73c0de',
          // },
          data: [...nodeList],
        },
      ]
    },

    initChart(seriesData) {
      if (this.myChart != null && this.myChart != '' && this.myChart != undefined) {
        this.myChart.dispose()
      }
      this.$nextTick(() => {
        this.myChart = echarts.init(this.$refs.Graph3dChartRef)
        window.addEventListener('resize', () => {
          this.myChart.resize()
        })
        this.renderGraph(seriesData)
      })
    },
    resizeChart() {
      this.myChart.resize()
    },
    async renderGraph(seriesData) {
      if (this.myChart == null) await this.initChart()
      this.myChart.resize()
      const options = {
        tooltip: {
          formatter: function (params) {
            if (params.name.length > 0) return params.name
            if (params.seriesName) return params.seriesName
            return ''
          },
        },
        xAxis3D: {
          name: 'x',
          type: 'value',
          show: false,
        },
        yAxis3D: {
          name: 'y',
          type: 'value',
          show: false,
        },
        zAxis3D: {
          name: 'z',
          type: 'value',
          show: false,
        },
        grid3D: {
          show: false,
          axisLine: {
            lineStyle: {
              color: '#fff',
            },
          },
          axisPointer: {
            lineStyle: {
              color: '#ffbd67',
            },
          },
          viewControl: {
            autoRotate: true,
            projection: 'orthographic',
          },
        },
        series: seriesData || [],
      }
      this.myChart.setOption(options, true)
    },
    saveImage() {
      return this.getChartImage(this.myChart)
    },
    getChartImage(chart) {
      let picInfo = chart.getDataURL({
        type: 'png',
        pixelRatio: 1.5, //放大两倍下载，之后压缩到同等大小展示。解决生成图片在移动端模糊问题
        backgroundColor: '#fff',
      }) //获取到的是一串base64信息 saveModelGraphImage
      return picInfo
      // await ModelService.saveModelGraphImage({
      //   file: dataUrltoBlob(picInfo),
      //   modelId: this.modelId,
      //   projectId: this.projectId,
      // })
    },
  },
}

// const mockData = [
//   {
//     type: 'surface',
//     wireframe: {
//       // show: false
//     },
//     equation: {
//       x: {
//         step: 1,
//       },
//       y: {
//         step: 1,
//       },
//       z: function (x, y) {
//         return 100
//       },
//     },
//     itemStyle: {
//       color: 'rgba(200,0,0,0.2)',
//     },
//   },
//   {
//     type: 'surface',
//     wireframe: {
//       // show: false
//     },
//     equation: {
//       x: {
//         step: 1,
//       },
//       y: {
//         step: 1,
//       },
//       z: function (x, y) {
//         return 200
//       },
//     },
//     itemStyle: {
//       color: 'rgba(200,100,0,0.2)',
//     },
//   },
//   {
//     type: 'surface',
//     wireframe: {
//       // show: false
//     },
//     equation: {
//       x: {
//         step: 1,
//       },
//       y: {
//         step: 1,
//       },
//       z: function (x, y) {
//         return 300
//       },
//     },
//     itemStyle: {
//       color: 'rgba(000,0,200,0.2)',
//     },
//   },
//   {
//     type: 'surface',
//     wireframe: {
//       // show: false
//     },
//     itemStyle: {
//       color: 'rgba(100,255,0,0.2)',
//     },
//     equation: {
//       x: {
//         step: 1,
//       },
//       y: {
//         step: 1,
//       },
//       z: function (x, y) {
//         return 400
//       },
//     },
//   },
//   {
//     type: 'scatter3D',
//     symbol: 'circle',
//     zlevel: 10,
//     itemStyle: {
//       color: 'yellow',
//     },
//     data: [{ id: '101', name: '', value: [0.15, 0.88, 100] }, { id: '102', name: '', value: [0.15, 0.7, 200] }, [0.5, 0.7, 200]],
//   },
//   {
//     type: 'line3D',
//     data: [{ value: [0.15, 0.88, 100] }, [0.15, 0.7, 200]],
//     zlevel: 11,
//     lineStyle: {
//       width: 4,
//     },
//   },
//   {
//     type: 'line3D',
//     data: [
//       [0.15, 0.7, 200],
//       [0.5, 0.7, 200],
//     ],
//     zlevel: 12,
//     lineStyle: {
//       width: 4,
//     },
//   },
//   {
//     type: 'line3D',
//     data: [
//       [0.15, 0.88, 100],
//       [0.5, 0.7, 200],
//     ],
//     zlevel: 12,
//     lineStyle: {
//       width: 4,
//     },
//   },
// ]
</script>

<style scoped lang="less">
.graph-3d-page {
  height: calc(100% - 0px);
  width: 100%;
}
</style>
