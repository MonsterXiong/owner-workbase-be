# 3d Echart图相关注释

- Graph3dChart.vue文件

```js
//  props传参

propsData: {
  type: Object,
  default: () => {
    return mockPropsData//具体参考index.js文件
  },
},
textColor: { type: String, default: '#333' },

```

```js
// 示例 
<template>
  <div>
    <Graph3dChart :propsData="propsData" :textColor="'#333'" />
  </div>
</template>
<script>
import { mockPropsData } from '.'
import Graph3dChart from './Graph3dChart.vue'
export default {
  name: 'Table3',
  components: {
    Graph3dChart,
  },
  data() {
    return {
      propsData: mockPropsData,
    }
  },
}
</script>
```
