export const mockPropsData = {
  nodes: [
    {
      id: 'a883c4b1b03848a4a540dec2ff2cb93e',
      name: '移动通信基站2',
      category: 1,
      symbolSize: 55.45,
      symbol: 'circle',
      data: {
        //...
      },
      value: '0.909',
    },
    {
      id: '614b0d1399994e9a921b9fadb9d92977',
      name: '台北世界贸易中心国际贸易大楼',
      symbolSize: 4,
      symbol: 'circle',
      data: {},
      value: '0',
    },
    {
      id: 'e48f954ac6694d9cbaa7777eac6880c5',
      name: '联通通信基站2',
      category: 1,
      symbolSize: 50.9,
      symbol: 'circle',
      data: {},
      value: '0.818',
    },
    {
      id: 'd95e161d1cc84edf96acb642bb016c16',
      name: '电信通信基站1',
      category: 1,
      symbolSize: 46.35,
      symbol: 'circle',
      data: {},
      value: '0.727',
    },
    {
      id: '47776759ac944bc0b249a877340db959',
      name: '联通通信基站1',
      category: 1,
      symbolSize: 41.8,
      symbol: 'circle',
      data: {},
      value: '0.636',
    },

    {
      id: '8853d88243d44d56b454f71a2a0f53ea',
      name: '变电所',
      category: 2,
      symbolSize: 37.25,
      symbol: 'circle',
      data: {},
      value: '0.545',
    },

    {
      id: '97da022ab25b4612b77be3dfada301cd',
      name: '电信通信基站2',
      category: 1,
      symbolSize: 32.75,
      symbol: 'circle',
      data: {},
      value: '0.455',
    },

    {
      id: 'af6d0818c389423ab4eac79481cae6ab',
      name: '台湾桃园国际机场',
      category: 0,
      symbolSize: 28.2,
      symbol: 'circle',
      data: {},
      value: '0.364',
    },

    {
      id: 'c86d3129c877404a92251004773e8f54',
      name: '移动通信基站1',
      category: 1,
      symbolSize: 23.65,
      symbol: 'circle',
      data: {},
      value: '0.273',
    },

    {
      id: '465f3d2f16454b03b1fd0b3fb4a0367b',
      name: '士林站',
      category: 0,
      symbolSize: 4,
      symbol: 'circle',
      data: {},
      value: '0.000',
    },

    {
      id: '219387d892bc428eb40869cff52b30c4',
      name: '南港火车站',
      category: 0,
      symbolSize: 4,
      symbol: 'circle',
      data: {},
      value: '0.000',
    },
    {
      id: '9a2f4603851645288755589fa6df54d1',
      name: '台北市立兴雅国民中学',
      category: 3,
      symbolSize: 4,
      symbol: 'circle',
      data: {},
      value: '0',
    },
    {
      id: 'b3a464aea8e246aba6fcfd5012b6f88b',
      name: '松山机场',
      category: 0,
      symbolSize: 4,
      symbol: 'circle',
      data: {},
      value: '0.000',
    },
  ],
  links: [
    {
      source: '9a2f4603851645288755589fa6df54d1',
      target: '8853d88243d44d56b454f71a2a0f53ea',
      value: '',
    },
    {
      source: 'e48f954ac6694d9cbaa7777eac6880c5',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: 'd95e161d1cc84edf96acb642bb016c16',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '97da022ab25b4612b77be3dfada301cd',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: 'af6d0818c389423ab4eac79481cae6ab',
      target: '72ffeb404a3048eaa1eb34674d617fc7',
      value: '',
    },
    {
      source: '465f3d2f16454b03b1fd0b3fb4a0367b',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: 'a883c4b1b03848a4a540dec2ff2cb93e',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'a883c4b1b03848a4a540dec2ff2cb93e',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'c86d3129c877404a92251004773e8f54',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '465f3d2f16454b03b1fd0b3fb4a0367b',
      value: '',
    },
    {
      source: 'c86d3129c877404a92251004773e8f54',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '219387d892bc428eb40869cff52b30c4',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '58630ca130f1450a9d4a8cb224188d1c',
      value: '',
    },
    {
      source: '97da022ab25b4612b77be3dfada301cd',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '465f3d2f16454b03b1fd0b3fb4a0367b',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '97da022ab25b4612b77be3dfada301cd',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'd95e161d1cc84edf96acb642bb016c16',
      value: '',
    },
    {
      source: '47776759ac944bc0b249a877340db959',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: 'd95e161d1cc84edf96acb642bb016c16',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: '219387d892bc428eb40869cff52b30c4',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '72ffeb404a3048eaa1eb34674d617fc7',
      value: '',
    },
    {
      source: 'e48f954ac6694d9cbaa7777eac6880c5',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: 'b3a464aea8e246aba6fcfd5012b6f88b',
      target: '72ffeb404a3048eaa1eb34674d617fc7',
      value: '',
    },
    {
      source: 'a883c4b1b03848a4a540dec2ff2cb93e',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '47776759ac944bc0b249a877340db959',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: '955bb430e0264dcf84320430aaf995e8',
      value: '',
    },
    {
      source: '219387d892bc428eb40869cff52b30c4',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: 'c86d3129c877404a92251004773e8f54',
      target: 'af6d0818c389423ab4eac79481cae6ab',
      value: '',
    },
    {
      source: '47776759ac944bc0b249a877340db959',
      target: 'b3a464aea8e246aba6fcfd5012b6f88b',
      value: '',
    },
    {
      source: '8853d88243d44d56b454f71a2a0f53ea',
      target: 'e48f954ac6694d9cbaa7777eac6880c5',
      value: '',
    },
  ],
  categories: [
    {
      name: '交通域',
    },
    {
      name: '通信域',
    },
    {
      name: '电力域',
    },
    {
      name: '其他域',
    },
  ],
}
