<template>
  <div class="common-page">
    <el-table ref="basicTableRef" v-bind="$attrs" v-on="$listeners" :height="tableHeight">
      <template v-for="ele in columnList">
        <el-table-column
          v-if="ele.type == 'selection'"
          :key="ele.code"
          type="selection"
          :width="ele.width || 80"
          :align="ele.align || 'center'"
          :fixed="ele.fixed"
        ></el-table-column>
        <el-table-column
          v-else-if="ele.type == 'index'"
          :key="ele.code"
          type="index"
          :width="ele.width || 80"
          :align="ele.align || 'center'"
          :fixed="ele.fixed"
        >
          <template #header>序号</template>
        </el-table-column>
        <el-table-column
          v-else
          :prop="ele.code"
          :key="ele.code"
          :width="ele.width"
          :min-width="ele.minWidth"
          :label="ele.labelTable || ele.label"
          :align="ele.align || 'center'"
          :fixed="ele.fixed"
        >
          <template slot-scope="{ row }">
            <slot :name="ele.code" :scope="row">
              <template v-if="['select', 'radio', 'checkbox'].includes(ele.type)">
                <template v-if="ele.isEdit">
                  <!-- 下拉框 -->
                  <template v-if="ele.type === 'select'">
                    <el-select
                      v-model="row[ele.code]"
                      :placeholder="`请选择${ele.label}`"
                      :clearable="ele.clearable"
                      :disabled="ele.disabled"
                      :multiple="ele.multiple"
                      :filterable="ele.filterable"
                    >
                      <el-option
                        v-for="item in ele.options"
                        :key="item[ele.defaultProps?.value || 'value']"
                        :label="item[ele.defaultProps?.label || 'label']"
                        :value="item[ele.defaultProps?.value || 'value']"
                        :disabled="item.disabled"
                      >
                      </el-option>
                    </el-select>
                  </template>
                  <!-- 单选框 -->
                  <template v-else-if="ele.type === 'radio'">
                    <el-radio-group v-model="row[ele.code]" :disabled="ele.disabled">
                      <el-radio
                        v-for="item in ele.options"
                        :key="item[ele.defaultProps?.value || 'value']"
                        :label="item[ele.defaultProps?.value || 'value']"
                        :disabled="item.disabled"
                      >
                        {{ item[ele.defaultProps?.label || 'label'] }}
                      </el-radio>
                    </el-radio-group>
                  </template>
                  <!-- 多选框 -->
                  <template v-else-if="ele.type === 'checkbox'">
                    <el-checkbox-group v-model="row[ele.code]" :disabled="ele.disabled">
                      <el-checkbox
                        v-for="item in ele.options"
                        :key="item[ele.defaultProps?.value || 'value']"
                        :label="item[ele.defaultProps?.value || 'value']"
                        :disabled="item.disabled"
                      >
                        {{ item[ele.defaultProps?.label || 'label'] }}
                      </el-checkbox>
                    </el-checkbox-group>
                  </template>
                </template>
                <template v-else>
                  <span v-if="['select', 'radio', 'checkbox'].includes(ele.type)">
                    <template v-if="ele.type === 'checkbox' || (ele.type === 'select' && ele.multiple)">
                      {{ getOptionName(ele, row) }}
                    </template>
                    <template v-else-if="ele.optDataType === 'interface'"> {{ getOptionName(ele, row) }}</template>
                    <template v-else>{{ getOptionName(ele, row) }}</template>
                  </span>
                </template>
              </template>
              <!-- treeselect树形下拉框 -->
              <template v-else-if="ele.type === 'treeselect'">
                <template v-if="ele.isEdit">
                  <TreeSelect
                    style="width: 100%"
                    :placeholder="`请选择${ele.label}`"
                    v-model="row[ele.code]"
                    :clearable="ele.clearable"
                    :flat="ele.flat"
                    appendToBody
                    :normalizer="normalizer"
                    :options="ele.options"
                    :default-expand-level="Infinity"
                    noOptionsText="暂无数据"
                    class="vueTreeSelectSmall"
                    :zIndex="treeSelectZindex"
                    :multiple="ele.multiple"
                  >
                    <label slot="value-label" slot-scope="{ node }">
                      <span>{{ getTreeNodeValue(node) }}</span>
                    </label>
                  </TreeSelect>
                </template>
              </template>
              <!-- 时间选择器 -->
              <template v-else-if="ele.type == 'time'">
                <template v-if="ele.isEdit">
                  <el-time-picker
                    v-model="row[ele.code]"
                    :placeholder="`请选择${ele.label}`"
                    :value-format="timeFormat.includes(ele.dataFormat?.trim()) ? ele.dataFormat : 'HH:mm:ss'"
                    :disabled="ele.disabled"
                  ></el-time-picker>
                </template>
                <template v-else>
                  <span> {{ row[ele.code] | filter_timeFormat(ele.dataFormat || 'HH:mm:ss') }} </span>
                </template>
              </template>
              <!-- 日期选择器 -->
              <template v-else-if="ele.type == 'date'">
                <template v-if="ele.isEdit">
                  <el-date-picker
                    v-model="row[ele.code]"
                    :placeholder="`请选择${ele.label}`"
                    :value-format="dateFormat.includes(ele.dataFormat?.trim()) ? ele.dataFormat : 'yyyy-MM-dd'"
                    :disabled="ele.disabled"
                  ></el-date-picker>
                </template>
                <template v-else>
                  <span> {{ row[ele.code] | filter_timeFormat(ele.dataFormat || 'YYYY-MM-DD') }} </span>
                </template>
              </template>
              <!-- 日期时间选择器 -->
              <template v-else-if="ele.type == 'datetime'">
                <template v-if="ele.isEdit">
                  <el-date-picker
                    v-model="row[ele.code]"
                    :placeholder="`请选择${ele.label}`"
                    :format="getDateTimeFormat().includes(ele.dataFormat?.trim()) ? ele.dataFormat : 'yyyy-MM-dd HH:mm:ss'"
                    :disabled="ele.disabled"
                  >
                  </el-date-picker>
                </template>
                <template v-else>
                  <span> {{ row[ele.code] | filter_timeFormat(ele.dataFormat || 'YYYY-MM-DD HH:mm:ss') }} </span>
                </template>
              </template>
              <!-- Switch 开关 -->
              <template v-else-if="ele.type == 'switch'">
                <template v-if="ele.isEdit">
                  <el-switch
                    v-model="row[ele.code]"
                    :disabled="ele.disabled"
                    :active-color="ele.activeColor"
                    :inactive-color="ele.inactiveColor"
                    :active-text="ele.activeText"
                    :inactive-text="ele.inactiveText"
                  >
                  </el-switch>
                </template>
                <template v-else>
                  <span> {{ getSwitchText(ele, row) }} </span>
                </template>
              </template>
              <!-- Slider 滑块 -->
              <template v-else-if="ele.type === 'slider'">
                <template v-if="ele.isEdit">
                  <el-slider v-model="row[ele.code]" :disabled="ele.disabled"></el-slider>
                </template>
                <template v-else>
                  <span>{{ row[ele.code] }}</span>
                </template>
              </template>
              <!-- 颜色选择器 -->
              <template v-else-if="ele.type == 'color'">
                <span>
                  <el-color-picker v-model="row[ele.code]" :disabled="ele.isEdit ? false : true" :color-format="ele.colorFormat" size="small"></el-color-picker>
                </span>
              </template>
              <!-- 编辑表格中暂时不处理图片 -->
              <template v-else-if="ele.type == 'picture'">
                <el-image :src="getCompleteUrl(row[ele.code])" class="img-icon" fit="contain">
                  <div slot="error"></div>
                </el-image>
              </template>
              <!-- 数字框 -->
              <template v-else-if="ele.type == 'number'">
                <template v-if="ele.isEdit">
                  <el-input-number
                    v-model="row[ele.code]"
                    :min="ele.min || ele.min === 0 ? ele.min : -Infinity"
                    :max="ele.max ? ele.max : Infinity"
                    :controls="ele.controls"
                    :controls-position="ele.controlsPosition"
                    :placeholder="`请输入${ele.label}`"
                    :disabled="ele.disabled"
                  ></el-input-number>
                </template>
                <template v-else>
                  <span>{{ row[ele.code] }}</span>
                </template>
              </template>
              <!-- 按钮 -->
              <span v-else-if="ele.type == 'button'">
                <el-button
                  v-for="bItem in ele.buttonList"
                  :key="bItem.emitCode + Math.random()"
                  size="mini"
                  :type="bItem.type ? bItem.type : 'primary'"
                  plain
                  @click="onButtonClick(row, bItem.emitCode)"
                  >{{ bItem.label }}</el-button
                >
              </span>
              <!-- 文本域 -->
              <template v-else-if="ele.type === 'textarea'">
                <template v-if="ele.isEdit">
                  <el-input type="textarea" v-model="row[ele.code]" :placeholder="`请输入${ele.label}`" :disabled="ele.disabled"></el-input>
                </template>
                <template v-else>
                  <span>{{ row[ele.code] }}</span>
                </template>
              </template>
              <template v-else>
                <template v-if="ele.isEdit">
                  <el-input v-model="row[ele.code]" :placeholder="`请输入${ele.label}`" :disabled="ele.disabled"></el-input>
                </template>
                <template v-else>
                  <span>{{ row[ele.code] }}</span>
                </template>
              </template>
            </slot>
          </template>
        </el-table-column>
      </template>
    </el-table>
    <div class="pagination-wrapper" v-if="tableConfig.showPagination" ref="paginationRef">
      <el-pagination
        :current-page="tableConfig.pageInfo.page"
        :page-sizes="[10, 20, 30, 50, 100]"
        :page-size="tableConfig.pageInfo.rows"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        @size-change="onPageSizeChange"
        @current-change="onPageCurrentChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import TreeSelect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import { mergeObj, isObject } from '@/utils/commonUtil.js'
import { treeToList } from '@/utils/treeTool'
import { getTreeNodeValue } from '@/utils/treeSelectFn'
import moment from 'moment'
import { getCompleteUrl } from '@/utils/domUtil'

const baseTableConfig = {
  pageInfo: {
    page: 1,
    rows: 20,
  },
  showPagination: true,
}
export default {
  name: 'Table',
  props: {
    columnList: {
      type: Array,
      default: () => [],
    },
    height: {
      type: Number,
      default: 300,
    },
    total: {
      type: Number,
      default: 0,
    },
    config: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      tableHeight: '300px',
      multipleSelection: [],
      timeFormat: ['HH:mm', 'HH:mm:ss'],
      dateFormat: ['yyyy-MM-dd', 'yyyy/MM/dd', 'yyyy MM dd', 'yyyy年MM月dd日', 'yyyy-MM', 'MM-dd-yyyy'],
      treeSelectZindex: 5999,
      normalizer(node) {
        return {
          id: node.id,
          label: node.label,
          children: node.children,
        }
      },
      getTreeNodeValue,
      getCompleteUrl,
    }
  },
  computed: {
    tableConfig() {
      return mergeObj(baseTableConfig, this.config)
    },
  },
  mounted() {
    this.$refs.basicTableRef.doLayout()
  },
  methods: {
    // 将编辑表格中多选、复选框转成数组
    handleTableData() {
      const columnItems = this.columnList.filter((item) => item.isEdit && (item.multiple || item.type === 'checkbox'))
      const columnCodes = columnItems.map((item) => item.code)
      if (!columnItems.length) return
      this.$attrs.data.forEach((item) => {
        columnCodes.forEach((code) => {
          if (!Array.isArray(item[code])) {
            try {
              item[code] = JSON.parse(item[code])
            } catch (error) {
              item[code] = item[code]?.split(',') || []
            }
          }
        })
      })
    },
    // 获取select|radio|checkbox名称
    getOptionName(ele, row) {
      // options 下拉框的数据已经在columnList中有值了
      const columnItem = this.columnList.find((item) => item.code === ele.code)
      if (columnItem.type === 'checkbox' || (['select', 'treeselect'].includes(ele.type) && ele.multiple)) {
        // 静态枚举
        if (ele.enumType) {
          // @TODO 获取多个枚举名称
          const options = this.$enum.getOption(ele.enumType)
          return this.getOptMultipleName(options, ele, row)
        } else {
          let optionData = [...ele.options]
          // 处理树形数据 多选
          if (['treeselect'].includes(ele.type)) optionData = this.handleTreeToList(ele)
          return this.getOptMultipleName(optionData, ele, row)
        }
      } else {
        if (ele.enumType) return this.$enum.getLabel(ele.enumType, row[ele.code])
        else {
          if (!(ele.options && ele.options.length)) return
          let optionData = [...ele.options]
          // 处理树形数据
          if (['treeselect'].includes(ele.type)) optionData = this.handleTreeToList(ele)
          return this.getOptItemData(optionData, ele, row)
        }
      }
    },
    // 将树形数据转扁平数据
    handleTreeToList(ele) {
      const listData = treeToList(ele.options)
      return listData.map((item) => {
        return {
          ...item,
          id: item[ele.defaultProps.id],
          label: item[ele.defaultProps.label],
          parentId: item[ele.defaultProps.parentId],
        }
      })
    },
    // 获取多个
    getOptMultipleName(list, ele, row) {
      if (!(Array.isArray(list) && list.length > 0)) return ''
      return list
        .filter((item) => row[ele.code]?.split(',').includes(item[ele.defaultProps?.value || 'value']))
        .map((item) => item[ele.defaultProps?.label || 'label'])
        .join(',')
    },
    // 获取单个
    getOptItemData(list, ele, row) {
      if (!list?.length) return ''
      let optItemData = list.find((item) => item[ele.defaultProps?.value || 'value'] === row[ele.code])
      return optItemData ? optItemData[ele.defaultProps?.label || 'label'] : ''
    },
    getSwitchText(ele, row) {
      return row[ele.code] == 1 && row[ele.code] == true ? ele.activeText || '是' : ele.inactiveText || '否'
    },
    // 表格操作事件
    onButtonClick(row, code) {
      this.$emit('btnClick', code, row)
    },
    // 多选
    onSelectionChange(val) {
      this.multipleSelection = val
      this.$emit('selectionChange', val)
    },
    //处理页面大小改变
    onPageSizeChange(rows) {
      this.tableConfig.pageInfo.rows = rows
      this.$emit('updateTable', this.tableConfig.pageInfo)
    },
    //处理当前页面改变
    onPageCurrentChange(page) {
      this.tableConfig.pageInfo.page = page
      this.$emit('updateTable', this.tableConfig.pageInfo)
    },
    getDateTimeFormat() {
      return this.dateFormat.reduce((pre, cur) => {
        this.timeFormat.forEach((tf) => {
          pre.push(`${cur} ${tf}`)
        })
        return pre
      }, [])
    },
  },
  components: { TreeSelect },
  filters: {
    filter_timeFormat: (value, code) => {
      if (!value) return ''
      return moment(value).format(code)
    },
  },
  watch: {
    height() {
      this.tableHeight = `${this.height - (this.tableConfig.showPagination ? this.$refs.paginationRef?.offsetHeight : 0)}px`
    },
    '$attrs.data': {
      handler() {
        this.handleTableData()
      },
      immediate: true,
      deep: true,
    },
  },
}
</script>

<style lang="less" scoped>
.img-icon {
  width: 70px;
  height: 70px;
}
</style>
