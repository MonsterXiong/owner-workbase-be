<template>
  <div class="rtf-page" ref="rtfRef">
    <div class="rtf-top" v-if="isSaveBtn">
      <el-button type="primary" size="small" icon="el-icon-finished" plain @click="onSave">保存</el-button>
    </div>
    <div :id="richTextId"></div>
  </div>
</template>

<script>
import { uuid } from '@/utils/commonUtil'
import E from 'wangeditor'
function resetPlaceholder(editor) {
  editor.$textContainerElem.elems[0].lastChild.textContent = ''
}
export default {
  name: 'RichText',
  props: {
    value: {
      type: String,
      default: '',
    },
    isSaveBtn: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      editor: null,
      richTextId: '',
    }
  },
  created() {
    const randomId = uuid()
    this.richTextId = `richText${randomId}`
  },
  mounted() {
    this.init()
    this.$nextTick(() => {
      if (this.isSaveBtn) document.onkeydown = this.onKeyDown
    })
  },
  methods: {
    // ctrl + s 保存
    onKeyDown(e) {
      let currKey = 0,
        event = e || event || window.event
      currKey = event.keyCode || event.which || event.charCode
      if (currKey === 83 && (event.ctrlKey || event.metaKey)) {
        event.preventDefault()
        this.onSave()
      }
    },
    async init() {
      await this.$nextTick()
      const editor = new E(`#${this.richTextId}`)
      editor.config.height = this.$refs.rtfRef.offsetHeight - 50 + ''
      // 配置菜单栏，设置不需要的菜单
      editor.config.excludeMenus = ['emoticon', 'video', 'image', 'table', 'code', 'link', 'backColor']
      editor.config.onchange = (newHtml) => {
        this.$emit('input', newHtml)
      }
      editor.config.onchangeTimeout = 100
      editor.create()
      editor.txt.html(this.value)
      this.editor = editor
    },
    onSave() {
      this.$emit('save', JSON.stringify(this.editor.txt.html()))
    },
  },
  watch: {
    value: function (newValue) {
      this.editor.txt.html(newValue)
      if (newValue) {
        resetPlaceholder(this.editor)
      }
    },
  },
}
</script>

<style lang="less" scoped>
.rtf-page {
  height: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  position: relative;
  .rtf-top {
    padding: 5px 0;
    position: absolute;
    right: 30px;
    z-index: 999;
  }
  #rtfbox {
    height: 100%;
  }
}
</style>
