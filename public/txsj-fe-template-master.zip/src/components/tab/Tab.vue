<template>
  <div class="tab-wrap">
    <div
      class="tab-item"
      v-for="tab in tabList"
      :key="tab[config.code]"
      :class="tab[config.code] == activeTab ? 'active' : ''"
      @click="onTabClick(tab[config.code])"
    >
      <base-icon class="tab-item-icon" :iconName="tab?.icon || ''" style="margin-right: 4px" v-show="tab.icon"></base-icon>
      <span>{{ tab[config.name] }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tab',
  props: {
    tabList: {
      type: Array,
      default: () => [],
    },
    initActive: {
      type: String,
      default: '',
    },
    config: {
      type: Object,
      default: () => {
        return {
          name: 'name',
          code: 'code',
        }
      },
    },
  },
  data() {
    return {
      activeTab: '',
    }
  },
  watch: {
    activeTab: {
      handler() {
        this.$emit('input', this.activeTab)
      },
      immediate: true,
    },
    initActive: {
      handler(val) {
        if (val) this.onTabClick(val)
      },
      immediate: true,
    },
  },
  methods: {
    onTabClick(code) {
      this.activeTab = code
      this.$emit('tabClick', this.activeTab)
    },
  },
}
</script>
<style lang="less" scoped>
.tab-wrap {
  width: 100%;
  height: 40px;
  border-bottom: 1px solid #dcdfe6;
  overflow-x: auto;
  white-space: nowrap;
}
.tab-item {
  display: inline-block;
  height: 100%;
  padding: 0 10px;
  border: 1px solid #dcdfe6;
  border-bottom: none;
  user-select: none;
  cursor: pointer;
  line-height: 40px;
  border-right: none;
}
.tab-item:first-child {
  border-radius: 3px 0px 0 0;
}
.tab-item:last-child {
  border-radius: 0px 3px 0 0;
  border-right: 1px solid #dcdfe6;
}
.tab-item.active {
  color: #409eff;
}
</style>
