### 表单组件使用

> 支持 select、radio、checkbox、time、date、datetime、switch、slider、color、number、textarea、input

- 弹窗表单

> 超过六个之后分两行显示

```javascript
// 示例
<FormDialog ref="FormDialogRef" @update="onDialogUpdate" />

// 显示弹窗
this.$refs.FormDialogRef.show('弹窗名称', this.columnList, row)

```

- 行内表单

```javascript
// 示例
<InlineForm :formItems="columnList" :btnList="queryFormBtns" @btnFn='onBtnFn'></InlineForm>

// 数据
queryFormBtns: [
    {
        code: 'search',
        type: 'primary',
        label: '查询',
        icon: 'el-icon-search',
        action: this.handleSearch,
    },
    {
        code: 'reset',
        label: '重置',
        icon: 'el-icon-refresh-right',
        action: this.handleReset,
    },
    {
        code: 'add',
        type: 'success',
        label: '新增',
        icon: 'el-icon-plus',
        action: this.handleAdd,
    },
    {
        code: 'delete',
        type: 'danger',
        label: '批量删除',
        icon: 'el-icon-delete',
        action: this.handleDeleteBatch,
        disabled: this.deleteDisabled,
    },
    {
        code: 'template',
        type: 'primary',
        label: '下载模板',
        icon: 'el-icon-download',
        action: this.handleTemplateExport,
    },
    {
        code: 'import',
        type: 'primary',
        label: '导入',
        icon: 'el-icon-upload',
        action: this.handleImport,
    },
    {
        code: 'export',
        type: 'primary',
        label: '导出',
        icon: 'el-icon-download',
        action: this.handleExport,
    },
]

// 方法
deleteDisabled() {
    return this.multipleSelection.length < 1
},
onBtnFn() {
    switch (code) {
        case 'search':
            this.handleSearch()
            break;
        case 'reset':
            this.handleReset()
            break;
        case 'add':
            this.handleAdd()
            break;
        case 'delete':
            this.handleDeleteBatch()
            break;
        case 'template':
          this.handleTemplateExport()
          break
        case 'import':
          this.handleImport()
          break
        case 'export':
          this.handleExport()
          break
        default:
            break;
    }
}

```
