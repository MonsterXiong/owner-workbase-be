<template>
  <el-form :model="queryForm" inline size="small" ref="queryFormRef" @submit.native.prevent>
    <div class="inline-form-wrap">
      <div class="left">
        <FormItem v-for="item in formItemLeft" :key="item.code" :itemData="item" :formData="queryForm" />
        <el-form-item>
          <el-button
            v-for="btnItem in leftBtnList"
            :key="btnItem.code"
            :type="btnItem.type"
            :icon="btnItem.icon"
            :disabled="isFunction(btnItem.disabled) ? btnItem.disabled() : btnItem.disabled"
            @click="onBtnClick(btnItem)"
          >
            {{ btnItem.label }}
          </el-button>
          <slot name="left"></slot>
        </el-form-item>
      </div>
      <div class="right">
        <FormItem v-for="item in formItemRight" :key="item.code" :itemData="item" :formData="queryForm" />
        <el-form-item>
          <el-button
            v-for="btnItem in rightBtnList"
            :key="btnItem.code"
            :type="btnItem.type"
            :icon="btnItem.icon"
            :disabled="isFunction(btnItem.disabled) ? btnItem.disabled() : btnItem.disabled"
            @click="onBtnClick(btnItem)"
          >
            {{ btnItem.label }}
          </el-button>
          <slot name="right"></slot>
        </el-form-item>
      </div>
    </div>
  </el-form>
</template>

<script>
import FormItem from './FormItem.vue'
import { isFunction } from '@/utils/commonUtil.js'
export default {
  name: 'InlineForm',
  props: {
    formItems: {
      type: Array,
      required: true,
    },
    btnList: {
      type: Array,
      default: () => [],
    },
    // 外部传入对应表单数据
    form: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      queryForm: {},
      isFunction,
    }
  },
  computed: {
    formItemLeft() {
      return this.formItems.filter((item) => item.query && (item.position === 'left' || !item.position))
    },
    formItemRight() {
      return this.formItems.filter((item) => item.query && item.position === 'right')
    },
    leftBtnList() {
      return this.btnList.filter((item) => item.position === 'left' || !item.position)
    },
    rightBtnList() {
      return this.btnList.filter((item) => item.position === 'right')
    },
  },
  methods: {
    onBtnClick(item) {
      if (item.code === 'reset') this.queryForm = {}
      this.$emit('btnFn', item.code, this.queryForm)
    },
  },
  components: { FormItem },
  watch: {
    form: {
      handler() {
        this.queryForm = { ...this.form }
      },
      deep: true,
    },
  },
}
</script>

<style lang="less" scoped>
.el-form {
  width: 100%;
}
.inline-form-wrap {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>
