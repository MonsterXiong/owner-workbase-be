<template>
  <el-form-item :label="itemData.label" :prop="itemData.code">
    <!-- 下拉框 -->
    <template v-if="itemData.type === 'select'">
      <el-select
        v-model="formData[itemData.code]"
        :placeholder="`请选择${itemData.label}`"
        :clearable="itemData.clearable"
        :disabled="itemData.disabled"
        :multiple="itemData.multiple"
        :filterable="itemData.filterable"
      >
        <el-option
          v-for="item in itemData.options"
          :key="item[itemData.defaultProps?.value || 'value']"
          :label="item[itemData.defaultProps?.label || 'label']"
          :value="item[itemData.defaultProps?.value || 'value']"
          :disabled="item.disabled"
        >
        </el-option>
      </el-select>
    </template>
    <!-- treeselect树形下拉框 -->
    <template v-else-if="itemData.type === 'treeselect'">
      <TreeSelect
        style="width: 100%"
        :placeholder="`请选择${itemData.label}`"
        v-model="formData[itemData.code]"
        :clearable="itemData.clearable"
        :flat="itemData.flat"
        appendToBody
        :normalizer="normalizer"
        :options="itemData.options"
        :default-expand-level="Infinity"
        noOptionsText="暂无数据"
        class="vueTreeSelectSmall"
        :zIndex="treeSelectZindex"
        :multiple="itemData.multiple"
      >
        <label slot="value-label" slot-scope="{ node }">
          <span>{{ getTreeNodeValue(node) }}</span>
        </label>
      </TreeSelect>
    </template>
    <!-- 单选框 -->
    <template v-else-if="itemData.type === 'radio'">
      <el-radio-group v-model="formData[itemData.code]" :disabled="itemData.disabled">
        <el-radio
          v-for="item in itemData.options"
          :key="item[itemData.defaultProps?.value || 'value']"
          :label="item[itemData.defaultProps?.value || 'value']"
          :disabled="item.disabled"
        >
          {{ item[itemData.defaultProps?.label || 'label'] }}
        </el-radio>
      </el-radio-group>
    </template>
    <!-- 多选框 -->
    <template v-else-if="itemData.type === 'checkbox'">
      <el-checkbox-group v-model="formData[itemData.code]" :disabled="itemData.disabled">
        <el-checkbox
          v-for="item in itemData.options"
          :key="item[itemData.defaultProps?.value || 'value']"
          :label="item[itemData.defaultProps?.value || 'value']"
          :disabled="item.disabled"
        >
          {{ item[itemData.defaultProps?.label || 'label'] }}
        </el-checkbox>
      </el-checkbox-group>
    </template>
    <!-- 时间选择器 -->
    <template v-else-if="itemData.type === 'time'">
      <el-time-picker
        v-model="formData[itemData.code]"
        :placeholder="`请选择${itemData.label}`"
        :value-format="timeFormat.includes(itemData.dataFormat?.trim()) ? itemData.dataFormat : 'HH:mm:ss'"
        :disabled="itemData.disabled"
      ></el-time-picker>
    </template>
    <!-- 日期选择器 -->
    <template v-else-if="itemData.type === 'date'">
      <el-date-picker
        v-model="formData[itemData.code]"
        :placeholder="`请选择${itemData.label}`"
        :value-format="dateFormat.includes(itemData.dataFormat?.trim()) ? itemData.dataFormat : 'yyyy-MM-dd'"
        :disabled="itemData.disabled"
      ></el-date-picker>
    </template>
    <!-- 日期时间选择器 -->
    <template v-else-if="itemData.type === 'datetime'">
      <el-date-picker
        v-model="formData[itemData.code]"
        :placeholder="`请选择${itemData.label}`"
        :format="getDateTimeFormat().includes(itemData.dataFormat?.trim()) ? itemData.dataFormat : 'yyyy-MM-dd HH:mm:ss'"
        :disabled="itemData.disabled"
      >
      </el-date-picker>
    </template>
    <!-- Switch 开关 -->
    <template v-else-if="itemData.type === 'switch'">
      <el-switch
        v-model="formData[itemData.code]"
        :disabled="itemData.disabled"
        :active-color="itemData.activeColor"
        :inactive-color="itemData.inactiveColor"
        :active-text="itemData.activeText"
        :inactive-text="itemData.inactiveText"
      >
      </el-switch>
    </template>
    <!-- Slider 滑块 -->
    <template v-else-if="itemData.type === 'slider'">
      <el-slider v-model="formData[itemData.code]" :disabled="itemData.disabled"></el-slider>
    </template>
    <!-- 颜色选择器 -->
    <template v-else-if="itemData.type === 'color'">
      <el-color-picker v-model="formData[itemData.code]" :disabled="itemData.disabled" :color-format="itemData.colorFormat"></el-color-picker>
    </template>
    <!-- 数字框 -->
    <template v-else-if="itemData.type === 'number'">
      <el-input-number
        v-model="formData[itemData.code]"
        :min="itemData.min || itemData.min === 0 ? itemData.min : -Infinity"
        :max="itemData.max ? itemData.max : Infinity"
        :controls="itemData.controls"
        :controls-position="itemData.controlsPosition"
        :placeholder="`请输入${itemData.label}`"
        :disabled="itemData.disabled"
      ></el-input-number>
    </template>
    <!-- 文本域 -->
    <template v-else-if="itemData.type === 'textarea'">
      <el-input type="textarea" v-model="formData[itemData.code]" :placeholder="`请输入${itemData.label}`" :disabled="itemData.disabled"></el-input>
    </template>
    <!-- 图片 目前图片跟文件分开处理 -->
    <template v-else-if="itemData.type === 'picture'">
      <UploadFile
        @upload="onFileChange"
        :filePath="filePathUrl(formData[itemData.code])"
        :itemData="itemData"
        :multipleImportFile="itemData.multiple"
      ></UploadFile>
    </template>
    <!-- 输入框 -->
    <template v-else>
      <el-input v-model="formData[itemData.code]" :placeholder="`请输入${itemData.label}`" :disabled="itemData.disabled"></el-input>
    </template>
  </el-form-item>
</template>

<script>
import TreeSelect from '@riophae/vue-treeselect'
import '@riophae/vue-treeselect/dist/vue-treeselect.css'
import UploadFile from '@/components/upload/UploadFile.vue'
import { getTreeNodeValue } from '@/utils/treeSelectFn'
import tools from '@/utils/tools'
import configData from '@/utils/config'

export default {
  name: 'FormItem',
  props: {
    itemData: {
      type: Object,
      default: () => {},
    },
    formData: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      timeFormat: ['HH:mm', 'HH:mm:ss'],
      dateFormat: ['yyyy-MM-dd', 'yyyy/MM/dd', 'yyyy MM dd', 'yyyy年MM月dd日', 'yyyy-MM', 'MM-dd-yyyy'],
      treeSelectZindex: 5999,
      normalizer(node) {
        return {
          id: node.id,
          label: node.label,
          children: node.children,
        }
      },
      getTreeNodeValue,
    }
  },
  computed: {
    filePathUrl() {
      return (value) => (value ? this.getCompleteUrl(value) : '')
    },
  },
  methods: {
    getDateTimeFormat() {
      return this.dateFormat.reduce((pre, cur) => {
        this.timeFormat.forEach((tf) => {
          pre.push(`${cur} ${tf}`)
        })
        return pre
      }, [])
    },
    onFileChange(file, itemData) {
      let type = file.raw.type
      const isImage = ['image/bmp', 'image/jpeg', 'image/jpg', 'image/jp2', 'image/png', 'image/svg+xml', 'image/webp', 'image/gif', 'image/x-icon'].includes(
        type
      )
      if (!isImage) return tools.message('文件必须为图片类型', { type: 'warning' })
      this.$emit('callBack', file, 'pictureFile', itemData)
    },
    getCompleteUrl(path, baseUrl = configData.baseUrl) {
      let subStr = '/'
      let hasEnd = baseUrl.endsWith(subStr)
      let hasStart = path.startsWith(subStr)
      let url = ''
      if (hasEnd && hasStart) {
        url = baseUrl.substring(0, baseUrl.length - 1) + path
      } else if (!hasEnd && !hasStart) {
        url = baseUrl + subStr + path
      } else {
        url = baseUrl + path
      }
      return url
    },
  },
  components: { TreeSelect, UploadFile },
}
</script>

<style lang="less" scoped>
.el-input-number,
.el-date-editor {
  width: 100%;
}
</style>
