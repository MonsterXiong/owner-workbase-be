<template>
  <base-dialog :title="dialogTitle" :visible.sync="dialogVisible" :width="formConfig.dialogWidth" :before-close="onHide">
    <el-form :model="formData" :rules="formRules" ref="formRef" label-width="auto">
      <el-row v-for="index in halfLengthList" :gutter="20" :key="index">
        <el-col :span="formItemList[index].span ? formItemList[index].span : formItemList.length > itemNum ? 12 : 24">
          <slot :name="formItemList[index].code" v-bind="formData">
            <FormItem :itemData="formItemList[index]" :formData="formData" @callBack="formItemCallBackFn" />
          </slot>
        </el-col>
        <el-col :span="formItemList[index + 1]?.span ? formItemList[index + 1].span : formItemList.length > itemNum ? 12 : 24">
          <slot :name="formItemList[index + 1]?.code" v-bind="formData">
            <FormItem :itemData="formItemList[index + 1]" :formData="formData" @callBack="formItemCallBackFn" />
          </slot>
        </el-col>
      </el-row>
      <slot v-bind="formData"></slot>
    </el-form>
    <template slot="footer">
      <el-button size="medium" @click="onHide()">取 消</el-button>
      <el-button size="medium" type="primary" @click="onSubmit">确 定</el-button>
    </template>
  </base-dialog>
</template>

<script>
import { DialogWidths } from '@/common/baseConstants'
import FormItem from './FormItem.vue'
import { mergeObj } from '@/utils/commonUtil'
const baseConfig = {
  dialogWidth: DialogWidths.MEDIUM_FORM,
}

export default {
  name: 'FormDialog',
  props: {
    config: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      dialogTitle: '',
      dialogVisible: false,
      // width: DialogWidths.MEDIUM_FORM,
      formData: {},
      formRules: {},
      formItemList: [],
      itemNum: 6,
    }
  },
  computed: {
    // 处理一行显示两个，总数为单数时的错乱
    halfLengthList() {
      const length = this.formItemList.length
      const result = []
      for (let i = 0; i < length; i = i + 2) {
        result.push(i)
      }
      return result
    },
    formConfig() {
      return mergeObj(baseConfig, this.config || {})
    },
  },
  methods: {
    show(title, columnList, row) {
      this.dialogTitle = title
      this.formData = row ? { ...row } : {}
      this.formItemList = columnList.filter((item) => !['selection', 'index', 'button'].includes(item.type))
      this.setFormRules()
      this.dialogVisible = true
    },
    setFormRules() {
      const rulesList = this.formItemList.filter((item) => item.required)
      rulesList.map((item) => {
        this.formRules[item.code] = [
          { required: true, message: `请输入${item.label}`, trigger: item.type === 'input' ? 'blur' : 'chnage' },
          { validator: item.validateFn, trigger: item.type === 'input' ? 'blur' : 'chnage' },
        ]
      })
    },
    // 处理formItem组件派发出来的事件
    async formItemCallBackFn(params, code, itemData) {
      switch (code) {
        case 'pictureFile':
          if (this.$listeners.pictureFile) return this.$emit('pictureFile', params)
          const { data } = await this.onUploadFileAPI(params.raw)
          this.formData[itemData.code] = data
          break
        default:
          this.$emit(code, params)
          break
      }
    },
    onSubmit() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.$emit('update', { ...this.formData })
          this.onHide()
        }
      })
    },
    resetForm() {
      this.$refs.formRef.resetFields()
    },
    onHide() {
      this.dialogVisible = false
      this.resetForm()
    },
    // 上传文件
    async onUploadFileAPI(file) {
      return await this.$api.SystemService.uploadFile(file)
    },
  },
  components: { FormItem },
}
</script>

<style lang="less" scoped>
.el-form {
  width: 100%;
  max-height: 500px;
  overflow-y: auto;
  .el-row {
    width: 100%;
  }
}
</style>
