<template>
  <div class="common-page">
    <div class="form-wrap">
      <el-form :model="formData" :rules="formRules" ref="formRef" :label-width="labelWidth">
        <el-row v-for="index in halfLengthList" :gutter="20" :key="index">
          <el-col :span="formItems.length > itemNum ? 12 : 24">
            <FormItem :itemData="formItems[index]" :formData="formData" @callBack="formItemCallBackFn" />
          </el-col>
          <el-col v-if="formItems[index + 1]" :span="formItems.length > itemNum ? 12 : 24">
            <FormItem :itemData="formItems[index + 1]" :formData="formData" @callBack="formItemCallBackFn" />
          </el-col>
        </el-row>
        <slot v-bind="formData"></slot>
      </el-form>
    </div>
    <div class="footer">
      <el-button @click="onSaveForm">保存</el-button>
    </div>
  </div>
</template>

<script>
import FormItem from './FormItem.vue'
import { listToTree } from '@/utils/treeTool'

export default {
  name: 'PageForm',
  props: {
    formItemList: {
      type: Array,
      default: () => [],
    },
    form: {
      type: Object,
    },
    labelWidth: {
      type: String,
      default: 'auto',
    },
  },
  data() {
    return {
      formData: {},
      formRules: {},
      formItems: [],
      itemNum: 12,
    }
  },
  computed: {
    // 处理一行显示两个，总数为单数时的错乱
    halfLengthList() {
      const length = this.formItems.length
      const result = []
      for (let i = 0; i < length; i = i + 2) {
        result.push(i)
      }
      return result
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      await this.setColumnOptions()
      this.$nextTick(() => {
        this.setFormRules()
        this.formItems = this.formItemList.filter((item) => !['selection', 'index', 'button'].includes(item.type))
        this.handleFormItemMultipleOrSwitch(this.formData)
      })
    },
    onSaveForm() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.$emit('saveForm', { ...this.formData })
        }
      })
    },
    // 处理formItem组件派发出来的事件
    async formItemCallBackFn(params, code, itemData) {
      switch (code) {
        case 'pictureFile':
          if (this.$listeners.pictureFile) return this.$emit('pictureFile', params)
          const { data } = await this.onUploadFileAPI(params.raw)
          this.formData[itemData.code] = data
          break
        default:
          this.$emit(code, params)
          break
      }
    },
    setFormRules() {
      const rulesList = this.formItemList.filter((item) => item.required)
      rulesList.map((item) => {
        this.formRules[item.code] = [
          { required: true, message: `请输入${item.label}`, trigger: item.type === 'input' ? 'blur' : 'chnage' },
          { validator: item.validateFn, trigger: item.type === 'input' ? 'blur' : 'chnage' },
        ]
      })
    },
    // 设置column中的options
    async setColumnOptions() {
      const instanceItems = this.formItemList.filter((item) => item.dataType === 'interface')
      const enumItems = this.formItemList.filter((item) => item.dataType === 'enum')
      // 枚举
      enumItems.forEach((ele) => {
        const index = this.formItemList.findIndex((item) => item.code === ele.code)
        this.formItemList[index] = {
          ...this.formItemList[index],
          options: [...this.$enum.getOption(ele.params)],
        }
      })
      // 接口
      const instanceMap = new Map()
      instanceItems.forEach((item) => {
        const optService = item.params.service
        instanceMap.set(optService, instanceMap.get(optService) ? instanceMap.get(optService).concat(item.code) : [item.code])
      })
      for (const iterator of instanceMap) {
        const { data } = await this.getInstanceOption(iterator[0])
        if (iterator[1]?.length > 0) {
          // 设置columns
          iterator[1].forEach((code) => {
            const index = this.formItemList.findIndex((item) => item.code === code)
            const itemData = this.formItemList[index]
            let optionData = [...data]
            // 处理树形数据
            if (['treeselect'].includes(itemData.type)) {
              const listData = data.map((item) => {
                return {
                  ...item,
                  id: item[itemData.defaultProps.id],
                  label: item[itemData.defaultProps.label],
                  parentId: item[itemData.defaultProps.parentId],
                }
              })
              optionData = listToTree(listData)
            }
            this.formItemList[index] = {
              ...this.formItemList[index],
              options: optionData,
            }
          })
        }
      }
    },
    // 处理多选和switch的值
    handleFormItemMultipleOrSwitch(formData, data = {}) {
      const formItems = this.formItems.filter((item) => item.type === 'checkbox' || (item.type === 'select' && item.multiple))
      const switchItems = this.formItems.filter((item) => item.type === 'switch')
      formItems.forEach((item) => {
        formData[item.code] = data[item.code]?.join(',') || []
      })
      switchItems.forEach((item) => {
        formData[item.code] = data[item.code] == 1 && data[item.code] == true ? 1 : 0
      })
    },
    // 查询options数据
    async getInstanceOption(optInterface, params) {
      return await this.$getInterface(optInterface, 'query')(params)
    },
    // 上传文件
    async onUploadFileAPI(file) {
      return await this.$api.SystemService.uploadFile(file)
    },
  },
  components: { FormItem },
  watch: {
    formItemList: {
      handler() {
        this.init()
      },
    },
    form: {
      handler() {
        this.formData = { ...this.form }
        console.log(this.formData)
      },
      deep: true,
    },
  },
}
</script>

<style lang="less" scoped>
.form-wrap {
  height: calc(100% - 40px);
  .el-form {
    height: 100%;
    overflow-y: auto;
    .el-row {
      width: 100%;
    }
  }
}
.footer {
  height: 35px;
  text-align: center;
}
::v-deep {
  .el-select {
    width: 100%;
  }
}
</style>
