<template>
  <div class="com-echart" ref="echartRef"></div>
</template>

<script>
import * as echarts from 'echarts'
import ElementResizeDetectorMaker from 'element-resize-detector'

export default {
  props: {
    option: {
      type: Object,
      default: () => null,
    },
    autoHighlight: {
      type: Boolean,
    },
    autoAloneHighlight: {
      type: Boolean,
    },
  },
  inject: ['echartTheme'],
  data() {
    this.myEchart = null
    this.resizeListen = null
    return {
      curIndex: 0,
      timer: null,
    }
  },
  mounted() {
    this.initEchart()
    // 监听窗口变化,使地图自适应填充
    this.resizeListen = ElementResizeDetectorMaker()
    this.resizeListen.listenTo(this.$el, () => {
      if (this.myEchart && this.myEchart.resize) this.myEchart.resize()
    })
  },
  watch: {
    option: {
      handler() {
        if (this.option) {
          this.setOption()
        }
      },
    },
    immediate: true,
  },
  methods: {
    initEchart() {
      this.myEchart && this.myEchart.dispose()
      if (this.echartTheme) {
        let themeName = 'theme' + Math.floor(Math.random() * 10)
        echarts.registerTheme(themeName, this.echartTheme)
        this.myEchart = echarts.init(this.$refs.echartRef, themeName)
      } else this.myEchart = echarts.init(this.$refs.echartRef)
      this.$emit('initEchart', this.myEchart)
    },
    setOption() {
      if (!this.myEchart) {
        this.initEchart()
      }

      if (this.option) this.myEchart.setOption(this.option)
      this.autoHighlight && this.setSelect()
      this.autoAloneHighlight && this.setAloneSelect()
    },
    // 获取echart实例
    getInstance() {
      return this.myEchart
    },
    setSelect() {
      let data = this.option.series[0].data
      this.timer = setInterval(() => {
        let dataLen = data.length
        this.curIndex = (this.curIndex + 1) % dataLen
        for (const index in data) {
          if (!this.myEchart) {
            clearInterval(this.timer)
            break
          }
          this.myEchart.dispatchAction({
            type: 'downplay',
            seriesIndex: 0,
            dataIndex: index,
          })

          this.myEchart.dispatchAction({
            type: 'highlight',
            seriesIndex: 0,
            dataIndex: this.curIndex,
          })
        }
      }, 1000)
    },
    setAloneSelect() {
      let data = this.option.series[0].data
      let type = 'highlight'
      this.timer = setInterval(() => {
        for (const index in data) {
          if (!this.myEchart) {
            clearInterval(this.timer)

            break
          }
          this.myEchart.dispatchAction({
            type: type,
            seriesIndex: 0,
            dataIndex: index,
          })
        }
        type = type === 'downplay' ? 'highlight' : 'downplay'
      }, 500)
    },
  },
  beforeDestroy() {
    this.myEchart && this.myEchart.dispose()
    this.myEchart = null
    this.resizeListen.uninstall(this.$el)
    this.resizeListen = null
    clearInterval(this.timer)
  },
}
</script>

<style scoped lang="less">
.com-echart {
  height: 100%;
  width: 100%;
}
</style>
