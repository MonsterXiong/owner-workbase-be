<template>
  <!-- 组织图组件 -->
  <div class="org-diagram">
    <Toolbar
      :addToolList="addToolList"
      :saveMode="saveMode"
      :diasbleToolCode="diasbleToolCode"
      @toolbarClick="onToolbarClick"
      @changeNodeStyle="changeNodeStyle"
      v-show="!hideTool"
    >
      <slot></slot
    ></Toolbar>
    <main :style="hideTool ? `height:100%` : ''">
      <div id="orgDiagram" ref="orgDiagramRef" style="height: 100%"></div>
    </main>
    <ContextMenu ref="contextMenuRef" :menuList="contextMenuList" />
    <!-- <div id="orgDiagram" ></div> -->
  </div>
</template>

<script>
import * as go from 'gojs'
import { v4 as uuidv4 } from 'uuid'
import { linkTemplate, nodeTemplate, tagNodeHorizontalTemplate, tagNodeVerticalTemplate } from './gojs/diagramTemplate'
import { findUpOrDownNode, exchangeNodeValue, changeLayoutAngle } from './gojs/gojsHelper'
import ContextMenu from './ContextMenu.vue'
import Toolbar from './Toolbar.vue'
import { DefaultAddNodeConfig } from './gojs/typeConfig'
import { taskNodeTemplate } from './gojs/taskNodeTemplate'
import {
  lightNodeTemplate,
  darkNodeTemplate,
  darkTagNodeTemplate,
  iconTagNodeTemplate,
  ruleNodeTemplate,
  systemStructNodeTemplate,
  lightIconNodeTemplate,
  dashNodeTemplate,
} from './gojs/nodeTemplate/NodeTemplate'
import tools from '@/utils/tools'
const $ = go.GraphObject.make

export default {
  name: 'OrgDiagram',
  inject: ['nodeTemp', 'linkTemp', 'orgNodeType'],
  props: {
    nodeList: {
      type: Array,
      default: () => [],
    },
    defaultAngle: { type: Number, default: 0 },
    saveMode: {
      type: String,
      default: 'save', //monitor
    },
    addToolList: {
      type: Array,
      default: () => [],
    },
    nodeTemplate: {
      type: Object,
    },
    defaultTemplate: {
      type: String,
    },
    addNodeConfig: {
      type: Object,
    },
    textList: {
      type: Array,
      // default: () => [{ code: 'remark', title: '描述' }],
      default: () => [],
    },
    forbidDeleteIds: {
      type: Array,
      default: () => [],
    },
    forbidRootNodeType: {
      type: Array,
      default: () => [],
    },
    hideTool: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      diagram: null,
      nodeData: [],
      contextMenuList: [],
      angle: 0,
      tempConfig: {},
      diasbleToolCode: [],
    }
  },
  computed: {
    // isRoot() {
    //   return this.activeNodeData?.type == 'mainFunction'
    // },
    selection() {
      return this.diagram?.selection
    },
    activeNode() {
      return this.diagram?.selection?.first()
    },
    activeNodeData() {
      return this.activeNode?.data
    },
  },
  watch: {
    nodeList: {
      handler() {
        this.$nextTick(() => {
          this.setNodeData()
        })
      },
      immediate: true,
    },
    defaultAngle: {
      handler() {
        this.angle = this.defaultAngle
      },
      immediate: true,
    },
    activeNodeData: {
      handler(val) {
        this.diasbleToolCode = []
        if (val) {
          let allowType = this.addNodeConfig[this.activeNodeData?.nodeType].allowType || []
          if (allowType.length != 0)
            this.addToolList.forEach((ele) => {
              if (!allowType.find((code) => code == ele.addTemplateCode)) {
                this.diasbleToolCode.push(ele.addTemplateCode)
              }
            })
        }
        console.log(this.diasbleToolCode, '***')
        this.$emit('setCurrentNodeData', this.activeNodeData)
      },
    },
  },
  beforeDestroy() {
    this.$emitter.off('treeGraphContextmenuShow', this.showContextMenu)
    this.$emitter.off('treeGraphContextmenuHide', this.hideContextMenu)
    this.$emitter.off('updateActiveNodeData', this.updateActiveNodeData)
  },
  methods: {
    async initDiagram(fn) {
      if (this.diagram) {
        this.diagram.div = null
        this.diagram = null
      }
      const diagram = $(go.Diagram, this.$refs.orgDiagramRef, {
        allowDelete: false,
        allowTextEdit: true,
        layout: $(go.TreeLayout, {
          sorting: go.TreeLayout.SortingAscending,
          angle: this.angle,
          comparer: function (a, b) {
            const da = a.node.data
            const db = b.node.data
            return parseInt(da.sortValue) - parseInt(db.sortValue) > 0 ? 1 : -1
          },
        }),
        model: new go.TreeModel({
          nodeKeyProperty: 'id',
          nodeParentKeyProperty: 'parentId',
        }),
        padding: new go.Margin(54, 0, 0, 0),
      })
      await this.settempConfig()
      diagram.nodeTemplate = this.getNodeTemplate(this.defaultTemplate)
      diagram.linkTemplate = this.linkTemp ? this.linkTemp() : linkTemplate()
      this.diagram = diagram
      window.diagram = diagram
      if (fn) fn()
      this.initEventListener()
      this.setNodeTemplateMap()
    },
    settempConfig() {
      this.tempConfig = {
        node1: lightNodeTemplate({ angle: this.angle, textList: [] }),
        node2: lightNodeTemplate({ angle: this.angle, textList: this.textList }),
        node3: lightIconNodeTemplate({ angle: this.angle, textList: [] }),
        node4: darkNodeTemplate({ angle: this.angle }),
        node5: darkTagNodeTemplate({ angle: this.angle, textList: this.textList || [] }),
        node6: iconTagNodeTemplate({}, { angle: this.angle, textList: [] }),
        node7: iconTagNodeTemplate({}, { angle: this.angle, textList: this.textList }),

        node8: ruleNodeTemplate({ angle: this.angle, textList: [] }),
        node9: ruleNodeTemplate({ angle: this.angle, textList: this.textList }),

        node10: systemStructNodeTemplate({}, { angle: this.angle, textList: [] }),
        node11: systemStructNodeTemplate({}, { angle: this.angle, textList: this.textList }),

        node12: dashNodeTemplate({ angle: this.angle, dash: [0, 0], textList: [] }),
        node13: dashNodeTemplate({ angle: this.angle, textList: this.textList, dash: [8, 8] }),
        vertical: tagNodeVerticalTemplate({ angle: this.angle }),
        horizontal: tagNodeHorizontalTemplate({ angle: this.angle }),
        task: taskNodeTemplate({ angle: this.angle, textList: this.textList }),
        default: nodeTemplate(),
      }
    },
    setNodeTemplateMap() {
      for (const key in this.tempConfig) {
        const temp = this.tempConfig[key]
        this.diagram.nodeTemplateMap.add(key, temp)
      }
    },
    setNodeData() {
      this.nodeData = []
      this.nodeList.map((node, index) => {
        if (node.id) {
          let sortValue = node.parentId ? index : 0
          this.nodeData.push({ ...node, sortValue: node.sortValue || sortValue, _type: node._type || 'default', category: node.category || '' })
        }
      })
      this.renderDiagram()
    },
    renderDiagram() {
      if (this.diagram) {
        this.diagram.model.nodeDataArray = [...this.nodeData]
      } else {
        this.initDiagram(() => {
          this.diagram.model.nodeDataArray = [...this.nodeData]
        })
      }
    },
    getNodeTemplate(code = 'horizontal') {
      let res
      if (this.nodeTemplate) return this.nodeTemplate
      if (this.nodeTemp) return this.nodeTemp({ angle: this.angle })
      if (this.orgNodeType && this.tempConfig[this.orgNodeType]) return this.tempConfig[this.orgNodeType]
      res = this.tempConfig[code] || this.tempConfig.default
      return res
    },
    initEventListener() {
      this.$emitter.on('treeGraphContextmenuShow', this.showContextMenu)
      this.$emitter.on('treeGraphContextmenuHide', this.hideContextMenu)
      this.$emitter.on('updateActiveNodeData', this.updateActiveNodeData)
    },
    hideContextMenu() {
      this.$refs['contextMenuRef']?.hide()
    },
    showContextMenu({ obj, diagram, tool }) {
      const viewPoint = diagram.lastInput.viewPoint
      const mockEvent = {
        clientX: viewPoint.x,
        clientY: viewPoint.y,
        type: 'canvas',
        w: 0,
        h: 50,
      }
      this.contextMenuList = this.getContextMenuList(obj)
      this.$nextTick(() => {
        this.$refs['contextMenuRef']?.show(mockEvent)
      })
    },
    getContextMenuList(obj) {
      let nodeType = obj.data.nodeType || ''
      if (obj instanceof go.Node) {
        let arr = [
          {
            title: '删除节点',
            code: 'delete',
            action: () => {
              this.handleDelete()
            },
            params: obj,
          },
        ]
        if (this.addToolList) {
          let allowType = this.addNodeConfig[nodeType].allowType || []
          this.addToolList.map((ele) => {
            if (allowType.length == 0 || allowType.find((code) => code == ele.addTemplateCode)) {
              arr.push({
                title: ele.name,
                code: ele.code,
                addTemplateCode: ele.addTemplateCode,
                action: () => {
                  this.handleAdd(ele?.addTemplateCode || '')
                },
                params: obj,
              })
            }
          })
        } else {
          arr.push({
            title: '添加节点',
            code: 'add',
            action: () => {
              this.handleAdd()
            },
            params: obj,
          })
        }
        return arr
      } else return []
    },
    getDeleteListById(node) {
      let childrens = this.nodeData.filter((v) => v.parentId === node.id)
      if (childrens.length === 0) return []
      childrens.forEach((children) => {
        childrens = childrens.concat(this.getDeleteListById(children))
      })
      return childrens
    },
    handleDelete() {
      if (!this.activeNodeData) {
        return
      }
      if (this.forbidDeleteIds.find((id) => id == this.activeNodeData.id)) {
        this.$message.warning('当前节点不可删除')
        return
      }
      const downnode = findUpOrDownNode(this.diagram, this.activeNode, 1)
      const upnode = findUpOrDownNode(this.diagram, this.activeNode, -1)
      let parentNode = this.activeNodeData.parentId ? this.diagram.findNodeForKey(this.activeNodeData.parentId) : null
      let deleteList = this.getDeleteListById(this.activeNodeData)
      deleteList = [this.activeNodeData, ...deleteList]
      this.diagram.model.removeNodeDataCollection(deleteList)
      const deleteIds = deleteList.map((item) => item.id)
      this.nodeData = this.nodeData.filter((item) => !deleteIds.includes(item.id))
      if (downnode) {
        this.diagram.select(downnode)
      } else {
        if (upnode) this.diagram.select(upnode)
        else {
          if (parentNode) this.diagram.select(parentNode)
        }
      }
      this.$emit('deleteNode', deleteList)
    },
    deleteNodeById(id) {
      const node = this.diagram.findNodeForKey(id)
      this.diagram.model.removeNodeData(node.data)
    },
    _uuid() {
      const id = uuidv4()
      return id.replace(/-/g, '')
    },
    handleAdd(addTemplateCode = '') {
      if (this.nodeData.length == 0) {
        this.addRoot(addTemplateCode)
      } else {
        this.addChildNode(addTemplateCode)
      }
    },
    addRoot(addTemplateCode) {
      let staticParams = DefaultAddNodeConfig
      if (addTemplateCode) {
        staticParams = this.addNodeConfig[addTemplateCode]
        if (this.forbidRootNodeType.find((ele) => ele == staticParams.nodeType)) {
          tools.message('根节点不可为此类型', { type: 'info' })
          return
        }
      }
      const params = {
        id: this._uuid(),
        sortValue: 0,
        name: staticParams?.nodeLabel || '根节点',
        tag: staticParams?.tag || '',
        parentId: '',
        _type: staticParams?._type || '',
        nodeType: staticParams?.nodeType || '',
        category: staticParams?.category || '',
        properties: {
          ...staticParams.template,
        },
      }
      for (const key in staticParams.matchCode) {
        const match = staticParams.matchCode[key]
        params.properties[match] = params[key]
      }
      this.diagram.model.addNodeData(params)
      this.nodeData.push(params)
      const node = this.diagram.findNodeForKey(params.id)
      this.diagram.select(node)
      // this.diagram.model.setDataProperty(node.data, '_type', 'red')
      this.$emit('addNode', params)
      // console.log(node, 777)
    },
    addChildNode(addTemplateCode) {
      if (!this.activeNodeData) {
        return this.$message.warning('先选择一个节点')
      }
      let staticParams = DefaultAddNodeConfig
      if (addTemplateCode) {
        staticParams = this.addNodeConfig[addTemplateCode]
        let allowType = this.addNodeConfig[this.activeNodeData.nodeType].allowType || []
        if (allowType.length > 0 && !allowType.find((ele) => staticParams.nodeType == ele)) {
          tools.message('当前节点类型下不可添加此类型节点', { type: 'info' })
          return
        }
      }
      const params = {
        id: this._uuid(),
        sortValue: this.nodeData.length,
        name: (staticParams?.nodeLabel || '子节点') + this.nodeData.length,
        tag: staticParams?.tag || '',
        parentId: this.activeNodeData.id,
        _type: staticParams?._type || '',
        nodeType: staticParams?.nodeType || '',
        category: staticParams?.category || '',
        properties: {
          ...staticParams.template,
        },
      }
      for (const key in staticParams.matchCode) {
        const match = staticParams.matchCode[key]
        params.properties[match] = params[key]
      }
      this.diagram.model.addNodeData(params)
      this.nodeData.push(params)
      this.$emit('addNode', params)
    },
    extAddNodeData(params) {
      this.diagram.model.addNodeData(params)
      this.nodeData.push(params)
      // this.$emit('addNode', params)
    },
    //上移
    upNode() {
      const node = findUpOrDownNode(this.diagram, this.activeNode, -1)
      if (node) {
        exchangeNodeValue(this.diagram, this.activeNode.data, node.data, 'sortValue')
        this.$emit('updateNode', [this.activeNode.data, node.data])
      }
    },
    // 下移
    downNode() {
      const node = findUpOrDownNode(this.diagram, this.activeNode, 1)
      if (node) {
        exchangeNodeValue(this.diagram, this.activeNode.data, node.data, 'sortValue')
        this.$emit('updateNode', [this.activeNode.data, node.data])
      }
    },
    export() {
      this.$emit('export', this.diagram)
    },
    onToolbarClick(data) {
      let code = data.code
      switch (code) {
        case 'save':
          // 保存
          this.saveDiagram()
          break
        case 'delete':
          // 删除
          this.handleDelete()
          break
        case 'add':
          // 添加
          this.handleAdd(data?.addTemplateCode || '')
          break
        case 'moveUp':
          // 上移
          this.upNode()
          break
        case 'moveDown':
          // 下移
          this.downNode()
          break
        case 'export':
          // 导出
          this.export()
          break
        case 'horizontal':
          this.changeAngle(0)
          break
        case 'vertical':
          this.changeAngle(90)
          break

        default:
          break
      }
    },
    changeNodeStyle(code) {
      const node = this.diagram.findNodeForKey(this.activeNodeData?.id)
      if (node) {
        this.diagram.model.setDataProperty(node.data, '_type', code)
        this.diagram.model.setDataProperty(node, 'isSelected', false)
        this.diagram.select(node)
        this.$emit('updateNode', [node.data])
      }
    },
    changeAngle(value) {
      changeLayoutAngle(this.diagram, { value })
    },
    saveDiagram() {
      this.$emit('saveDiagram', this.diagram.model.nodeDataArray)
    },
    getDiagramNodeData() {
      return this.diagram.model.nodeDataArray
    },
    // 更新当前选中节点数据
    updateActiveNodeData(params, id) {
      const node = this.diagram.findNodeForKey(id ? id : this.activeNodeData?.id)
      if (node) {
        for (const key in params) {
          const element = params[key]
          this.diagram.model.setDataProperty(node.data, key, element)
        }
        if (!id) {
          this.diagram.model.setDataProperty(node, 'isSelected', false)
          this.diagram.select(node)
        }
      }
    },
  },
  components: {
    Toolbar,
    ContextMenu,
  },
}
</script>

<style lang="less" scoped>
.org-diagram {
  height: 100%;
  main {
    height: calc(100% - 50px);
  }
}
</style>
