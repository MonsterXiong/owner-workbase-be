import * as go from 'gojs'
import Vue from 'vue'
import { typeColorConfig, typeImageConfig } from './typeConfig'
const $ = go.GraphObject.make

export const treeGraphContextMenu = $(go.HTMLInfo, {
  show: (obj, diagram, tool) => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuShow', {
      obj,
      diagram,
      tool,
    })
  },
  hide: () => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuHide')
  },
})
export function nodeTemplate() {
  return $(
    go.Node,
    'Vertical',
    {
      selectionObjectName: 'shape',
      contextMenu: treeGraphContextMenu,
    },
    $(
      go.Panel,
      'Spot',
      $(
        go.Panel,
        'Auto',
        $(
          go.Shape,
          'RoundedRectangle',
          {
            name: 'shape',
            cursor: 'pointer',
            fill: 'transparent',
            // stroke: 'red',
            strokeWidth: 1,
          },
          new go.Binding('stroke', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].deep
          }),
          new go.Binding('fill', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].deep
          })
        ),
        $(
          go.TextBlock,
          {
            font: 'bold 14px sans-serif',
            // stroke: 'red',
            margin: new go.Margin(10),
            minSize: new go.Size(86, 0),
            maxSize: new go.Size(210, Infinity),
            textAlign: 'center',
            editable: false,
          },
          new go.Binding('text', 'name').makeTwoWay(),
          new go.Binding('stroke', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].shallow
          })
        )
      )
    )
  )
}

export function linkTemplate(isBezier = true) {
  if (isBezier)
    return $(
      go.Link,
      {
        curve: go.Link.Bezier,
        toEndSegmentLength: 30,
        fromEndSegmentLength: 30,
        corner: 0,
        // routing: go.Link.Orthogonal,
        // corner: 0,
        fromSpot: go.Spot.RightCenter,
        toSpot: go.Spot.LeftCenter,
        reshapable: false,
        resegmentable: false,
      },
      // new go.Binding('fromEndSegmentLength', 'fromEndSegmentLength'),
      // new go.Binding('toEndSegmentLength', 'toEndSegmentLength'),
      $(go.Shape, {
        strokeWidth: 1.5,
        stroke: '#2155c3',
      })
    )
  else
    return $(
      go.Link,
      { routing: go.Link.Orthogonal, corner: 5 },
      $(go.Shape, {
        toArrow: 'Standard',
        stroke: '#5a5a5a',
      })
    )
}

export function tagNodeHorizontalTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      ...options,
    },
    // new go.Binding('location', '', function (nodeData) {
    //   return new go.Point(nodeData.x, nodeData.y)
    // }),
    $(
      go.Panel,
      'Auto',
      $(
        go.Shape,
        {
          stroke: 'transparent',
          fill: 'transparent',
        },
        new go.Binding('stroke', '', function (nodeData, targetObj) {
          const typeValue = nodeData._type || 'default'
          return typeColorConfig[typeValue].deep
        })
      ),
      $(
        go.Panel,
        'Horizontal',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Vertical,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              fill: 'transparent',
              strokeWidth: 1,
              stroke: 'transparent',
            },
            new go.Binding('fill', '', function (nodeData) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            })
          ),
          $(
            go.Panel,
            'Vertical',
            {
              margin: new go.Margin(2, 8),
            },
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 0, 4, 0),
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                width: 14,
                isMultiline: true,
                stroke: '#fff',
              },
              new go.Binding('text', 'tag', function (tag) {
                return tag || ''
              })
            )

            // new go.Binding('margin', 'tag', function (tag) {
            //   return tag ? new go.Margin(2, 8) : new go.Margin(0, 0)
            // })
          )
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
            width: 118,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              strokeWidth: 0,
            },
            new go.Binding('fill', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
            }).ofObject()
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(15, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              width: 100,
            },
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),
    // $(
    //   go.Panel,
    //   'Auto',
    //   {
    //     alignment: go.Spot.Center,
    //     alignmentFocusName: go.Spot.TopLeft,
    //   },
    //   $(
    //     go.Shape,
    //     'Rectangle',
    //     {
    //       fill: 'rgba(0, 0, 0, 0.1)',
    //       stroke: null,
    //       width: 150,
    //       height: 55,
    //       visible: false,
    //     }
    //     // new go.Binding('visible', '_disable')
    //   )
    // ),
    $(
      'TreeExpanderButton',
      {
        alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

export function tagNodeVerticalTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      ...options,
    },
    // new go.Binding('location', '', function (nodeData) {
    //   return new go.Point(nodeData.x, nodeData.y)
    // }),
    $(
      go.Panel,
      'Auto',
      $(
        go.Shape,
        {
          stroke: 'transparent',
          fill: 'transparent',
        },
        new go.Binding('stroke', '', function (nodeData, targetObj) {
          const typeValue = nodeData._type || 'default'
          return typeColorConfig[typeValue].deep
        })
      ),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              fill: 'transparent',
              strokeWidth: 1,
              stroke: 'transparent',
            },
            new go.Binding('fill', '', function (nodeData) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            })
          ),
          $(
            go.Panel,
            'Horizontal',
            {
              // margin: new go.Margin(2, 8),
            },
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 0, 4, 0),
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(5, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#fff',
              },
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              })
            )
          )
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
            width: 118,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              strokeWidth: 0,
            },
            new go.Binding('fill', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
            }).ofObject()
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(18, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              width: 100,
            },
            // new go.Binding('text', 'name'),
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),

    $(
      'TreeExpanderButton',
      {
        alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}
