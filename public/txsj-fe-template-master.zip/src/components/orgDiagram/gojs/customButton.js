import * as go from 'gojs'
go.GraphObject.defineBuilder('ExpanderButton', function (args) {
  var button = /** @type {Panel} */ (
    go.GraphObject.make(
      'Button',
      {
        // set these values for the isTreeExpanded binding conversion
        _treeExpandedFigure: 'MinusLine',
        _treeCollapsedFigure: 'PlusLine',
      },
      go.GraphObject.make(
        go.Shape, // the icon
        {
          name: 'ButtonIcon',
          figure: 'MinusLine', // default value for isTreeExpanded is true
          stroke: '#424242',
          strokeWidth: 2,
          desiredSize: new go.Size(8, 8),
        },
        // bind the Shape.figure to the Node.isTreeExpanded value using this converter:
        new go.Binding('figure', 'isTreeExpanded', function (exp, shape) {
          var but = shape.panel
          return exp ? but['_treeExpandedFigure'] : but['_treeCollapsedFigure']
        }).ofObject()
      ),
      // assume initially not visible because there are no links coming out
      { visible: false },
      // bind the button visibility to whether it's not a leaf node
      new go.Binding('visible', '', function (nodeData, targetObj) {
        const node = targetObj.part
        const outOfNodes = node.findNodesOutOf()
        if (outOfNodes.count == 0) {
          return false
        }
        const outOfLinks = node.findLinksOutOf()
        let equipRelationList = new go.List()
        outOfLinks.each((link) => {
          const category = link.data.category
          if (category === 'EquipRelation') {
            equipRelationList.add(link)
          }
        })
        return equipRelationList.size < 1
      }).ofObject()
    )
  )

  // tree expand/collapse behavior
  button.click = function (e, btn) {
    var node = btn.part
    if (node instanceof go.Adornment) node = node.adornedPart
    if (!(node instanceof go.Node)) return
    var diagram = node.diagram
    if (diagram === null) return
    var cmd = diagram.commandHandler
    if (node.isTreeExpanded) {
      if (!cmd.canCollapseTree(node)) return
    } else {
      if (!cmd.canExpandTree(node)) return
    }
    e.handled = true
    if (node.isTreeExpanded) {
      cmd.collapseTree(node)
    } else {
      cmd.expandTree(node)
    }
  }

  return button
})
