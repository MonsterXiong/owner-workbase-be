import * as go from 'gojs'
import Vue from 'vue'
import { typeColorConfig, typeImageConfig } from '../typeConfig'
import '../customButton'
const $ = go.GraphObject.make

export const treeGraphContextMenu = $(go.HTMLInfo, {
  show: (obj, diagram, tool) => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuShow', {
      obj,
      diagram,
      tool,
    })
  },
  hide: () => {
    Vue.prototype.$emitter.emit('treeGraphContextmenuHide')
  },
})

function textStyle(field) {
  return [
    {
      font: '14px Roboto, sans-serif',
      stroke: 'rgba(0, 0, 0, .60)',
      stretch: go.GraphObject.Horizontal,
      maxLines: 1,
      // maxSize: new go.Size(NaN, NaN),
      overflow: go.TextBlock.OverflowEllipsis,
      // visible: false, // only show textblocks when there is corresponding data for them
    },
    new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
      const nodeData = targetObj.part.data
      const typeValue = nodeData._type || 'default'
      return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
    }).ofObject(),
  ]
}

function getTextBlock(array) {
  let res = array.map((ele) => {
    return $(
      go.TextBlock,
      textStyle(ele.code),
      new go.Binding('margin', '', () => new go.Margin(3, 5)),
      new go.Binding('text', '', (code, targetObj) => {
        const properties = targetObj.part.data.properties
        return ele.title + '：' + (properties[ele.code] || '')
      })
      // new go.Binding('visible', '', (code, targetObj) => {
      //   const properties = targetObj.part.data.properties
      //   return properties[ele.code] ? true : false
      // })
    )
  })
  return res
}

const _template = function (options, panelWidth = 118, textWidth = 100) {
  return $(
    go.Panel,
    'Vertical',
    {
      name: 'shape',
      stretch: go.GraphObject.Fill,
    },
    $(
      go.Panel,
      'Auto',
      {
        stretch: go.GraphObject.Vertical,
      },
      $(
        go.Shape,
        'Rectangle',
        {
          fill: 'transparent',
          strokeWidth: 1,
          stroke: 'transparent',
        },
        new go.Binding('fill', '', function (nodeData) {
          let key = options?.nodeCategoryProperty || '_type'
          const typeValue = nodeData[key]
          return typeColorConfig[typeValue].deep
        })
      ),
      $(
        go.Panel,
        'Horizontal',
        {
          width: panelWidth,
          margin: new go.Margin(2, 0),
        },
        $(
          go.Picture,
          {
            source: '',
            margin: new go.Margin(2, 2, 4, 2),
          },
          new go.Binding('source', '', function (nodeData) {
            let key = options?.nodeCategoryProperty || '_type'
            const typeValue = nodeData[key]
            return typeImageConfig[typeValue]
          })
        ),
        $(
          go.TextBlock,
          '',
          {
            width: 90,
            isMultiline: true,
            stroke: '#fff',
          },
          new go.Binding('text', 'tag', function (value) {
            return value || ''
          })
        )
      )
    ),
    $(
      go.Panel,
      'Auto',
      {
        stretch: go.GraphObject.Fill,
        width: panelWidth,
      },
      $(
        go.Shape,
        'Rectangle',
        {
          strokeWidth: 0,
        },
        new go.Binding('fill', 'isSelected', function (sel, targetObj) {
          const nodeData = targetObj.part.data
          let key = options?.nodeCategoryProperty || '_type'
          const typeValue = nodeData[key]
          return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
        }).ofObject()
      ),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'INFO', // identify to the PanelExpanderButton
          stretch: go.GraphObject.Horizontal,
          defaultAlignment: go.Spot.Left,
          visible: options?.textList.length > 0 ? true : false,
        },
        ...getTextBlock(options?.textList || [])
      ),
      $(
        go.TextBlock,
        {
          font: 'bold 14px sans-serif',
          stroke: '#333',
          margin: new go.Margin(4, 10),
          isMultiline: true,
          maxLines: 1,
          editable: false,
          textAlign: 'center',
          width: textWidth,
          overflow: go.TextBlock.OverflowEllipsis,
          visible: !options?.textList || options?.textList.length == 0 ? true : false,
        },
        new go.Binding('text', '', function (node) {
          let key = options?.nodeTextKey || 'name'
          return node[key] || ''
        }),
        new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
          const nodeData = targetObj.part.data
          let key = options?.nodeCategoryProperty || '_type'
          const typeValue = nodeData[key]
          return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
        }).ofObject()
      )
    )
  )
}

const _horizontalTemplate = function (panelWidth = 118, textWidth = 100, options) {
  return $(
    go.Panel,
    'Horizontal',
    {
      name: 'shape',
      stretch: go.GraphObject.Fill,
    },
    $(
      go.Panel,
      'Auto',
      {
        stretch: go.GraphObject.Vertical,
      },
      $(
        go.Shape,
        'Rectangle',
        {
          fill: 'transparent',
          strokeWidth: 1,
          stroke: 'transparent',
        },
        new go.Binding('fill', '', function (nodeData) {
          const typeValue = nodeData._type
          return typeColorConfig[typeValue].deep
        })
      ),
      $(
        go.Panel,
        'Vertical',
        {
          margin: new go.Margin(2, 8),
        },
        $(
          go.Picture,
          {
            source: '',
            margin: new go.Margin(0, 0, 4, 0),
          },
          new go.Binding('source', '_type', function (value) {
            return typeImageConfig[value]
          })
        ),
        $(
          go.TextBlock,
          '',
          {
            width: 14,
            isMultiline: true,
            stroke: '#fff',
          },
          new go.Binding('text', 'tag', function (value) {
            return value || ''
          })
        )
      )
    ),
    $(
      go.Panel,
      'Auto',
      {
        stretch: go.GraphObject.Fill,
        width: panelWidth,
      },
      $(
        go.Shape,
        'Rectangle',
        {
          strokeWidth: 0,
        },
        new go.Binding('fill', 'isSelected', function (sel, targetObj) {
          const nodeData = targetObj.part.data
          const typeValue = nodeData._type
          return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
        }).ofObject()
      ),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'INFO', // identify to the PanelExpanderButton
          stretch: go.GraphObject.Horizontal,
          // margin: new go.Margin(12, 10),
          defaultAlignment: go.Spot.Left,
          visible: options?.textList.length > 0 ? true : false,
        },
        ...getTextBlock(options?.textList || [])
      ),
      $(
        go.TextBlock,
        {
          font: 'bold 14px sans-serif',
          stroke: '#333',
          margin: new go.Margin(0, 10),
          isMultiline: true,
          maxLines: 2,
          editable: false,
          textAlign: 'center',
          width: textWidth,
          visible: !options?.textList || options?.textList.length == 0 ? true : false,
          overflow: go.TextBlock.OverflowEllipsis,
        },
        new go.Binding('text', 'name').makeTwoWay(),
        new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
          const nodeData = targetObj.part.data
          const typeValue = nodeData._type
          return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
        }).ofObject()
      )
    )
  )
}

const TreeExpanderButtonStyle = function (options, color) {
  return $(
    'TreeExpanderButton',
    {
      alignment: options?.angle != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.23, 0, 0),
      alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
      'ButtonBorder.figure': 'Circle',
      'ButtonBorder.fill': 'transparent',
    },
    new go.Binding('alignment', 'angle', function (value) {
      return value != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.29, 0, 0)
    }),
    new go.Binding('alignmentFocus', 'angle', function (value) {
      return value != 90 ? go.Spot.Right : go.Spot.Bottom
    }),
    new go.Binding('ButtonBorder.stroke', '', function (nodeData, targetObj) {
      const typeValue = nodeData._type || 'default'
      return color || typeColorConfig[typeValue].deep
    }),
    new go.Binding('ButtonIcon.stroke', '', function (nodeData, targetObj) {
      const typeValue = nodeData._type || 'default'
      return color || typeColorConfig[typeValue].deep
    })
  )
}
export function lightNodeTemplate(options) {
  return $(
    go.Node,
    'Vertical',
    {
      selectionObjectName: 'shape',
      contextMenu: treeGraphContextMenu,
    },
    $(
      go.Panel,
      'Spot',
      $(
        go.Panel,
        'Auto',
        $(
          go.Shape,
          'RoundedRectangle',
          {
            name: 'shape',
            cursor: 'pointer',
            fill: 'transparent',
            // stroke: 'red',
            strokeWidth: 1,
          },
          new go.Binding('stroke', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].deep
          })
        ),
        $(
          go.Panel,
          'Vertical',
          {
            name: 'INFO', // identify to the PanelExpanderButton
            stretch: go.GraphObject.Horizontal,
            // margin: new go.Margin(12, 10),
            defaultAlignment: go.Spot.Left,
            visible: options?.textList.length > 0 ? true : false,
          },
          ...getTextBlock(options?.textList || [])
        ),
        $(
          go.TextBlock,
          {
            font: 'bold 14px sans-serif',
            // stroke: 'red',
            margin: new go.Margin(10),
            minSize: new go.Size(86, 0),
            maxSize: new go.Size(210, Infinity),
            textAlign: 'center',
            editable: false,
            visible: !options?.textList || options?.textList.length == 0 ? true : false,
          },
          new go.Binding('text', 'name').makeTwoWay(),
          new go.Binding('stroke', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].deep
          })
        )
      ),
      TreeExpanderButtonStyle(options)
    )
  )
}
export function lightIconNodeTemplate(options) {
  return $(
    go.Node,
    'Vertical',
    {
      selectionObjectName: 'shape',
      contextMenu: treeGraphContextMenu,
    },
    $(
      go.Panel,
      'Spot',
      $(
        go.Panel,
        'Auto',
        $(
          go.Shape,
          'RoundedRectangle',
          {
            name: 'shape',
            cursor: 'pointer',
            fill: 'transparent',
            // stroke: 'red',
            strokeWidth: 1,
          },
          new go.Binding('stroke', '', function (nodeData, targetObj) {
            const typeValue = nodeData._type || 'default'
            return typeColorConfig[typeValue].deep
          }),
          new go.Binding('fill', '', function (nodeData) {
            const typeValue = nodeData._type
            return typeColorConfig[typeValue].deep
          })
        ),
        $(
          go.Panel,
          'Horizontal',
          {
            width: 118,
            margin: new go.Margin(7, 2),
          },
          $(
            go.Picture,
            {
              source: '',
              margin: new go.Margin(2, 2, 4, 2),
            },
            new go.Binding('source', '', function (nodeData) {
              const typeValue = nodeData._type
              return typeImageConfig[typeValue]
            })
          ),
          $(
            go.TextBlock,
            '',
            {
              width: 90,
              isMultiline: true,
              maxLines: 1,
              stroke: '#000',
              textAlign: 'center',
              overflow: go.TextBlock.OverflowEllipsis,
            },
            new go.Binding('stroke', '', function (nodeData, targetObj) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].shallow
            }),
            new go.Binding('text', 'name').makeTwoWay()
          )
        )
      ),
      TreeExpanderButtonStyle(options)
    )
  )
}

export function darkNodeTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      selectionAdorned: true,
      ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(
        go.Picture,
        {},
        new go.Binding('source', '', function (nodeData) {
          return require('@/assets/image/xydLayout/01.png')
        })
      ),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },

          $(go.Shape, 'Rectangle', {
            fill: 'transparent',
            strokeWidth: 1,
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Horizontal',
            {},
            new go.Binding('visible', '', function (nodeData) {
              return nodeData.tag ? true : false
            }),
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 0, 4, 0),
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(6, 0, 4, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#35cef6',
              },
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              }),
              new go.Binding('stroke', '', function (nodeData, targetObj) {
                const typeValue = nodeData._type || 'default'
                return typeColorConfig[typeValue].deep
              })
            )
          )
        ),
        $(
          go.Shape,
          'LineH',
          {
            stroke: '#05a9ff',
            strokeWidth: 1,
            height: 1,
            stretch: go.GraphObject.Horizontal,
          },
          new go.Binding('visible', '', function (nodeData) {
            return nodeData.tag ? true : false
          }) // only visible when info is expanded
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
            width: 118,
          },
          $(go.Shape, 'Rectangle', {
            strokeWidth: 0,
            fill: 'transparent',
          }),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(18, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              width: 100,
            },
            // new go.Binding('text', 'name'),
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              // return '#35cef6'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),

    $(
      'TreeExpanderButton',
      {
        // alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        'ButtonBorder.figure': 'Circle',
        'ButtonBorder.fill': 'transparent',
        'ButtonBorder.stroke': '#035ca2',
        'ButtonIcon.stroke': '#035ca2',
        alignment: options?.angle != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.23, 0, 0), //new go.Spot(1.13, 0.5, 0, 0),
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? new go.Spot(1.13, 0.5, 0, 0) : new go.Spot(0.5, 1.23, 0, 0)
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

export function darkTagNodeTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'none',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      // ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(
        go.Picture,
        {},
        new go.Binding('source', '', function (nodeData) {
          return require('@/assets/image/xydLayout/01.png')
        })
      ),
      $(go.Shape, {
        stroke: 'transparent',
        fill: 'transparent',
      }),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
          width: 208,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },
          $(go.Shape, 'Rectangle', {
            fill: 'transparent',
            strokeWidth: 1,
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Horizontal',
            {},
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 4),
                width: 16,
                height: 16,
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(5, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#fff',
                font: 'bold 16px sans-serif',
              },
              new go.Binding('stroke', '', function (nodeData, targetObj) {
                const typeValue = nodeData._type || 'default'
                return typeColorConfig[typeValue].deep
              }),
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              })
            )
          )
        ),
        $(go.Shape, 'LineH', {
          stroke: '#05a9ff',
          strokeWidth: 1,
          height: 1,
          stretch: go.GraphObject.Horizontal,
        }),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
          },
          $(go.Shape, 'Rectangle', {
            strokeWidth: 1,
            fill: 'transparent',
            stroke: 'transparent',
          }),
          $(
            go.Panel,
            'Vertical',
            {
              name: 'INFO', // identify to the PanelExpanderButton
              stretch: go.GraphObject.Horizontal,
              // margin: new go.Margin(12, 10),
              defaultAlignment: go.Spot.Left,
              visible: options?.textList.length > 0 ? true : false,
            },
            ...getTextBlock(options?.textList || [])
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(14, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              visible: !options?.textList || options?.textList.length == 0 ? true : false,
            },
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),
    $(
      'TreeExpanderButton',
      {
        // alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        'ButtonBorder.figure': 'Circle',
        'ButtonBorder.fill': 'transparent',
        'ButtonBorder.stroke': '#035ca2',
        'ButtonIcon.stroke': '#035ca2',
        alignment: options?.angle != 90 ? new go.Spot(1.08, 0.5, 0, 0) : new go.Spot(0.5, 1.15, 0, 0),
      },
      new go.Binding('alignment', 'angle', function (value) {
        // return value != 90 ? go.Spot.Right : go.Spot.Bottom
        return value != 90 ? new go.Spot(1.08, 0.5, 0, 0) : new go.Spot(0.5, 1.15, 0, 0)
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

export const iconTagNodeTemplate = function (nodeOptions = {}, config) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      fromLinkable: true,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: true,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      selectionObjectName: 'shape',
      selectionAdorned: true,
      ...nodeOptions,
    },
    new go.Binding('location', 'loc', go.Point.parse).makeTwoWay(go.Point.stringify),
    $(
      go.Panel,
      'Auto',
      $(
        go.Shape,
        {
          stroke: 'transparent',
          fill: 'transparent',
        },
        new go.Binding('stroke', '', function (nodeData) {
          let key = config?.nodeCategoryProperty || '_type'
          const typeValue = nodeData[key]
          return typeColorConfig[typeValue].deep
        })
      ),
      _template(config)
    ),
    TreeExpanderButtonStyle(config)
  )
}

export function ruleNodeTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      // ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(go.Shape, {
        stroke: 'transparent',
        fill: 'transparent',
      }),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
          width: 178,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              fill: 'transparent',
              strokeWidth: 1,
              stroke: 'transparent',
            },
            new go.Binding('fill', '', function (nodeData) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            }),
            new go.Binding('stroke', '', function (nodeData, targetObj) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            })
          ),
          $(
            go.Panel,
            'Horizontal',
            {},
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 4),
                width: 16,
                height: 16,
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(5, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#fff',
                font: 'bold 16px sans-serif',
              },
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              })
            )
          )
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              strokeWidth: 1,
            },
            new go.Binding('fill', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
            }).ofObject(),
            new go.Binding('stroke', '_type', function (value, targetObj) {
              const typeValue = value || 'default'
              return typeColorConfig[value].deep
            }),
            new go.Binding('visible', '', function (nodeData, targetObj) {
              let arr = options?.textList || []
              if (arr.length == 0) return true
              let flag = false
              // 当properties 都没有赋值数据时不显示
              arr.map((ele) => {
                const properties = nodeData.data.properties
                if (properties[ele.code]) {
                  flag = true
                }
              })
              return flag
            }).ofObject()
          ),
          $(
            go.Panel,
            'Vertical',
            {
              name: 'INFO', // identify to the PanelExpanderButton
              stretch: go.GraphObject.Horizontal,
              // margin: new go.Margin(12, 10),
              defaultAlignment: go.Spot.Left,
              visible: options?.textList.length > 0 ? true : false,
            },
            ...getTextBlock(options?.textList || [])
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(14, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              visible: !options?.textList || options?.textList.length == 0 ? true : false,
            },
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),
    $(
      'TreeExpanderButton',
      {
        alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

export const systemStructNodeTemplate = function (options, config) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      ...options,
    },
    new go.Binding('location', 'loc'),
    $(
      go.Panel,
      'Auto',
      $(
        go.Shape,
        {
          stroke: 'transparent',
          fill: 'transparent',
        },
        new go.Binding('stroke', '', function (nodeData, targetObj) {
          const typeValue = nodeData._type
          return typeColorConfig[typeValue].deep
        })
      ),
      _horizontalTemplate(118, 100, { ...config })
    ),
    $(
      go.Panel,
      'Auto',
      {
        alignment: go.Spot.Center,
        alignmentFocusName: go.Spot.TopLeft,
      },
      $(
        go.Shape,
        'Rectangle',
        {
          fill: 'rgba(0, 0, 0, 0.3)',
          stroke: null,
          width: 150,
          height: 55,
          visible: false,
        },
        new go.Binding('visible', '_disable')
      )
    ),
    $(
      'ExpanderButton',
      {
        alignment: go.Spot.Right,
        alignmentFocus: go.Spot.Right,
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}

export function dashNodeTemplate(options) {
  return $(
    go.Node,
    'Spot',
    {
      portId: '',
      cursor: 'pointer',
      selectionObjectName: 'shape',
      fromLinkable: false,
      fromLinkableSelfNode: false,
      fromLinkableDuplicates: false,
      toLinkable: false,
      toLinkableSelfNode: false,
      toLinkableDuplicates: false,
      locationSpot: go.Spot.Center,
      contextMenu: treeGraphContextMenu,
      // desiredSize: new go.Size(150, 60),
      // maxSize: new go.Size(150, 60),
      selectionAdorned: true,
      // ...options,
    },
    $(
      go.Panel,
      'Auto',
      $(go.Shape, {
        stroke: 'transparent',
        fill: 'transparent',
      }),
      $(
        go.Panel,
        'Vertical',
        {
          name: 'shape',
          stretch: go.GraphObject.Fill,
          width: 208,
        },
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Horizontal,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              fill: 'transparent',
              strokeWidth: 1,
              stroke: 'transparent',
            },
            new go.Binding('fill', '', function (nodeData) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            }),
            new go.Binding('stroke', '', function (nodeData, targetObj) {
              const typeValue = nodeData._type || 'default'
              return typeColorConfig[typeValue].deep
            }),
            new go.Binding('visible', 'tag', function (value) {
              if (options.showTag !== undefined) {
                return options.showTag
              }
              return value ? true : false
            })
          ),
          $(
            go.Panel,
            'Horizontal',
            {},
            new go.Binding('visible', 'tag', function (value) {
              if (options.showTag !== undefined) {
                return options.showTag
              }
              return value ? true : false
            }),
            $(
              go.Picture,
              {
                source: '',
                margin: new go.Margin(0, 4),
                width: 16,
                height: 16,
              },
              new go.Binding('source', '_type', function (value) {
                return value ? typeImageConfig[value] : ''
              })
            ),
            $(
              go.TextBlock,
              '',
              {
                text: '',
                margin: new go.Margin(5, 0),
                textAlign: 'center',
                isMultiline: true,
                stroke: '#fff',
                font: 'bold 16px sans-serif',
              },
              new go.Binding('text', 'tag', function (value) {
                return value || ''
              })
            )
          )
        ),
        $(
          go.Panel,
          'Auto',
          {
            stretch: go.GraphObject.Fill,
          },
          $(
            go.Shape,
            'Rectangle',
            {
              strokeWidth: 1,
              strokeDashArray: options?.dash || [0, 0],
            },
            new go.Binding('fill', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].deep : typeColorConfig[typeValue].shallow
            }).ofObject(),
            new go.Binding('stroke', '_type', function (value, targetObj) {
              const typeValue = value || 'default'
              return typeColorConfig[value].deep
            })
            // new go.Binding('visible', '', function (nodeData, targetObj) {
            //   const parentId = nodeData.data.parentId
            //   if (options?.textList && nodeData.data.name) {
            //     return false
            //   } else return true
            // }).ofObject()
          ),
          $(
            go.Panel,
            'Vertical',
            {
              name: 'INFO', // identify to the PanelExpanderButton
              stretch: go.GraphObject.Horizontal,
              // margin: new go.Margin(12, 10),
              defaultAlignment: go.Spot.Left,
              visible: options?.textList.length > 0 ? true : false,
            },
            ...getTextBlock(options?.textList || [])
          ),
          $(
            go.TextBlock,
            {
              font: 'bold 14px sans-serif',
              stroke: '#333',
              margin: new go.Margin(14, 10),
              isMultiline: true,
              maxLines: 2,
              editable: false,
              textAlign: 'center',
              visible: !options?.textList || options?.textList.length == 0 ? true : false,
            },
            new go.Binding('text', 'name').makeTwoWay(),
            new go.Binding('stroke', 'isSelected', function (sel, targetObj) {
              const nodeData = targetObj.part.data
              const typeValue = nodeData._type || 'default'
              return sel ? typeColorConfig[typeValue].shallow : typeColorConfig[typeValue].deep
            }).ofObject()
          )
        )
      )
    ),

    $(
      'TreeExpanderButton',
      {
        alignment: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
        alignmentFocus: options?.angle != 90 ? go.Spot.Right : go.Spot.Bottom,
      },
      new go.Binding('alignment', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      }),
      new go.Binding('alignmentFocus', 'angle', function (value) {
        return value != 90 ? go.Spot.Right : go.Spot.Bottom
      })
    )
  )
}
