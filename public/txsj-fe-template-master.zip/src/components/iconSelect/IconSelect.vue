<template>
  <div :class="['angle-btn', iconComConfig.size]" @click="showIconList">
    <span class="icon-text123">
      <template v-if="currentNode?.iconType === iconType.ELEMENT">
        <i :class="currentIcon"></i>
      </template>
      <template v-if="currentNode?.iconType === iconType.ICONFONT">
        <span :class="['iconfont', currentIcon]"></span>
      </template>
      <template v-if="currentNode?.iconType === iconType.SVG">
        <SvgIcon :iconClass="currentIcon"></SvgIcon>
      </template>
      <template v-if="currentNode?.iconType === iconType.IMG">
        <img :src="currentIcon" />
      </template>
      {{ currentNode?.iconType === iconType.IMG ? currentNode?.label : currentIcon || '请选择图标' }}
    </span>
    <i class="el-icon-caret-bottom"></i>
    <div class="icon-container" v-if="isShow" v-click-outside="hide">
      <div :class="['icon-tabs', iconComConfig.size]" v-if="tabName === '' && iconData.length < 1">
        <el-tabs v-model="activeIconType" type="card" @tab-click="onIconTabClick">
          <el-tab-pane label="Element-UI" :name="iconType.ELEMENT"></el-tab-pane>
          <el-tab-pane label="Iconfont" :name="iconType.ICONFONT"></el-tab-pane>
        </el-tabs>
      </div>
      <div class="icon-wrap">
        <el-input
          v-if="iconComConfig.isFilter"
          v-model="filterText"
          placeholder="请输入关键词过滤"
          :size="iconComConfig.size"
          prefix-icon="el-icon-search"
          ref="inputRef"
          clearable
          @input="filterIconData"
        ></el-input>
        <template v-if="mode === modeType.CARD">
          <div class="card-wrap">
            <el-row :gutter="20">
              <el-col :span="24 / iconComConfig.colSpan" v-for="item in iconList" :key="item.id">
                <div :class="['icon-item', currentIcon === item.icon ? 'active' : '']" @click="selectNode(item.icon)">
                  <el-tooltip placement="top">
                    <div slot="content">
                      {{ item.label }}
                    </div>
                    <template v-if="item.iconType == iconType.ELEMENT">
                      <i :class="item.icon"></i>
                    </template>
                    <template v-if="item.iconType === iconType.ICONFONT">
                      <span :class="['iconfont', item.icon]"></span>
                    </template>
                    <template v-if="item.iconType === iconType.SVG">
                      <SvgIcon :iconClass="item.icon"></SvgIcon>
                    </template>
                    <template v-if="item.iconType === iconType.IMG">
                      <img :src="item.icon" />
                    </template>
                  </el-tooltip>
                </div>
              </el-col>
            </el-row>
          </div>
        </template>
        <template v-else>
          <el-tree :data="iconList" :props="defaultProps" node-key="id" default-expand-all ref="treeRef" @node-click="selectNode" highlight-current>
            <div slot-scope="{ data }" :class="['icon-item-wrap', data.icon == currentIcon ? 'active' : '']">
              <template v-if="item.iconType == iconType.ELEMENT">
                <i :class="item.icon"></i>
              </template>
              <template v-if="item.iconType === iconType.ICONFONT">
                <span :class="['iconfont', item.icon]"></span>
              </template>
              <template v-if="item.iconType === iconType.SVG">
                <SvgIcon :iconClass="item.icon"></SvgIcon>
              </template>
              <template v-if="item.iconType === iconType.IMG">
                <img :src="item.icon" />
              </template>
              <span>{{ data.label }}</span>
            </div>
          </el-tree>
        </template>
        <el-pagination
          small
          layout="prev,pager,next"
          @size-change="handlePageSizeChange"
          @current-change="handleCurrentPageChange"
          :current-page="this.pageInfo.pageNumber"
          :page-sizes="[10, 20, 50, 100, 200]"
          :page-size="this.pageInfo.pageSize"
          :total="pageInfo.total"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import elementIcons from './element-icons'
import iconfont from './iconfont.js'

const modeType = {
  CARD: 'card',
  LIST: 'list',
}

const iconType = {
  ELEMENT: 'element',
  ICONFONT: 'iconfont',
  SVG: 'svg',
  IMG: 'img',
}

const baseConfig = {
  colSpan: 6,
  size: 'small',
  maxRow: 6,
  isFilter: true,
  isCurrentPage: false,
}

export default {
  name: 'IconSelect',
  props: {
    // 外部传入的数据
    iconData: {
      type: Array,
      default: () => [],
    },
    // 模式 列表|卡片
    mode: {
      type: String,
      default: modeType.CARD,
    },
    tabName: {
      type: String,
      default: '',
    },
    value: {
      type: String,
      default: '',
    },
    config: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      activeIconType: iconType.ICONFONT,
      currentIcon: '',
      currentNode: null,
      // isElementIcon: false,
      filterText: '',
      isShow: false,
      iconAll: [],
      iconList: [],
      defaultProps: {
        children: 'children',
        label: 'icon',
      },
      pageInfo: {
        pageSize: 20,
        pageNumber: 1,
        total: 0,
      },
      modeType,
      iconType,
      isPage: false, // 用于默认选中当前页
    }
  },
  created() {
    this.pageInfo.pageSize = modeType.CARD ? this.iconComConfig.colSpan * this.iconComConfig.maxRow : 20
    this.initIconData()
  },
  computed: {
    iconComConfig() {
      return Object.assign(baseConfig, this.config)
    },
  },
  methods: {
    selectNode(node) {
      if (this.mode === modeType.CARD) {
        this.currentIcon = node
      } else {
        this.currentIcon = node
        this.$refs.treeRef.setCurrentKey(this.currentIcon)
      }
      this.setCurrentNode()
    },
    showIconList() {
      this.isShow = true
      if (this.iconComConfig.isCurrentPage && !this.isPage) {
        const activeIndex = this.iconAll.findIndex((item) => item.icon === this.currentIcon)
        this.pageInfo.pageNumber = ![-1, 0].includes(activeIndex) ? Math.ceil(activeIndex / this.pageInfo.pageSize) : this.pageInfo.pageNumber
      }
      this.setIconList(this.iconAll)
      this.$nextTick(() => {
        this.$refs.treeRef?.setCurrentKey(this.currentIcon)
        this.$refs['inputRef']?.focus()
      })
    },
    hide() {
      this.isShow = false
      this.isPage = false
      this.pageInfo.pageNumber = 1
      this.filterText = ''
    },
    initIconData() {
      this.iconAll = []
      const icons = []
      if (this.iconData.length > 0) {
        this.iconData.map((item) => {
          icons.push({
            ...item,
          })
        })
        this.tabName = 'data'
      } else {
        if (this.activeIconType === iconType.ICONFONT) {
          iconfont.map((item) => {
            icons.push({
              id: `icon-${item.icon}`,
              icon: `icon-${item.icon}`,
              label: `icon-${item.icon}`,
              iconType: iconType.ICONFONT,
            })
          })
        } else if (this.activeIconType === iconType.ELEMENT) {
          elementIcons.map((item) => {
            icons.push({
              id: `el-icon-${item}`,
              icon: `el-icon-${item}`,
              label: `el-icon-${item}`,
              iconType: iconType.ELEMENT,
            })
          })
        }
      }

      this.iconAll = [...icons]
      this.pageInfo.total = this.iconAll.length
    },
    setIconList(listData) {
      this.iconList = _.cloneDeep(listData).splice((this.pageInfo.pageNumber - 1) * this.pageInfo.pageSize, this.pageInfo.pageSize)
    },
    setCurrentNode() {
      const nodeItem = this.iconAll.find((item) => item.icon === this.currentIcon)
      this.currentNode = nodeItem
    },
    onIconTabClick() {
      this.pageInfo.pageNumber = 1
      this.initIconData()
    },
    filterIconData() {
      const iconNodes = this.iconAll.filter((item) => item.icon.indexOf(this.filterText) !== -1)
      this.pageInfo.total = iconNodes.length
      this.setIconList(iconNodes)
    },
    handlePageSizeChange(rows) {
      this.pageInfo.pageSize = rows
    },
    handleCurrentPageChange(page) {
      this.isPage = true
      this.pageInfo.pageNumber = page
    },
  },
  watch: {
    value: {
      handler: function () {
        this.currentIcon = this.value
        this.setCurrentNode()
      },
      immediate: true,
    },
    iconData: {
      handler() {
        this.initIconData()
      },
      immediate: true,
    },
    currentIcon() {
      this.$emit('input', this.currentIcon)
      this.$emit('selectNode', this.currentNode)
    },
  },
}
</script>

<style lang="less" scoped>
@input-border-color: var(--input-border-color, #d5d5d5);
@input-bg-color: var(--input-bg-color, #fff);
@shadow-color-base: var(--shadow-color-base, #0000004d);
@background-color-light-hover: var(--background-color-light-hover, #dfeeff);
@font-color-active: var(--font-color-active, #409eff);

.angle-btn {
  width: 100%;
  display: inline-block;
  border: 1px solid @input-border-color;
  padding: 2px 10px;
  height: 40px;
  font-size: 14px;
  border-radius: 2px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-radius: 4px;
  &.medium {
    height: 36px;
  }
  &.small {
    height: 32px;
  }
  &.mini {
    height: 25px;
  }
  .icon-text123 {
    height: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: flex;
    align-items: center;
    img {
      height: 100%;
    }
  }
  .icon-container {
    width: 100%;
    background-color: @input-bg-color;
    position: absolute;
    left: 0;
    top: 29px;
    z-index: 3000;
    box-shadow: 0 0 2px 2px @shadow-color-base;
    .icon-wrap {
      cursor: default;
    }
    .card-wrap {
      max-height: 250px;
      padding: 10px 10px 0;
      overflow-y: auto;
      .el-row {
        height: 100%;
      }
      .icon-item {
        text-align: center;
        &:hover {
          background-color: @background-color-light-hover;
          cursor: pointer;
        }
        &.active {
          background-color: @background-color-light-hover;
          color: @font-color-active;
          cursor: not-allowed;
        }
        img {
          width: 100%;
          // height: 36px;
        }
      }
    }
    .el-tree {
      padding-bottom: 10px;
      max-height: 250px;
      overflow-y: auto;
    }
    .icon-item-wrap {
      display: flex;
      justify-content: space-between;
      align-items: center;
      svg {
        width: 16px;
        height: 16px;
      }
      span {
        margin-left: 20px;
      }
    }
  }
  .icon {
    width: 14px;
    height: 14px;
  }
  .active {
    color: @font-color-active;
    cursor: not-allowed;
  }
}

::v-deep {
  .icon-tabs {
    .el-tabs__header {
      margin-bottom: 0;
    }
    &.medium {
      .el-tabs__item {
        height: 36px;
        line-height: 36px;
      }
    }
    &.small {
      .el-tabs__item {
        height: 32px;
        line-height: 32px;
      }
    }
    &.mini {
      .el-tabs__item {
        height: 25px;
        line-height: 25px;
      }
    }
  }
  .el-pager {
    .active {
      cursor: pointer;
    }
  }
}
</style>

