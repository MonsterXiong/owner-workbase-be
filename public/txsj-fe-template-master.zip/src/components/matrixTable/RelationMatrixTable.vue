<template>
  <div class="table-content">
    <main>
      <MatrixTable v-bind="$attrs" v-on="$listeners" @cellClick="onCellClick">
        <template slot-scope="{ data }">
          <i v-show="data.from && data.to" style="font-size: 16px" :class="getRelationIcon(data)"></i>
        </template>
      </MatrixTable>
    </main>
    <footer class="relation-list">
      <div
        v-for="item in relationList"
        class="relation"
        @click="changeActiveRelationId(item.id)"
        :class="{ active: item.id === activeRelationId }"
        :key="item.id"
      >
        <i :class="item.icon"></i> {{ item.name }}
      </div>
      <div class="relation" :class="{ active: !activeRelationId }" @click="changeActiveRelationId()"><i class="el-icon-delete"></i> 清除</div>
    </footer>
  </div>
</template>

<script>
import MatrixTable from './MatrixTable.vue'

// 关系矩阵矩阵
export default {
  components: {
    MatrixTable,
  },
  props: {
    // 关系列表
    relationList: {
      type: Array,
      default: () => [],
    },
  },
  watch: {
    relationList: {
      handler() {
        if (this.relationList.length > 0) {
          this.activeRelationId = this.relationList[0].id
        } else {
          this.activeRelationId = ''
        }
      },
      immediate: true,
    },
  },
  data() {
    return {
      activeRelationId: '',
    }
  },

  methods: {
    changeActiveRelationId(id) {
      this.activeRelationId = id || ''
    },
    getRelationIcon(data) {
      if (data.value) {
        const relation = this.relationList.find((item) => item.id === data.value)
        return relation?.icon || ''
      }
    },
    onCellClick({ from, to, data }) {
      const list = this.$attrs.data
      if (!data && this.activeRelationId) {
        list.push({
          from,
          to,
          value: this.activeRelationId,
        })
      } else if ((data.value && data.value === this.activeRelationId) || !this.activeRelationId) {
        // 重复点击 或者 点了清除关系 则删除该关系
        const removeIndex = list.findIndex((item) => item === data)
        if (removeIndex >= 0) list.splice(removeIndex, 1)
      } else if (data.value) {
        // 修改
        data.from = from
        data.to = to
        data.value = this.activeRelationId
      }
    },
  },
}
</script>

<style scoped lang="less">
.table-content {
  height: 100%;

  main {
    height: calc(100% - 35px);
  }

  .relation-list {
    margin-top: 10px;
    display: flex;
    font-size: 16px;
    .relation {
      padding: 2px 4px;
      cursor: pointer;
      &:not(:last-child) {
        margin-right: 10px;
      }
      &.active {
        background-color: #dfecfc;
        color: #25559e;
      }
      &:hover {
        background-color: #dfecfc;
      }
    }
  }
}
</style>
