<template>
  <div class="table-content">
    <main>
      <MatrixTable v-bind="$attrs" v-on="$listeners" @cellClick="onCellClick" ref="matrixTableRef">
        <template slot-scope="{ data }">
          <i v-show="data.from && data.to" style="font-size: 16px" :class="getRelationIcon(data)"></i>
        </template>
      </MatrixTable>
    </main>
    <footer class="relation-list">
      <div
        v-for="(item, index) in relationList"
        class="relation"
        @click="changeActiveRelationId(item.id)"
        :class="{ active: item.id === activeRelationId }"
        :key="item.id"
      >
        <i :class="item.icon || defaultIcon[index] || ''"></i> {{ item.name }}
      </div>
      <div class="relation" :class="{ active: !activeRelationId }" @click="changeActiveRelationId()"><i class="el-icon-delete"></i> 清除</div>
    </footer>
  </div>
</template>

<script>
import MatrixTable from './MatrixTable.vue'

// 默认图标
const defaultIcon = Object.freeze(['iconfont icon-circle1', 'iconfont icon-circle-hollow'])
// 关系矩阵矩阵
export default {
  components: {
    MatrixTable,
  },
  props: {
    // 关系列表
    relationList: {
      type: Array,
      default: () => [],
    },
  },
  watch: {
    relationList: {
      handler() {
        if (this.relationList.length > 0) {
          this.activeRelationId = this.relationList[0].id
        } else {
          this.activeRelationId = ''
        }
      },
      immediate: true,
    },
  },
  data() {
    return {
      activeRelationId: '',
      defaultIcon,
    }
  },

  methods: {
    changeActiveRelationId(id) {
      this.activeRelationId = id || ''
    },
    getRelationIcon(data) {
      if (data.value) {
        const relation = this.relationList.find((item) => item.id === data.value)
        if (relationIndex >= 0) return this.relationList[relationIndex]?.icon || defaultIcon[relationIndex] || ''
      }
      return ''
    },
    onCellClick({ from, to, data, row, column }) {
      const list = this.$attrs.data
      if (!data && this.activeRelationId) {
        list.push({
          from,
          to,
          value: this.activeRelationId,
        })
      } else if ((data.value && data.value === this.activeRelationId) || !this.activeRelationId) {
        // 重复点击 或者 点了清除关系 则删除该关系
        const removeIndex = list.findIndex((item) => item === data)
        if (removeIndex >= 0) list.splice(removeIndex, 1)
      } else if (data.value) {
        // 修改
        data.from = from
        data.to = to
        data.value = this.activeRelationId
      }
      this.$emit('cellClick', {
        from,
        to,
        data,
        value: this.activeRelationId,
        row,
        column,
      })
    },
    saveImage(name) {
      if (this.$refs.matrixTableRef) {
        this.$refs.matrixTableRef.saveImage(name || '关系矩阵')
      }
    },
  },
}
</script>

<style scoped lang="less">
.table-content {
  height: 100%;

  main {
    height: calc(100% - 35px);
  }

  .relation-list {
    margin-top: 10px;
    display: flex;
    font-size: 16px;
    .relation {
      padding: 2px 4px;
      cursor: pointer;
      &:not(:last-child) {
        margin-right: 10px;
      }
      &.active {
        background-color: #dfecfc;
        color: #25559e;
      }
      &:hover {
        background-color: #dfecfc;
      }
    }
  }
}
</style>
