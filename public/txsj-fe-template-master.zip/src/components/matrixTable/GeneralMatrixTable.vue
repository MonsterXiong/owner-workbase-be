<template>
  <MatrixTable v-bind="$attrs" v-on="$listeners" @cellClick="onCellClick" ref="matrixTableRef">
    <template slot-scope="{ data }">
      <i v-show="data.from && data.to" style="font-size: 16px" :class="icon"></i>
    </template>
  </MatrixTable>
</template>

<script>
import MatrixTable from './MatrixTable.vue'

// 通用矩阵
export default {
  components: {
    MatrixTable,
  },
  props: {
    // 有关联的单元格用什么图标显示
    icon: {
      type: String,
      default: 'el-icon-success',
    },
  },
  data() {
    return {}
  },

  methods: {
    onCellClick({ from, to, data, row, column }) {
      const list = this.$attrs.data
      if (data) {
        const removeIndex = list.findIndex((item) => item === data)
        if (removeIndex >= 0) list.splice(removeIndex, 1)
      } else {
        list.push({
          from,
          to,
        })
      }
      this.$emit('cellClick', {
        from,
        to,
        data,
        row,
        column,
      })
    },
    saveImage(name) {
      if (this.$refs.matrixTableRef) {
        this.$refs.matrixTableRef.saveImage(name || '关系矩阵')
      }
    },
  },
}
</script>

<style scoped lang="less"></style>
