<template>
  <MatrixTable v-bind="$attrs" v-on="$listeners" ref="matrixTableRef">
    <template slot-scope="{ data, from, to }">
      <el-input-number @change="onInputChange(data, from, to)" style="width: 100%" size="mini" :controls="false" v-model="data.value"></el-input-number>
    </template>
  </MatrixTable>
</template>

<script>
import MatrixTable from './MatrixTable.vue'

// 权重矩阵
export default {
  components: {
    MatrixTable,
  },
  props: {
    // 有关联的单元格用什么图标显示
    icon: {
      type: String,
      default: 'el-icon-success',
    },
  },
  data() {
    return {}
  },

  methods: {
    onInputChange(data, from, to) {
      // 没有关联则新增一个关联
      if (!data.from && !data.to) {
        data.from = from
        data.to = to
        this.$attrs.data.push(data)
      }
      this.$emit('change', {
        data,
        from,
        to,
        value: data.value,
      })
    },
    saveImage(name) {
      if (this.$refs.matrixTableRef) {
        this.$refs.matrixTableRef.saveImage(name || '关系矩阵')
      }
    },
  },
}
</script>

<style scoped lang="less"></style>
