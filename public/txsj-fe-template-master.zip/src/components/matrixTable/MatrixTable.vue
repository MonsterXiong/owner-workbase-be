<template>
  <el-table
    border
    class="matrix"
    :data="tableData"
    height="100%"
    ref="tableRef"
    :span-method="arraySpanMethod"
    :header-cell-style="headerCellStyle"
    :cell-class-name="getCellClassName"
    @cell-mouse-enter="cellMouseEnter"
    @cell-mouse-leave="cellMouseLeave"
    @cell-click="cellClick"
    v-if="visible"
  >
    <el-table-column v-if="beforeColumn.length === 0"></el-table-column>
    <el-table-column v-for="item in beforeColumn" class-name="cell-header" :key="item.prop" align="center" v-bind="item"></el-table-column>
    <TreeColumn :vertical="vertical" v-for="item in mainColumn" :data="item" :key="item.id">
      <template slot-scope="{ row, column }">
        <slot :row="row" :column="column" :from="row._id" :to="column.property" :data="getData(row, column)"> {{ getData(row, column).value }} </slot>
      </template>
    </TreeColumn>
  </el-table>
</template>

<script>
import TreeColumn from './components/TreeColumn.vue'
import MatrixTableRenderMixins from './MatrixTableRenderMixins'

export default {
  mixins: [MatrixTableRenderMixins],
  props: {
    // 额外的头部数据
    headerData: {
      type: Array,
      default: () => [],
    },
    // 组成表格的数据
    treeData: {
      type: Array,
      default: () => [],
    },
    // 数据
    data: {
      type: Array,
      default: () => [],
      require: true,
    },
    // 是否只读
    readOnly: {
      type: Boolean,
      default: false,
    },
    // 是否是垂直
    vertical: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      tableData: [],
      valueData: [],
    }
  },
  watch: {
    data: {
      handler() {
        this.valueData = [...this.data]
      },
      immediate: true,
    },
  },
  computed: {
    // 减少表格渲染的循环次数,优化效率
    valueMap() {
      const dataMap = new Map()
      this.valueData.forEach((item) => {
        dataMap.set(`${item.from}-${item.to}`, item)
      })
      return dataMap
    },
  },
  methods: {
    // 获取每一个单元格的样式类名
    getCellClassName({ row, column }) {
      const from = row._id
      const to = column.property
      if (from === to) return 'disable'
      const findValue = this.valueMap.get(`${from}-${to}`)
      return findValue?.readOnly ? 'readOnly' : ''
    },
    cellClick(row, column) {
      const from = row._id
      const to = column.property
      const findValue = this.valueMap.get(`${from}-${to}`)
      if (from === to) return
      this.$emit('cellClick', {
        from,
        to,
        row,
        column,
        data: findValue,
      })
    },
    getData(row, column) {
      const from = row._id
      const to = column.property
      return this.valueMap.get(`${from}-${to}`) || {}
    },
  },
  components: { TreeColumn },
}
</script>

<style scoped lang="less">
@import './matrix.less';
</style>
