<template>
  <div class="context-wrap" v-show="visible" :style="{ left: left + 'px', top: top + 'px' }" v-click-outside="hideContextMenu">
    <ContextMenuItem :menuList="contextMenuList || []" @contextMenuSelect="onContextMenuSelect" v-if="contextMenuList.length > 0" />
  </div>
</template>

<script>
import ContextMenuItem from './ContextMenuItem.vue'
export default {
  props: {
    contextMenuList: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      left: 0,
      top: 0,
      visible: false,
      // contextMenuList: [],
    }
  },
  methods: {
    show(left, top) {
      this.left = left
      this.top = top
      this.visible = true
      console.log('右键菜单显示')
    },
    showContextMenu(e) {
      const left = e.clientX + 15 // 15: margin right
      const top = e.clientY
      this.left = left
      this.top = top
      this.visible = true
      console.log('右键菜单显示', e.clientX, e.clientY, 88888888)
    },
    hideContextMenu() {
      if (this.visible) {
        this.visible = false
        console.log('右键菜单隐藏')
      }
    },
    onContextMenuSelect(data) {
      // console.log('右键菜单点击', data)
      this.$emit('contextMenuClick', data)
      this.hideContextMenu()
    },
  },
  components: { ContextMenuItem },
}
</script>

<style lang="less" scoped>
.context-wrap {
  position: fixed;
  min-width: 240px;
  border: 1px solid #e4e4e4;
  background: #fff;
  box-shadow: 1px 1px 3px rgba(128, 128, 128, 0.322);
  .context-menu-item {
    padding: 5px;
    text-align: center;
    &:hover {
      background: #f8f8f8;
      color: #1890ff;
    }
  }
  max-height: 500px;
  overflow-y: auto;
}
</style>
