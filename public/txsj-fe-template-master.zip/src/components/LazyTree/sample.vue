<template>
  <div>
    <LazyTree
      ref="lazyTreeRef"
      :menu_TreeData="treeData"
      style="margin: 0; border: none"
      @contextmenuClick="onNodeContextMenu"
      @dbClickEvent="onDbClick"
      @getMenuChildren="getMenuChildren"
    ></LazyTree>
    <ContextMenu ref="contextMenuRef" :contextMenuList="contextMenuList" @contextMenuClick="onContextMenuSelect" />
  </div>
</template>

<script>
import { uuid } from '@/utils/commonUtil'
import LazyTree from './LazyTree.vue'
import { listToTree, treeToList } from '@/utils/treeTool'
import ContextMenu from './ContextMenu.vue'
import { StaticContextMenu } from './index'
export default {
  name: 'Welcome',
  components: { LazyTree, ContextMenu },
  data() {
    return {
      props: {
        label: 'name',
        children: 'children',
        isLeaf: 'leaf',
      },
      treeData: [
        {
          id: '101',
          code: 'root',
          icon: 'el-icon-folder',
          name: 'model1',
          parentId: '',
          collapse: true,
        },
      ],
      left: 0,
      top: 0,
      visible: false,
      contextMenuList: [],
    }
  },
  methods: {
    getTreeData() {
      this.$refs.lazyTreeRef.getTreeData()
    },
    async getMenuChildren(menu) {
      let treeData = this.$refs.lazyTreeRef.getTreeData()
      let list = treeToList(treeData).map((ele) => {
        if (menu.id == ele.id) {
          ele.collapse = !menu.collapse
        }
        return ele
      })
      let arr = []
      if (menu.collapse && menu.leaf !== false) {
        arr = await this.queryMenuData(menu)
        // todo 逻辑还有点问题
        list.forEach((element) => {
          if (element.id == menu.id) element.leaf = arr.length == 0 ? true : false
        })
      }
      this.treeData = listToTree([...list, ...arr])
    },
    onDbClick(data) {
      console.log('双击事件', data)
    },
    queryMenuData(menu) {
      let arr = []
      let num = Math.floor(Math.random() * 10)
      for (let i = 0; i < num; i++) {
        arr.push({ id: uuid(), name: '子节点' + i, parentId: menu.id, collapse: true, code: 'leaf', icon: 'icon-tianjiajiedian' })
      }
      return arr
    },
    onNodeContextMenu(menu, e) {
      this.getContextMenu(menu)
      this.$refs.contextMenuRef.showContextMenu(e)
    },
    getContextMenu(menu) {
      if (menu.code == 'root') {
        this.contextMenuList = StaticContextMenu
      } else {
        this.contextMenuList = [
          {
            code: 'refresh',
            name: '刷新',
          },
        ]
      }
    },
    onContextMenuSelect(data) {
      console.log('右键菜单', data)
    },
  },
}
</script>

<style lang="less" scoped></style>
