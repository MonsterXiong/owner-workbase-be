<template>
  <div class="menu-item-wrap">
    <div v-for="item in menuData" :key="item.code">
      <div :class="item.children ? 'context-menu-gather' : 'context-menu-item'" @click="onContextMenuSelect(item)">
        <span class="context-menu-text">
          <BaseIcon :iconName="item.icon || ''" style="margin-right: 2px" v-show="item.icon" />
          {{ item.name }}
        </span>
        <i class="el-icon-caret-top" v-show="item.collapse && item.children" @click.stop="onChangeCollapse(item)" />
        <i class="el-icon-caret-bottom" v-show="!item.collapse && item.children" @click.stop="onChangeCollapse(item)" />
      </div>
      <ContextMenuItem v-show="item.children && !item.collapse" :menuList="item.children || []" v-on="$listeners" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'ContextMenuItem',
  props: {
    menuList: { type: Array, default: () => [] },
  },
  data() {
    return {
      menuData: [],
    }
  },
  watch: {
    menuList: {
      handler() {
        this.menuData = JSON.parse(JSON.stringify(this.menuList))
      },
      deep: true,
      immediate: true,
    },
  },
  methods: {
    onChangeCollapse(menu) {
      this.$set(menu, 'collapse', !menu.collapse)
    },
    onContextMenuSelect(data) {
      if (data.children) {
        this.onChangeCollapse(data)
        return
      }
      this.$emit('contextMenuSelect', data)
    },
  },
}
</script>

<style lang="less" scoped>
.context-menu-item {
  padding: 5px;
  // text-align: center;
  cursor: pointer;
  font-size: 15px;
  // padding-left: 30px;
  &:hover {
    background: #cde0f8;
    // color: #1890ff;
  }
}
.context-menu-gather {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px;
  position: relative;
  background: #f2f2f2;
  font-size: 15px;
  .context-menu-text {
    padding-left: 0px !important;
  }
  cursor: pointer;
  i {
    cursor: pointer;
    color: #679dec;
  }
}
.menu-item-wrap {
  .menu-item-wrap {
    .context-menu-text {
      padding-left: 30px;
    }
  }
}
.context-menu-text {
  margin-right: 10px;
}
</style>
