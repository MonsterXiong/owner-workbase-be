<template>
  <div class="lazy-tree" style="">
    <ul>
      <li v-for="menu in treeData" :key="menu.id" @contextmenu.stop.prevent="onContextMenu(menu, $event)" @dblclick.stop="onDbClick(menu)">
        <span class="collapse-span" v-if="!menu.leaf">
          <!-- <i class="el-icon-caret-top" v-show="menu.collapse" @click="onChangeCollapse(menu)" style="font-size: 14px"/>
          <i class="el-icon-caret-bottom" v-show="!menu.collapse" @click="onChangeCollapse(menu)" style="font-size: 14px"/> -->
          <span class="iconfont icon-shangyi" v-show="menu.collapse" @click="onChangeCollapse(menu)" style="font-size: 14px" />
          <span class="iconfont icon-xiayi" v-show="!menu.collapse" @click="onChangeCollapse(menu)" style="font-size: 14px" />
        </span>
        <span class="tree-text" :style="menu.leaf ? 'margin-left:16px;' : ''" draggable @dragstart="onDragStart($event, menu)">
          <BaseIcon :iconName="menu.icon || ''" style="margin-right: 2px" v-show="menu.icon" />{{ menu.name }}</span
        >
        <LazyTree
          class="lazy-tree-width-before"
          :menu_TreeData="menu.children || []"
          v-show="!menu.collapse && menu.children ? true : false"
          style="padding-left: 10px"
          v-on="$listeners"
        />
        <!-- @contextmenu="onContextMenu" -->
      </li>
    </ul>
    <slot />
  </div>
</template>

<script>
export default {
  name: 'LazyTree',
  props: {
    menu_TreeData: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      treeData: [],
    }
  },
  watch: {
    menu_TreeData: {
      handler() {
        this.treeData = JSON.parse(JSON.stringify(this.menu_TreeData))
      },
      immediate: true,
    },
  },
  methods: {
    getTreeData() {
      return JSON.parse(JSON.stringify(this.treeData))
    },
    onChangeCollapse(menu) {
      this.$emit('getMenuChildren', menu)
    },
    onContextMenu(menu, e) {
      this.$emit('contextmenuClick', menu, e)
    },
    onDbClick(menu) {
      this.$emit('dbClickEvent', menu)
    },
    onDragStart(event, data) {
      event.dataTransfer.setData('data', data)
      console.log('拖拽事件', data)
    },
  },
}
</script>

<style lang="less" scoped>
@li-gap: 6px;
@li-height: 24px;
// .lazy-tree-width-before {
//   position: relative;
//   padding-left: @li-gap;
//   &::before {
//     content: '';
//     width: 20px;
//     height: calc(100% - @li-height + 1px);
//     position: absolute;
//     border-left: 1px solid #b9b9b9;
//     border-bottom: 1px dashed #b9b9b9;
//     left: @li-gap;
//     top: 10px;
//   }
//   li {
//     position: relative;
//     line-height: @li-height;
//     padding-left: 10px;
//     &::before {
//       content: '';
//       position: absolute;
//       width: 16px;
//       height: calc(@li-height - 8px);
//       border-left: 1px solid #b9b9b9;
//       border-bottom: 1px dashed #b9b9b9;
//       left: -4px;
//       top: -5px;
//     }
//   }
// }
.lazy-tree-width-before {
  position: relative;
  padding-left: @li-gap;
  &::before {
    content: '';
    width: 18px;
    height: calc(100% - (@li-height / 2) + 5px);
    position: absolute;
    border-left: 1px solid #b9b9b9;
    border-bottom: 1px dashed #b9b9b9;
    left: 6px;
    top: -5px;
  }
  li {
    position: relative;
    line-height: @li-height;
    padding-left: 12px;
    // margin-left: 20px;
    &::before {
      content: '';
      position: absolute;
      width: 16px;
      height: calc(@li-height - 8px);
      border-bottom: 1px dashed #b9b9b9;
      left: -4px;
      top: -3px;
    }
  }
}
.collapse-span {
  cursor: pointer;
}
.tree-text {
  margin-left: 3px;
  user-select: none;
}
.lazy-tree {
  padding-left: 0px;
  position: relative;
}
</style>
