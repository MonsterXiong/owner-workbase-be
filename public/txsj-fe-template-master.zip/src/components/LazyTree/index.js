export const ContextMenuCode = {
  CREATE_ELEMENT: 'createElement',
  CREATE_PACKAGE: 'createPackage',
  CREATE_REQUIREMENT: 'createRequirement',
  CREATE_USECASE: 'createUseCase',
  CREATE_ACTOR: 'createActor',
  CREATE_BLOCK: 'createBlock',
  CREATE_CONSTRAINBLOCK: 'createConstrainBlock',
  CREATE_INTERFACE: 'createInterface',
  CREATE_VALUETYPE: 'createValueType',
  CREATE_UNIT: 'createUnit',
  CREATE_ENUMERATION: 'createEnumeration',
  CREATE_ACTIVITY: 'createActivity',
  CREATE_INTERACTION: 'createInteraction',
  CREATE_STATEMERCHINE: 'createStateMerchine',
  CREATE_FUNCTION: 'createFunction',
  CREATE_STEREOTYPE: 'createStereotype',
  CREATE_SIGNAL: 'createSignal',
  CREATE_DIAGRAM: 'createDiagram',
  SYSML_DRAGRAM: 'sysMLDiagram',
  REQUIREMENT_DIAGRAM: 'requirementDiagram',
  SYSML_BLOCK_DEFINATION_DIAGRAM: 'SysmlBlockDefinitonDiagram',
  SYSML_REQUIREMENT_DIAGRAM: 'sysmlRequirementDiagram',
  SYSML_USE_CASE_DIAGRAM: 'sysmlUseCaseDiagram',
  SYSML_PACKAGE_DIAGRAM: 'sysmlPackageDiagram',
  SYSML_STATE_MERCHINE_DIAGRAM: 'sysmlSStateMerchineDiagram',
  SYSML_ACTIVITY_DIAGRAM: 'sysmlActivityDiagram',
  SYSML_SEQUENCE_DIAGRAM: 'sysmlSequenceDiagram',
  SYSML_INTERNAL_BLOCK_DIAGRAM: 'sysmlInternalBlockDiagram',
  SYSML_PARAMETER_DIAGRAM: 'sysmlParameterDiagram',
  REQUIREMENT_TABLE: 'requirementTable',
  SATISFY_REQUIREMENT_MATRIX: 'SatisfyRequirementMatrix',
  DERIVE_REQUIREMENT_MATRIX: 'DeriveRequirementMatrix',
  VERIFY_REQUIREMENT_MATRIX: 'VerifyRequirementMatrix',
  REFINE_REQUIREMENT_MATRIX: 'RefineRequirementMatrix',
  RENAME: 'rename',
  COPY: 'copy',
  PASTE: 'paste',
  CUT: 'cut',
  DELETE: 'delete',
}
export const StaticContextMenu = [
  {
    code: ContextMenuCode.CREATE_ELEMENT,
    name: '创建元素/对象 Create Element',
    children: [
      {
        icon: 'el-icon-folder',
        code: ContextMenuCode.CREATE_PACKAGE,
        name: '包 Package',
      },
      {
        icon: 'icon-wenjian',
        code: ContextMenuCode.CREATE_REQUIREMENT,
        name: '需求 Requirement',
      },
      {
        code: ContextMenuCode.CREATE_USECASE,
        name: '用例 UseCase',
      },
      { code: ContextMenuCode.CREATE_ACTOR, name: '执行者 Requirement' },
      { code: ContextMenuCode.CREATE_BLOCK, name: '块 Block' },
      { code: ContextMenuCode.CREATE_CONSTRAINBLOCK, name: '约束块 ConstrainBlock' },
      { code: ContextMenuCode.CREATE_INTERFACE, name: '接口 Interface' },
      { code: ContextMenuCode.CREATE_VALUETYPE, name: '类型值 Value Type' },
      { code: ContextMenuCode.CREATE_UNIT, name: '单位 Unit' },
      { code: ContextMenuCode.CREATE_ENUMERATION, name: '枚举类型 Enumeration' },
      { code: ContextMenuCode.CREATE_ACTIVITY, name: '活动 Activity' },
      { code: ContextMenuCode.CREATE_INTERACTION, name: '序列 Interaction' },
      { code: ContextMenuCode.CREATE_STATEMERCHINE, name: '状态机 StateMerchine' },
      { code: ContextMenuCode.CREATE_FUNCTION, name: '函数 Function' },
      { code: ContextMenuCode.CREATE_STEREOTYPE, name: '构造型 Stereotype' },
      { code: ContextMenuCode.CREATE_SIGNAL, name: '信号 Signal' },
    ],
  },
  {
    code: ContextMenuCode.CREATE_DIAGRAM,
    name: '创建视图 Create Diagram',
    children: [
      {
        code: ContextMenuCode.SYSML_DRAGRAM,
        name: 'SysMl视图 SysML Diagram',
        children: [
          {
            code: ContextMenuCode.SYSML_BLOCK_DEFINATION_DIAGRAM,
            name: '块图 Sysml Block Definiton Diagram',
          },
          {
            code: ContextMenuCode.SYSML_REQUIREMENT_DIAGRAM,
            name: '需求图 Sysml Requirement Diagram',
          },
          {
            code: ContextMenuCode.SYSML_USE_CASE_DIAGRAM,
            name: '用例图 Sysml Use Case Diagram',
          },
          {
            code: ContextMenuCode.SYSML_PACKAGE_DIAGRAM,
            name: '包图 Sysml Package Diagram',
          },
          {
            code: ContextMenuCode.SYSML_STATE_MERCHINE_DIAGRAM,
            name: '状态机图 Sysml State Machine Diagram',
          },
          {
            code: ContextMenuCode.SYSML_ACTIVITY_DIAGRAM,
            name: '活动图 Sysml Activity Diagram',
          },
          {
            code: ContextMenuCode.SYSML_SEQUENCE_DIAGRAM,
            name: '时序图 Sysml Sequence Diagram',
          },
          {
            code: ContextMenuCode.SYSML_INTERNAL_BLOCK_DIAGRAM,
            name: '内部块图 Sysml Internal Block Diagram',
          },
          {
            code: ContextMenuCode.SYSML_PARAMETER_DIAGRAM,
            name: '内部块图 Sysml Parameter Diagram',
          },
        ],
      },
      {
        code: ContextMenuCode.REQUIREMENT_DIAGRAM,
        name: '需求衍生图形 Requirement Diagrams',
        children: [
          {
            code: ContextMenuCode.REQUIREMENT_TABLE,
            name: '需求表 Requirement Table',
          },
          {
            code: ContextMenuCode.SATISFY_REQUIREMENT_MATRIX,
            name: '需求满足矩阵 Satisfy Requirement Matrix ',
          },
          {
            code: ContextMenuCode.DERIVE_REQUIREMENT_MATRIX,
            name: '衍生需求矩阵 Derive Requirement Matrix',
          },
          {
            code: ContextMenuCode.VERIFY_REQUIREMENT_MATRIX,
            name: '验证需求矩阵 Verify Requirement Matrix',
          },
          {
            code: ContextMenuCode.REFINE_REQUIREMENT_MATRIX,
            name: '提炼需求矩阵 Refine Requirement Matrix',
          },
        ],
      },
    ],
  },
  {
    code: ContextMenuCode.RENAME,
    name: '重命名 rename',
  },
  {
    code: ContextMenuCode.COPY,
    name: '复制 copy',
  },
  {
    code: ContextMenuCode.PASTE,
    name: '粘贴 paste',
  },
  {
    code: ContextMenuCode.CUT,
    name: '剪切 cut',
  },
  {
    code: ContextMenuCode.DELETE,
    name: '删除 delete',
  },
]
