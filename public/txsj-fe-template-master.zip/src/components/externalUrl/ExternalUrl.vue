<template>
  <div class="iframe-container">
    <iframe style="width: 100%; height: 100%" :src="iframeUrl"></iframe>
  </div>
</template>

<script>
// import configData from '@/utils/config'
export default {
  name: 'ExternalUrl',
  props: {
    url: {
      type: String,
      required: true,
    },
  },
  data() {
    return {}
  },
  computed: {
    iframeUrl() {
      return this.url
    },
  },
  mounted() {
    this.initProd()
  },
  methods: {
    initProd() {
      const buildEnv = process.env.VUE_APP_BUILD_ENV
      this.isProd = false
      if (buildEnv) {
        const envArr = buildEnv.split('_')
        //为prod模式，读取static数据
        if (envArr && envArr.length > 0 && envArr[0] === 'prod') {
          this.isProd = true
        }
      }
    },
  },
}
</script>

<style lang="less" scoped>
.iframe-container {
  height: 100%;
  width: 100%;

  iframe {
    border: none;
  }
}
</style>
