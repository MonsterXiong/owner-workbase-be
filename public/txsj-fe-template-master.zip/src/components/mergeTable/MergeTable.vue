<template>
  <el-table v-bind="$attrs" v-on="$listeners" ref="tableRef" :data="tableData" :span-method="_arraySpanMethod" v-if="visible">
    <template v-for="item in columns">
      <el-table-column
        v-if="item.type === 'index' || item.type === 'selection'"
        :key="`${item.label}_${item.prop}_fixed_column`"
        v-bind="item"
      ></el-table-column>
      <el-table-column v-else :key="`${item.label}_${item.prop}_column`" v-bind="item">
        <template slot-scope="{ row, column }">
          <slot v-if="item.slotName" :name="item.slotName" :row="row" :column="column"></slot>
          <template v-else-if="item.type === 'enum'">
            {{ $enum.getLabel(item.enum, row[item.prop]) }}
          </template>
          <template v-else>
            <span>
              {{ row[item.prop] }}
            </span>
          </template>
        </template>
      </el-table-column>
    </template>
  </el-table>
</template>

<script>
export default {
  props: {
    // 表格头
    columns: {
      type: Array,
      default: () => [],
    },
    // 表格数据
    data: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      tableData: [],
      rowspan: [],
      lastRowIndex: [],
      visible: true,
    }
  },
  watch: {
    data: {
      handler(val) {
        this._initRender()
      },
      immediate: true,
    },
  },
  methods: {
    // 初始化渲染 计算合并
    _initRender() {
      this.visible = false
      this.rowspan = []
      this.lastRowIndex = []
      this.tableData = [...this.data].sort((a, b) => {
        let flag = 0
        this.columns.forEach((col) => {
          if (col.merge && col.prop && flag === 0) {
            if (a[col.merge] > b[col.merge]) {
              flag = 1
            } else if (a[col.merge] < b[col.merge]) {
              flag = -1
            }
          }
        })
        return flag
      })
      this.lastRowIndex = this.columns.map(() => 0)
      this.tableData.forEach((item, rowIndex) => {
        this.rowspan.push([])
        this.columns.forEach((col, colIndex) => {
          this.rowspan[rowIndex].push(1)
          if (rowIndex === 0) return
          if (col.prop && col.merge && item[col.merge] === this.tableData[rowIndex - 1][col.merge]) {
            this.rowspan[this.lastRowIndex[colIndex]][colIndex] += 1
            this.rowspan[rowIndex][colIndex] = 0
          } else {
            this.lastRowIndex[colIndex] = rowIndex
          }
        })
      })
      this.$nextTick(() => {
        this.visible = true
      })
    },
    // 合并表格
    _arraySpanMethod({ row, rowIndex, columnIndex }) {
      const rowspan = this.rowspan[rowIndex][columnIndex]
      if (rowspan) {
        return {
          rowspan: rowspan,
          colspan: 1,
        }
      } else {
        return {
          rowspan: 0,
          colspan: 0,
        }
      }
    },
  },
}
</script>

<style scoped lang='less'>
</style>
