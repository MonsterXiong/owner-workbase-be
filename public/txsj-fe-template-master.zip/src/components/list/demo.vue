<template>
  <div style="display: flex">
    <div style="width: 300px; margin-right: 20px">
      <List v-model="taskId" :title="listTitle" :data="listData" @change="onChange" />
    </div>
    <div style="width: 300px">
      <List v-model="childrenId" :title="childrenTitle" :data="childrenList" />
    </div>
  </div>
</template>

<script>
import List from '@/components/list/List.vue'
import { uuid } from '@/utils/commonUtil'

export default {
  name: 'welcome',
  data() {
    return {
      taskId: '456',
      listTitle: '列表',
      listData: [
        {
          id: '123',
          name: '表格',
          children: [
            {
              id: uuid(),
              name: '通用表格',
            },
            {
              id: uuid(),
              name: '编辑表格',
            },
            {
              id: uuid(),
              name: '树形表格',
            },
            {
              id: uuid(),
              name: '合并表格',
            },
            {
              id: uuid(),
              name: '链路表格',
            },
            {
              id: uuid(),
              name: '卡片表格',
            },
            {
              id: uuid(),
              name: '清单列表',
            },
          ],
        },
        {
          id: '456',
          name: '表单',
          children: [
            {
              id: uuid(),
              name: '通用表单',
            },
            {
              id: uuid(),
              name: '富文本表单',
            },
            {
              id: uuid(),
              name: '代码编辑器',
            },
            {
              id: uuid(),
              name: '文档编辑器',
            },
          ],
        },
        {
          id: '789',
          name: '矩阵',
          children: [
            {
              id: uuid(),
              name: '文本矩阵',
            },
            {
              id: uuid(),
              name: '关系矩阵',
            },
            {
              id: uuid(),
              name: '权重矩阵',
            },
            {
              id: uuid(),
              name: '规则矩阵',
            },
          ],
        },
      ],
      childrenId: '',
      childrenTitle: '子列表',
      childrenList: [],
    }
  },
  methods: {
    onChange(data) {
      console.log(data, '==============')
      this.childrenList = data.children
    },
  },
  components: { List },
}
</script>

<style lang="less" scoped>
</style>
