<template>
  <div class="common-page list-wrap" ref="listWrapRef">
    <div class="head-wrap" ref="headWrapRef" :style="headStyle()">
      <div class="head-title">
        <span>{{ title }}</span>
        <i class="el-icon-plus" v-if="listConfig.allowAdd" @click="onAddNode"></i>
      </div>
    </div>
    <div class="list-content" :style="{ height: contentHeight }">
      <div class="search-wrap" v-if="listConfig.isFilter">
        <template v-if="listConfig.filterMode === filterMode.APPEND">
          <el-input v-model="searchName" size="mini" placeholder="请输入关键字进行过滤" clearable @keyup.enter.native="onQueryList">
            <el-button slot="append" icon="el-icon-search" @click="onQueryList"></el-button>
          </el-input>
          <el-button type="success" size="mini" icon="el-icon-circle-plus-outline" @click="onAddNode">新增</el-button>
        </template>
        <template v-else>
          <el-input v-model="searchName" size="mini" placeholder="请输入名称" clearable @keyup.enter.native="onQueryList"></el-input>
        </template>
      </div>
      <div
        v-for="item in data"
        :key="item[defaultProps.id]"
        :class="['list-item', item[defaultProps.id] == currentNodeId ? 'is-active' : '']"
        @click="onNodeClick(item)"
      >
        <slot v-bind="item">
          <span class="text-span" :style="{ width: item?.icons?.length > 0 ? `calc(100% - ${item.icons.length * 20}px)` : '100%' }">
            <Icon :iconName="item.icon || 'el-icon-collection-tag'" :type="item.iconType || 'el'" />
            {{ item[defaultProps.name] }}
          </span>
          <div class="button-wrap" v-if="item?.icons?.length > 0">
            <base-icon
              v-for="ele in item.icons"
              :key="ele.code"
              :iconName="ele.icon"
              :title="ele.name"
              style="margin-left: 4px"
              @click.native="onIconClick(ele.code, item)"
            ></base-icon>
          </div>
        </slot>
      </div>
    </div>
    <div class="footer-btn" ref="footerBtnRef">
      <slot name="footer"></slot>
    </div>
  </div>
</template>

<script>
import Icon from '@/baseComponents/icon/Icon.vue'
import { mergeObj } from '@/utils/commonUtil'

const filterMode = {
  APPEND: 'append',
}

export default {
  name: 'List',
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    title: {
      type: String,
      default: 'xx列表',
    },
    value: {
      type: String,
      default: '',
    },
    defaultProps: {
      type: Object,
      default: () => {
        return {
          name: 'name',
          id: 'id',
        }
      },
    },
    config: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      searchName: '',
      currentNodeId: '',
      selectNode: null,
      filterMode,
      baseConfig: {
        allowAdd: false,
        isFilter: false, // 搜索
        // filterMode: filterMode.APPEND,
        // headStyle: { backgroundImage: 'url(' + require('./image/list-hed-bg.png') + ')', backgroundSize: '100% 100%' }, // 头部背景
        isSelectOneNode: true, // 选中第一个节点
      },
      contentHeight: '',
    }
  },
  computed: {
    listConfig() {
      return mergeObj(this.baseConfig, this.config)
    },
  },
  mounted() {
    this.$nextTick(() => {
      let timer = setTimeout(() => {
        this.setContentHeight()
        clearTimeout(timer)
      }, 0)
    })
  },
  methods: {
    onQueryList() {
      this.$emit('query', this.searchName)
    },
    onNodeClick(data) {
      if (!data || this.currentNodeId === data[this.defaultProps.id]) return
      this.currentNodeId = data[this.defaultProps.id]
      this.selectNode = data
      this.$emit('nodeClick', data)
    },
    onIconClick(code, data) {
      this.$emit('iconClick', { code, data })
    },
    onAddNode() {
      this.$emit('add')
    },
    headStyle() {
      return mergeObj(this.listConfig.headStyle)
    },
    setContentHeight() {
      this.contentHeight = this.$refs.listWrapRef.offsetHeight - this.$refs.headWrapRef.offsetHeight - this.$refs.footerBtnRef.offsetHeight - 20 + 'px'
    },
  },
  components: { Icon },
  watch: {
    currentNodeId() {
      this.$emit('input', this.currentNodeId)
      this.$emit('change', this.selectNode)
    },
    value: {
      handler() {
        if (this.value) {
          const itemData = this.data.find((item) => item[this.defaultProps.id] === this.value)
          this.onNodeClick(itemData)
        } else {
          if (this.listConfig.isSelectOneNode) this.onNodeClick(this.data[0])
        }
      },
      immediate: true,
    },
    // 数据还未拿到
    data() {
      if (this.listConfig.isSelectOneNode) this.onNodeClick(this.data[0])
    },
  },
}
</script>

<style lang="less" scoped>
@base-border-color: var(--base-border-color, #56adeb);
@font-color-light: var(--font-color-light, #fff);
@font-color-active: var(--font-color-active, #1990ff);
@linear-to-color: var(--linear-to-color, #1b6dd9);
@linear-right-color: var(--linear-to-color, #002150);
@padding-num: 10px;
.list-wrap {
  width: 100%;
  height: 100%;
  border: 1px solid @base-border-color;
  .head-wrap {
    padding: 0 10px;
    height: 36px;
    line-height: 36px;
    width: 100%;
    position: relative;
    display: flex;
    align-items: center;
    background-image: linear-gradient(to right, @linear-to-color, @linear-right-color);
    .head-title {
      width: 100%;
      height: 100%;
      position: relative;
      font-size: 18px;
      color: @font-color-light;
      span {
        position: relative;
        font-weight: 600;
        letter-spacing: 0.1em;
      }
      i {
        padding: 2px;
        border: 1px solid @font-color-light;
        border-radius: 2px;
        font-size: 16px;
        position: absolute;
        top: 50%;
        right: 0;
        transform: translateY(-50%);
        cursor: pointer;
      }
    }
  }
  .list-content {
    padding: @padding-num;
    overflow-y: auto;
    .search-wrap {
      padding-bottom: @padding-num;
      display: flex;
      .el-button {
        margin-left: @padding-num;
      }
    }
    .list-item {
      cursor: pointer;
      width: 100%;
      line-height: 26px;
      overflow: hidden;
      text-overflow: ellipsis;
      font-size: 14px;
      display: flex;
      justify-content: space-between;
      .text-span {
        display: inline-block;
        // width: calc(100% - 68px);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      &.is-active {
        color: @font-color-active;
      }
      .button-wrap {
        i {
          margin-right: 5px;
          &:last-child {
            margin-right: 0;
          }
        }
      }
    }
  }
  .footer-btn {
    display: flex;
    justify-content: center;
  }
}
</style>
