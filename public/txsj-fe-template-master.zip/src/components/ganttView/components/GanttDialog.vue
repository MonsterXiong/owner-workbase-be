<template>
  <base-dialog :title="dialogTitle" :visible.sync="dialogVisible" :width="width" :before-close="hide">
    <el-form :model="formData" ref="formRef" :rules="formRules" label-width="auto">
      <el-form-item label="名称" :prop="formData[config.nodeName]">
        <el-input v-model="formData[config.nodeName]" placeholder="请输入名称"></el-input>
      </el-form-item>
      <el-form-item label="开始时间" prop="start_date">
        <template v-if="config.durationUnit === 'hour'">
          <el-time-picker style="width: 100%" v-model="formData.start_date" placeholder="请选择开始时间"></el-time-picker>
        </template>
        <template v-else>
          <el-date-picker style="width: 100%" v-model="formData.start_date" type="date" placeholder="选择开始时间"> </el-date-picker>
        </template>
      </el-form-item>
      <el-form-item label="结束时间" prop="end_date">
        <template v-if="config.durationUnit === 'hour'">
          <el-time-picker style="width: 100%" v-model="formData.end_date" placeholder="请选择结束时间"></el-time-picker>
        </template>
        <template v-else>
          <el-date-picker style="width: 100%" v-model="formData.end_date" type="date" placeholder="请选择结束时间"> </el-date-picker>
        </template>
      </el-form-item>
    </el-form>
    <template slot="footer">
      <el-button size="medium" @click="hide()">取 消</el-button>
      <el-button size="medium" type="primary" @click="onSubmit">确 定</el-button>
    </template>
  </base-dialog>
</template>

<script>
import { DialogWidths } from '@/common/baseConstants'
export default {
  name: 'ganttDialog',
  props: {
    config: Object,
  },
  data() {
    return {
      dialogTitle: '新增',
      dialogVisible: false,
      width: DialogWidths.MEDIUM_FORM,
      formData: {},
      formRules: {
        [this.config.nodeName]: [{ required: true, message: '请输入名称', trigger: 'blur' }],
        start_date: [{ required: true, message: '请选择开始时间', trigger: 'change' }],
        end_date: [{ required: true, message: '请选择结束时间', trigger: 'change' }],
      },
    }
  },
  methods: {
    show(row) {
      this.dialogVisible = true
      if (row) {
        this.formData = { ...row }
        this.dialogTitle = '编辑'
      } else {
        this.dialogTitle = '新增'
      }
    },
    onSubmit() {
      this.$refs.formRef.validate((valid) => {
        if (valid) {
          this.$emit('update', { ...this.formData })
          this.hide()
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    hide() {
      this.dialogVisible = false
    },
  },
}
</script>
