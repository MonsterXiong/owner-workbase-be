<template>
  <div class="gantt-container">
    <slot>
      <div class="toolbar_btn_group">
        <el-form v-model="queryForm" ref="queryFormRef" label-width="auto" size="small" inline @submit.native.prevent>
          <el-form-item label="名称">
            <el-input v-model="queryForm.name" placeholder="请输入名称"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" @click="onSearchQuery">查询</el-button>
            <el-button icon="el-icon-refresh" type="primary" @click="onResetQuery">重置</el-button>
            <el-button size="small" type="primary" icon="el-icon-circle-plus-outline" @click="onAdd">新增</el-button>
            <el-button plain type="success" size="small" icon="el-icon-upload" @click="onImport">导入数据</el-button>
            <el-button plain type="success" size="small" icon="el-icon-download" @click="onExport">导出数据</el-button>
            <el-button plain size="small" icon="el-icon-delete" @click="onClearData">清空数据</el-button>
          </el-form-item>
        </el-form>
      </div>
    </slot>
    <div class="gantt-wrap">
      <div ref="myGantt"></div>
    </div>
    <slot name="dialog">
      <GanttDialog ref="ganttDialogRef" @update="onUpdate" :config="config" />
    </slot>
  </div>
</template>

<script>
import { gantt } from 'dhtmlx-gantt'
import 'dhtmlx-gantt/codebase/dhtmlxgantt.css'
import GanttDialog from './components/GanttDialog.vue'
import { baseConfig, ganttColumns, ganttData } from './index'
import { isFunction, mergeObj, uuid } from '@/utils/commonUtil'

export default {
  name: 'ganttView',
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    ganttConfig: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      queryForm: {},
      ganttData,
      defaultOption: {
        ...baseConfig,
        ganttColumns,
      },
    }
  },
  computed: {
    config() {
      return mergeObj(this.defaultOption, this.ganttConfig)
    },
  },
  mounted() {
    if (this.data.length > 0) {
      this.ganttData = this.data
    }
    this.init()
  },
  methods: {
    init() {
      this.initGantt()
      this.setGanttData()
      this.ganttRegisterEvent()
    },
    initGantt() {
      gantt.i18n.setLocale('cn') // 设置中文
      gantt.config.show_errors = false // 隐藏错误消息
      gantt.config.columns = this.config.ganttColumns // 初始化列
      // 工具栏
      gantt.plugins({
        tooltip: true, // 启用tooltip悬浮框
        marker: true, // 时间标记
        // drag_timeline: true, // 拖动图
        // quick_info: true, // 快速信息框
      })
      gantt.config.scale_height = this.config.durationUnit ? 40 : 80 // 设置表头高度
      gantt.config.show_progress = false
      gantt.config.show_links = false
      gantt.config.lightbox = false
      gantt.config.drag_resize = true
      gantt.config.drag_move = false
      gantt.config.fit_tasks = true
      // 设置甘特图时间
      if (this.config.durationUnit === 'hour') {
        gantt.config.start_date = new Date(`${new Date().toLocaleDateString().replaceAll('/', '-')} 00:00`)
        gantt.config.end_date = new Date(`${new Date().toLocaleDateString().replaceAll('/', '-')} 23:59`)
      }
      gantt.config.show_tasks_outside_timescale = true // 允许显示超过时间刻度的任务
      // 设置时间刻度
      gantt.config.scales = this.getGanttScales()

      // 任务显示内容
      gantt.templates.task_text = (start, end, task) => {
        return task[this.config.nodeName]
      }
      // 鼠标悬浮提示内容
      gantt.templates.tooltip_text = (start, end, task) => {
        return task[this.config.nodeName]
      }
      gantt.init(this.$refs.myGantt)
      window.gantt = gantt
    },
    // 事件
    ganttRegisterEvent() {
      // 双击事件
      gantt.attachEvent('onTaskDblClick', this.handleTaskDblClick, { id: 'onTaskDblClick' })
    },
    handleTaskDblClick(id) {
      const taskData = gantt.getTask(id)
      const row = {
        [this.config.nodeId]: taskData[this.config.nodeId],
        [this.config.nodeName]: taskData[this.config.nodeName],
        start_date: taskData.start_date,
        end_date: taskData.end_date,
      }
      this.$refs.ganttDialogRef.show(row)
    },
    onSearchQuery() {
      // 查询
      this.$emit('query', this.queryForm)
    },
    onResetQuery() {
      for (const key in this.queryForm) {
        this.queryForm[key] = ''
      }
      this.$emit('reset')
    },
    onAdd() {
      this.$refs.ganttDialogRef.show()
    },
    onImport() {
      this.$emit('import')
    },
    onExport() {
      this.$emit('reset')
    },
    onUpdate(formData) {
      if (formData[this.config.nodeId]) {
        const index = this.ganttData.findIndex((item) => item[this.config.nodeId] === formData[this.config.nodeId])
        this.ganttData[index] = { ...formData }
        // 编辑
      } else {
        // 新增
        this.ganttData.push({
          ...formData,
          [this.config.nodeId]: uuid(),
        })
      }
      this.setGanttData()
      this.$emit('saveNode', formData)
    },
    setGanttData() {
      gantt.clearAll()
      gantt.init(this.$refs.myGantt)
      gantt.parse({
        data: this.ganttData.map((item) => {
          return {
            ...item,
            start_date: new Date(item.start_date),
            end_date: new Date(item.end_date),
          }
        }),
      })
    },
    onClearData() {
      this.ganttData = []
      this.setGanttData()
    },
    getGanttScales() {
      if (this.config.ganttScalesHook && isFunction(this.config.ganttScalesHook)) {
        return this.config.ganttScalesHook || []
      } else {
        let scales = []
        const year = {
          unit: 'year',
          step: 1,
          format: (date) => {
            return `${date.getFullYear()}年`
          },
        }
        const month = {
          unit: 'month',
          step: 1,
          format: (date) => {
            return `${date.getMonth() + 1}月`
          },
        }
        const day = {
          unit: 'day',
          step: 1,
          format: (date) => {
            return `${date.getDate()}日`
          },
        }
        const hour = {
          unit: 'hour',
          step: 1,
          format: (date) => {
            const hourNum = new Date(date).getHours() + 1
            return `${hourNum < 10 ? '0' + hourNum : hourNum}:00`
          },
        }
        switch (this.config.durationUnit) {
          case 'hour':
            scales.push(hour)
            break
          case 'day':
            scales.push(day)
            break
          case 'month':
            scales.push(month)
            break
          case 'year':
            scales.push(year)
            break
          case 'year_month':
            scales.push(month)
            scales.push(year)
            break
          case 'month_day':
            scales.push(day)
            scales.push(month)
            break
          default:
            scales.push(year)
            scales.push(month)
            scales.push(day)
            break
        }
        return scales
      }
    },
  },
  deactivated() {
    gantt.clearAll()
  },
  components: { GanttDialog },
}
</script>

<style lang="less" scoped>
.gantt-container {
  width: 100%;
  height: 100%;
  .gantt-wrap {
    height: calc(100% - 51px);
    & > div {
      height: 100%;
    }
  }
}
</style>
