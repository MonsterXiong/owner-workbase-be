import { uuid } from '@/utils/commonUtil'

const currDate = '2024-05-14'

export const baseConfig = {
  nodeName: 'text',
  nodeId: 'id',
  durationUnit: '',
}

export const ganttColumns = [
  {
    name: baseConfig.nodeName,
    label: '名称',
    tree: true,
    width: '*',
  },
  {
    name: 'start_date',
    label: '开始时间',
    align: 'center',
    width: '*',
  },
  {
    name: 'end_date',
    label: '结束时间',
    align: 'center',
    width: '*',
  },
]

export const ganttData = [
  {
    id: uuid(),
    [baseConfig.nodeName]: '名称1',
    start_date: `${currDate} 01:00:00`,
    end_date: `${currDate} 12:00:00`,
  },
]
