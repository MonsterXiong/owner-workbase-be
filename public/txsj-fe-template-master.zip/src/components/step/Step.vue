<template>
  <div class="step-bar" :style="{ height: tabHeight }">
    <div class="step-wrapper" v-show="pattern == '1'">
      <div class="step-item" v-for="step in stepList" :key="step[defaultProps.code]" @click="onStepClick(step)" :class="getStepClass(step[defaultProps.sort])">
        <span class="step-sort" v-show="showSort">{{ step[defaultProps.sort] }}</span>
        <span class="step-name">{{ step[defaultProps.name] }}</span>
      </div>
    </div>
    <div class="step-wrapper" v-show="pattern == '2'" :class="pattern == '2' ? 'step-wrapper2' : ''">
      <div class="step-item2" v-for="item in stepList" :key="item[defaultProps.code]" :class="getStepClass2(item[defaultProps.sort])">
        <div style="width: 171px; text-align: center">
          <span class="step-sort" v-show="showSort">{{ item[defaultProps.sort] }}</span>
          {{ item[defaultProps.name] }}
        </div>
      </div>
      <div style="position: absolute; right: 0; top: 0px; right: 10px">
        <div class="step-select"></div>
        <div class="step-btn">
          <el-button v-if="activeStep[defaultProps.sort] > 1" size="mini" type="primary" @click="onChnageStep(-1)">上一步</el-button>
          <el-button v-if="activeStep[defaultProps.sort] < this.stepList.length" size="mini" type="primary" @click="onChnageStep(1)">下一步</el-button>
          <slot name="operate-btn"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'StepBar',
  props: {
    stepList: {
      type: Array,
      default: () => [],
    },
    defaultProps: {
      type: Object,
      default: () => {
        return {
          sort: 'sort',
          code: 'code',
          name: 'name',
        }
      },
    },
    showSort: {
      type: Boolean,
      default: true,
    },
    tabHeight: {
      type: String,
      default: '50px', //100%
    },
    initStep: {
      type: String,
      default: '',
    },
    pattern: {
      type: String,
      default: '1',
    },
  },
  data() {
    return {
      activeStep: '',
    }
  },
  mounted() {
    this.onStepClick(this.stepList[0])
  },
  methods: {
    onStepClick(step) {
      this.activeStep = step
      this.$emit('stepClick', step)
    },
    getStepClass(sort) {
      if (!this.activeStep) return ''
      if (sort <= this.activeStep[this.defaultProps.sort]) return 'isActive'
    },
    getStepClass2(sort) {
      if (!this.activeStep) return ''
      if (sort == this.activeStep[this.defaultProps.sort]) return 'active'
    },
    onChnageStep(val) {
      let sort = Number(this.activeStep[this.defaultProps.sort]) + val
      let step = this.stepList.find((ele) => ele[this.defaultProps.sort] == sort)
      this.onStepClick(step)
    },
  },
  watch: {
    initStep: {
      handler(val) {
        if (this.stepList.length == 0) return
        if (val) {
          let step = this.stepList.find((ele) => ele[this.defaultProps.code] == val)
          this.onStepClick(step)
        } else {
          this.onStepClick(this.stepList[0])
        }
      },
      immediate: true,
    },
    activeStep: {
      handler() {
        this.$emit('input', this.activeStep[this.defaultProps.code])
      },
      immediate: true,
    },
  },
}
</script>

<style lang="less" scoped>
.step-bar {
  height: 100%;
  .step-wrapper {
    height: 100%;
    display: flex;
    justify-content: center;
    position: relative;
  }
  .step-wrapper2 {
    // padding: 5px 0;
    // background: url('./image/step-top-bg.png') 100% / cover;
  }
  .step-item {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0 24px;
    // margin: 2px;
    clip-path: polygon(0% 0%, calc(100% - 18px) 0%, 100% 50%, calc(100% - 18px) 100%, 0px 100%, 18px 50%, 0% 0%);
    background: #bdc3c7;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    width: 170px;
    margin: 0 4px;

    .step-sort {
      display: inline-block;
      height: 16px;
      width: 16px;
      border-radius: 8px;
      background: #fff;
      color: #19a5dc;
      text-align: center;
      margin-right: 8px;
      font-size: 14px;
    }
    .step-name {
      line-height: 38px;
    }
    &:hover {
      background: #19a5dc;
    }
  }
  .isActive {
    background: #19a5dc !important;
  }
  .step-item2:last-child {
    margin-right: 0px;
  }
  .step-item2 {
    background: url('./image/flow.png') no-repeat;
    background-size: 100% 100%;

    height: 100%;
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #3390e7;
    font-weight: bold;
    position: relative;
    cursor: pointer;
    margin-right: 30px;
    &.active,
    &:hover {
      background: url('./image/flow-active.png') no-repeat;
      background-size: 100% 100%;

      height: 100%;
      color: white;
    }
    &:not(:first-of-type) {
      &::after {
        content: '';
        position: absolute;
        left: -25px;
        width: 0;
        height: 0;
        border-radius: 4px;
        border-top: 10px solid transparent;
        border-bottom: 10px solid transparent;
        border-left: 20px solid #e6f1fc;
      }
    }
  }
}
</style>
