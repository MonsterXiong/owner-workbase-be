<template>
  <MatrixTable v-bind="$attrs" v-on="$listeners">
    <template slot-scope="{ data, y, x }">
      <el-input-number @change="onInputChange(data, y, x)" style="width: 100%" size="mini" :controls="false" v-model="data.value"></el-input-number>
    </template>
  </MatrixTable>
</template>

<script>
import MatrixTable from '../MatrixTable.vue'

export default {
  components: {
    MatrixTable,
  },
  data() {
    return {}
  },

  methods: {
    onInputChange(data, y, x) {
      console.log(data, y, x)
    },
  },
}
</script>

<style scoped lang="less"></style>
