<template>
  <el-table
    border
    class="matrix"
    :data="tableData"
    height="100%"
    ref="tableRef"
    :span-method="render_spanMethod"
    @cell-mouse-enter="render_cellMouseEnter"
    @cell-mouse-leave="render_cellMouseLeave"
    @cell-click="cellClick"
    v-bind="tableProps"
    v-if="render_visible"
  >
    <el-table-column v-for="(item, index) in render_yColumn" :class-name="`cell-header cell${index}`" :key="item.prop" align="center" v-bind="item">
      <template #header>
        <div class="column-header">
          <div>{{ titles[0] }}</div>
          <div>{{ titles[1] }}</div>
        </div>
      </template>
    </el-table-column>
    <TreeColumn v-for="item in render_xColumn" :data="item" :key="item.id" :minColumnWidth="minColumnWidth">
      <template slot-scope="{ row, column }">
        <slot :row="row" :column="column" :x="column.property" :y="row._id" :data="getData(row, column)"> {{ getData(row, column).value }} </slot>
      </template>
    </TreeColumn>
  </el-table>
</template>

<script>
import html2canvas from 'html2canvas'
import renderMixins from './mixins/renderMixins'
import TreeColumn from './components/TreeColumn.vue'

export default {
  mixins: [renderMixins],
  props: {
    // X轴数据
    xData: {
      type: Array,
      default: () => [],
    },
    // X轴数据字段定义
    xProps: {
      type: Object,
      default: () => ({
        name: 'name',
        id: 'id',
        parentId: 'parentId',
      }),
    },
    // Y轴数据
    yData: {
      type: Array,
      default: () => [],
    },
    // Y轴数据字段定义
    yProps: {
      type: Object,
      default: () => ({
        name: 'name',
        id: 'id',
        parentId: 'parentId',
      }),
    },
    // 关系数据
    data: {
      type: Array,
      default: () => [],
    },
    // 关系字段定义
    dataProps: {
      type: Object,
      default: () => ({
        x: 'x',
        y: 'y',
        value: 'value',
      }),
    },
    // 矩阵标题
    titles: {
      type: Array,
      default: () => [],
    },
    // 最小column宽度
    minColumnWidth: [String, Number],
    // 原生el-table属性
    tableProps: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    this.timer = null
    return {
      xTreeData: [], // x轴树形数组
      yTreeData: [], // y轴树形数组
      xyRelData: [], // 关联数据
      tableData: [], // 构成表格的数据
    }
  },
  watch: {},
  methods: {
    getData(row, column) {
      return this.render_dataMap.get(`${row._id}-${column.property}`) || {}
    },
    // 获取当前单元格对应的X轴数据
    getXData(row, column) {
      const id = row['_id' + column.property.split('_name')[1]]
      return this.render_xIdMap.get(id)
    },
    cellClick(row, column, cell, event) {
      const y = row._id
      const x = column.property
      const findValue = this.getData(row, column)
      if (y === x) return
      this.$emit('cellClick', {
        y,
        x,
        xData: this.getXData(row, column),
        yData: row,
        row,
        column,
        cell,
        event,
        data: findValue,
      })
    },
    // 保存图片 供外部调用
    saveImage(name) {
      const element = this.$el
      html2canvas(element).then(async (canvas) => {
        this.downloadBlobFile(name || '矩阵图', this.dataUrltoBlob(canvas.toDataURL()))
        this.$message.success('导出图片成功')
      })
    },
    downloadBlobFile(name, blob) {
      const objectUrl = URL.createObjectURL(blob)
      const link = document.createElement('a') // 创建a标签
      link.href = objectUrl
      // 重命名文件
      link.download = name
      link.click()
      URL.revokeObjectURL(objectUrl)
    },
    dataUrltoBlob(dataUrl) {
      let arr = dataUrl.split(','),
        mine = arr[0].match(/:(.*?);/)[1],
        bstr = window.atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
      }
      return new Blob([u8arr], {
        type: mine,
      })
    },
  },
  components: { TreeColumn },
}
</script>

<style scoped lang="less">
@import './matrix.less';
</style>
