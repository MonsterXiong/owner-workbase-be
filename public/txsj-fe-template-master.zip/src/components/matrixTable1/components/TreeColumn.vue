<template>
  <el-table-column :label="data.name" align="center" :prop="data.id" :min-width="columnWidth">
    <template v-if="data.children && Array.isArray(data.children)">
      <tree-column v-for="item in data.children" :data="item" :key="item.id" :minColumnWidth="minColumnWidth">
        <template slot-scope="{ row, column }">
          <slot :row="row" :column="column"></slot>
        </template>
      </tree-column>
    </template>
    <template slot-scope="{ row, column }">
      <slot :row="row" :column="column"></slot>
    </template>
  </el-table-column>
</template>

<script>
export default {
  name: 'TreeColumn',
  props: {
    data: {
      type: Object,
      default: () => {},
    },
    // 最小column宽度
    minColumnWidth: [String, Number],
  },
  computed: {
    isHaveChildren() {
      if (this.data.children && Array.isArray(this.data.children) && this.data.children.length) {
        return true
      }
      return false
    },
    columnWidth() {
      return this.isHaveChildren ? '' : this.minColumnWidth
    },
  },
  data() {
    return {}
  },
}
</script>

<style scoped lang="less"></style>
