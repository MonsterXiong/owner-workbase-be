import InputMatrixTable from './extTable/InputMatrixTable.vue'
import MatrixTable from './MatrixTable.vue'

export { InputMatrixTable, MatrixTable }

export default MatrixTable
