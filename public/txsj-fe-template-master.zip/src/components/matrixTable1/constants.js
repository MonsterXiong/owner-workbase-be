// 默认X轴字段定义
const default_xProps = Object.freeze({
  name: 'name',
  id: 'id',
  parentId: 'parentId',
})
// 默认Y轴字段定义
const default_yProps = Object.freeze({
  name: 'name',
  id: 'id',
  parentId: 'parentId',
})
// 默认关系字段定义
const default_props = Object.freeze({
  x: 'to',
  y: 'from',
  value: 'value',
})

export { default_xProps, default_yProps, default_props }
