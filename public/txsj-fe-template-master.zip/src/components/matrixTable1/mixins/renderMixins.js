// 这里只写矩阵渲染相关的逻辑,不涉及操作
import { default_xProps, default_yProps, default_props } from '../constants'

export default {
  data() {
    this.timer = null
    this.colWidth = {}
    this.colMinTotal = {}
    this.colMaxLength = {}
    return {
      render_visible: true,
      render_xColumn: [],
      render_yColumn: [],

      yMaxDepth: 0, // y轴树形数据最大深度
      rowspan: [], // 帮助判断表格合并的数据
      lastIndex: [],

      render_xIdMap: new Map(), // 用来快速根据ID查找到对应X轴数据
      render_dataMap: new Map(), // 用来快速找到 映射关系
    }
  },
  watch: {
    xData: {
      handler() {
        this.render_onRefresh()
      },
      immediate: true,
    },
    yData: {
      handler() {
        this.render_onRefresh()
      },
      immediate: true,
    },
    data: {
      handler() {
        this.render_initData()
      },
      immediate: true,
    },
  },
  methods: {
    render_onRefresh() {
      this.timer && clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        this.render_initRenderData()
      }, 0)
    },
    // 初始化渲染需要的数据
    render_initRenderData() {
      this.render_visible = false
      this.render_yColumn = []
      this.render_xColumn = []
      this.tableData = []
      this.yMaxDepth = 0
      this.render_xIdMap.clear()

      this.colWidth = {}
      this.colMinTotal = {}
      this.colMaxLength = {}

      this.rowspan = []
      this.lastIndex = []
      this.xTreeData = this.listToTree(
        this.xData,
        {
          ...default_xProps,
          ...this.xProps,
        },
        false,
        this.render_xIdMap
      )
      this.yTreeData = this.listToTree(
        this.yData,
        {
          ...default_yProps,
          ...this.yProps,
        },
        true
      )
      this.yTreeData.forEach((item) => this.getChildrenTotal(item, 0))
      this.render_xColumn = this.xTreeData
      // 生成对应y轴的column
      for (let i = 0; i <= this.yMaxDepth; ++i) {
        this.lastIndex.push(0)
        const data = {
          name: '',
          prop: '_name' + i,
        }
        // 最多有几行
        const maxLen = Math.ceil((this.colMinTotal[i] * 35 - 10) / 24)
        const maxWidth = Math.ceil(this.colMaxLength[i] / maxLen) * 15 + 20
        if (this.colWidth[i]) {
          data.width = i === this.yMaxDepth ? this.colWidth[i] : Math.max(maxWidth, this.colWidth[i])
        } else {
          data.width = maxWidth
        }
        this.render_yColumn.push(data)
      }
      this.getRowspan()
      this.$nextTick(() => {
        this.render_visible = true
        this.render_slash()
        this.onScroll()
      })
    },
    render_initData() {
      this.render_dataMap.clear()
      this.xyRelData = this.data.map((item) => {
        const newData = this.render_transformDataByProps(item, {
          ...default_props,
          ...this.dataProps,
        })
        this.render_dataMap.set(`${newData.x}-${newData.y}`, newData)
        this.render_dataMap.set(`${newData.y}-${newData.x}`, newData)
        return newData
      })
    },
    getChildrenTotal(parent, index) {
      if (parent.children) {
        parent._total = parent.children.reduce((total, item) => {
          return total + this.getChildrenTotal(item, index + 1)
        }, 0)
        if (!this.colMaxLength[index]) this.colMaxLength[index] = 1
        if (!this.colMinTotal[index]) this.colMinTotal[index] = 9999
        this.colMaxLength[index] = Math.max(this.colMaxLength[index], parent.name.length)
        this.colMinTotal[index] = Math.min(this.colMinTotal[index], parent._total)
        return parent._total
      }
      return 1
    },
    // 数组转成树结构
    listToTree(list, props, isY = false, idMap = new Map()) {
      const newList = list.map((item) => {
        const newItem = this.render_transformDataByProps(item, props)
        idMap.set(newItem.id, newItem)
        return newItem
      })
      const treeData = newList.reduce((tree, item) => {
        const parent = idMap.get(item.parentId)
        if (parent) {
          ;(parent.children || (parent.children = [])).push(item)
        } else {
          tree.push(item)
        }
        return tree
      }, [])
      this.traverseTreeAndCreateTableData(treeData, isY)
      return treeData
    },
    // 遍历树 如果是Y轴则生成表格数据   TODO 可能要做树剪枝
    traverseTreeAndCreateTableData(tree, isY = false, parent = {}, parentRow = {}, index = 0) {
      if (Array.isArray(tree)) {
        tree.forEach((item) => {
          // 生成表格数据
          const row = {
            ...item,
            ...parentRow,
            ['_name' + index]: item.name,
            ['_id' + index]: item.id,
            _name: item.name || '',
            _id: item.id,
            _index: index,
          }
          if (parent.id) {
            item.parentNameChain = [...parent.parentNameChain, item.name]
            item.parentIdChain = [...parent.parentIdChain, item.id]
          } else {
            item.parentNameChain = [item.name]
            item.parentIdChain = [item.id]
          }
          if (Array.isArray(item.children)) {
            this.traverseTreeAndCreateTableData(item.children, isY, item, row, index + 1)
          } else if (isY) {
            if (!this.colWidth[index]) this.colWidth[index] = 15 + 20
            this.colWidth[index] = Math.max(row._name.length * 15 + 20, this.colWidth[index])
            this.yMaxDepth = Math.max(index, this.yMaxDepth)
            this.tableData.push(row)
          }
        })
      }
    },
    // 根据props定义转换数据
    render_transformDataByProps(data, props) {
      const newData = {
        _data: data,
      }
      Object.keys(props).forEach((key) => {
        newData[key] = data[props[key]]
      })
      return newData
    },
    // 渲染左上角斜线
    render_slash() {
      this.$nextTick(() => {
        this.render_yColumn.forEach((column, index) => {
          if (index === 0) {
            const dom = document.querySelector(`.cell-header.cell${index}`)
            if (dom) {
              dom.setAttribute('colspan', this.yMaxDepth + 1)
              // 如果不需要斜线, 下面这行注释掉就行
              dom.className = dom.className + ' matrixLine'
            }
          } else {
            const dom = document.querySelector(`.cell-header.cell${index}`)
            if (dom) dom.style = `display: none`
          }
        })
      })
    },
    // 用来计算表格合并
    getRowspan() {
      this.tableData.forEach((item, index) => {
        this.rowspan.push([])
        for (let col = 0; col <= this.yMaxDepth; ++col) {
          this.rowspan[index].push(1)
          if (index > 0) {
            if (item['_id' + col] === this.tableData[index - 1]['_id' + col]) {
              this.rowspan[this.lastIndex[col]][col] += 1
              this.rowspan[index][col] = 0
            } else {
              this.lastIndex[col] = index
            }
          }
        }
      })
    },
    // 合并表格的方法
    render_spanMethod({ row, rowIndex, columnIndex }) {
      if (columnIndex <= this.yMaxDepth) {
        const rowspan = this.rowspan[rowIndex][columnIndex]
        if (rowspan) {
          return {
            rowspan: rowspan,
            colspan: columnIndex < row._index ? 1 : columnIndex > row._index ? 0 : this.yMaxDepth + 1 - row._index,
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0,
          }
        }
      }
    },
    // 鼠标移入效果
    render_cellMouseEnter(row, column, cell) {
      if (row._id === column.property || column.property.includes('_name')) {
        return
      }
      // 给这一竖上hover特效
      const colDomList = [...document.getElementsByClassName(column.id)]
      // 给这一行加上hover特效
      const rowDomList = [...cell.parentElement.cells]

      // 怕x轴拖的很远,看不到这一行是哪个名称
      const domList = [...colDomList, ...rowDomList]
      domList.forEach((dom) => {
        if (!dom.className.includes('is-leaf')) dom.classList.add('hover')
      })
      cell.classList.add('cell-hover')
    },
    // 鼠标移出 清除效果
    render_cellMouseLeave(row, column, cell) {
      const colDomList = [...document.getElementsByClassName(column.id)]
      const rowDomList = [...cell.parentElement.cells]
      const domList = [...colDomList, ...rowDomList]
      domList.forEach((dom) => {
        dom.classList.remove('hover')
      })
      cell.classList.remove('cell-hover')
    },
    onScroll(e) {
      this.unScroll()
      this.$nextTick(() => {
        const table = this.$refs.tableRef.bodyWrapper
        const rowList = table.querySelectorAll('tr.el-table__row')
        const fixedHeader = document.createElement('aside')
        fixedHeader.className = 'fixed-aside'
        rowList.forEach((dom) => {
          const header = [...dom.childNodes].findLast((dom) => dom.className.includes('cell-header'))
          if (header) {
            const cloneHeader = document.createElement('div')
            cloneHeader.className = 'fixed-header cell-header'
            cloneHeader.style.height = `${header.offsetHeight}px`
            cloneHeader.innerHTML = header.children[0].innerHTML
            fixedHeader.appendChild(cloneHeader)
          }
        })
        table.appendChild(fixedHeader)
        table.addEventListener('scroll', this.handleScroll)
      })
    },
    unScroll() {
      const bodyWrapper = this.$refs?.tableRef?.bodyWrapper
      if (bodyWrapper) {
        const fixedHeader = bodyWrapper.querySelector('.fixed-aside')
        if (fixedHeader) bodyWrapper.removeChild(fixedHeader)
        bodyWrapper.removeEventListener('scroll', this.handleScroll)
      }
    },
    handleScroll(e) {
      const rowHeader = this.$el.querySelector(`td.cell-header.cell${this.yMaxDepth}`)
      const bodyWrapper = this.$refs.tableRef.bodyWrapper
      if (rowHeader && bodyWrapper) {
        const { right } = rowHeader.getBoundingClientRect()
        const { left: parentLeft } = bodyWrapper.getBoundingClientRect()
        const fixedHeader = bodyWrapper.querySelector('.fixed-aside')
        if (right <= parentLeft) {
          fixedHeader.style.setProperty('transform', `translateX(${bodyWrapper.scrollLeft}px)`)
          fixedHeader.style.setProperty('opacity', '1')
          fixedHeader.style.setProperty('pointer-events', 'initial')
        } else {
          fixedHeader.style.setProperty('opacity', '0')
          fixedHeader.style.setProperty('pointer-events', 'none')
        }
      }
    },
  },
  beforeDestroy() {
    this.unScroll()
  },
}
