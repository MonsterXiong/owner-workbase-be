<template>
  <div class="graph-design" ref="graphDesignRef">
    <slot>
      <!-- <Toolbar ref="ToolbarRef" @toolbarClick="onToolbarClick" /> -->
      <GojsDiagramToolbar
        ref="ToolbarRef"
        :optionVisible="finallyConfig.optionVisible"
        @valueChange="handleValueChange"
        @itemClick="handleItemClick"
        @layerChange="handleLayerChange"
        @layoutChange="handleLayoutChange"
        @exportData="handleExportData"
        @importXml="handleImportXml"
      ></GojsDiagramToolbar>
    </slot>
    <div class="diagram-wrap" ref="diagramWrapRef">
      <div class="graph-diagram" ref="diagramRef" @drop="handleDrop" @dragenter="handleDragenter" @dragover="handleDragover"></div>
      <RightOperatePanel
        ref="RightOperatePanelRef"
        :metaToolConfig="operateConfig"
        @currentMetaToolChange="handleCMTChange"
        :panelPosition="$attrs.panelPosition"
      />
    </div>
  </div>
</template>

<script>
// import Toolbar from './Toolbar.vue'
import GojsDiagramToolbar from './gojs/toolbar/GojsDiagramToolbar.vue'
import RightOperatePanel from './RightOperatePanel.vue'
import './gojs/plugin/Figures.js'
import { isFunction, mergeObj, uuid } from '@/utils/commonUtil.js'
import { baseConfig, categoryShapeList, nodeCategory, poolCategory } from './config'
import { defaultNodeTemplateMaker, defaultLinkTemplateMaker, poolTemplateMaker, drawTextNodeMaker, drawLinkNodeMaker } from './gojs/template/template.js'
import { isMap, isObject, isString } from '@/utils/commonUtil'
import { LinkShiftingTool } from '@/utils/LinkShiftingTool'

import * as go from 'gojs'
const $ = go.GraphObject.make

export default {
  name: 'BasicGraphDiagram',
  props: {
    diagramConfig: {
      type: Object,
      default: () => {},
    },
    metaToolConfig: {
      type: Array,
      default: () => [],
    },
    diagramData: {
      type: Object,
      default: () => {
        return {
          nodeData: [],
          linkData: [],
        }
      },
    },
  },
  data() {
    return {
      diagram: null,
      activeMetaTool: null,
    }
  },
  computed: {
    operateConfig() {
      return this.handleOperateConfig()
    },
    finallyConfig() {
      return mergeObj(baseConfig, this.diagramConfig)
    },
    activeNode() {
      return this.diagram?.selection.first()
    },
    selection() {
      return this.diagram?.selection
    },
  },
  mounted() {
    this.setGraphDiagramHeight()
    this.initDiagram()
  },
  methods: {
    handleValueChange({ code, value }) {
      this.$emit('valueChange', { code, value })
    },
    // 头部菜单点击
    handleItemClick({ code }) {
      switch (code) {
        case 'save':
          this.saveDiagramData()
          break
        case 'refresh':
          this.refreshDiagram()
          break
        case 'copy':
          this.refreshDiagram()
          break
        case 'paste':
          this.refreshDiagram()
          break
        case 'cut':
          this.refreshDiagram()
          break
        case 'delete':
          this.deleteSelection()
          break
        case 'clearAll':
          this.refreshDiagram()
          break
        case 'undo':
          this.refreshDiagram()
          break
        case 'redo':
          this.refreshDiagram()
          break
        default:
          console.warn('不支持的code: ' + code)
      }
      this.$emit('itemClick', { code })
    },
    handleLayerChange(layer) {
      this.$emit('layerChange', layer)
    },
    handleLayoutChange(layoutType) {
      this.$emit('layoutChange', layoutType)
    },
    handleExportData(data) {
      this.$emit('exportData', data)
    },
    handleImportXml(xmlData) {
      this.$emit('importXml', xmlData)
    },
    initDiagram() {
      const diagram = $(go.Diagram, this.$refs.diagramRef, {
        allowMove: true,
        allowLink: false,
        allowRelink: true,
        initialContentAlignment: go.Spot.Center,
        mouseDragOver: (e) => {
          // console.log(e, '=++++-+++--=-=_+-+++++++++++++')
        },
        click: (inputEvent) => {
          this.diagramClick(inputEvent)
        },
        contextClick: () => {
          // 清空工具栏选中状态
          this.$refs.RightOperatePanelRef?.handleToolClick()
        },
        mouseDrop: (e) => {},
        linkDrawn: (linkDrawnEvent) => {
          if (this.finallyConfig.linkDrawnAfterHook && isFunction(this.finallyConfig.linkDrawnAfterHook)) {
            let linkData = null
            const { subject, diagram } = linkDrawnEvent
            const linkFromKeyProperty = diagram.model.linkFromKeyProperty
            const linkToKeyProperty = diagram.model.linkToKeyProperty
            linkDrawnEvent.diagram.model.removeLinkData(subject.data)
            const fromNode = diagram.findNodeForKey(subject.data[linkFromKeyProperty])
            const toNode = diagram.findNodeForKey(subject.data[linkToKeyProperty])
            linkData = this.finallyConfig.linkDrawnAfterHook(fromNode, toNode, linkDrawnEvent, this.activeMetaTool, this.finallyConfig)
            if (!linkData) {
              console.warn('linkDrawnAfterHook 函数返回的连线数据为空')
            } else {
              diagram.startTransaction('addLink')
              diagram.model.addLinkData(linkData)
              diagram.commitTransaction('addLink')
            }
          }
        },
        'commandHandler.copiesGroupKey': true,
        'animationManager.isEnabled': false,
        'undoManager.isEnabled': true, //ctrl-z, ctrl-y 撤销和恢复上一步 移动 复制 删除
      })
      // 泳道节点模板
      const poolTemplate = poolTemplateMaker(this.finallyConfig)
      diagram.groupTemplateMap.add(poolCategory, poolTemplate)

      // 默认节点类型
      diagram.nodeTemplate = defaultNodeTemplateMaker(this.finallyConfig)
      diagram.nodeTemplateMap.add(nodeCategory.TEXT_NODE, drawTextNodeMaker())
      diagram.nodeTemplateMap.add(nodeCategory.LINE_NODE, drawLinkNodeMaker())
      diagram.linkTemplate = defaultLinkTemplateMaker(this.finallyConfig)
      if (this.finallyConfig.initDiagramAfterHook && isFunction(this.finallyConfig.initDiagramAfterHook)) {
        // 外部初始化画布
        this.finallyConfig.initDiagramAfterHook(diagram)
      }
      diagram.model = new go.GraphLinksModel({
        nodeCategoryProperty: this.finallyConfig.nodeCategoryProperty,
        nodeKeyProperty: this.finallyConfig.nodeKeyProperty,
        linkFromKeyProperty: this.finallyConfig.linkFromKeyProperty,
        linkToKeyProperty: this.finallyConfig.linkToKeyProperty,
      })
      // 连线可在节点周围拖动依赖
      diagram.toolManager.mouseDownTools.add($(LinkShiftingTool))
      this.diagram = diagram
      window.diagram = diagram
    },
    // 更新画布数据
    loadDiagramData(diagramData) {
      if (this.diagram) {
        this.diagram.model = new go.GraphLinksModel({
          nodeCategoryProperty: this.finallyConfig.nodeCategoryProperty,
          nodeKeyProperty: this.finallyConfig.nodeKeyProperty,
          linkFromKeyProperty: this.finallyConfig.linkFromKeyProperty,
          linkToKeyProperty: this.finallyConfig.linkToKeyProperty,
          nodeDataArray: [...diagramData.nodeData],
          linkDataArray: [...diagramData.linkData],
        })
      }
    },
    deleteSelection() {
      if (this.diagram.commandHandler.canDeleteSelection()) {
        this.diagram.commandHandler.deleteSelection()
      }
    },
    // 保存画布数据
    saveDiagramData() {
      console.log(this.diagram.model.nodeDataArray, '*********')
      this.$emit('saveDiagram', this.diagram.model.nodeDataArray, this.diagram.model.linkDataArray)
    },
    refreshDiagram() {
      this.$emit('refreshDiagram')
    },
    // 画布点击创建节点
    diagramClick(inputEvent) {
      if (this.activeMetaTool === null) return console.log('当前选择的系统元素为null')
      if (this.isLine()) {
        console.warn('当前线类型不支持点击添加')
      } else {
        const { documentPoint } = inputEvent
        const graphObject = this.diagram.findObjectAt(documentPoint, function (x) {
          return x.part
        })
        const belongToGroup = graphObject && graphObject instanceof go.Group ? graphObject : null
        if (this.isQuoteCreateElement(this.activeMetaTool)) {
          this.$emit('showQuoteDialog', { documentPoint, metaData: this.activeMetaTool, belongToGroup }, this.diagram)
          return
        }
        this.addPart(documentPoint, this.activeMetaTool, graphObject && graphObject instanceof go.Group ? graphObject : null)
      }
    },
    // 拖拽创建节点
    handleDrop() {
      if (this.isLine()) return
      const documentPoint = this.diagram.transformViewToDoc(new go.Point(event.offsetX, event.offsetY))
      const graphObject = this.diagram.findObjectAt(documentPoint, function (x) {
        return x.part
      })
      const belongToGroup = graphObject && graphObject instanceof go.Group ? graphObject : null
      // 引用节点
      if (this.isQuoteCreateElement(this.activeMetaTool)) {
        this.$emit('showQuoteDialog', { documentPoint, metaData: this.activeMetaTool, belongToGroup }, this.diagram)
        return
      }
      this.addPart(documentPoint, this.activeMetaTool, graphObject && graphObject instanceof go.Group ? graphObject : null)
    },
    // 添加节点
    addPart(documentPoint, metaData, belongToGroup) {
      const uuidStr = uuid()
      const partData = {
        [this.finallyConfig.nodeKeyProperty]: uuidStr,
        ...metaData.goJsProperty,
        loc: `${documentPoint.x} ${documentPoint.y}`,
        isGroup: metaData.isGroup,
        objData: {
          [this.finallyConfig.nodeTextKey]: metaData.goJsProperty[this.finallyConfig.nodeTextKey],
          [this.finallyConfig.nodeKeyProperty]: uuidStr,
        },
      }
      if (this.finallyConfig.addPartBeforeHook && isFunction(this.finallyConfig.addPartBeforeHook)) {
        this.finallyConfig.addPartBeforeHook(partData, belongToGroup, this.diagram)
      }
      // 设置层级
      let nodes = this.diagram.model.nodeDataArray
      let zOrders = nodes.map((item) => item.zOrder)
      partData.zOrder = isNaN(_.max(zOrders)) ? 0 : _.max(zOrders) + 1
      // 节点添加进泳道设置节点与泳道关联
      if (belongToGroup && belongToGroup instanceof go.Group) {
        partData.group = belongToGroup.data.statusId
      }
      this.diagram.model.addNodeData(partData)
      // console.log(partData, 'addPart----------')
      this.$emit('add', partData)
    },
    // 处理右侧工具栏的形状 默认显示绘图元素所有形状
    handleOperateConfig() {
      if (this.metaToolConfig.length > 0) {
        return this.metaToolConfig.map((ele) => {
          // 根据goJsProperty中_code匹配工具栏中对应形状
          ele.category = ele.category.map((item) => {
            const categoryItem = categoryShapeList.find((tool) => tool.goJsProperty._code === item.goJsProperty?._code)
            if (categoryItem) {
              const itemData = {
                ...categoryItem,
                ...item,
                goJsProperty: {
                  ...categoryItem.goJsProperty,
                  ...item.goJsProperty,
                  [categoryItem.goJsProperty._category === 'link' ? this.finallyConfig.linkTextKey : this.finallyConfig.nodeTextKey]:
                    categoryItem.goJsProperty._category === 'link'
                      ? categoryItem[this.finallyConfig.linkTextKey] || categoryItem.toolName || item.toolName
                      : categoryItem[this.finallyConfig.nodeTextKey] || categoryItem.toolName || item.toolName,
                },
                icon: { ...categoryItem.icon, ...item.icon },
              }
              item = itemData
            }
            return item
          })
          return ele
        })
      } else {
        return [
          {
            title: '绘图元素',
            colSpan: 12,
            category: [...categoryShapeList],
          },
        ]
      }
    },
    // 设置画布容器的高度
    setGraphDiagramHeight(headerHeight) {
      this.$refs.diagramWrapRef.style.height =
        this.$refs.graphDesignRef.offsetHeight - (headerHeight ? headerHeight : this.$refs.ToolbarRef.$el.offsetHeight) + 'px'
    },
    handleDragenter(ev) {
      ev.preventDefault()
    },
    handleDragover(ev) {
      ev.preventDefault()
    },
    // 选中工具栏元素
    handleCMTChange(metaTool) {
      this.activeMetaTool = metaTool
      if (this.isLine()) {
        this.diagram.allowLink = true
        this.diagram.allowReLink = true
      } else {
        this.diagram.allowLink = false
        this.diagram.allowReLink = false
      }
      this.setNodeResizable()
    },
    // 更新节点属性
    onUpdateNodeOrLinkData(data) {
      for (const key in data) {
        this.updateNodeOrLinkProperty(this.diagram, this.selection, key, data[key])
      }
    },
    updateNodeOrLinkProperty(diagram, nodeOrLink, attr, value) {
      if (!nodeOrLink) return
      diagram.model.startTransaction('updateProperty')
      try {
        if (isMap(attr)) {
          attr.forEach((value, key) => {
            updateOne(key, value)
          })
        } else if (isObject(attr)) {
          Object.keys(attr).forEach((key) => updateOne(key, attr[key]))
        } else if (isString(attr)) {
          updateOne(attr, value)
        }
        diagram.model.commitTransaction('updateProperty')
      } catch (e) {
        console.error('更新属性失败', e)
        diagram.model.rollbackTransaction()
      }

      function updateOne(key, value) {
        if (nodeOrLink instanceof go.Node || nodeOrLink instanceof go.Link) {
          diagram.model.setDataProperty(nodeOrLink.data, key, value)
        } else if (nodeOrLink.each) {
          nodeOrLink.each((item) => {
            diagram.model.setDataProperty(item.data, key, value)
          })
        } else if (isObject(nodeOrLink)) {
          diagram.model.setDataProperty(nodeOrLink, key, value)
        }
      }
    },
    // 判断线
    isLine() {
      return this.activeMetaTool?.goJsProperty.figure === 'line'
    },
    // 判断引用节点
    isQuoteCreateElement(metaData) {
      return metaData?.quoteCreate === '1'
    },
    setNodeResizable() {
      // 选择线时节点不可拉伸
      this.diagram.nodes.each((node) => {
        this.diagram.model.setDataProperty(node, 'resizable', this.isLine() ? false : true)
      })
      // 设置节点是否移动
      this.diagram.allowMove = this.isLine() ? false : true
    },
  },
  components: { GojsDiagramToolbar, RightOperatePanel },
  watch: {
    diagramData: {
      handler: function () {
        this.loadDiagramData(this.diagramData)
      },
      immediate: true,
    },
    activeNode() {
      this.setNodeResizable()
      this.$emit('selectNode', this.activeNode?.data || null)
    },
  },
}
</script>

<style lang="less" scoped>
.graph-design {
  width: 100%;
  height: 100%;
  .diagram-wrap {
    width: 100%;
    height: 100%;
    position: relative;
    .graph-diagram {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
