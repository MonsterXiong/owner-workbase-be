import * as go from 'gojs'
const $ = go.GraphObject.make

const defaultLinkTemplateMaker = function (finallyConfig) {
  return $(
    go.Link, // the whole link panel
    {
      routing: go.Link[finallyConfig.linkRouting],
      corner: 0,
      fromEndSegmentLength: 10,
      toEndSegmentLength: 10,
      relinkableFrom: true,
      relinkableTo: true,
      reshapable: true,
      resegmentable: true,
      cursor: 'pointer',
    },
    new go.Binding('points').makeTwoWay(),
    new go.Binding('fromSpot', 'fromSpot', function (value) {
      if (!value) {
        return go.Spot.None
      }
      if (Object.prototype.toString.call(value) === '[object Object]') {
        return value
      }
      return go.Spot.parse(value)
    }).makeTwoWay(go.Spot.stringify),
    new go.Binding('toSpot', 'toSpot', function (value) {
      if (!value) {
        return go.Spot.None
      }
      if (Object.prototype.toString.call(value) === '[object Object]') {
        return value
      }
      return go.Spot.parse(value)
    }).makeTwoWay(go.Spot.stringify),
    $(
      go.Shape,
      {
        strokeWidth: 1.5,
        stroke: '#7f7f7f',
      },
      new go.Binding('strokeDashArray', 'dash', function (strokeDashArray) {
        if (!strokeDashArray || strokeDashArray.length != 2) {
          return [0, 0]
        }
        return strokeDashArray
      })
    ),
    $(
      go.Shape, // the arrowhead
      {
        toArrow: 'OpenTriangle',
        fill: null,
      }
    ),
    $(
      go.TextBlock,
      {
        font: '400 9pt Source Sans Pro, sans-serif',
        segmentIndex: 0,
        segmentOffset: new go.Point(NaN, NaN),
        isMultiline: false,
        editable: true,
      },
      new go.Binding('text', finallyConfig.linkTextKey).makeTwoWay(),
      new go.Binding('stroke', 'lineColor').makeTwoWay(),
      new go.Binding('visible', 'textVisible')
    )
  )
}

export { defaultLinkTemplateMaker }
