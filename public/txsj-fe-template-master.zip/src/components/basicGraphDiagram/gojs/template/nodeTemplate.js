import * as go from 'gojs'
const $ = go.GraphObject.make

const defaultNodeTemplateMaker = (finallyConfig) => {
  return $(
    go.Node,
    'Auto',
    {
      locationSpot: go.Spot.Center,
      copyable: false,
      resizable: true,
      desiredSize: new go.Size(50, 50),
      cursor: 'pointer',
    },
    new go.Binding('location', 'loc', go.Point.parse).makeTwoWay(go.Point.stringify),
    new go.Binding('desiredSize', 'size', go.Size.parse).makeTwoWay(go.Size.stringify),
    new go.Binding('resizable', 'resizable'),
    $(
      go.Shape,
      'RoundedRectangle',
      {
        name: 'SHAPE',
        portId: '',
        // fromLinkableDuplicates: true,
        // toLinkableDuplicates: true,
        cursor: 'pointer',
        fromSpot: go.Spot.AllSides,
        toSpot: go.Spot.AllSides,
        strokeWidth: 1,
        fromLinkable: true,
        toLinkable: true,
        stroke: '#027db4',
        fill: 'transparent',
      },
      new go.Binding('figure', 'figure'),
      new go.Binding('stroke', 'stroke'),
      new go.Binding('fill', 'fill')
    ),
    $(
      go.Shape,
      {
        strokeWidth: 0,
        fill: 'transparent',
      },
      new go.Binding('desiredSize', 'size', (size) => {
        // 给节点留出20px的连线触发区域
        // 取消双向绑定，防止数值过小时大小不正确
        const realSize = size
          .split(' ')
          .map((value) => Number(value) - 20)
          .join(' ')
        return go.Size.parse(realSize)
      })
    ),
    $(
      go.TextBlock,
      { margin: new go.Margin(4, 4), editable: false },
      new go.Binding('text', finallyConfig.nodeTextKey),
      new go.Binding('stroke', 'fontColor'),
      new go.Binding('visible', 'textVisible')
    ),
    new go.Binding('zOrder')
  )
}

/**
 * 文本节点
 */
export function drawTextNodeMaker(option) {
  return $(
    go.Node,
    'Auto',
    {
      locationSpot: go.Spot.Center,
      resizable: true,
      resizeCellSize: new go.Size(1, 1),
      rotatable: true,
      resizeObjectName: 'BODY',
      locationObjectName: 'BODY',
      selectionObjectName: 'SHAPE',
      cursor: 'pointer',
    },
    new go.Binding('location', 'loc', go.Point.parse).makeTwoWay(go.Point.stringify),
    // new go.Binding(bindingKey.ANGLE).makeTwoWay(),
    $(
      go.TextBlock,
      {
        margin: new go.Margin(8, 8, 8, 8),
        textAlign: 'center',
        font: 'normal normal normal 14px sans-serif', // normal small-caps(小写转成大写) normal 14px sans-serif
        verticalAlignment: go.Spot.Center,
        isMultiline: true,
        editable: true,
        textEdited: function (textBlock, oldString, newString) {
          textBlock.part.data.objData.objectName = newString
        },
        name: 'drawTextNode',
        text: '文本信息',
        // stroke: 'red',
      },
      new go.Binding('stroke', 'stroke')
    )
  )
}

export function drawLinkNodeMaker(option) {
  return $(
    go.Node,
    'Auto',
    {
      locationSpot: go.Spot.Center,
      resizable: true,
      resizeCellSize: new go.Size(1, 1),
      rotatable: true,
      resizeObjectName: 'BODY',
      locationObjectName: 'BODY',
      selectionObjectName: 'SHAPE',
      cursor: 'pointer',
    },
    new go.Binding('location', 'loc', go.Point.parse).makeTwoWay(go.Point.stringify),
    new go.Binding('desiredSize', 'size', go.Size.parse).makeTwoWay(go.Size.stringify),
    $(
      go.Shape,
      'LineH',
      {
        name: 'SHAPE',
        portId: '',
        cursor: 'pointer',
        strokeWidth: 1,
        stroke: '#027db4',
        fill: 'transparent',
      },
      new go.Binding('figure', 'figure'),
      new go.Binding('stroke', 'stroke'),
      new go.Binding('fill', 'fill')
    )
  )
}

export { defaultNodeTemplateMaker }
