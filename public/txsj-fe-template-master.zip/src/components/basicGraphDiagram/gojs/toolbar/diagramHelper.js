import * as go from 'gojs'
import { isMap, isObject, isString } from '@/utils/commonUtil'
import isUndefined from 'lodash/isUndefined'
export const layerOptionType = Object.freeze({
  UP: 'up',
  DOWN: 'down',
  TOP: 'top',
  BOTTOM: 'bottom',
})
export const layoutOptionType = Object.freeze({
  TOP: 'top',
  BOTTOM: 'bottom',
  LEFT: 'left',
  RIGHT: 'right',
  HCENTER: 'hCenter',
  VCENTER: 'vCenter',
  TREE: 'tree',
  SAMEWIDTH: 'sameWidth',
  SAMEHEIGHT: 'sameHeight',
  VSAMEGAP: 'vSameGap',
  HSAMEGAP: 'hSameGap',
})

function getFontSize(fontStr) {
  if (!fontStr) {
    return 12
  }
  const reg = /(\d*)px.*/
  const match = fontStr.match(reg)
  if (match && match[1]) {
    return match[1]
  }
  return 12
}

function updateNodeOrLinkProperty(diagram, nodeOrLink, attr, value) {
  if (!nodeOrLink) return
  diagram.model.startTransaction('updateProperty')
  try {
    if (isMap(attr)) {
      attr.forEach((value, key) => {
        updateOne(key, value)
      })
    } else if (isObject(attr)) {
      Object.keys(attr).forEach((key) => updateOne(key, attr[key]))
    } else if (isString(attr)) {
      updateOne(attr, value)
    }
    diagram.model.commitTransaction('updateProperty')
  } catch (e) {
    console.error('更新属性失败', e)
    diagram.model.rollbackTransaction()
  }

  function updateOne(key, value) {
    if (nodeOrLink instanceof go.Node || nodeOrLink instanceof go.Link) {
      diagram.model.setDataProperty(nodeOrLink.data, key, value)
    } else if (nodeOrLink.each) {
      nodeOrLink.each((item) => {
        diagram.model.setDataProperty(item.data, key, value)
      })
    } else if (isObject(nodeOrLink)) {
      diagram.model.setDataProperty(nodeOrLink, key, value)
    }
  }
}

class ToolbarHelper {
  constructor(diagram) {
    this.diagram = diagram
    this.findPartTextObject = () => ''
  }
  handleValueChange({ code, value }) {
    const fontKey = ['italic', 'bolder', 'fontSizePlus', 'fontSizeMinus', 'fontSize', 'fontFamily']
    const selection = this.diagram.selection
    const firstNode = this.diagram.selection.first()
    const textBlock = this.findPartTextObject(firstNode)
    const fontStr = textBlock.font
    if (fontKey.includes(code)) {
      let fontSize = getFontSize(fontStr)
      fontSize = parseInt(fontSize)
      if (code === 'fontSizePlus') {
        fontSize = fontSize + 1
        updateNodeOrLinkProperty(this.diagram, selection, 'fontSize', fontSize)
      } else if (code === 'fontSizeMinus') {
        fontSize = fontSize - 1
        updateNodeOrLinkProperty(this.diagram, selection, 'fontSize', fontSize)
      } else if (code === 'fontSize') {
        updateNodeOrLinkProperty(this.diagram, selection, 'fontSize', value)
      } else if (code === 'italic') {
        const boolean = Boolean(firstNode.data['italic'])
        updateNodeOrLinkProperty(this.diagram, selection, 'fontSize', fontSize)
        updateNodeOrLinkProperty(this.diagram, this.diagram.selection, code, !boolean)
      } else if (code === 'bolder') {
        const boolean = Boolean(firstNode.data['bolder'])
        updateNodeOrLinkProperty(this.diagram, selection, 'fontSize', fontSize)
        updateNodeOrLinkProperty(this.diagram, this.diagram.selection, code, !boolean)
      } else if (code === 'fontFamily') {
        updateNodeOrLinkProperty(this.diagram, selection, 'fontFamily', value)
      }
      this.setFont()
    } else {
      if (isUndefined(value)) {
        const boolean = Boolean(firstNode.data[code])
        updateNodeOrLinkProperty(this.diagram, this.diagram.selection, code, !boolean)
      } else {
        updateNodeOrLinkProperty(this.diagram, this.diagram.selection, code, value)
      }
    }
  }
  copySelection() {
    if (this.diagram.commandHandler.canCopySelection()) {
      this.diagram.commandHandler.copySelection()
    }
  }
  pasteSelection() {
    if (this.diagram.commandHandler.canPasteSelection()) {
      this.diagram.commandHandler.pasteSelection()
    }
  }
  cutSelection() {
    if (this.diagram.commandHandler.canCutSelection()) {
      this.diagram.commandHandler.cutSelection()
    }
  }
  deleteSelection() {
    if (this.diagram.commandHandler.canDeleteSelection()) {
      this.diagram.commandHandler.deleteSelection()
    }
  }
  clearAll() {
    if (this.diagram.commandHandler.canSelectAll()) {
      this.diagram.commandHandler.selectAll()
      this.diagram.commandHandler.deleteSelection()
    }
  }
  undoAction() {
    if (this.diagram.commandHandler.canUndo()) {
      this.diagram.commandHandler.undo()
    }
  }
  redoAction() {
    if (this.diagram.commandHandler.canUndo()) {
      this.diagram.commandHandler.redo()
    }
  }
  changeLayer(activeNode, type) {
    switch (type) {
      case layerOptionType.TOP:
        this.diagram.commandHandler.pullToFront()
        break
      case layerOptionType.UP:
      case layerOptionType.DOWN: {
        let intersectNodes = this.diagram.findObjectsIn(
          activeNode.getDocumentBounds(),
          (graphObject) => {
            return graphObject.part instanceof go.Node ? graphObject.part : null
          },
          (node) => {
            return node
          },
          false
        )

        let zOrders = []
        intersectNodes.each((node) => {
          if (node !== activeNode) {
            zOrders.push(node.data.zOrder)
          }
        })
        zOrders.sort()
        if (type === layerOptionType.UP) {
          zOrders = zOrders.filter((item) => item > activeNode.data.zOrder)
          this.diagram.model.setDataProperty(activeNode.data, 'zOrder', zOrders.length > 0 ? zOrders[zOrders.length - 1] + 1 : activeNode.data.zOrder + 1)
        } else {
          zOrders = zOrders.filter((item) => item < activeNode.data.zOrder)
          this.diagram.model.setDataProperty(activeNode.data, 'zOrder', zOrders.length > 0 ? zOrders[zOrders.length - 1] - 1 : activeNode.data.zOrder - 1)
        }
        break
      }
      case layerOptionType.BOTTOM:
        this.diagram.commandHandler.pushToBack()
        break
    }
  }
  changeLayout(type) {
    const cmd = this.diagram.commandHandler
    switch (type) {
      case layoutOptionType.TOP:
        cmd.alignTop()
        break
      case layoutOptionType.BOTTOM:
        cmd.alignBottom()
        break
      case layoutOptionType.LEFT:
        cmd.alignLeft()
        break
      case layoutOptionType.RIGHT:
        cmd.alignRight()
        break
      case layoutOptionType.VCENTER:
        cmd.alignCenterY()
        break
      case layoutOptionType.HCENTER:
        cmd.alignCenterX()
        break
      case layoutOptionType.SAMEHEIGHT:
        cmd.sameHeight()
        break
      case layoutOptionType.SAMEWIDTH:
        cmd.sameWidth()
        break
      case layoutOptionType.VSAMEGAP:
        cmd.sameGapY()
        break
      case layoutOptionType.HSAMEGAP:
        cmd.sameGapX()
        break
    }
  }
  registerFindPartTextObjectFn(fn) {
    this.findPartTextObject = fn
  }
  setFont(variant = false) {
    const firstNode = this.diagram.selection.first()
    const data = firstNode.data
    let isCase = null
    if (variant) {
      isCase = data.font ? data.font.indexOf('small-caps') === -1 : data.case
    }
    const newFontStr = `${data.italic ? 'italic' : 'normal'} normal ${data.bolder ? 'bolder' : 'normal'} ${parseInt(data.fontSize || 10)}px ${
      data.fontFamily ? data.fontFamily : '黑体'
    }`
    updateNodeOrLinkProperty(this.diagram, this.diagram.selection, 'font', newFontStr)
  }
  genStyleJson(data, isNode = true) {
    const styleJSON = {}
    const commonStyleKey = ['textStroke', 'font', 'visible', 'stroke', 'strokeWidth', 'fill', 'strokeDashArray', 'textVisible']
    const nodeStyleKey = ['isUnderline', 'isStrikethrough', 'figure', 'size', 'loc', ...commonStyleKey]
    const linkStyleKey = [
      'points',
      'toArrow',
      'fromArrow',
      'curve',
      'routing',
      'fromSpot',
      'toSpot',
      'segmentOffset',
      'fromEndSegmentLength',
      'toEndSegmentLength',
      ...commonStyleKey,
    ]
    const styleKey = isNode ? nodeStyleKey : linkStyleKey
    Object.keys(data).forEach((key) => {
      if (styleKey.includes(key)) {
        if (key === 'points') {
          let points = []
          if (data[key] && data[key].toArray) {
            points = data[key]?.toArray()
          } else {
            points = data[key]
          }
          styleJSON[key] = points
        } else if (key === 'routing') {
          styleJSON[key] = typeof data[key] === 'object' ? data[key]?.name : data[key]
        } else if (key === 'curve') {
          styleJSON[key] = typeof data[key] === 'object' ? data[key]?.name : data[key]
        } else {
          styleJSON[key] = data[key]
        }
      }
    })
    return JSON.stringify(styleJSON)
  }
}

export { ToolbarHelper, getFontSize, updateNodeOrLinkProperty }
