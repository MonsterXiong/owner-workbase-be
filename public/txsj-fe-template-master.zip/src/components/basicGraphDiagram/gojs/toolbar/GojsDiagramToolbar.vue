<template>
  <div class="style-bar">
    <ul @click.stop>
      <slot name="left"></slot>
      <template>
        <li @click="onBarClick({ code: 'save' })" v-if="optionVisible.saveVisible">
          <span>
            <BaseIcon iconName="icon-save" />
            <span class="style-bar-text">保存</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'refresh' })" v-if="optionVisible.refreshVisible">
          <span>
            <BaseIcon iconName="icon-refresh" />
            <span class="style-bar-text">刷新</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'copy' })" v-if="optionVisible.copyVisible">
          <span>
            <BaseIcon iconName="icon-copy" />
            <span class="style-bar-text">复制</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'paste' })" v-if="optionVisible.pasteVisible">
          <span>
            <BaseIcon iconName="icon-paste" />
            <span class="style-bar-text">粘贴</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'cut' })" v-if="optionVisible.cutVisible">
          <span>
            <BaseIcon iconName="icon-cut" />
            <span class="style-bar-text">剪切</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'delete' })" v-if="optionVisible.deleteVisible">
          <span>
            <BaseIcon iconName="icon-delete" />
            <span class="style-bar-text">删除</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'clearAll' })" v-if="optionVisible.clearAllVisible">
          <span>
            <BaseIcon iconName="icon-clear" />
            <span class="style-bar-text">清空所有</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'undo' })" v-if="optionVisible.undoVisible">
          <span>
            <BaseIcon iconName="icon-back" />
            <span class="style-bar-text">撤消</span>
          </span>
        </li>
        <li @click="onBarClick({ code: 'redo' })" v-if="optionVisible.redoVisible">
          <span>
            <BaseIcon iconName="icon-redo" />
            <span class="style-bar-text">重做</span>
          </span>
        </li>
      </template>

      <li style="position: relative" @click="showLineStylePanel" v-if="optionVisible.lineStyleVisible">
        <span>
          <BaseIcon iconName="icon-line-color" />
          <span class="line-color-bar" :style="{ backgroundColor: lineColor }"></span>
          <span class="style-bar-text">线条</span>
          <BaseIcon iconName="icon-dropdown" />
        </span>
        <div class="line-style" v-show="blockState.isShowLineBlock" v-click-outside="hideLineBlock">
          <colorPicker
            style="left: -111px; top: -36px"
            ref="lineColorPicker"
            v-model="lineColor"
            v-on:change="handleLineColorChange"
            class="color-picker-nonbottom"
          >
          </colorPicker>
          <el-menu
            style="top: 274px"
            :background-color="themeCode === 'netsinBlue' ? '#0b2952' : '#fff'"
            :text-color="themeCode === 'netsinBlue' ? '#fff' : '#333'"
            active-text-color=""
            :collapse="true"
          >
            <el-submenu :index="item.text" :key="item.text" v-for="item in lineOptions">
              <div class="title" slot="title">
                <div>
                  <BaseIcon :icon-name="item.iconName" />
                  <div style="margin-left: 10px">{{ item.text }}</div>
                </div>
                <BaseIcon icon-name="icon-right-arrow" />
              </div>
              <el-menu-item @click="handleLineItemClick(subItem)" :key="subItem.text" v-for="subItem in item.children">
                <div style="text-align: center">
                  <img v-if="subItem.imgUrl" :src="subItem.imgUrl" />
                  <span v-if="subItem.text">{{ subItem.text }}</span>
                </div>
              </el-menu-item>
            </el-submenu>
          </el-menu>
        </div>
      </li>

      <li style="position: relative" @click="showTextStylePanel" v-if="optionVisible.textStyleVisible">
        <span>
          <BaseIcon iconName="icon-text" />
          <span class="style-bar-text">文本</span>
        </span>
        <div class="drop-down-panel text-setting-block drop-down-panel-bg" v-if="blockState.isShowTextSettingBlock" v-click-outside="hideTextSettingBlock">
          <div v-for="item in textOptions" :key="item.code" :class="item.className" class="text-option">
            <template v-if="item.type === 'select'">
              <template v-if="item.code === 'fontFamily'">
                <el-select v-model="fontFamily" size="mini" style="width: 90%" placeholder="" @change="handleFontFamilyChange">
                  <el-option v-for="option in item.options" :key="option" :label="option" :value="option"> </el-option>
                </el-select>
              </template>
              <template v-if="item.code === 'fontSize'">
                <el-select v-model="fontSize" size="mini" style="width: 90%" placeholder="" @change="handleFontSizeChange">
                  <el-option v-for="option in item.options" :key="option" :label="option" :value="option"> </el-option>
                </el-select>
              </template>
            </template>
            <template v-else>
              <template v-if="item.code === 'fontColor'">
                <div style="position: relative" @click.stop="fontColorClickFn">
                  <BaseIcon icon-name="icon-font-color" />
                  <div class="font-color-bar" :style="{ backgroundColor: fontColor }"></div>
                </div>
              </template>
              <template v-else>
                <div @click.stop="handleTextShapeChange(item)">
                  <BaseIcon :icon-name="item.iconName" />
                </div>
              </template>
            </template>
          </div>
        </div>
        <colorPicker
          style="position: relative; top: 125px; left: -58px"
          ref="fontColorPicker"
          class="font-color"
          v-model="fontColor"
          v-on:change="fontColorChange"
        >
        </colorPicker>
      </li>

      <li style="position: relative" @click="showFillPanel" v-if="optionVisible.fillVisible">
        <span>
          <BaseIcon iconName="icon-fill-color" />
          <span class="fill-color-bar" :style="{ backgroundColor: fillColor }"></span>
          <span class="style-bar-text">填充</span>
          <BaseIcon iconName="icon-dropdown" />
        </span>
        <colorPicker
          style="position: relative; top: 20px; left: -66px"
          v-show="blockState.isShowFillColorBlock"
          v-click-outside="hideFillColorBlock"
          ref="fillColorPicker"
          v-model="fillColor"
          class="fill-color"
          @change="fillColorChange"
        />
      </li>

      <li style="position: relative" @click="showLayoutPanel" v-if="optionVisible.layoutVisible">
        <span>
          <BaseIcon iconName="icon-layout" />
          <span class="style-bar-text">排列</span>
        </span>
        <div v-if="blockState.isShowLayoutBlock" class="drop-down-panel layout-panel drop-down-panel-bg" v-click-outside="hideLayoutBlock">
          <ul>
            <li @click="changeLayoutFn(item.type)" :key="item.type" v-for="item in alignOptions">
              <div v-if="item.type != 'divider'">
                <BaseIcon :icon-name="item.iconName" />
                <span class="text">{{ item.text }}</span>
                <template v-if="item.hasDivider">
                  <el-divider></el-divider>
                </template>
              </div>
            </li>
          </ul>
        </div>
      </li>
      <li style="position: relative" @click="showLayerPanel" v-if="optionVisible.layerVisible">
        <span>
          <BaseIcon iconName="icon-layer" />
          <span class="style-bar-text">图层</span>
        </span>
        <div v-if="blockState.isShowLayerBlock" class="drop-down-panel layer-panel drop-down-panel-bg" v-click-outside="hideLayerBlock">
          <ul>
            <li @click="changeLayerFn(item.type)" :key="item.type" v-for="item in layerOptions">
              <BaseIcon :icon-name="item.iconName" />
              <span class="text">{{ item.text }}</span>
            </li>
          </ul>
        </div>
      </li>
      <li style="position: relative" @click="showImportPanel" v-if="optionVisible.importVisible">
        <span>
          <BaseIcon iconName="icon-import-export" />
          <span class="line-color-bar" :style="{ backgroundColor: lineColor }"></span>
          <span class="style-bar-text">导入/导出</span>
          <BaseIcon iconName="icon-dropdown" />
          <div v-if="blockState.isShowImportBlock" class="drop-down-panel import-panel drop-down-panel-bg" v-click-outside="hideImportExportBlock">
            <ul>
              <li @click="handleImportExportSelectChange(item.type)" :key="item.type" v-for="item in importOptions">
                <BaseIcon :icon-name="item.iconName" />
                <span class="text">{{ item.text }}</span>
              </li>
            </ul>
          </div>
        </span>
      </li>
      <slot></slot>
    </ul>
    <UploadDialog ref="uploadDrawModelRef" v-on:callBack="importXml" />
  </div>
</template>
<script>
import ColorPicker from './ToolbarColorPicker.vue'
import UploadDialog from '@/components/upload/uploadDialog.vue'
import { barOptions, lineOptions, alignOptions, textOptions, layerOptions, importOptions } from './toolbarConfig.js'

export default {
  name: 'GojsDiagramToolbar',
  components: {
    ColorPicker,
    UploadDialog,
  },
  props: {
    diagram: {
      type: Object,
      default: () => {},
    },
    optionVisible: {
      type: Object,
      default: () => {
        return {}
      },
    },
  },
  data() {
    return {
      lineColor: '',
      fillColor: '',
      fontColor: 'black',
      fontFamily: 'sans-serif',
      fontSize: '13px',
      blockState: {
        isShowLineBlock: false,
        isShowTextSettingBlock: false,
        isShowFillColorBlock: false,
        isShowLayerBlock: false,
        isShowLayoutBlock: false,
        isShowImportBlock: false,
      },
      barOptions,
      lineOptions,
      alignOptions,
      textOptions,
      layerOptions,
      importOptions,
    }
  },
  async mounted() {},
  computed: {
    activeNode() {
      // TODO 会有同时选中多个的情况
      return this.diagram?.selection.first()
    },
    selection() {
      return this.diagram?.selection
    },
    themeCode() {
      return this.$store.getters['theme/getThemeCode']
    },
  },
  methods: {
    onBarClick(barItem) {
      this.$emit('itemClick', barItem)
    },
    handleLineItemClick(lineItem) {
      this.$emit('valueChange', lineItem)
    },
    handleLineColorChange(color) {
      this.$emit('valueChange', { value: color, code: 'stroke' })
    },
    // 字体大小改变
    handleFontSizeChange(value) {
      if (value === 'fontSizePlus') {
        this.fontSize = parseInt(this.fontSize) + 1 + 'px'
      } else if (value === 'fontSizeMinus') {
        this.fontSize = parseInt(this.fontSize) - 1 + 'px'
      } else {
        this.fontSize = parseInt(value) + 'px'
      }
      this.$emit('valueChange', { code: 'fontSize', value: this.fontSize })
    },
    handleFontFamilyChange(value) {
      this.$emit('valueChange', { code: 'fontFamily', value: value })
    },
    // 填充色改变
    fillColorChange() {
      this.$emit('valueChange', { value: this.fillColor, code: 'fill' })
    },
    // 字体改变
    fontFamilyChange(value) {
      this.$emit('valueChange', { value: this.fillColor, code: 'fontFamily' })
    },
    fontColorClickFn() {
      this.$refs.fontColorPicker.openPanel()
    },
    fontColorChange(value) {
      this.$emit('valueChange', { code: 'textStroke', value: value })
      this.$refs.fontColorPicker.closePanel()
    },
    handleTextShapeChange(item) {
      this.$emit('valueChange', { code: item.code })
    },
    changeLayerFn(type) {
      this.$emit('layerChange', type)
    },
    changeLayoutFn(type) {
      this.$emit('layoutChange', type)
    },
    handleImportExportSelectChange(value) {
      if (value == 'xml_import') {
        this.$refs.uploadDrawModelRef.show('xml_import')
      } else if (value === 'xml_export') {
        this.$emit('exportData', value)
      } else if (value === 'image_export') {
        this.$emit('exportData', value)
      }
    },
    async importXml(xmlData) {
      if (xmlData.length == 0) {
        this.$message('请先选择导入文件')
        return
      }
      this.$emit('importXml', xmlData)
    },
    getNodeAttrValue(attrName) {
      return this.activeNode?.data[attrName]
    },
    handleImageFill() {
      this.$refs.fillImageSelectRef.show()
    },

    // 点击文本，显示文本设置面板
    showTextStylePanel() {
      this.hideAllBlock()
      this.blockState.isShowTextSettingBlock = !this.blockState.isShowTextSettingBlock
    },
    // 点击布局(排列)
    showLayoutPanel() {
      this.hideAllBlock()
      this.blockState.isShowLayoutBlock = !this.blockState.isShowLayoutBlock
    },
    //  点击图层
    showLayerPanel() {
      this.hideAllBlock()
      this.blockState.isShowLayerBlock = !this.blockState.isShowLayerBlock
    },
    // 点击导入导出
    showImportPanel() {
      this.hideAllBlock()
      this.blockState.isShowImportBlock = !this.blockState.isShowImportBlock
    },
    // 点击线条，显示线条设置面板
    showLineStylePanel() {
      this.hideAllBlock()
      this.blockState.isShowLineBlock = true
      this.$refs.lineColorPicker.openPanel()
    },
    //  点击填充,显示填充面板
    showFillPanel() {
      this.hideAllBlock()
      this.blockState.isShowFillColorBlock = true
      this.$refs.fillColorPicker.openPanel()
    },

    hideLayoutBlock() {
      this.blockState.isShowLayoutBlock = false
    },
    hideLayerBlock() {
      this.blockState.isShowLayerBlock = false
    },
    hideImportExportBlock() {
      this.blockState.isShowImportBlock = false
    },
    hideTextSettingBlock() {
      this.blockState.isShowTextSettingBlock = false
      this.$refs.fontColorPicker.closePanel()
    },
    hideFillColorBlock() {
      this.blockState.isShowFillColorBlock = false
    },
    hideLineBlock() {
      this.blockState.isShowLineBlock = false
    },
    hideAllBlock() {
      Object.keys(this.blockState).forEach((key) => (this.blockState[key] = false))
    },
    getCommandHandler() {
      const cmd = this.diagram.commandHandler
      return cmd
    },
  },
  watch: {
    activeNode(newNode) {
      if (newNode) {
        this.fillColor = newNode.data.fillColor || ''
        this.lineColor = newNode.data.lineColor || ''
        this.fontColor = newNode.data.fontColor || ''
      } else {
        // 设置 文本 填充 线条... 为不可编辑
        this.fontColor = 'black'
      }
    },
  },
}
</script>

<style lang="less" scoped>
@input-border-color: var(--input-border-color, #dcdfe6);
@font-color-main: var(--font-color-main, #5e5e5e);

@media (min-width: 1653px) and (max-width: 3600px) {
  .style-bar {
    height: 50px;
  }
}
@media (min-width: 1000px) and (max-width: 1652px) {
  .style-bar {
    height: 100px;
  }
}
/deep/.colorPicker .box {
  width: 200px !important;
}
/deep/.color-picker-nonbottom .box {
  border-bottom: none !important;
}
.style-bar {
  position: relative;
  z-index: 999;
  display: flex;
  line-height: 50px;
  padding: 0 10px 0 0;
  border-bottom: 1px solid @input-border-color;
  color: @font-color-main;

  .toolbar-fold {
    height: 50px;
    line-height: 60px;
    width: 30px;
    padding-left: 5px;
    cursor: pointer;
  }
  ul {
    flex: 1;
    list-style: none;
    padding: 0;
    margin: 0;
    // overflow-x: auto;
    // height: 50px;
    > li {
      display: inline-block;
      text-align: center;
      padding: 0 10px;
      &:hover {
        cursor: pointer;
        background-color: @shadow-color-base;
      }
      &.disable {
        &:hover {
          cursor: not-allowed;
        }
        span {
          color: @input-font-disable-color;
        }
      }
      &.timesHover {
        &:hover {
          background-color: transparent;
        }
        /* 倍数 input输入样式调整 */
        /deep/ .el-input-number--mini {
          width: 87px;
          margin-left: 5px;
          .el-input-number__decrease,
          .el-input-number__increase {
            width: 16px;
            font-size: 12px;
          }
        }
        /deep/ .el-input-number--mini .el-input__inner {
          padding-left: 18px;
          padding-right: 18px;
        }
      }
      > span {
        .style-bar-text {
          margin-left: 4px;
          font-size: 14px;
        }
        .fill-color-bar,
        .line-color-bar {
          display: inline-block;
          width: 20px;
          background-color: @background-color-dark;
          height: 4px;
          position: absolute;
          top: 32px;
          left: 8px;
        }
      }
      .drop-down-panel {
        position: absolute;
        left: 0;
        width: 300px;
        padding: 0 2px;
        border: 1px solid @shadow-color-base;
        background-color: @background-color-base;
        box-shadow: 2px 2px 2px @shadow-color-base;
        z-index: 999;
        ul {
          li {
            height: 36px;
            line-height: 36px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            .text {
              margin-left: 10px;
            }
          }
        }
      }
      // 布局块
      .layout-panel {
        width: 150px;
        .el-divider--horizontal {
          margin: 0;
        }
      }
      // 图层块
      .layer-panel {
        width: 120px;
        padding: 0;
      }
      .import-panel {
        width: 140px;
        padding: 0;
      }
      /deep/ .m-colorPicker {
        position: static;
        .colorBtn {
          visibility: hidden;
          width: 0px;
          height: 0px;
        }
        .box {
          width: 200px;
          left: 0px;
          top: 50px;
          border-bottom: unset;
        }
      }
      .line-style {
        position: absolute;
        width: 222px;
        left: 0px;
        background-color: @background-color-base;
        /deep/ .el-menu {
          width: 100%;
          border: 1px solid @border-color-base;
          border-top: unset;
          .el-submenu,
          .el-menu-item {
            width: 100%;
            height: 36px !important;
            line-height: 36px !important;
            .el-submenu__title {
              height: 36px !important;
              line-height: 36px !important;
              .title {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 36px;
                line-height: 36px;
                > div {
                  display: flex;
                  align-items: center;
                }
                span {
                  height: 20px;
                  width: 20px;
                }
              }
            }
            .el-menu-item {
              height: 36px;
              line-height: 36px;
            }
            &:hover {
              background-color: unset;
            }
          }
        }
      }
      // 文本块
      .text-setting-block {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        grid-template-areas:
          'fontFamily fontFamily fontSize fontSize plusFontSize minusFontSize'
          'bolder italic underline middleline case fontColor'
          'topAlign centerVAlign bottomAlign left center right';
        max-height: 200px;
        max-width: 280px;
        overflow: hidden;
        .fontFamily {
          grid-area: fontFamily;
        }
        .fontSize {
          grid-area: fontSize;
        }
        .text-option:nth-child(n + 3) {
          &:hover {
            background-color: @shadow-color-base;
          }
        }
        .textShow {
          display: block;
        }
        .textHide {
          display: none;
        }
        .font-color-bar {
          position: absolute;
          width: 20px;
          height: 4px;
          left: 14px;
          bottom: 10px;
          background-color: @background-color-dark;
        }
        /deep/ .el-select {
          input {
            padding: 0 5px;
          }
        }
      }
    }
    /* .timesHover */
  }
}
::v-deep {
  .draw-model-select {
    width: 120px;
    // margin: 0 0 0 10px;
    display: inline-block;
    .el-input__inner {
      padding: 0 7px;
    }
  }
}
.el-menu-item,
.el-submenu {
  height: 36px !important;
  line-height: 36px !important;
}
</style>
