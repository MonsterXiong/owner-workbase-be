const barOptions = [
  { iconName: 'icon-save', text: '保存' },
  {
    iconName: 'icon-refresh',
    text: '刷新',
  },
  { iconName: 'icon-copy', text: '复制' },
  { iconName: 'icon-paste', text: '粘贴' },
  { iconName: 'icon-cut', text: '剪切' },
  {
    iconName: 'icon-delete',
    text: '删除',
  },
  { iconName: 'icon-clear', text: '清空所有' },
  { iconName: 'icon-back', text: '撤消' },
  { iconName: 'icon-redo', text: '重做' },
]
const lineOptions = [
  {
    iconName: 'icon-thickness',
    text: '粗细',
    children: [
      {
        imgUrl: require('./resource/diagram/strokeWidth/1.png'),
        value: 1,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/2.png'),
        value: 2,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/3.png'),
        value: 3,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/4.png'),
        value: 4,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/5.png'),
        value: 5,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/6.png'),
        value: 6,
        code: 'strokeWidth',
      },
      {
        imgUrl: require('./resource/diagram/strokeWidth/7.png'),
        value: 7,
        code: 'strokeWidth',
      },
    ],
  },
  {
    iconName: 'icon-dash',
    text: '虚线',
    children: [
      {
        imgUrl: require('./resource/diagram/line/0-0.png'),
        value: [0, 0],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/1-1.png'),
        value: [1, 1],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/2-1.png'),
        value: [2, 1],
        code: 'strokeDashArray',
      },

      {
        imgUrl: require('./resource/diagram/line/2-4.png'),
        value: [2, 4],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/3-1.png'),
        value: [3, 1],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/4-2.png'),
        value: [4, 2],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/5-2.png'),
        value: [5, 2],
        code: 'strokeDashArray',
      },
      {
        imgUrl: require('./resource/diagram/line/5-4.png'),
        value: [5, 4],
        code: 'strokeDashArray',
      },
    ],
  },
  {
    iconName: 'icon-arrow',
    text: '箭头',
    children: [
      {
        imgUrl: require('./resource/diagram/arrow/none.png'),
        value: '',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Standard.png'),
        value: 'Standard',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Triangle.png'),
        value: 'Triangle',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Boomerang.png'),
        value: 'Boomerang',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/OpenTriangle.png'),
        value: 'OpenTriangle',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/OpenTriangleLine.png'),
        value: 'OpenTriangleLine',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/ForwardSemiCircle.png'),
        value: 'ForwardSemiCircle',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Feather.png'),
        value: 'Feather',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/DoubleFeathers.png'),
        value: 'DoubleFeathers',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Fork.png'),
        value: 'Fork',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/LineFork.png'),
        value: 'LineFork',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Circle.png'),
        value: 'Circle',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Block.png'),
        value: 'Block',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/Diamond.png'),
        value: 'Diamond',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/NormalArrow.png'),
        value: 'NormalArrow',
        code: 'toArrow',
      },
      {
        imgUrl: require('./resource/diagram/arrow/RoundedTriangle.png'),
        value: 'RoundedTriangle',
        code: 'toArrow',
      },
    ],
  },
  {
    iconName: 'icon-line-shape',
    text: '线型',
    children: [
      {
        imgUrl: require('./resource/diagram/lineShape/Normal.png'),
        text: '直线',
        value: 'Normal',
        code: 'lineShape',
      },
      {
        imgUrl: require('./resource/diagram/lineShape/Orthogonal.png'),
        text: '直角',
        value: 'Orthogonal',
        code: 'lineShape',
      },
      {
        imgUrl: require('./resource/diagram/lineShape/Bezier.png'),
        text: '曲线',
        value: 'Bezier',
        code: 'lineShape',
      },
    ],
  },
]
const alignOptions = [
  { iconName: 'icon-layout-top', text: '顶部对齐', type: 'top' },
  { iconName: 'icon-layout-bottom', text: '底部对齐', type: 'bottom' },
  { iconName: 'icon-layout-left', text: '左对齐', type: 'left' },
  { iconName: 'icon-layout-right', text: '右对齐', type: 'right' },
  { iconName: 'icon-layout-h-center', text: '垂直对齐', type: 'hCenter' },
  {
    iconName: 'icon-layout-v-center',
    text: '水平对齐',
    type: 'vCenter',
    hasDivider: true,
  },
  { iconName: 'icon-layout-tree', text: '垂直树形布局', type: 'tree' },
  {
    iconName: 'icon-layout-htree',
    text: '水平树形布局',
    type: 'hTree',
    hasDivider: true,
  },
  {
    iconName: 'icon-layout-ltree',
    text: '层次树形布局',
    type: 'lTree',
    hasDivider: true,
  },
  {
    iconName: 'icon-layout-same-height',
    text: '等高',
    type: 'sameHeight',
  },
  {
    iconName: 'icon-layout-same-width',
    text: '等宽',
    type: 'sameWidth',
  },
  {
    iconName: 'icon-layout-v-same-gap',
    text: '垂直等间距',
    type: 'vSameGap',
  },
  {
    iconName: 'icon-layout-h-same-gap',
    text: '水平等间距',
    type: 'hSameGap',
  },
]
const layerOptions = [
  { iconName: 'icon-layer-top', text: '置于顶层', type: 'top' },
  { iconName: 'icon-layer-up', text: '上移一层', type: 'up' },
  { iconName: 'icon-layer-down', text: '下移一层', type: 'down' },
  { iconName: 'icon-layer-bottom', text: '置于底层', type: 'bottom' },
]
const textOptions = [
  {
    type: 'select',
    className: 'fontFamily',
    code: 'fontFamily',
    options: ['宋体', '黑体', 'sans-serif'],
  },
  {
    type: 'select',
    className: 'fontSize',
    code: 'fontSize',
    options: [
      10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
      48, 49, 50,
    ],
  },
  {
    iconName: 'icon-plus-fontsize',
    code: 'fontSizePlus',
    tip: '字体大小+1',
  },
  {
    iconName: 'icon-minus-fontsize',
    code: 'fontSizeMinus',
    tip: '字体大小-1',
  },
  {
    iconName: 'icon-bolder',
    code: 'bolder',
    tip: '是否加粗',
  },
  {
    iconName: 'icon-italic',
    code: 'italic',
    tip: '是否斜体',
  },
  {
    iconName: 'icon-underline',
    code: 'isUnderline',
    tip: '是否添加下划线',
  },
  {
    iconName: 'icon-middleline',
    code: 'isStrikethrough',
    tip: '是否添加中划线',
  },
  {
    iconName: 'icon-font-color',
    code: 'fontColor',
    tip: '字体颜色',
  },
]
const importOptions = [
  {
    iconName: 'icon-import',
    text: '导入xml文件',
    type: 'xml_import',
  },
  {
    iconName: 'icon-export',
    text: '导出xml文件',
    type: 'xml_export',
  },
  {
    iconName: 'icon-export-image',
    text: '导出图片',
    type: 'image_export',
  },
]

export { barOptions, lineOptions, alignOptions, layerOptions, textOptions, importOptions }
